package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaProductos {

	private DatosProducto producto;

	public DatosProducto getProducto() {
		return producto;
	}

	public void setProducto(DatosProducto producto) {
		this.producto = producto;
	}
	
}
