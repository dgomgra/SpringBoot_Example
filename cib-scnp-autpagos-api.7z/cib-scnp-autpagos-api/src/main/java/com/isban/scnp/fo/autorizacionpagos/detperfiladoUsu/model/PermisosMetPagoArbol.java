package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

import java.util.List;

public class PermisosMetPagoArbol {

	private int codigoSubProducto;
	private String codPermiso;
	private String necesitaCuenta;
	private String necesTipo;
	private List<ListaMetodosPagoArbol> listaMetodosPago;
	
	public int getCodigoSubProducto() {
		return codigoSubProducto;
	}
	public void setCodigoSubProducto(int codigoSubProducto) {
		this.codigoSubProducto = codigoSubProducto;
	}
	public String getCodPermiso() {
		return codPermiso;
	}
	public void setCodPermiso(String codPermiso) {
		this.codPermiso = codPermiso;
	}
	public String getNecesitaCuenta() {
		return necesitaCuenta;
	}
	public void setNecesitaCuenta(String necesitaCuenta) {
		this.necesitaCuenta = necesitaCuenta;
	}
	public String getNecesTipo() {
		return necesTipo;
	}
	public void setNecesTipo(String necesTipo) {
		this.necesTipo = necesTipo;
	}
	public List<ListaMetodosPagoArbol> getListaMetodosPago() {
		return listaMetodosPago;
	}
	public void setListaMetodosPago(List<ListaMetodosPagoArbol> listaMetodosPago) {
		this.listaMetodosPago = listaMetodosPago;
	}
		
	
}
