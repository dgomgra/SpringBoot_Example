/**
 * 
 */
/**
 * @author sgbosca
 *
 */
package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;