package com.isban.scnp.fo.autorizacionpagos.detallear.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.Importe;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ListaImportes;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.ConversionDivisaHelperService;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DatosArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DatosArchivoMapper;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARRequest;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARResponse;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleArchivoMapper;
import com.isban.scnp.fo.autorizacionpagos.detallear.service.DetalleARHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DetalleARHelperServiceImpl implements DetalleARHelperService {

	private static final String STR_VACIO = "";

	private static final String STR_MSG_OK = "OK";
		
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
	@Autowired
	private ConversionDivisaHelperService conversionDivisaHelperService;
	
	@Value("${schema_proc}")
    protected String schemaproc;

	public DetalleArchivo obtDetalleArchivo(Integer idArchivo, String usuario) {

		usuario = String.format("%1$-30s", usuario);
		String sql = "SELECT O9247_FEC_ARCH, O9247_ESTARCH, O9247_NOMARCHAUT, O9247_NUM_TRANS, O2760_ANOTAS AS MOTIVO_RECHAZO, G0657_TRADUC AS ESTADO_TRADUC " + 
				"FROM " + schemaproc + ".SGP_ARCH_REMOT " + 
				"LEFT JOIN " + schemaproc + ".SGP_USUARIO ON (H1186_UID= ?) " + 
				"LEFT JOIN " + schemaproc + ".SGP_R_NOTA_ARCH ON (O9257_IDARCH=O9247_IDARCH) LEFT JOIN " + schemaproc + ".SGP_NOTA ON (O2760_CODACTIV='RE' AND O2760_CDNOTA= O9257_CDNOTA) " + 
				"LEFT JOIN " + schemaproc + ".TXT_MULIDI_GRAL ON (G0657_CODTRADU='CT_COD_ESTADO_RA_GBMSGP ' AND G0657_IDENDATO=RPAD(O9247_ESTARCH,40,' ') AND G0657_IDIOMASC = H1186_IDIOMASC AND G0657_CODPAIS  = H1186_CODPAIS AND G0657_CONCEPCT = '001' AND G0657_INTIPTRA = '0') " + 
				"WHERE O9247_IDARCH = ? "; //idArchivo
		
		Object [] params = new Object [] {usuario, idArchivo};
		
		List<DetalleArchivo> resultadoQuery = jdbcTemplate.query(sql, params, new DetalleArchivoMapper());
		
		if (!resultadoQuery.isEmpty())
		{
			return resultadoQuery.get(0);
			
		}
		else
		{
			return null;
		}
	}
	
	public List<DatosArchivo> obtDatosArchivo (Integer idArchivo)
	{
		String sql = "SELECT O9248_CODPAIS, O9248_NUM_TRANS, O9248_IMPPAISMON, O9248_CODMONSWI " +
				"FROM " + schemaproc + ".SGP_ARCH_PAIMON " +
				"WHERE O9248_IDARCH = ?";
		
		Object [] params = new Object [] {idArchivo};
		
		return jdbcTemplate.query(sql, params, new DatosArchivoMapper());
	}
	
	public DetalleARResponse getDetalleARImpl (DetalleARRequest request)
	{
				
		// Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
		
		int idArchivo = request.getIdArchivo();
		
		DetalleArchivo detalle = obtDetalleArchivo(idArchivo, uidLogado);
		
		List<DatosArchivo> datosArchivo = obtDatosArchivo (idArchivo);

		procesarSalida(request.getTokenBks(), detalle, datosArchivo);
		
		DetalleARResponse detalleARResponse = new DetalleARResponse();			
		detalleARResponse.setDetalleArchivo(detalle);
		detalleARResponse.setListaDatosArchivo(datosArchivo);
		detalleARResponse.setStatus("OK");
		detalleARResponse.setMessage(STR_MSG_OK);
		return detalleARResponse;

	}

	private void procesarSalida(String tokenBks, DetalleArchivo detalle, List<DatosArchivo> listaDatosArchivo) {

		ConversionDivisaRequest entradaConvDivisa = new ConversionDivisaRequest ();		
		List<ListaImportes> listaGruposImportes = new ArrayList<ListaImportes>(0);
		
		ListaImportes listaImportes = new ListaImportes();
		int tamListaDatos = listaDatosArchivo.size();
		for (int i=0;i<tamListaDatos;i++)
		{
			BigDecimal bdImporte = listaDatosArchivo.get(i).getMonto();
			String divisa =listaDatosArchivo.get(i).getDivisa();
			ImporteType impTAnadir = new ImporteType (bdImporte, divisa);
			Importe impAnadir = new Importe(impTAnadir);
			
			listaImportes.addImporte(impAnadir);
		}
		listaGruposImportes.add(listaImportes);
		entradaConvDivisa.getRequestData().getConversionDivisa().getEntrada().setDivisaConsolidacion("EUR");
		entradaConvDivisa.getRequestData().getConversionDivisa().getEntrada().setListaGruposImportes(listaGruposImportes);
		entradaConvDivisa.setToken(tokenBks);
		
		ConversionDivisaResponse salidaConvDivisa = conversionDivisaHelperService.conversionDivisa(entradaConvDivisa);
		
		int tamSalida = salidaConvDivisa.getMethodResult().getListaImportes().size();
		if (tamSalida>0)
		{
			BigDecimal importeTotal = salidaConvDivisa.getMethodResult().getListaImportes().get(0).getIMPORTE();
			String divisa = salidaConvDivisa.getMethodResult().getListaImportes().get(0).getDIVISA();
			
			detalle.setMonto(importeTotal);
			detalle.setDivisa(divisa);
		}		
	}
}
