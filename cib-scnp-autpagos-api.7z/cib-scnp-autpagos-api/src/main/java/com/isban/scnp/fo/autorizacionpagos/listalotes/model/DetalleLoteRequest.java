package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

public class DetalleLoteRequest {
	
	private String numLote;
	private String tokenBks;

	public String getNumLote() {
		return numLote;
	}

	public void setNumLote(String numLote) {
		this.numLote = numLote;
	}

	public String getTokenBks() {
		return tokenBks;
	}

	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}	
}
