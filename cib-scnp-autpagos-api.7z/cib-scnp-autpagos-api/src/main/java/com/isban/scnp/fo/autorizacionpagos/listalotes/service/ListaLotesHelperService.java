package com.isban.scnp.fo.autorizacionpagos.listalotes.service;

import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesRequest;

public interface ListaLotesHelperService {
	public ListaLotesAutorizarResponse getListaLotesAutorizarByPage(ListaLotesRequest listaLotesRequest, boolean resumen);
	public DetalleLoteResponse getDetalleLoteImp(DetalleLoteRequest detalleLoteRequest);
}
