/**
 * 
 */
/**
 * @author sgbosca
 *
 */
package com.isban.scnp.fo.autorizacionpagos.autorizar.component;