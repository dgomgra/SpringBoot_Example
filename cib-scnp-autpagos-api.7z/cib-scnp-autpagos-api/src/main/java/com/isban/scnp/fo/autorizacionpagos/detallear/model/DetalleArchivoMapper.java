package com.isban.scnp.fo.autorizacionpagos.detallear.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DetalleArchivoMapper implements RowMapper<DetalleArchivo> {

	@Override
	public DetalleArchivo mapRow(ResultSet rs, int rowNum) throws SQLException {

		DetalleArchivo datos = new DetalleArchivo();
		datos.setFecha(rs.getDate("O9247_FEC_ARCH"));
		datos.setEstadoArchivo(rs.getString("O9247_ESTARCH"));
		datos.setNombre(rs.getString("O9247_NOMARCHAUT"));
		datos.setNumTransac(rs.getInt("O9247_NUM_TRANS"));
		datos.setMotivoRechazo(rs.getString("MOTIVO_RECHAZO"));
		datos.setDescEstado(rs.getString("ESTADO_TRADUC"));		
		return datos;
	}

}
