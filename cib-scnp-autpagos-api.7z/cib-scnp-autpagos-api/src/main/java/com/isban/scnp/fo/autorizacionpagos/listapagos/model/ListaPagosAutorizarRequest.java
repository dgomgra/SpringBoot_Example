package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

public class ListaPagosAutorizarRequest {

	private int numPorPagina;
	private int numPagina;
	private String idLote;
	private String pais;
	private String tokenBks;
	
	public int getNumPorPagina() {
		return numPorPagina;
	}
	public void setNumPorPagina(int numPorPagina) {
		this.numPorPagina = numPorPagina;
	}
	public int getNumPagina() {
		return numPagina;
	}
	public void setNumPagina(int numPagina) {
		this.numPagina = numPagina;
	}
	public String getIdLote() {
		return idLote;
	}
	public void setIdLote(String idLote) {
		this.idLote = idLote;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}
	
}
