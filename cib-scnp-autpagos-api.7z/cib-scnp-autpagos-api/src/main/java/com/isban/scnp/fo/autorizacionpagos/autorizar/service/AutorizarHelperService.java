package com.isban.scnp.fo.autorizacionpagos.autorizar.service;

import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdLoteNombre;

public interface AutorizarHelperService {
	public AutorizarResponse autorizarImpl (AutorizarRequest autorizarRequest);
	public List obtenerListaNombres (String tipo, List<String> listaIds);
}
