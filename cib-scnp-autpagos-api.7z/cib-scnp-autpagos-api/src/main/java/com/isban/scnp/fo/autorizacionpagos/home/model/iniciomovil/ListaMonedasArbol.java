
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class ListaMonedasArbol {

    private MonedaArbol monedaArbol;
    
    public MonedaArbol getMonedaArbol() {
        return monedaArbol;
    }

    public void setMonedaArbol(MonedaArbol monedaArbol) {
        this.monedaArbol = monedaArbol;
    }

}
