package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaServiciosAR {

	private ServicioPaisAR servicio;

	public ServicioPaisAR getServicio() {
		return servicio;
	}

	public void setServicio(ServicioPaisAR servicio) {
		this.servicio = servicio;
	}
	
}
