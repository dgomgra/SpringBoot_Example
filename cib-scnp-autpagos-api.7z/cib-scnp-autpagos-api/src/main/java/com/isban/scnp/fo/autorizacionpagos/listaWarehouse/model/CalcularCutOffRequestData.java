package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class CalcularCutOffRequestData {
	private CalcularCutOffIn calcularCutOff;

	
	public CalcularCutOffRequestData() {
		super();
		calcularCutOff=new CalcularCutOffIn();
	}

	public CalcularCutOffIn getCalcularCutOff() {
		return calcularCutOff;
	}

	public void setCalcularCutOff(CalcularCutOffIn calcularCutOff) {
		this.calcularCutOff = calcularCutOff;
	}
	
	
}
