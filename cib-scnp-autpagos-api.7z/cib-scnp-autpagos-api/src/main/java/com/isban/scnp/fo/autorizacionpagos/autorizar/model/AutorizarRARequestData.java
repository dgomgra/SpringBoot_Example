package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarRARequestData {
	private AutorizarRAIn autorizarRA;

	public AutorizarRARequestData() {
		super();
		this.setAutorizarRA(new AutorizarRAIn());
	}

	public AutorizarRAIn getAutorizarRA() {
		return autorizarRA;
	}

	public void setAutorizarRA(AutorizarRAIn autorizarRA) {
		this.autorizarRA = autorizarRA;
	}
	
}
