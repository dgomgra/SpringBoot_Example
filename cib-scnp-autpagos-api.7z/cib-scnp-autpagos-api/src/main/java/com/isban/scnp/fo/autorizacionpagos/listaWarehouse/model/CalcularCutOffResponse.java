package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CalcularCutOffResponse {
	private List<CalcularCutOff_S >methodResult;

	public List<CalcularCutOff_S> getMethodResult() {
		return methodResult;
	}

	public void setMethodResult(List<CalcularCutOff_S> methodResult) {
		this.methodResult = methodResult;
	}
}
