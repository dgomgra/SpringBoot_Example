package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;

public class ArchivoAR implements Comparable<ArchivoAR>{

	private int idArchivo;
	private Date fecha;
	private String estado;
	private String descripcionEstado;
	private String nombre;
	private int numTransacciones;
	private BigDecimal importe;
	private String divisa;
	
	public int getIdArchivo() {
		return idArchivo;
	}
	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}
	
	@JsonSerialize(using = DateSerializer.class)
	public Date getFecha() {
		return new Date (fecha.getTime());
	}
	public void setFecha(Date fecha) {
		this.fecha = new Date (fecha.getTime());
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDescripcionEstado() {
		return descripcionEstado;
	}
	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNumTransacciones() {
		return numTransacciones;
	}
	public void setNumTransacciones(int numTransacciones) {
		this.numTransacciones = numTransacciones;
	}
	
	@JsonSerialize(using = AmountSerializer.class)
	public BigDecimal getImporte() {
		return importe;
	}
	
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	
	public String getDivisa() {
		return divisa;
	}
	
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	
	@Override
	public int compareTo(ArchivoAR o) {
		return o.getFecha().compareTo(getFecha());
	}
	
	@Override
	public boolean equals(Object o) {
		boolean retorno=false;

		if (o != null && this.getClass()==o.getClass())
		{
			ArchivoAR dl = (ArchivoAR) o ;
			retorno = getIdArchivo() == (dl.getIdArchivo());
		}
		return retorno;
	}
	
	@Override
	public int hashCode() 
	{
		 return getIdArchivo();
	}
}
