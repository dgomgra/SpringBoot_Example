package com.isban.scnp.fo.autorizacionpagos.home.service;

import com.isban.scnp.fo.autorizacionpagos.home.model.HomeRequest;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeResponseData;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.InicioMovilResponse;

public interface HomeHelperService {

	/**
	 * 	Operacion principal de la pantalla de Home.
	 *	Se llama a la operacion que tenemos expuesta de balances en BKS para el movil, y devolvemos toda la información que nos devuelva. 
	 *	Se consulta tambien otros metodos expuestos para devolver :
	 *	Total de pagos, lotes, pagos warehouse y archivos de autorizacion remota pendientes de autorizar.
	 *
	 *  @param token 
	 *
	 */
	public HomeResponseData getHome (HomeRequest request);

	/**
	 * 	Operacion interna que llama a la operacion expuesta inicioMovil de balances de BKS
	 * 
	 * 	@return InicioMovilResponse
	 */
	public InicioMovilResponse getBalancesMovil(String token, String monConsolidacion);

}
