package com.isban.scnp.fo.autorizacionpagos.home.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.home.model.HomeRequest;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeResponseData;
import com.isban.scnp.fo.autorizacionpagos.home.service.HomeHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "HomeRestController", description = "Operations pertaining to Home Operation")
public class HomeRestController {
	
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_OPERATION_NAME = "Home";
	private static final String STR_ERROR = "error";
	private static final String STR_KO = "KO";
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";
	
	@Autowired
	private HomeHelperService homeHelperService;
	
	@PostMapping(value = "/v1/datosHome", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Home operation")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	public ResponseEntity<HomeResponseData> getHome(@RequestBody HomeRequest homeRequest){
		try
		{
			log.debug("REST POST call received in /v1/datosHome {} {}",
					homeRequest.getMonConsolidacion(),
					homeRequest.getTokenBks()
					);

			HomeResponseData homeResponseData = homeHelperService.getHome(homeRequest);
			return new ResponseEntity<>(homeResponseData, HttpStatus.OK);
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_OPERATION_NAME + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			HomeResponseData respuesta = new HomeResponseData();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {
				respuesta.setInicioMovil(null);
				respuesta.setCantidadPagos(0);
				respuesta.setCantidadLotes(0);
				respuesta.setCandidadWarehouse(0);
				respuesta.setcantidadArchivosR(0);
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(respuesta, HttpStatus.UNAUTHORIZED);
			}else {
				respuesta.setInicioMovil(null);
				respuesta.setCantidadPagos(0);
				respuesta.setCantidadLotes(0);
				respuesta.setCandidadWarehouse(0);
				respuesta.setcantidadArchivosR(0);
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
			}			
		}catch(Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_OPERATION_NAME + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			HomeResponseData respuesta = new HomeResponseData();
			respuesta.setInicioMovil(null);
			respuesta.setCantidadPagos(0);
			respuesta.setCantidadLotes(0);
			respuesta.setCandidadWarehouse(0);
			respuesta.setcantidadArchivosR(0);
			respuesta.setStatus(STR_KO);
			respuesta.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
}
