package com.isban.scnp.fo.autorizacionpagos.datosFirma.service;


import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaArchOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaLotesOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaRequest;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaResponse;

public interface DatosFirmaHelperService {
	
	// Metodo del controller
	public DatosFirmaResponse getDatosFirma(DatosFirmaRequest datosFirmaRequest);
	
	// Consulta SQL
	public String getDatosFirmaPagos(List<String> listaIds);
	public DatosFirmaLotesOut getDatosFirmaLotes(List<String> listaIds);
	public DatosFirmaArchOut getDatosFirmaArch(List<String> listaIds);
	public String getPaisPago(String idPago);
}
