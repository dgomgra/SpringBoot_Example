package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.math.BigDecimal;
import java.util.Date;

public class DatosPagoDeLoteW {
	
	private String idPago;
	private String estPago;
	private String medPago;
	private int codEnt;
	private int cuenta;
	private String codExtracto;
	private BigDecimal montoPago;
	private String divisa;
	private String indStopPayment;
	private Date fecValPago;
	
	public String getIdPago() {
		return idPago;
	}
	public void setIdPago(String idPago) {
		this.idPago = idPago;
	}
	public String getEstPago() {
		return estPago;
	}
	public void setEstPago(String estPago) {
		this.estPago = estPago;
	}
	public String getMedPago() {
		return medPago;
	}
	public void setMedPago(String medPago) {
		this.medPago = medPago;
	}
	public int getCodEnt() {
		return codEnt;
	}
	public void setCodEnt(int codEnt) {
		this.codEnt = codEnt;
	}
	public int getCuenta() {
		return cuenta;
	}
	public void setCuenta(int cuenta) {
		this.cuenta = cuenta;
	}
	public String getCodExtracto() {
		return codExtracto;
	}
	public void setCodExtracto(String codExtracto) {
		this.codExtracto = codExtracto;
	}
	public BigDecimal getMontoPago() {
		return montoPago;
	}
	public void setMontoPago(BigDecimal montoPago) {
		this.montoPago = montoPago;
	}
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	public String getIndStopPayment() {
		return indStopPayment;
	}
	public void setIndStopPayment(String indStopPayment) {
		this.indStopPayment = indStopPayment;
	}
	public Date getFecValPago() {
		return fecValPago;
	}
	public void setFecValPago(Date fecValPago) {
		this.fecValPago = fecValPago;
	}
}
