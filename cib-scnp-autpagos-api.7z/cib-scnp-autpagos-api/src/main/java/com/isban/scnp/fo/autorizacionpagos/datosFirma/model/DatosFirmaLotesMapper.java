package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosFirmaLotesMapper implements RowMapper<DatosFirmaLotesOut>{
	
	@Override
	public DatosFirmaLotesOut mapRow(ResultSet rs, int row) throws SQLException {
		DatosFirmaLotesOut datosFirmaLotesOut = new DatosFirmaLotesOut();
		datosFirmaLotesOut.setImporte(rs.getBigDecimal("O2046_IMPLOTE2"));
		datosFirmaLotesOut.setNumPagos(rs.getInt("O2046_TOTPAGOS"));
		
		return datosFirmaLotesOut;
	}
}
