package com.isban.scnp.fo.autorizacionpagos.common.model;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;

public class DateSerializer extends JsonSerializer<Date>{
	
	@Autowired
	private AppContext appContext;

	@Override
	public void serialize(Date value, JsonGenerator gen, SerializerProvider serializers)
			throws IOException{
		
		String format = appContext.getUserData().getFormatoFecha();
		gen.writeString(new SimpleDateFormat(format).format(value));
	
	}

}
