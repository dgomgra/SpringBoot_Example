package com.isban.scnp.fo.autorizacionpagos.common.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class TraducCodErrorMapper implements RowMapper<String>{

	@Override
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		return rs.getString("G0658_TRADUC").trim();
	}
}
