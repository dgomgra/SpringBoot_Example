package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

public class ConversionDivisaRequest {

	private static final String STR_VACIO = "";
	private String token;
	private ConversionDivisaRequestData requestData;
	
	public ConversionDivisaRequest ()
	{
		super();
		this.token=STR_VACIO;
		this.requestData=new ConversionDivisaRequestData ();
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public ConversionDivisaRequestData getRequestData() {
		return requestData;
	}

	public void setRequestData(ConversionDivisaRequestData requestData) {
		this.requestData = requestData;
	}	
}
