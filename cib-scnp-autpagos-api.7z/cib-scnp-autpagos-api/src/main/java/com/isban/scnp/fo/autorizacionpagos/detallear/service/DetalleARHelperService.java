package com.isban.scnp.fo.autorizacionpagos.detallear.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARRequest;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARResponse;

public interface DetalleARHelperService {
	public DetalleARResponse getDetalleARImpl (@RequestBody DetalleARRequest request);
}
