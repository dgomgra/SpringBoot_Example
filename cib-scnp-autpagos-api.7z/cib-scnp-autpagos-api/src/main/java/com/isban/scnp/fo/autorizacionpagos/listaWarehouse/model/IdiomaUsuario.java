package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class IdiomaUsuario {
	private String idioma;
	private String pais;
	
	public IdiomaUsuario(String idioma, String pais) {
		super();
		this.setIdioma(idioma);
		this.setPais(pais);
	}	
	public IdiomaUsuario() {
		super();
	}
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
}
