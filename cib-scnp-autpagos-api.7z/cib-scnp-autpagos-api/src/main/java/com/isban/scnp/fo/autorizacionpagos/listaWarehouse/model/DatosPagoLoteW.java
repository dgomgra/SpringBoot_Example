package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.math.BigDecimal;
import java.util.Date;

public class DatosPagoLoteW {
	
	private String lote;
	private String idEstado;
	private String nombreLote;
	private String codPais;
	private String moneda;
	
	private BigDecimal monto;	
	private	Date fecha;

	private int totalPagos;
	private String indBulk;
	private String indSalarios;

	private String indImp;
	private String indUpl;
	private String indNota;
	private String indCbl;
	
	private int tamEliminables;
	private String indEli;
	private String estado;
	
	private int numPagosAutRech;
	private BigDecimal montoAcre;
	private String divAcre;
	
	private DatosPagoDeLoteW datosPagoDeLote;
	
	public String getLote() {
		return lote;
	}
	public void setLote(String lote) {
		this.lote = lote;
	}
	public String getIdEstado() {
		return idEstado;
	}
	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}
	public String getNombreLote() {
		return nombreLote;
	}
	public void setNombreLote(String nombreLote) {
		this.nombreLote = nombreLote;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public BigDecimal getMonto() {
		return monto;
	}
	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public int getTotalPagos() {
		return totalPagos;
	}
	public void setTotalPagos(int totalPagos) {
		this.totalPagos = totalPagos;
	}
	public String getIndBulk() {
		return indBulk;
	}
	public void setIndBulk(String indBulk) {
		this.indBulk = indBulk;
	}
	public String getIndSalarios() {
		return indSalarios;
	}
	public void setIndSalarios(String indSalarios) {
		this.indSalarios = indSalarios;
	}
	public String getIndImp() {
		return indImp;
	}
	public void setIndImp(String indImp) {
		this.indImp = indImp;
	}
	public String getIndUpl() {
		return indUpl;
	}
	public void setIndUpl(String indUpl) {
		this.indUpl = indUpl;
	}
	public String getIndNota() {
		return indNota;
	}
	public void setIndNota(String indNota) {
		this.indNota = indNota;
	}
	public String getIndCbl() {
		return indCbl;
	}
	public void setIndCbl(String indCbl) {
		this.indCbl = indCbl;
	}
	public int getTamEliminables() {
		return tamEliminables;
	}
	public void setTamEliminables(int tamEliminables) {
		this.tamEliminables = tamEliminables;
	}
	public String getIndEli() {
		return indEli;
	}
	public void setIndEli(String indEli) {
		this.indEli = indEli;
	}	
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public int getNumPagosAutRech() {
		return numPagosAutRech;
	}
	public void setNumPagosAutRech(int numPagosAutRech) {
		this.numPagosAutRech = numPagosAutRech;
	}
	public BigDecimal getMontoAcre() {
		return montoAcre;
	}
	public void setMontoAcre(BigDecimal montoAcre) {
		this.montoAcre = montoAcre;
	}
	public String getDivAcre() {
		return divAcre;
	}
	public void setDivAcre(String divAcre) {
		this.divAcre = divAcre;
	}
	public DatosPagoDeLoteW getDatosPagoDeLote() {
		return datosPagoDeLote;
	}
	public void setDatosPagoDeLote(DatosPagoDeLoteW datosPagoDeLote) {
		this.datosPagoDeLote = datosPagoDeLote;
	}	
}
