package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;

public class DatosPagoWarehousing implements Comparable<DatosPagoWarehousing>{
	
	private String rftrans;
	private String indNota;
	private String ultimaNota;
	private String  indImp;
	private String idEstado;
	private String codExtracto;
	private String nomBenef;
	private int codBeneficiario;
	private int idAutorizacion;
	private BigDecimal importe;
	private String divisa;
	private Date fecha;
	private String refCliente;
	private String indicadorUpload;
	private String codPais;
	private String codMedioPago;
	private String descEstPago;
	private int cuentaOrdenante;
	private String aliasCuentaOrdenante;
	private String indStopPayment;
	
	public String getRftrans() {
		return rftrans;
	}
	public void setRftrans(String rftrans) {
		this.rftrans = rftrans;
	}
	public String getIndNota() {
		return indNota;
	}
	public void setIndNota(String indNota) {
		this.indNota = indNota;
	}
	public String getIndImp() {
		return indImp;
	}
	public void setIndImp(String indImp) {
		this.indImp = indImp;
	}
	public String getIdEstado() {
		return idEstado;
	}
	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}
	public String getCodExtracto() {
		return codExtracto;
	}
	public void setCodExtracto(String codExtracto) {
		this.codExtracto = codExtracto;
	}
	public String getNomBenef() {
		return nomBenef;
	}
	public void setNomBenef(String nomBenef) {
		this.nomBenef = nomBenef;
	}	
	public int getCodBeneficiario() {
		return codBeneficiario;
	}
	public void setCodBeneficiario(int codBeneficiario) {
		this.codBeneficiario = codBeneficiario;
	}
	public int getIdAutorizacion() {
		return idAutorizacion;
	}
	public void setIdAutorizacion(int idAutorizacion) {
		this.idAutorizacion = idAutorizacion;
	}
	@JsonSerialize(using = AmountSerializer.class)
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	@JsonSerialize(using = DateSerializer.class)
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getRefCliente() {
		return refCliente;
	}
	public void setRefCliente(String refCliente) {
		this.refCliente = refCliente;
	}
	public String getIndicadorUpload() {
		return indicadorUpload;
	}
	public void setIndicadorUpload(String indicadorUpload) {
		this.indicadorUpload = indicadorUpload;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getCodMedioPago() {
		return codMedioPago;
	}
	public void setCodMedioPago(String codMedioPago) {
		this.codMedioPago = codMedioPago;
	}
	public String getDescEstPago() {
		return descEstPago;
	}
	public void setDescEstPago(String descEstPago) {
		this.descEstPago = descEstPago;
	}
	public int getCuentaOrdenante() {
		return cuentaOrdenante;
	}
	public void setCuentaOrdenante(int cuentaOrdenante) {
		this.cuentaOrdenante = cuentaOrdenante;
	}
	public String getUltimaNota() {
		return ultimaNota;
	}
	public void setUltimaNota(String ultimaNota) {
		this.ultimaNota = ultimaNota;
	}
	public String getAliasCuentaOrdenante() {
		return aliasCuentaOrdenante;
	}
	public void setAliasCuentaOrdenante(String aliasCuentaOrdenante) {
		this.aliasCuentaOrdenante = aliasCuentaOrdenante;
	}
	public String getIndStopPayment() {
		return indStopPayment;
	}
	public void setIndStopPayment(String indStopPayment) {
		this.indStopPayment = indStopPayment;
	}
	@Override
	public int compareTo(DatosPagoWarehousing o) {
		int comparaFecha =   getFecha().compareTo(o.getFecha());
		if (comparaFecha==0)
		{
			return getRftrans().compareTo(o.getRftrans());
		}
		else
		{
			return comparaFecha;
		}
	}
	@Override
	public boolean equals(Object o) {
		boolean retorno=false;

		if (o != null && this.getClass()==o.getClass())
		{
			DatosPagoWarehousing dp = (DatosPagoWarehousing) o ;
			retorno = getRftrans().equals(dp.getRftrans());
		}
		return retorno;
	}
	@Override
	public int hashCode() 
	{
		 return getRftrans().hashCode();
	}
}
