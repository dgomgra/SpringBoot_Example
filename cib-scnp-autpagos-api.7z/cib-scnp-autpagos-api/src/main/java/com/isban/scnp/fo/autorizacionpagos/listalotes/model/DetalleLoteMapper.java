package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;



public class DetalleLoteMapper implements RowMapper<DetalleLoteOut>{

	@Override
	public DetalleLoteOut mapRow(ResultSet rs, int row) throws SQLException {
		DetalleLoteOut detalleLoteOut = new DetalleLoteOut();
		
		detalleLoteOut.setNumLote(rs.getString("O2046_NULOTE"));
		detalleLoteOut.setEstadoLote(rs.getString("O2046_ESTPAGO"));
		detalleLoteOut.setNombreLote(rs.getString("O2046_DESCRI50"));
		detalleLoteOut.setPais(rs.getString("O2046_CODPAIS"));
		detalleLoteOut.setDivisa(rs.getString("O2046_CODMONSWI"));
		detalleLoteOut.setMonto(rs.getBigDecimal("O2046_IMPLOTE2"));
		detalleLoteOut.setNumPagos(rs.getInt("O2046_TOTPAGOS"));
		detalleLoteOut.setFecha(rs.getDate("O2046_FECHALOT"));
		
		return detalleLoteOut;
	}
}
