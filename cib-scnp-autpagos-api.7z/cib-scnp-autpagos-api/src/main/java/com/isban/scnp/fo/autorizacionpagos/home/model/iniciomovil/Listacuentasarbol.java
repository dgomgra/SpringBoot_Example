
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class Listacuentasarbol {

    private CuentaArbol cuentaArbol;

    public CuentaArbol getCuentaArbol() {
        return cuentaArbol;
    }

    public void setCuentaArbol(CuentaArbol cuentaArbol) {
        this.cuentaArbol = cuentaArbol;
    }

}
