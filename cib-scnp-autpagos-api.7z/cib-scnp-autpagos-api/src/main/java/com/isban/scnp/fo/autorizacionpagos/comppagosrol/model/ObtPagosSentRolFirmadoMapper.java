package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ObtPagosSentRolFirmadoMapper implements RowMapper<ObtPagosSentRolFirmadoOut> {

	private static final String STR_O2787_IDAUTH = "O2787_IDAUTH";
	private static final String STR_O2787_CPOLSENTE = "O2787_CPOLSENTE";
	private static final String STR_O2787_RFTRANS = "O2787_RFTRANS";

	@Override
	public ObtPagosSentRolFirmadoOut mapRow(ResultSet rs, int row) throws SQLException {
		ObtPagosSentRolFirmadoOut obtPagosSentRolFirmadoOut = new ObtPagosSentRolFirmadoOut();
		obtPagosSentRolFirmadoOut.setRftrans(rs.getString(STR_O2787_RFTRANS));
		obtPagosSentRolFirmadoOut.setCodSentencia(rs.getInt(STR_O2787_CPOLSENTE));
		obtPagosSentRolFirmadoOut.setIdAutorizacion(rs.getInt(STR_O2787_IDAUTH));
		
		return obtPagosSentRolFirmadoOut;
	}

}
