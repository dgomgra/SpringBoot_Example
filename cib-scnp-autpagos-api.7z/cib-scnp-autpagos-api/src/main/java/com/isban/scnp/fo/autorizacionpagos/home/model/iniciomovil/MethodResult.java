
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class MethodResult {

    private String status;
    private Object message;
    private Object tipoMensaje;
    private Language language;
    private String pantalla;
    private DatosPantalla datosPantalla;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public Object getTipoMensaje() {
        return tipoMensaje;
    }

    public void setTipoMensaje(Object tipoMensaje) {
        this.tipoMensaje = tipoMensaje;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public String getPantalla() {
        return pantalla;
    }

    public void setPantalla(String pantalla) {
        this.pantalla = pantalla;
    }

    public DatosPantalla getDatosPantalla() {
        return datosPantalla;
    }

    public void setDatosPantalla(DatosPantalla datosPantalla) {
        this.datosPantalla = datosPantalla;
    }
}
