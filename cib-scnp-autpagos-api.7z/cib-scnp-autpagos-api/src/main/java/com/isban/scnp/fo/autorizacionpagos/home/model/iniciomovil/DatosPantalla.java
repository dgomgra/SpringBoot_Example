
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class DatosPantalla {

    private Saldos saldos;
    private InfoUsuario infoUsuario;
    
    public Saldos getSaldos() {
        return saldos;
    }

    public void setSaldos(Saldos saldos) {
        this.saldos = saldos;
    }

    public InfoUsuario getInfoUsuario() {
        return infoUsuario;
    }

    public void setInfoUsuario(InfoUsuario infoUsuario) {
        this.infoUsuario = infoUsuario;
    }

}
