package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT ,use = JsonTypeInfo.Id.NAME)
public class IdPagoNombreK {
	private IdPagoNombre idPagoNombre;

	public IdPagoNombreK() {
		super();
		this.setIdPagoNombre(new IdPagoNombre());
	}
	public IdPagoNombre getIdPagoNombre() {
		return idPagoNombre;
	}

	public void setIdPagoNombre(IdPagoNombre idPagoNombre) {
		this.idPagoNombre = idPagoNombre;
	}	
}
