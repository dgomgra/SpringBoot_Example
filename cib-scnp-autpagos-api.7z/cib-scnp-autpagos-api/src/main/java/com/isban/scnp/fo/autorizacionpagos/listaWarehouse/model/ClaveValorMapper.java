package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ClaveValorMapper implements RowMapper<ClaveValor> {

	@Override
	public ClaveValor mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		String clave = rs.getString(1);
		String valor = rs.getString(2);
		
		return new ClaveValor(clave, valor);
	}
}
