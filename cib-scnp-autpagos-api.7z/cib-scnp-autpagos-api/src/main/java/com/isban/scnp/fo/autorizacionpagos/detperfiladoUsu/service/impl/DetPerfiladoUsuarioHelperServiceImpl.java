package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.impl;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.DetPerfiladoUsuarioHelperService;

@Service
public class DetPerfiladoUsuarioHelperServiceImpl implements DetPerfiladoUsuarioHelperService {

	@Value("${urlBks}")
    protected String urlBks;
	
	@Autowired
	private ApiRestTemplate apiRestTemplate;
	
	public DetPerfiladoUsuarioResponse detPerfiladoUsuario(String token) {
		
        String urlInfoUsuarioIntradia = urlBks + "/json/F_GBMSGP_PortalPerfilado_E/1?authenticationType=token&requestData={\"detPerfiladoUsuario\": {\"entrada\":{\"usuario\":null}}}&token=" + token;
        URI uriInfoUsuarioIntradia = UriComponentsBuilder.fromUriString(urlInfoUsuarioIntradia).build().encode().toUri();
        RestTemplate restTemplatePost = apiRestTemplate.getRestTemplate();
        ResponseEntity<DetPerfiladoUsuarioResponse> response = restTemplatePost.exchange(uriInfoUsuarioIntradia, HttpMethod.GET, null, DetPerfiladoUsuarioResponse.class);
        return response.getBody();
	}

}
