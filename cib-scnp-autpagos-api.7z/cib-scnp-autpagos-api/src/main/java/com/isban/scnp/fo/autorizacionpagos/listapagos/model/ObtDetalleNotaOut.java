package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.sql.Timestamp;

public class ObtDetalleNotaOut {

	private int O2760_CDNOTA;
	private String O2760_ANOTAS;
	private Timestamp O2760_NOTES_TS;
	
	public int getO2765_CDNOTA() {
		return O2760_CDNOTA;
	}
	public void setO2765_CDNOTA(int o2760_CDNOTA) {
		O2760_CDNOTA = o2760_CDNOTA;
	}
	public String getO2760_ANOTAS() {
		return O2760_ANOTAS;
	}
	public void setO2760_ANOTAS(String o2760_ANOTAS) {
		O2760_ANOTAS = o2760_ANOTAS;
	}
	public Timestamp getO2760_NOTES_TS() {
		return O2760_NOTES_TS;
	}
	public void setO2760_NOTES_TS(Timestamp o2760_NOTES_TS) {
		O2760_NOTES_TS = o2760_NOTES_TS;
	}
}

