package com.isban.scnp.fo.autorizacionpagos.datosFirma.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaRequest;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaResponse;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.DatosFirmaHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * Servicio que informa los datos para firmar pagos, lotes o ficheros
 * 
 * @author Vector
 *
 */

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "DatosFirmaRestController")
public class DatosFirmaRestController {
	
	private static final String STR_KO = "KO";
	private static final String STR_ERROR = "error";
	private static final String STR_ESPACIO = " ";
	private static final String STR_DATOS_FIRMA = "Datos para la firma";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";
	
	@Autowired
	private DatosFirmaHelperService datosFirmaHelperService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
    	binder.setDisallowedFields("administrator");
	}
	
	/**
	 * Metodo rest que indica el numero de pagos y el importe que hay que indicar para la firma 
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/v1/datosParaFirma", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get data to sign")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request")}) 
	public ResponseEntity<DatosFirmaResponse> getDatosParaFirma(@RequestBody DatosFirmaRequest request){
		
		try {
			
			log.debug("REST POST call received in /v1/datosParaFirma ",
					request.getTipo(),
					request.getListaIds());
			
			DatosFirmaResponse datosFirmaResponse = datosFirmaHelperService.getDatosFirma(request);
			return new ResponseEntity<>(datosFirmaResponse, HttpStatus.OK);
			
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_DATOS_FIRMA + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			DatosFirmaResponse datosFirmaResponse = new DatosFirmaResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				datosFirmaResponse.setStatus(STR_KO);
				datosFirmaResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(datosFirmaResponse, HttpStatus.UNAUTHORIZED);
			}else {
				datosFirmaResponse.setStatus(STR_KO);
				datosFirmaResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(datosFirmaResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}			
		} catch (Exception e) {			
			log.error(STR_ERROR + STR_ESPACIO + STR_DATOS_FIRMA + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			DatosFirmaResponse datosFirmaResponse = new DatosFirmaResponse();
			datosFirmaResponse.setStatus(STR_KO);
			datosFirmaResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(datosFirmaResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
