package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import java.util.List;

public class DatosFirmaRequest {

	private String tipo;
	private List<String> listaIds;
	

	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public List<String> getListaIds() {
		return listaIds;
	}
	public void setListaIds(List<String> listaIds) {
		this.listaIds = listaIds;
	}
	
}
