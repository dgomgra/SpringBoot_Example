package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class ListaArchivosPendientesResponse {
	
	private String status;
	private String message;
	private List<ArchivoAR> listaArchivos;
	private List<String> listaDivisas;
	private int numFichTotales;
	private int numPaginaActual;
	
	public ListaArchivosPendientesResponse()
	{
		listaArchivos = new ArrayList<>();
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public List<ArchivoAR> getListaArchivos() {
		return listaArchivos;
	}
	
	public void setListaArchivos(List<ArchivoAR> listaArchivos) {
		this.listaArchivos = listaArchivos;
	}
	
	public int getNumFichTotales() {
		return numFichTotales;
	}
	
	public void setNumFichTotales(int numFichTotales) {
		this.numFichTotales = numFichTotales;
	}
	
	public int getNumPaginaActual() {
		return numPaginaActual;
	}
	
	public void setNumPaginaActual(int numPaginaActual) {
		this.numPaginaActual = numPaginaActual;
	}	
	
	public List<String> getListaDivisas() {
		return listaDivisas;
	}

	public void setListaDivisas(List<String> listaDivisas) {
		this.listaDivisas = listaDivisas;
	}

}
