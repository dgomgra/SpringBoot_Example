package com.isban.scnp.fo.autorizacionpagos.listaarchivos.service;

import java.util.List;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.GrupoPerfUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;

/**
 * 
 * Interfaz del servicio de listado de archivos pendientes de Autorizacion Remota
 * 
 * @author dagonzalez
 *
 */
public interface ListaArchivosPendientesHelperService {

	/** 
	 * 
	 * Operación principal via REST del listado de archivos pendientes de RA
	 * 
	 * 
	 * @param request (numPagina, numPorPagina, monConsolidacion, token)
	 * @param resumen (booleano) - para usar internamente desde el home devolviendo solo lo necesario para esta operacion
	 * @return response (status, message, listaArchivos, listaDivisas, numFichTotales, numPaginaActual)
	 * 
	 */
	public ListaArchivosPendientesResponse getListaArchivosPendientes (ListaArchivosARRequest request, boolean resumen);

	/**
	 * 
	 * Consulta SQL a la tabla SGP_USUARIO que nos devuelve el codigo de grupo empresarial de un usuario
	 * Filtrando por la situacion del usuario a Habilitado ('H')
	 * 
	 * @param uidToken - UID del usuario logado
	 * @return int con el codigo de grupo 
	 * 
	 */
	public int obtCodigoGrupoEmp(String uidToken);



	/**
	 * Consulta SQL a la tabla SGP_GRUPO_EMP que nos devuelve el indicador multi-pais del grupo empresarial
	 * 
	 * @param codigoGrupoEmpresarial
	 * @return String (N contieme multipais, S no contiene multipais)
	 */
	public String obtIndARMultiPais(int codigoGrupoEmpresarial);



	/**
	 * Consulta SQL a la tabla SGP_PERF_USU que nos devuelve el codigo de grupo e idauth del usuario
	 * Filtrado por el estado del usuario a H
	 * 
	 * 
	 * @param uid - UID del usuario logado
	 * @return GrupoPerfUsuarioOut - (codGrupoUsu, IDAuthUsu)
	 */
	public GrupoPerfUsuarioOut obtGrupoPerfUsuarioSQL(String uid);


	/**
	 * Consulta SQL a la tabla de SGP_R_AR_GUPAIS que obtiene los paises perfilados para un usuario
	 * 
	 * @param uid uid - UID del usuario logado
	 * @param idAuthUsu
	 * @return Lista de códigos ISO de los paises
	 */
	public List<String> obtPaisesARPerfUsuarioSQL(String uid, int idAuthUsu);


	/**	
	 * Consulta SQL a la tabla SGP_PERF_GRU que obtiene el idauth del usuario dentro del grupo
	 * 
	 * @param codGrupoUsu
	 * @return idAuthUsu
	 */
	public int obtIdauthPerfGrupUsuSQL(int codGrupoUsu);




	/**
	 * Consulta SQL a la tabla SGP_R_AR_GUPAIS que obtiene los paises perfilados para el grupo de usuarios
	 * 
	 * @param codGrupoUsu
	 * @param idAuthUsuGrupo
	 * @return Lista de códigos ISO de los paises
	 */
	public List<String> obtPaisesARPerfGrupUsuarioSQL(int codGrupoUsu, int idAuthUsuGrupo);

	/**
	 * Consulta SQL a las tablas SGP_ARCH_REMOT y SGP_ARCH_PAIMON que consultan los ficheros pendientes
	 * Filtrando por estado - E0 (Pendiente) - E1 (Parcial) - PP (Pendiente Politica)
	 * 		y    por los paises que
	 * 
	 * @param codigoGrupoEmpresarial
	 * @param indPais
	 * @param listaPaises
	 * @return
	 */
	public List<ArchivoAR> obtArchivosPendientes(int codigoGrupoEmpresarial, String indPais, List<String> listaPaises);

	/**
	 * Operacion interna que obtiene el detalle de la lista de ficheros de AR que tengamos, y realiza la conversion a una moneda determinada
	 * 
	 * @param lista lista de ficheros
	 * @param moneda moneda a la que consolidar
	 * @param token 
	 * @return lista divisas disponibles distintas
	 */
	public List<String> cambiarDivisaArchivoRA (List<ArchivoAR> list, String moneda, String token);
}
