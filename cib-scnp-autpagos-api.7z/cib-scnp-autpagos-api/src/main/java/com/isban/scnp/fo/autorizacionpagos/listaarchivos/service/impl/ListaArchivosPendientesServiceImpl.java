package com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ArchivoPolitica;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service.CompRolSecAutRemHelperService;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.Importe;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ListaImportes;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.ConversionDivisaHelperService;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.DetPerfiladoUsuarioHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.IntegerMapper;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.StringMapper;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoARMapper;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.GrupoPerfUsuarioMapper;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.GrupoPerfUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.MonedasArchivos;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.MonedasArchivosMapper;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.ListaArchivosPendientesHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

/**
 * Implementacion del servicio de listado de archivos pendientes de Autorizacion Remota
 * 
 * @author dagonzalez
 *
 */

@Slf4j
@Service
public class ListaArchivosPendientesServiceImpl implements ListaArchivosPendientesHelperService {

	private static final String STR_PERMISO_APR = "apr";
	private static final String STR_SERVICIO_FI = "FI";
	private static final String STR_FORMAT_UID = "%1$-30s";
	private static final String STR_PP = "PP";
	private static final String STR_OK = "OK";
	private static final String STR_KO = "KO";
	private static final String STR_COD_ESTADO_RA_GBMSGP = "CT_COD_ESTADO_RA_GBMSGP";
	private static final String STR_VACIO = "";
	private static final String STR_EUR = "EUR";
	private static final String STR_ERROR_NO_FIRMA = "0023";
	private static final String STR_ERROR_NO_HAY_DATOS = "0000";
	private static final String STR_MSG_OK = "OK";
	private static final int MAX_SIZE_QUERY = 1000;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${schema_proc}")
    protected String schemaproc;

	// Externos
	@Autowired
	private ListaPagosHelperService listaPagosHelperService;

	@Autowired
	private ListaWarehouseHelperService listaWarehouseHelperService;

	@Autowired
	private CompRolSecAutRemHelperService compRolSecAutRemHelperService;

	@Autowired
	private ConversionDivisaHelperService conversionDivisaHelperService;
	
	@Autowired
	private DetPerfiladoUsuarioHelperService detPerfiladoUsuarioHelperService;

	@Override
	public ListaArchivosPendientesResponse getListaArchivosPendientes (ListaArchivosARRequest request, boolean resumen) {

		//	 	Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }

		//	 	Obtenemos los datos de entrada
		int numPagina = request.getNumPagina();
		int numPorPagina = request.getNumPorPagina();
		String monConsolidacion = request.getMonConsolidacion();
		String tokenBks = request.getTokenBks();

		// 		Establecemos por defecto EUR si es necesario
		monConsolidacion = rellenarMonedaDefecto(monConsolidacion);

		// Comprobamos si el usuario tiene permisos metodo BKS - comprobarTokenUsuario (SQL)
		String uidToken = listaPagosHelperService.comprobarTokenSKeyUsu(uidLogado)	;
		if (uidToken!= null && uidToken.trim().equals(uidLogado)) {

			// Consultamos permisos del usuario para buscar el de Autorizacion Remota
			DetPerfiladoUsuarioResponse datosPerfilado = detPerfiladoUsuarioHelperService.detPerfiladoUsuario(request.getTokenBks());
			boolean permisoAR = comprobarPermisoAR(datosPerfilado);

			ListaArchivosPendientesResponse respuesta = new ListaArchivosPendientesResponse();
			
			if (permisoAR) {	// Si tenemos permiso listamos

				// Obtenemos el codigo del grupo empresarial del usuario y su nombre - obtCodNomGrupEmp (OI)
				int codigoGrupoEmpresarial 	= this.obtCodigoGrupoEmp(uidToken);
				String indMultiPais 		= this.obtIndARMultiPais(codigoGrupoEmpresarial); 

				/** 
				 * 	indMultiPais N cuando Acepta pais por fichero "UNO" 	y se especifica una lista de paises en BO
				 *  indMultiPais S cuando Acepta pais por fichero "VARIOS"  y no se especifica una lista de paises en BO
				 */

				List<String> paises = new ArrayList<>();
				if ("N".equals(indMultiPais)) { 	// Indicador multipais - obtListaPaisesARUsuario (OI)
					GrupoPerfUsuarioOut grupoPerf = this.obtGrupoPerfUsuarioSQL(uidToken);
					if (grupoPerf.getCodGrupoUsu() == 0) {
						paises = this.obtPaisesARPerfUsuarioSQL(uidToken, grupoPerf.getIDAuthUsu());
					}
					else {
						int idAuthUsuGrupo = this.obtIdauthPerfGrupUsuSQL(grupoPerf.getCodGrupoUsu());
						paises = this.obtPaisesARPerfGrupUsuarioSQL(grupoPerf.getCodGrupoUsu(), idAuthUsuGrupo);
					}					
				}

				// Obtenemos los archivos pendientes obtArchivosPendientes (SQL)
				List<ArchivoAR> salidaObtArchivosPendientes = this.obtArchivosPendientes(codigoGrupoEmpresarial, indMultiPais, paises);

				// Comprobamos los roles - comprobarRolSecuenciaAutRA (OI)
				List<ArchivoPolitica> comprobarRolSecuenciaAutRA = compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(uidToken, codigoGrupoEmpresarial, salidaObtArchivosPendientes);
				respuesta = generarResponse(comprobarRolSecuenciaAutRA);

				//Componer salida
				componerSalida(salidaObtArchivosPendientes, respuesta);

				// Comprobamos icono de notas - selectIconoNotaArchivo (SQL) ----- NO NECESARIO


				// Condicion para el resumen
				if (resumen) {
					respuesta.setNumFichTotales(respuesta.getListaArchivos().size());
					respuesta.setNumPaginaActual(numPagina);
					respuesta.setListaArchivos(null);
				}else {
					// Realizamos el cambio de divisas a mostrar - cambiarDivisaArchivoRA (OI)
					List<String> divisas = cambiarDivisaArchivoRA(respuesta.getListaArchivos(), monConsolidacion, tokenBks);

					// Preparamos datos de paginacion
					respuesta.setNumFichTotales(respuesta.getListaArchivos().size());
					respuesta.setNumPaginaActual(numPagina);

					respuesta.setListaDivisas(obtenerDivisas(divisas));

					Collections.sort(respuesta.getListaArchivos());
					respuesta.setListaArchivos(prepararPagina(numPagina-1, numPorPagina, respuesta.getListaArchivos()));

					// Traducimos el estado de archivo - getComplexMessages
					List<String> estadosTraducidos = listaWarehouseHelperService.traducirMulidi(STR_COD_ESTADO_RA_GBMSGP, obtenerEstados(respuesta.getListaArchivos()), uidToken);
					traducirArchivosPendientes(respuesta, estadosTraducidos);

				}
			}
			if (respuesta.getListaArchivos() != null && respuesta.getListaArchivos().isEmpty())
			{
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_NO_HAY_DATOS);
				respuesta.setNumPaginaActual(0);
			}
			else {
				respuesta.setStatus(STR_OK);
				respuesta.setMessage(STR_MSG_OK);
			}
			return respuesta;

		}else {
			ListaArchivosPendientesResponse respuesta = new ListaArchivosPendientesResponse();
			respuesta.setListaArchivos(null);
			respuesta.setNumFichTotales(0);
			respuesta.setNumPaginaActual(0);
			respuesta.setStatus(STR_KO);
			respuesta.setMessage(STR_ERROR_NO_FIRMA);
			return respuesta;
		}
	}

	/**
	 * Comprobamos el perfilado del usuario buscando el servicio SG - subproducto 102 - permiso apr
	 * 
	 * @param datosPerfilado
	 * @return permisoAR
	 */
	private boolean comprobarPermisoAR(DetPerfiladoUsuarioResponse datosPerfilado) {
		boolean permisoAR = false;
		int tamServicos = datosPerfilado.getMethodResult().getListadoServicios().size();
		for (int i=0;i<tamServicos && !permisoAR;i++) {	
			// Recorremos hasta el final o hasta encontrar servicio
			if (STR_SERVICIO_FI.equals(datosPerfilado.getMethodResult().getListadoServicios().get(i).getServicio().getCodServicio())) {
				int tamPermisos = datosPerfilado.getMethodResult().getListadoServicios().get(i).getServicio().getListaPermisosSinMetodos().size();
				for (int j=0;j<tamPermisos && !permisoAR;j++) {	
					if (datosPerfilado.getMethodResult().getListadoServicios().get(i).getServicio().getListaPermisosSinMetodos().get(j).getPemisos().getCodigoSubproducto() == 102 &&
							STR_PERMISO_APR.equalsIgnoreCase(datosPerfilado.getMethodResult().getListadoServicios().get(i).getServicio().getListaPermisosSinMetodos().get(j).getPemisos().getCodPermiso())) {
						permisoAR = true;
					}
				}
			}
		}
		return permisoAR;
	}

	private ListaArchivosPendientesResponse generarResponse(List<ArchivoPolitica> comprobarRolSecuenciaAutRA) {
		ListaArchivosPendientesResponse respuesta = new ListaArchivosPendientesResponse();
		for (int i=0;i<comprobarRolSecuenciaAutRA.size();i++) {
			ArchivoAR salida = new ArchivoAR();
			salida.setIdArchivo(comprobarRolSecuenciaAutRA.get(i).getIdArchivo());
			respuesta.getListaArchivos().add(salida);
		}
		return respuesta;
	}

	// *************************** SENTENCIAS Y METODOS PRIVADOS ***************************
	
	/**
	 * 	Operacion privada que nos devolverá la moneda por defecto EUR, o la moneda de entrada
	 * 	
	 * 	@param monConsolidacion
	 * 	@return
	 */
	private String rellenarMonedaDefecto(String monConsolidacion) {
		String monedaPorDefecto;
		if (monConsolidacion==null)
		{
			monedaPorDefecto= STR_VACIO;
			log.debug("Estableciendo moneda por defecto");
		}else
		{
			monedaPorDefecto = monConsolidacion;
		}
		return monedaPorDefecto;
	}
	
	
	
	@Override
	public String obtIndARMultiPais(int codigoGrupoEmpresarial) {
		
		String sql = 	"SELECT H1196_ARMULTIPAIS " +
						"FROM 	" + schemaproc + ".SGP_GRUPO_EMP " +
						"WHERE 	H1196_CDEMGR = ?";
		
		Object[] params = new Object[] {codigoGrupoEmpresarial};
		List<String> resultadoQuery = jdbcTemplate.query(sql, params, new StringMapper());
		
		if (resultadoQuery!=null && !resultadoQuery.isEmpty())
		{
			int tamLista = resultadoQuery.size();
			
			if(tamLista > 0) {
				return resultadoQuery.get(0);
			}else {
				return null;
			}
		}
		else
		{
			return null;
		}
	}

	@Override
	public GrupoPerfUsuarioOut obtGrupoPerfUsuarioSQL(String uid) {
		String sql =	"SELECT H1241_CODGRUPR, H1241_IDAUTH " +
						"FROM 	" + schemaproc + ".SGP_PERF_USU " +
						"WHERE 	H1241_UID=? AND H1241_IDACTIVO= 'S'";
		
		String fUid = String.format(STR_FORMAT_UID, uid);
		Object[] params = new Object[] {fUid};
		
		List<GrupoPerfUsuarioOut> resultadoQuery = jdbcTemplate.query(sql, params, new GrupoPerfUsuarioMapper());
		
		if (resultadoQuery!=null && !resultadoQuery.isEmpty())
		{
			int tamLista = resultadoQuery.size();
			
			if(tamLista > 0) {
				return resultadoQuery.get(0);
			}else {
				return null;
			}
		}
		else
		{
			return null;
		}
		
		
	}

	@Override
	public List<String> obtPaisesARPerfUsuarioSQL(String uid, int idAuthUsu) {

		String sql = 	"SELECT R5586_CODPAIS " + 
						"FROM 	" + schemaproc + ".SGP_R_AR_USPAIS " + 
						"WHERE 	R5586_UID=? AND R5586_IDAUTH=?";
		
		String fUid = String.format(STR_FORMAT_UID, uid);
		
		Object[] params = new Object[] {fUid, idAuthUsu};
		return jdbcTemplate.query(sql, params, new StringMapper());
	}

	@Override
	public int obtIdauthPerfGrupUsuSQL(int codGrupoUsu) {
		String sql = 	"SELECT H1242_IDAUTH " + 
						"FROM 	" + schemaproc + ".SGP_PERF_GRU " + 
						"WHERE 	H1242_CODGRUPR=? AND H1242_IDACTIVO='S'";
		Object[] params = new Object[] {codGrupoUsu};
		List<Integer> salidaQuery = jdbcTemplate.query(sql, params, new IntegerMapper());
		
		int salida = 0;
		if (salidaQuery!=null && !salidaQuery.isEmpty())
		{
			salida = salidaQuery.get(0);
		}
		return salida;
	}

	@Override
	public List<String> obtPaisesARPerfGrupUsuarioSQL(int codGrupoUsu, int idAuthUsuGrupo) {
		String sql = 	"SELECT R5585_CODPAIS " + 
						"FROM 	" + schemaproc + ".SGP_R_AR_GUPAIS " + 
						"WHERE 	R5585_CODGRUPR=? AND R5585_IDAUTH=?";
		
		Object[] params = new Object[] {codGrupoUsu,idAuthUsuGrupo};
		return jdbcTemplate.query(sql, params, new StringMapper());
	
	}

	@Override
	public List<ArchivoAR> obtArchivosPendientes(int codigoGrupoEmpresarial, String indMultipais, List<String> listaPaises) {
		List<String> listaTemp = new ArrayList<>();
		List<ArchivoAR> salida = new ArrayList<>();		
		List<ArchivoAR> salidaTemp = new ArrayList<>();
		
		int tamListaPaises = listaPaises.size();
		if (tamListaPaises>0)
		{
			int numIters = tamListaPaises/MAX_SIZE_QUERY + ((tamListaPaises%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaPaises);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaPaises.get(j));
					
				}
				
				salidaTemp = obtArchivosPendientesQuery (codigoGrupoEmpresarial, indMultipais,  listaTemp);
				
				salida.addAll(salidaTemp);
			
			}
		}
		else
		{
			salida=obtArchivosPendientesQuery (codigoGrupoEmpresarial, indMultipais,  listaPaises);
		}
		
		return salida;
	}
	
	private List<ArchivoAR> obtArchivosPendientesQuery(int codigoGrupoEmpresarial, String indMultipais, List<String> listaPaises) {
		
		// Estados: E0 (Pendiente) - E1 (Parcial) - PP (Pendiente Politica)
		
		String sql = 	"SELECT O9247_IDARCH, O9247_FEC_ARCH, O9247_ESTARCH, O9247_NOMARCHAUT, O9247_NUM_TRANS " + 
						"FROM " + schemaproc + ".SGP_ARCH_REMOT, " + schemaproc + ".SGP_ARCH_PAIMON " + 
						"WHERE O9247_CDEMGR = ? AND O9247_ESTARCH IN ('E0', 'E1', 'PP') " + 
						"AND O9247_IDERROR= RPAD(' ', 3) " +
						"AND O9247_IDARCH=O9248_IDARCH " +
						"AND ('N' = ? OR O9248_CODPAIS IN (" + getStringOfStringsList(listaPaises) +"))" +
						"GROUP BY O9247_IDARCH, O9247_FEC_ARCH, O9247_ESTARCH, O9247_NOMARCHAUT, O9247_NUM_TRANS";
		
		String indPais = "N".equals(indMultipais) ? "S" : "N";

		/** 
		 * Si el indicador viene como N (un pais por fichero, tendremos una lista de paises para filtrar) y en la query usamos S para filtrar
		 * Si el indicador viene como S (varios paies por fichero) y									    en la query usamos N para que no filtre
		 */

		Object[] params = new Object[] {codigoGrupoEmpresarial, indPais};
		
		return  jdbcTemplate.query(sql, params, new ArchivoARMapper());
	}

	@Override
	public int obtCodigoGrupoEmp(String uid) {
		String sql = "SELECT H1186_CDEMGR " + 
				"FROM " + schemaproc + ".SGP_USUARIO " + 
				"WHERE H1186_UID = ? " + 
				"AND H1186_CRSITUAC = 'H'";
		
		// Rellenamos con espacios
		String fUid = String.format(STR_FORMAT_UID, uid);
		Object[] params = new Object[] {fUid};
		List<Integer> resultadoQuery = jdbcTemplate.query(sql, params, new IntegerMapper());

		if (resultadoQuery!=null && !resultadoQuery.isEmpty())
		{
			return resultadoQuery.get(0);
		}
		else
		{
			return 0;
		}		
	}

	@Override
	public List<String> cambiarDivisaArchivoRA(List<ArchivoAR> list, String monConsolidacion, String token) {
		
		List<ArchivoAR> listaTemp = new ArrayList<>();
		List<MonedasArchivos> salida = new ArrayList<>();		
		List<MonedasArchivos> salidaTemp = new ArrayList<>();
		
		int tamListaIds = list.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(list.get(j));
					
				}
				
				salidaTemp = cambiarDivisaArchivoRAQuery(listaTemp);
				
				salida.addAll(salidaTemp);
			
			}
		}
		
		List<ListaImportes> listaGruposImportes = new ArrayList<>();
		ConversionDivisaRequest entradaConvDivisa = new ConversionDivisaRequest ();		
		
		int tamList = list.size();
		// Por cada archivo de entrada, tenemos que buscar en listadoDetalle lote los que son suyos
		List<String> divisas = new ArrayList<>();
		for (int i=0;i<tamList;i++)
		{
			ListaImportes listaImportes = new ListaImportes();

			int idArchivo = list.get(i).getIdArchivo();
			int tamArchivoMoneda = salida.size();
			for (int j=0;j<tamArchivoMoneda;j++) {

				int idArchivoMoneda = salida.get(j).getIdArchivo();
				if (idArchivo == idArchivoMoneda)
				{
					BigDecimal bdImporte = salida.get(j).getImporte();
					String divisa = salida.get(j).getMoneda();
					ImporteType impTAnadir = new ImporteType (bdImporte, divisa);
					Importe impAnadir = new Importe(impTAnadir);
					listaImportes.addImporte(impAnadir);
					
					// Añadimos monedas distintas
					if (!divisas.contains(divisa)) {
							divisas.add(divisa);
					}
				}
				
			}
			listaGruposImportes.add(listaImportes);
			entradaConvDivisa.getRequestData().getConversionDivisa().getEntrada().setDivisaConsolidacion(monConsolidacion);
			entradaConvDivisa.getRequestData().getConversionDivisa().getEntrada().setListaGruposImportes(listaGruposImportes);
		}
		entradaConvDivisa.setToken(token);
		
		ConversionDivisaResponse salidaConvDivisa = conversionDivisaHelperService.conversionDivisa(entradaConvDivisa);

		int tamSalida = salidaConvDivisa.getMethodResult().getListaImportes().size();
		for (int i=0;i<tamSalida;i++) {
			list.get(i).setImporte(salidaConvDivisa.getMethodResult().getListaImportes().get(i).getIMPORTE());
			list.get(i).setDivisa(salidaConvDivisa.getMethodResult().getListaImportes().get(i).getDIVISA());
		}
		
		// Añadir moneda de consolidacion
		if (!divisas.contains(monConsolidacion) && !STR_VACIO.equals(monConsolidacion)) {
			divisas.add(monConsolidacion);
		}
		else if (!list.isEmpty())
		{
			monConsolidacion=list.get(0).getDivisa();
			if (!divisas.contains(monConsolidacion))
			{
				divisas.add(monConsolidacion);
			}
		}
			
		return divisas;
	}
	

	private List<MonedasArchivos> cambiarDivisaArchivoRAQuery(List<ArchivoAR> list) {
		// Cambiada de iterada a indexada - 22.11.2018
		String sql = 	"SELECT O9248_IDARCH, O9248_CODMONSWI, O9248_IMPPAISMON " + 
						"FROM " + schemaproc + ".SGP_ARCH_PAIMON " + 
						"WHERE O9248_IDARCH IN (" + getStringOfIntegerList(list) + ")" ;
		
		return jdbcTemplate.query(sql, new MonedasArchivosMapper());
	}

	private void componerSalida(List<ArchivoAR> salidaObtArchivosPendientes, ListaArchivosPendientesResponse salida) {

		int tamSalida = salida.getListaArchivos().size();
		int tamAux = salidaObtArchivosPendientes.size();

		for (int i=0;i<tamSalida;i++){
			int idArchivo = salida.getListaArchivos().get(i).getIdArchivo();
			for (int j=0;j<tamAux;j++){
				int idArchivoAux = salidaObtArchivosPendientes.get(j).getIdArchivo();
				if (idArchivo == idArchivoAux){
					salida.getListaArchivos().get(i).setFecha(salidaObtArchivosPendientes.get(j).getFecha());
					salida.getListaArchivos().get(i).setEstado(salidaObtArchivosPendientes.get(j).getEstado());
					salida.getListaArchivos().get(i).setNombre(salidaObtArchivosPendientes.get(j).getNombre());
					salida.getListaArchivos().get(i).setNumTransacciones(salidaObtArchivosPendientes.get(j).getNumTransacciones());
					break;
				}
			}
		}
		
		for (int i=0;i<tamAux;i++){
			String estadoAux =  salidaObtArchivosPendientes.get(i).getEstado();
			if (STR_PP.equals(estadoAux)){
					ArchivoAR reg = new ArchivoAR();
					reg .setIdArchivo(salidaObtArchivosPendientes.get(i).getIdArchivo());
					reg.setFecha(salidaObtArchivosPendientes.get(i).getFecha());
					reg.setEstado(estadoAux);
					reg.setNombre(salidaObtArchivosPendientes.get(i).getNombre());
					reg.setNumTransacciones(salidaObtArchivosPendientes.get(i).getNumTransacciones());
				salida.getListaArchivos().add(reg);
			}
		}
	}

	private List<ArchivoAR> prepararPagina(int numPagina, int numPorPagina,
			List<ArchivoAR> listaCompleta) {
		
		List<ArchivoAR> salida = new ArrayList<>();

		int tamListaCompleta = listaCompleta.size();
		if (tamListaCompleta>(numPagina*numPorPagina))
		{
			int ini = numPagina*numPorPagina;
			int fin = ini+numPorPagina;
			if (fin>listaCompleta.size())
			{
				fin = listaCompleta.size();
			}
			for (int i=ini;i<fin;i++)
			{
				ArchivoAR elemento = listaCompleta.get(i);
				salida.add(elemento);
			}
		}
		return salida;
	}
	
	private void traducirArchivosPendientes(ListaArchivosPendientesResponse archivos, List<String> estadosTraducidos) {
		for (int i=0;i<archivos.getListaArchivos().size();i++) {
			archivos.getListaArchivos().get(i).setDescripcionEstado(estadosTraducidos.get(i));
		}
	}
	
	private List<String> obtenerEstados(List<ArchivoAR> lista){
		List<String> listaEstados = new ArrayList<>();
		for (int i=0;i<lista.size();i++)
		{
			listaEstados.add(lista.get(i).getEstado());
		}
		return listaEstados;
	}
	
	private List<String> obtenerDivisas(List<String> lista){
		List<String> mainList = new ArrayList<>();
		//  EUR GBP USD + Divisas archivos
		mainList.add("EUR");
		mainList.add("GBP");
		mainList.add("USD");
		
		for (int i=0;i<lista.size();i++)
		{
			if (!mainList.contains(lista.get(i))){
				mainList.add(lista.get(i));
			}
		}
		

		return mainList;
	}
	
	/**	Metodo privado para la conversion de una lista de ints a cadena
	 * 
	 * @param idArchivos
	 * @return
	 */
	private String getStringOfStringsList(List<String> cadena) {
		StringBuilder commaSepValueBuilder = new StringBuilder();
		for ( int i = 0; i< cadena.size(); i++){
			//append the value into the builder
			commaSepValueBuilder.append("'".concat(cadena.get(i)));

			//if the value is not the last element of the list then append the comma(,) as well
			if ( i != cadena.size()-1){
				commaSepValueBuilder.append("', ");
			}else {
				commaSepValueBuilder.append("'");
			}
		}
		// Si no hay valores añadimos un valor vacio para que no falle la sentencia IN
		if (commaSepValueBuilder.toString().equals(STR_VACIO)) {
			commaSepValueBuilder.append("''");
		}
		return commaSepValueBuilder.toString();
	}
	
	/**	Metodo privado para la conversion de una lista de ints a cadena
	 * 
	 * @param idArchivos
	 * @return
	 */
	private String getStringOfIntegerList(List<ArchivoAR> idArchivos) {
		StringBuilder commaSepValueBuilder = new StringBuilder();
		for ( int i = 0; i< idArchivos.size(); i++){
			//append the value into the builder
			commaSepValueBuilder.append(idArchivos.get(i).getIdArchivo());

			//if the value is not the last element of the list then append the comma(,) as well
			if ( i != idArchivos.size()-1){
				commaSepValueBuilder.append(", ");
			}
		}
		// Si no hay valores añadimos un valor vacio para que no falle la sentencia IN
		if (commaSepValueBuilder.toString().equals(STR_VACIO)) {
			commaSepValueBuilder.append("''");
		}
		return commaSepValueBuilder.toString();
	}
}
