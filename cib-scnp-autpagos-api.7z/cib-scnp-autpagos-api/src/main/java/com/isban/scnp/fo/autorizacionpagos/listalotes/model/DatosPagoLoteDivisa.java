package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

public class DatosPagoLoteDivisa {
	private String idPago;
	private String idLote;
	private String divisaPago;
	
	public String getIdPago() {
		return idPago;
	}
	public void setIdPago(String idPago) {
		this.idPago = idPago;
	}
	public String getIdLote() {
		return idLote;
	}
	public void setIdLote(String idLote) {
		this.idLote = idLote;
	}
	public String getDivisaPago() {
		return divisaPago;
	}
	public void setDivisaPago(String divisaPago) {
		this.divisaPago = divisaPago;
	}	
}
