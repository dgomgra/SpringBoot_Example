package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class GrupoPerfUsuarioMapper implements RowMapper<GrupoPerfUsuarioOut>{

	private static final String H1241_IDAUTH = "H1241_IDAUTH";
	private static final String H1241_CODGRUPR = "H1241_CODGRUPR";

	@Override
	public GrupoPerfUsuarioOut mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new GrupoPerfUsuarioOut(rs.getInt(H1241_CODGRUPR), rs.getInt(H1241_IDAUTH));
	}

}
