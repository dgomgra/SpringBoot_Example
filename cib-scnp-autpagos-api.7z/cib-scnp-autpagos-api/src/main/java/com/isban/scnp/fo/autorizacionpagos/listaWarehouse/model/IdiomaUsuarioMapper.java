package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class IdiomaUsuarioMapper implements RowMapper<IdiomaUsuario>{
	@Override
	public IdiomaUsuario mapRow(ResultSet rs, int rowNum) throws SQLException {
		String idioma=rs.getString("H1186_IDIOMASC");
		String pais=rs.getString("H1186_CODPAIS");
		
		return new IdiomaUsuario(idioma, pais);
	}
}