package com.isban.scnp.fo.autorizacionpagos.listapagos.service;

import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.PagosUsuarioAutorizProcedureOut;

public interface ListaPagosHelperService {

	// Metodo del Controller
	public ListaPagosAutorizarResponse getListaPagosAutorizarImp(ListaPagosAutorizarRequest listaPagosAutorizarRequest);
	
	// Consulta para el listado de Autorizar Pagos
	public String comprobarTokenSKeyUsu(String uid);
	public PagosUsuarioAutorizProcedureOut getPagosUsuarioAutorizProcedure(String uidLogado, String idLote, String pais);
	public List<String> obtPagosFirmaOKUsuario(String uid, List<String> listaPagos);
	public String obtNotas(String rftrans);
}
