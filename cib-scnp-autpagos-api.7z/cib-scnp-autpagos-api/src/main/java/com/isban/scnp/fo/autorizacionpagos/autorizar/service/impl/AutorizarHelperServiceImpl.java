package com.isban.scnp.fo.autorizacionpagos.autorizar.service.impl;

import java.math.BigDecimal;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarPagosLotesRequestData;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarPagosLotes_E;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarRARequestData;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarRA_E;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarStopPaymentRequestData;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarStopPayment_E;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.ClaveValor;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.ClaveValorMapper;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.DatosFirma;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdLoteNombre;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdPagoNombre;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.Nota;
import com.isban.scnp.fo.autorizacionpagos.autorizar.service.AutorizarHelperService;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.DatosFirmaHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class AutorizarHelperServiceImpl implements AutorizarHelperService{

	private static final int MAX_SIZE_QUERY = 1000;
	private static final String STR_RESPUESTA_DEL_SERVIDOR = "Respuesta del servidor: ";
	private static final String STR_DATOS_DE_LA_PETICION = "Datos de la petición: ";
	private static final String STR_ERROR_AL_CONECTAR_CON_HOST = "Error al conectar con host ";
	private static final String STR_CONEXION_HOST_OK = "Se ha realizado la petición al host ";
	private static final String STR_ESTADO_PAGO_PSGP = "ESTADO_PAGO_PSGP";
	private static final String STR_AND_TOKEN = "&token=";
	private static final String STR_CALL_BKS_REST = "/json/F_GBMSGF_FOMovil_E/1?authenticationType=token&requestData=";
	private static final String STR_AU = "AU";
	private static final String STR_ESTADO_AR = "AR";
	private static final String STR_ACCION_AUTORIZAR = "autorizar";
	private static final String STR_ACCION_RECHAZAR = "rechazar";
	private static final String STR_ACCION_STOP_PAYMENT = "stopPayment";
	private static final String STR_IDS = "ids";
	private static final String STR_N = "N";
	private static final String STR_S = "S";
	private static final String STR_VACIO = "";
	private static final String STR_OK = "OK";
	private static final String STR_KO = "KO";
	private static final String STR_LOTES = "lotes";
	private static final String STR_PAGOS = "pagos";
	private static final String STR_AR = "ar";
	private static final String STR_ERROR = "error";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_STOP_PAYMENT = "Servicio de stopPayment, pagos, lotes";	
	private static final String STR_MSG_OK = "OK";
	private static final String STR_ERROR_PARAMETROS = "0053";
	
	@Value("${urlBks}")
    protected String urlBks;
	
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplateSimple;
	
	@Autowired
	private ListaWarehouseHelperService listaWarehouseHelperService;
	
	@Autowired
	private DatosFirmaHelperService datosFirmaHelperService;
	
	@Autowired
	private ApiRestTemplate apiRestTemplate;
	
	@Autowired
	private AppContext appContext;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	private List ordenarSalida (String tipo, List<String> listaClaves, List<ClaveValor> listaClaveValor)
	{
		List salida = new ArrayList<>();
		if (listaClaveValor!=null && !listaClaveValor.isEmpty())
		{
			Map <String, String> mapaClaveValor= new HashMap<>();
			for (ClaveValor cv : listaClaveValor)
			{
				mapaClaveValor.put(cv.getClave(), cv.getValor());
			}
			for (int i=0;i<listaClaves.size();i++)
			{
				String clave = listaClaves.get(i);
				String valor = mapaClaveValor.containsKey(clave) ? mapaClaveValor.get(clave) : STR_VACIO;
				if (STR_PAGOS.equals(tipo))
				{
					IdPagoNombre ipn= new IdPagoNombre(clave, valor);
					salida.add(ipn);
				}
				else
				{
					IdLoteNombre iln = new IdLoteNombre(clave, valor);
					salida.add(iln);
				}
			}
		}
		return salida;		
	}
	
	public List obtenerListaNombres (String tipo, List<String> listaIds)
	{
	
		List listaTemp = new ArrayList<>();
		List salida = new ArrayList<>();		
		List salidaTemp = new ArrayList<>();
		
		int tamListaIds = listaIds.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaIds.get(j));
					
				}
				
				salidaTemp = obtenerListaNombresQuery (tipo, listaTemp);
				
				salida.addAll(salidaTemp);
			
			}
		}
		
		return ordenarSalida(tipo, listaIds, salida);
		
	}
	
	private List obtenerListaNombresQuery (String tipo, List<String> listaIds)
	{
		
		String sql = STR_LOTES.equals(tipo) ? "SELECT O2046_NULOTE, O2046_DESCRI50 FROM " + schemaproc + ".SGP_LOTE WHERE O2046_NULOTE IN (:ids)" : "SELECT N6563_RFTRANS, N6563_CLIREFER FROM " + schemaproc + ".SGP_PAGO WHERE N6563_RFTRANS IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		
		params.addValue(STR_IDS, listaIds);
		
		return jdbcTemplate.query(sql, params, new ClaveValorMapper());		
	}
	
	private String convertToJson (Object o)
	{
		//Object to JSON in String
		
		try {
			ObjectMapper mapper = new ObjectMapper();		
				
			return mapper.writeValueAsString(o);
		} catch (JsonProcessingException e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_STOP_PAYMENT + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			return STR_VACIO;
		}
	}
	
	private void autorizarPagosLotes (AutorizarRequest autorizarRequest, List listaIdNombre)
	{
		// Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
		
		String tipo = autorizarRequest.getTipo();
		String accion = autorizarRequest.getAccion();
		
		AutorizarPagosLotesRequestData autorizarPagosLotesRequestData = new AutorizarPagosLotesRequestData();		
		
		AutorizarPagosLotes_E entradaOI = new AutorizarPagosLotes_E ();
		
		DatosFirma datosFirma = new DatosFirma ();
		datosFirma.setKey(autorizarRequest.getRespuestaVasco());
		datosFirma.setNumPagos(autorizarRequest.getNumeroPagos());
		datosFirma.setImporteTotal(autorizarRequest.getMontoTotal());
		
		entradaOI.setDatosFirma(datosFirma);
		entradaOI.setIndAutorizar(STR_ACCION_AUTORIZAR.equalsIgnoreCase(autorizarRequest.getAccion()) ? STR_S : STR_N );
		if (STR_PAGOS.equalsIgnoreCase(tipo))
		{
			entradaOI.setListaIdPagoNombre(listaIdNombre);
		}
		else
		{
			entradaOI.setListaIdLoteNombre(listaIdNombre);
		}
		
		String textoNota = autorizarRequest.getNota().trim();
		String asuntoNota= obtenerAsuntoNota(textoNota, accion,uidLogado);
		Nota nota = new Nota(asuntoNota, textoNota);
		entradaOI.setNota(nota);
		
		autorizarPagosLotesRequestData.getAutorizarPagosLotes().setEntrada(entradaOI);
		
		String token = autorizarRequest.getTokenBks();
		String json=convertToJson(autorizarPagosLotesRequestData);
				
		String urlAutorizarPagosLotes = urlBks + STR_CALL_BKS_REST+json+STR_AND_TOKEN + token;
		
        URI uriAutorizarPagosLotes = UriComponentsBuilder.fromUriString(urlAutorizarPagosLotes).build().encode().toUri();
		
        String datosPeticion = convertToJson(entradaOI);
        AsyncRestTemplate restTemplatePost = apiRestTemplate.getAsyncRestTemplate();
		ListenableFuture<ResponseEntity<Object>> response = restTemplatePost.exchange(uriAutorizarPagosLotes, HttpMethod.GET, null, Object.class);

		response.addCallback(new ListenableFutureCallback<ResponseEntity<Object>>() {
		    @Override
		    public void onSuccess(ResponseEntity<Object> result) {                
		        log.debug(STR_CONEXION_HOST_OK+ uriAutorizarPagosLotes.getHost()+":"+uriAutorizarPagosLotes.getPort()+uriAutorizarPagosLotes.getPath());
		    }

		    @Override
		    public void onFailure(Throwable ex) {
		    	log.error(STR_ERROR_AL_CONECTAR_CON_HOST+ uriAutorizarPagosLotes.getHost()+":"+uriAutorizarPagosLotes.getPort()+uriAutorizarPagosLotes.getPath());
		    	log.error(STR_DATOS_DE_LA_PETICION+datosPeticion);
		    	log.error(STR_RESPUESTA_DEL_SERVIDOR+ ex.getMessage());	
		    }
		});
	}

	private void stopPayment(AutorizarRequest autorizarRequest, List listaIdsNombres)
	{
		String tipo = autorizarRequest.getTipo();
				
		AutorizarStopPaymentRequestData autorizarStopPaymentRequestData = new AutorizarStopPaymentRequestData();
			
		AutorizarStopPayment_E entradaOI = new AutorizarStopPayment_E();
		
		DatosFirma datosFirma = new DatosFirma ();
		datosFirma.setKey(autorizarRequest.getRespuestaVasco());
		datosFirma.setNumPagos(autorizarRequest.getNumeroPagos());
		datosFirma.setImporteTotal(autorizarRequest.getMontoTotal());
		
		entradaOI.setDatosFirma(datosFirma);
		if (STR_PAGOS.equalsIgnoreCase(tipo))
		{
			entradaOI.setIdPagoNombre((IdPagoNombre) listaIdsNombres.get(0));
		}
		else
		{
			entradaOI.setIdLoteNombre((IdLoteNombre) listaIdsNombres.get(0));
		}
		autorizarStopPaymentRequestData.getAutorizarStopPayment().setEntrada(entradaOI);
		
		String token = autorizarRequest.getTokenBks();
		
		String json=convertToJson(autorizarStopPaymentRequestData);
		
		String datosPeticion=convertToJson(entradaOI);
		String urlAutorizarStopPayment = urlBks+STR_CALL_BKS_REST+json+STR_AND_TOKEN + token;
		
		URI uriAutorizarStopPayment = UriComponentsBuilder.fromUriString(urlAutorizarStopPayment).build().encode().toUri();
		
		AsyncRestTemplate restTemplatePost = apiRestTemplate.getAsyncRestTemplate();
		ListenableFuture<ResponseEntity<Object>> response = restTemplatePost.exchange(uriAutorizarStopPayment, HttpMethod.GET, null, Object.class);

		response.addCallback(new ListenableFutureCallback<ResponseEntity<Object>>() {
		    @Override
		    public void onSuccess(ResponseEntity<Object> result) {                
		        log.debug(STR_CONEXION_HOST_OK+ uriAutorizarStopPayment.getHost()+":"+uriAutorizarStopPayment.getPort()+uriAutorizarStopPayment.getPath());
		    }

		    @Override
		    public void onFailure(Throwable ex) {
		    	log.error(STR_ERROR_AL_CONECTAR_CON_HOST+ uriAutorizarStopPayment.getHost()+":"+uriAutorizarStopPayment.getPort()+uriAutorizarStopPayment.getPath());
		    	log.error(STR_DATOS_DE_LA_PETICION+datosPeticion);
		    	log.error(STR_RESPUESTA_DEL_SERVIDOR+ ex.getMessage());	
		    }
		});

	    return;
        
	}
	
	private String obtenerAsuntoNota (String textoNota, String accion, String uid)
	{
		
		String retorno = STR_VACIO;
		if (!STR_VACIO.equals(textoNota.trim()))
		{
			
			String datoTraducir = STR_ACCION_AUTORIZAR.equals(accion)? STR_AU : STR_ESTADO_AR;
			List<String> listaATraducir = new ArrayList<>(0);
			listaATraducir.add(datoTraducir);
			
			List<String> listaTraducciones = listaWarehouseHelperService.traducirMulidi(STR_ESTADO_PAGO_PSGP, listaATraducir, uid);
			
			if (!listaTraducciones.isEmpty())
			{
				
				retorno = listaTraducciones.get(0);
			}
			
		}
		return retorno;
	}
	
	private void autorizarArchivos (AutorizarRequest autorizarRequest)
	{
		
		// Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
	
		String accion = autorizarRequest.getAccion();
		
		AutorizarRARequestData autorizarRARequestData = new AutorizarRARequestData();
			
		AutorizarRA_E entradaOI = new AutorizarRA_E();
		
		DatosFirma datosFirma = new DatosFirma ();
		datosFirma.setKey(autorizarRequest.getRespuestaVasco());
		datosFirma.setNumPagos(autorizarRequest.getNumeroPagos());
		datosFirma.setImporteTotal(autorizarRequest.getMontoTotal());
		
		entradaOI.setIndAutorizar(STR_ACCION_AUTORIZAR.equalsIgnoreCase(accion) ? STR_S:STR_N);
		entradaOI.setDatosFirma(datosFirma);
		entradaOI.setListaIdArchivoStr(autorizarRequest.getListaIds());
		
		String textoNota = autorizarRequest.getNota().trim();
		String asuntoNota= obtenerAsuntoNota(textoNota, accion,uidLogado);
		Nota nota = new Nota(asuntoNota, textoNota);
		entradaOI.setNota(nota);
		
		autorizarRARequestData.getAutorizarRA().setEntrada(entradaOI);
		
		String token = autorizarRequest.getTokenBks();
		String json=convertToJson(autorizarRARequestData);
				
		String urlAutorizarArchivos = urlBks + STR_CALL_BKS_REST+json+STR_AND_TOKEN + token;
		
        URI uriAutorizarArchivos = UriComponentsBuilder.fromUriString(urlAutorizarArchivos).build().encode().toUri();
        
        String datosPeticion =  convertToJson(entradaOI);
		
        AsyncRestTemplate restTemplatePost = apiRestTemplate.getAsyncRestTemplate();
        ListenableFuture<ResponseEntity<Object>> response = restTemplatePost.exchange(uriAutorizarArchivos, HttpMethod.GET, null, Object.class);
        
		response.addCallback(new ListenableFutureCallback<ResponseEntity<Object>>() {
		    @Override
		    public void onSuccess(ResponseEntity<Object> result) {                
		        log.debug(STR_CONEXION_HOST_OK+ uriAutorizarArchivos.getHost()+":"+uriAutorizarArchivos.getPort()+uriAutorizarArchivos.getPath());
		    }

		    @Override
		    public void onFailure(Throwable ex) {
		    	log.error(STR_ERROR_AL_CONECTAR_CON_HOST+ uriAutorizarArchivos.getHost()+":"+uriAutorizarArchivos.getPort()+uriAutorizarArchivos.getPath());
		    	log.error(STR_DATOS_DE_LA_PETICION+datosPeticion);
		    	log.error(STR_RESPUESTA_DEL_SERVIDOR+ ex.getMessage());	
		    }
		});
	}
	
	private int comprobarCaso (String tipo, String accion)
	{
		int retorno = 4;
		if ((STR_ACCION_AUTORIZAR.equalsIgnoreCase(accion) || STR_ACCION_RECHAZAR.equalsIgnoreCase(accion))
				&& 
				(STR_PAGOS.equalsIgnoreCase(tipo) || STR_LOTES.equalsIgnoreCase(tipo)))
		{
			retorno = 1;
		}
		else if (STR_ACCION_STOP_PAYMENT.equalsIgnoreCase(accion) && (STR_PAGOS.equalsIgnoreCase(tipo) || STR_LOTES.equalsIgnoreCase(tipo)))
		{
			retorno = 2;
		}
		else if(STR_AR.equalsIgnoreCase(tipo)) {
			retorno = 3;
		}
		return retorno;
	}
	
	public AutorizarResponse autorizarImpl (AutorizarRequest autorizarRequest) 
	{
		AutorizarResponse autorizarResponse = new AutorizarResponse();
		
		String tipoCripto = appContext.getUserData().getTipoCripto();
		String tipo = autorizarRequest.getTipo();
		String accion = autorizarRequest.getAccion();
		
		boolean paisPermitido = false;
		if(autorizarRequest.getListaIds().size() == 1 && STR_ACCION_AUTORIZAR.equalsIgnoreCase(accion) && STR_PAGOS.equalsIgnoreCase(tipo)) {
			String paisPago = datosFirmaHelperService.getPaisPago(autorizarRequest.getListaIds().get(0));
			String[ ] listCountry = {"ES", "PT", "IT", "FR", "DE", "GB"};
			List<String> arrayCountry= Arrays.asList(listCountry);
			if(arrayCountry.contains(paisPago)) {
				paisPermitido = true;
			}
		}
		
		if (STR_S.equals(tipoCripto) && autorizarRequest.getListaIds().size() == 1 && STR_ACCION_AUTORIZAR.equalsIgnoreCase(accion) && STR_PAGOS.equalsIgnoreCase(tipo) && paisPermitido) {
			List<DatosFirmaCuentaBenOut> listaCuenta = new ArrayList<>();
			String id = autorizarRequest.getListaIds().get(0);
			listaCuenta = getDatosDigitosCuentaBenQuery(id);	
			if(!listaCuenta.isEmpty() && listaCuenta != null && listaCuenta.get(0).getDigitosCuentaBen() != null) {													
				verificarFirmaVascoStrBks(autorizarRequest.getTokenBks(), autorizarRequest.getNumeroPagos(), autorizarRequest.getMontoTotal(), autorizarRequest.getRespuestaVasco());
			} else {
				verificarFirmaVascoBks(autorizarRequest.getTokenBks(), autorizarRequest.getNumeroPagos(), autorizarRequest.getMontoTotal(), autorizarRequest.getRespuestaVasco());	
			}
		} else {			
			verificarFirmaVascoBks(autorizarRequest.getTokenBks(), autorizarRequest.getNumeroPagos(), autorizarRequest.getMontoTotal(), autorizarRequest.getRespuestaVasco());
		}
		
		

		autorizarResponse.setStatus(STR_OK);
		autorizarResponse.setMessage(STR_MSG_OK);	

		List<String> listaIds = autorizarRequest.getListaIds();
		
		int selector = comprobarCaso (tipo,accion);
		
		switch (selector)
		{
			case 1:
				autorizarPagosLotes(autorizarRequest, obtenerListaNombres(tipo, listaIds));
				break;				
			case 2:
				stopPayment(autorizarRequest, obtenerListaNombres(tipo, listaIds));
				break;
			case 3:
				autorizarArchivos (autorizarRequest);
				break;
			default: 				
				autorizarResponse.setStatus(STR_KO);
				autorizarResponse.setMessage(STR_ERROR_PARAMETROS);				
		}
		

		return autorizarResponse;
	}
	
	public void verificarFirmaVascoBks(String token, int numeroPagos, BigDecimal montoTotal, String key) {
		
		String urlToken = urlBks + "/json/F_GBMSGF_FOComunGenerico_E/1?token=" + token;
		String body = "requestData={\"verificarFirmaVasco\":{\"entrada\":{\"key\":\"" + key + "\",\"numPagos\": " + numeroPagos + ",\"importeTotal\": " + montoTotal + "}}}";
				
	    HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
	    URI uriObtEntOfDay = null;
	    
		requestHeaders.add("token", token);
		uriObtEntOfDay = UriComponentsBuilder.fromUriString(urlToken).build().encode().toUri();
	
	    HttpEntity<String> entityObtEndOfDayIntradiaRequest = new HttpEntity<>(body, requestHeaders);
	    RestTemplate restTemplatePost = apiRestTemplate.getRestTemplate();
	    ResponseEntity<String> response = restTemplatePost.exchange(uriObtEntOfDay, HttpMethod.POST, entityObtEndOfDayIntradiaRequest, String.class);
	    		
	}
	
	public void verificarFirmaVascoStrBks(String token, int numeroPagos, BigDecimal montoTotal, String key) {
		
		
		
		String urlToken = urlBks + "/json/F_GBMSGF_FOComunGenerico_E/1?token=" + token;
		String numPagosStr = String.valueOf(numeroPagos);
		while(numPagosStr.length() < 4) {
			numPagosStr = "0".concat(numPagosStr);
		}
		String body = "requestData={\"verificarFirmaVascoStr\":{\"entrada\":{\"key\":\"" + key + "\",\"numPagos\": \"" + numPagosStr + "\",\"importeTotal\": " + montoTotal + "}}}";		
		
	    HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
	    URI uriObtEntOfDay = null;
	    
		requestHeaders.add("token", token);
		uriObtEntOfDay = UriComponentsBuilder.fromUriString(urlToken).build().encode().toUri();
	
	    HttpEntity<String> entityObtEndOfDayIntradiaRequest = new HttpEntity<>(body, requestHeaders);
	    RestTemplate restTemplatePost = apiRestTemplate.getRestTemplate();
	    ResponseEntity<String> response = restTemplatePost.exchange(uriObtEntOfDay, HttpMethod.POST, entityObtEndOfDayIntradiaRequest, String.class);
	    		
	}
	
	public List<DatosFirmaCuentaBenOut> getDatosDigitosCuentaBenQuery(String id) {				
		String sql = "SELECT CASE WHEN pag.N6563_CDMEDPAG IN ('SE','SU') THEN EXTRACTVALUE (XMLTYPE.CREATEXML (NVL (TRIM (loc.O2785_DAT_XML), xmltype ('<ROWS></ROWS>'))),"
	            + "'/CdtTrfTxInf/CdtrAcct/Id/IBAN') ELSE EXTRACTVALUE (XMLTYPE.CREATEXML (NVL (TRIM (loc.O2785_DAT_XML), xmltype ('<ROWS></ROWS>'))), '/CdtTrfTxInf/CdtrAcct/Id/Othr/Id') "
	            + "END AS " + "\"Cuenta Beneficiario\" " + "FROM " + schemaproc + ".sgp_pago pag LEFT JOIN " + schemaproc + ".SGP_PAG_MANL loc ON (pag.N6563_RFTRANS = loc.O2785_RFTRANS) WHERE pag.N6563_ALTAMAN='S' "
	            + "AND N6563_RFTRANS= :idPago union all ( SELECT N6542_CTALOC50 " +"\"Cuenta Beneficiario\" "+ "FROM "+ schemaproc + ".SGP_PAGO LEFT JOIN SGPOWN.SGP_BENEFIC ON (N6563_CLABEN=N2897_CLABEN AND N6563_IDAUTH=N2897_IDAUTH) "
	            + "LEFT JOIN " + schemaproc + ".SGP_BEN_CTAR ON (N6563_CLABEN=N6542_CLABEN) and (N6563_IDAUTH=N6542_IDAUTH) AND (N6542_BENCTA = N6563_BENCTA) LEFT JOIN " + schemaproc + ".SGP_CUENTA cta ON (N6563_ACUENCOT = H1162_ACUENCOT) "
	            +  "WHERE N6563_ALTAMAN='N' AND N6563_RFTRANS= :idPago)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("idPago", id);
			
		return jdbcTemplate.query(sql, params, new DatosFirmaCuentaBenMapper());
	}
	
}
