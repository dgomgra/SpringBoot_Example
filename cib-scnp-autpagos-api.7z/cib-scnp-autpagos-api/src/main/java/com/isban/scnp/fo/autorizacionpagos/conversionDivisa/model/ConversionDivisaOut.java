package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

import java.util.List;

public class ConversionDivisaOut {
	private List<ImporteType> listaImportes;
	private List<DivisaType> listaDivisas;
	private List<DivisaType> listaDivisasSinConversion;
	private String tipoCambio;
	public List<ImporteType> getListaImportes() {
		return listaImportes;
	}
	public void setListaImportes(List<ImporteType> listaImportes) {
		this.listaImportes = listaImportes;
	}

	public List<DivisaType> getListaDivisas() {
		return listaDivisas;
	}
	public void setListaDivisas(List<DivisaType> listaDivisas) {
		this.listaDivisas = listaDivisas;
	}
	public List<DivisaType> getListaDivisasSinConversion() {
		return listaDivisasSinConversion;
	}
	public void setListaDivisasSinConversion(List<DivisaType> listaDivisasSinConversion) {
		this.listaDivisasSinConversion = listaDivisasSinConversion;
	}
	public String getTipoCambio() {
		return tipoCambio;
	}
	public void setTipoCambio(String tipoCambio) {
		this.tipoCambio = tipoCambio;
	}
}
