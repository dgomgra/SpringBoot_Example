package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class MetodosPagoArbol {

	private String codMedioPago;
	private String codTipoPago;
	
	public String getCodMedioPago() {
		return codMedioPago;
	}
	public void setCodMedioPago(String codMedioPago) {
		this.codMedioPago = codMedioPago;
	}
	public String getCodTipoPago() {
		return codTipoPago;
	}
	public void setCodTipoPago(String codTipoPago) {
		this.codTipoPago = codTipoPago;
	}

}
