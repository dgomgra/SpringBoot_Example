/**
 * 
 */
/**
 * @author dagonzalez
 *
 */
package com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.impl;