package com.isban.scnp.fo.autorizacionpagos.listalotes.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.ListaLotesHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "AutorizacionLotesRestController", description = "Operations pertaining to Batches Authorization")
public class ListaLotesRestController {

	private static final String STR_KO = "KO";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_LISTA_DE_LOTES = "Lista de lotes";
	private static final String STR_DETALLE_DE_LOTE = "Detalle de lote";
	private static final String STR_ERROR = "error";
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";

	@Autowired
	private ListaLotesHelperService listaLotesHelperService;
	
	@RequestMapping(value = "/v1/listadoLotesAutorizar", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get the list of batches of user profilled accounts")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	public ResponseEntity<ListaLotesAutorizarResponse> getListaLotesAutorizarByPage(@RequestBody ListaLotesRequest listaLotesRequest){	
		
		try {
			
			log.debug("REST POST call received in /v1/listadoLotesAutorizar {} {} {}", 
					listaLotesRequest.getNumPorPagina(), 
					listaLotesRequest.getNumPagina(), 
					listaLotesRequest.getMonedaConsolidacion());

			
			ListaLotesAutorizarResponse listaLotesAutorizarResponse = listaLotesHelperService.getListaLotesAutorizarByPage(listaLotesRequest, false);
			return new ResponseEntity<>(listaLotesAutorizarResponse, HttpStatus.OK);
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_LOTES + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			ListaLotesAutorizarResponse listaLotesAutorizarResponse = new ListaLotesAutorizarResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				listaLotesAutorizarResponse.setStatus(STR_KO);
				listaLotesAutorizarResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(listaLotesAutorizarResponse, HttpStatus.UNAUTHORIZED);
			}else {
				listaLotesAutorizarResponse.setStatus(STR_KO);
				listaLotesAutorizarResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(listaLotesAutorizarResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}					
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_LOTES + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			ListaLotesAutorizarResponse listaLotesAutorizarResponse = new ListaLotesAutorizarResponse();
			listaLotesAutorizarResponse.setStatus(STR_KO);
			listaLotesAutorizarResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(listaLotesAutorizarResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping(value = "/v1/detalleLote", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get the details of a specified batch")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	public ResponseEntity<DetalleLoteResponse> getDetalleLotes(@RequestBody DetalleLoteRequest detalleLoteRequest){
		
		try
		{
			log.debug("REST POST call received in /v1/detalleLote {}", 
					detalleLoteRequest.getNumLote());
			
				
			DetalleLoteResponse detalleloteResponse = listaLotesHelperService.getDetalleLoteImp(detalleLoteRequest);
			return new ResponseEntity<>(detalleloteResponse, HttpStatus.OK);
		
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_LOTES + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			DetalleLoteResponse detalleloteResponse = new DetalleLoteResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				detalleloteResponse.setStatus(STR_KO);
				detalleloteResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(detalleloteResponse, HttpStatus.UNAUTHORIZED);
			}else {
				detalleloteResponse.setStatus(STR_KO);
				detalleloteResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(detalleloteResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}		
		}catch (Exception e)
		{
			log.error(STR_ERROR + STR_ESPACIO + STR_DETALLE_DE_LOTE + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			DetalleLoteResponse detalleloteResponse = new DetalleLoteResponse();
			detalleloteResponse.setStatus(STR_KO);
			detalleloteResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(detalleloteResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
		
}
