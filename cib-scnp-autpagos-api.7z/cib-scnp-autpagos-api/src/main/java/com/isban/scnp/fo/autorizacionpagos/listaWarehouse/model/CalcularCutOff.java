package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.util.Date;

public class CalcularCutOff {
	private Date fechaCutOff;
	private Date fechaPaisOrigen;
	public Date getFechaCutOff() {
		return fechaCutOff;
	}
	public void setFechaCutOff(Date fechaCutOff) {
		this.fechaCutOff = fechaCutOff;
	}
	public Date getFechaPaisOrigen() {
		return fechaPaisOrigen;
	}
	public void setFechaPaisOrigen(Date fechaPaisOrigen) {
		this.fechaPaisOrigen = fechaPaisOrigen;
	}
}
