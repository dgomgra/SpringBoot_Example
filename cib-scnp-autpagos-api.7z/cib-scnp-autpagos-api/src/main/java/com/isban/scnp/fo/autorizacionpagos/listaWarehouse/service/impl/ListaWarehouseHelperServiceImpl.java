package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.Importe;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ListaImportes;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.ConversionDivisaHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOff;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOffDatosE;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOffIn;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOffRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOffRequestData;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOffResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.CalcularCutOff_S;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ClaveValor;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ClaveValorMapper;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ConsultaPagosCreados_S;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosLotesWarehousing;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosPagoDeLoteW;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosPagoLoteW;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosPagoWarehousing;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.IdiomaUsuario;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.IdiomaUsuarioMapper;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;

@Slf4j
@Service
public class ListaWarehouseHelperServiceImpl implements ListaWarehouseHelperService {
	private static final String STR_0_00 = "0.00";

	private static final String STR_NULL = "null";

	private static final int MAX_DATOS_QUERY = 1000;

	private static final String STR_OK = "OK";
	private static final String STR_KO = "KO";
	private static final String STR_N = "N";
	private static final String STR_S = "S";
	private static final String STR_EUR = "EUR";
	private static final String STR_GBP = "GBP";
	private static final String STR_USD = "USD";
	private static final String STR_COMILLA = "'";
	private static final String STR_VACIO = "";	
	private static final String STR_ERROR = "error";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_LISTA_WAREHOUSE = "Lista de pagos Warehouse";
	private static final String STR_RESULT = "result";
	private static final String STR_FORMATO_FECHA = "yyyy-MM-dd";
	private static final String STR_MT101 = "MT";
	private static final String STR_ERROR_NO_FIRMA = "0023";
	private static final String STR_ERROR_GENERAL = "0001";
	private static final String STR_ERROR_NO_HAY_DATOS = "0000";
	private static final String STR_ERROR_PARAMETROS = "0053";
	private static final String STR_MSG_OK = "OK";

    @Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ConversionDivisaHelperService conversionDivisaHelperService;
	
	@Autowired
	private ListaPagosHelperService listaPagosHelperService;
	
	@Autowired
	private ApiRestTemplate apiRestTemplate;
	
    @Value("${urlBks}")
    protected String urlBks;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	private void closeConnection ()
	{
		try {
			if (jdbcTemplate!=null)
			{
				jdbcTemplate.getDataSource().getConnection().close();
			}
		} catch (SQLException e) {			
		}
		
	}
	
	public CalcularCutOffResponse calcularCutOff (CalcularCutOffRequest request)
	{
		String token = request.getToken();
		String json = null;
		try {
			json = convertToJson(request.getRequestData());
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_WAREHOUSE + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			json = STR_VACIO;
		}
		
		String urlCalcularCutOff = urlBks + "/json/F_GBMSGF_FOComunPagos_E/1?token=" + token;
        URI uriCalcularCutOff = UriComponentsBuilder.fromUriString(urlCalcularCutOff).build().encode().toUri();
        
        String body = "requestData="+json;

        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        requestHeaders.add("token", token);
        
        HttpEntity<String> entityRequest = new HttpEntity<>(body, requestHeaders);

        RestTemplate restTemplatePost = apiRestTemplate.getRestTemplate();
        ResponseEntity<CalcularCutOffResponse> response = restTemplatePost.exchange(uriCalcularCutOff, HttpMethod.POST, entityRequest, CalcularCutOffResponse.class);
        return response.getBody();        
	}
	private String convertToJson (CalcularCutOffRequestData o) throws JsonProcessingException 
	{
		//Object to JSON in String
		
		ObjectMapper mapper = new ObjectMapper();		
			
		String jsonInString = mapper.writeValueAsString(o);
	
		return jsonInString;
	
	}

	private String convertArray2String (List<?> lista)
	{
		int tamLista= lista.size();
		StringBuilder sb = new StringBuilder();
		for (int i=0;i<tamLista;i++)
		{
			Object elem = lista.get(i);

			if (i>0)
			{
				sb=sb.append(" , ");
			}
			if (elem instanceof String)
			{
				sb=sb.append(STR_COMILLA).append(elem).append(STR_COMILLA);
			}
			else
			{
				sb=sb.append(elem);
			}
		}
		return sb.toString();
	}

	
	public List<String> traducirMulidi (String tipoDatoMulidi, List<String> listaDatosTraducir, String usuario)
	{
		List<String> resultado = new ArrayList<> (0);
		
		if (listaDatosTraducir!=null && !listaDatosTraducir.isEmpty())
		{
		
			usuario = String.format("%1$-30s", usuario);
			tipoDatoMulidi = String.format("%1$-25s", tipoDatoMulidi);
	
			Set<String> hsEstados = new HashSet<> (0);
			int tamListaEstados = listaDatosTraducir.size();
			for (int i=0;i<tamListaEstados;i++)
			{
				String estado = listaDatosTraducir.get(i);
				estado = String.format("%1$-40s", estado);
				hsEstados.add(estado);
			}
			
			List<String> estados = new ArrayList<>(hsEstados);			
		
			List<String> listaTemp = new ArrayList<>();
			List<ClaveValor> salida = new ArrayList<>();		
			List<ClaveValor> salidaTemp = new ArrayList<>();
			
			int tamListaIds = estados.size();
			if (tamListaIds>0)
			{
				int numIters = tamListaIds/MAX_DATOS_QUERY + ((tamListaIds%MAX_DATOS_QUERY)>0? 1:0);
				
				for (int i = 0;i<numIters;i++)
				{
					int tamMin = Math.min(MAX_DATOS_QUERY*(i+1),tamListaIds);
					listaTemp.clear();
					for (int j=i*MAX_DATOS_QUERY;j<tamMin;j++)
					{
						listaTemp.add(estados.get(j));
						
					}
					
					salidaTemp = traducirMulidiQuery (tipoDatoMulidi, estados, usuario);
					
					salida.addAll(salidaTemp);
				
				}
			}
			
			Map<String, String> mapaClaveValor = new HashMap<>(0);
			int tamLista = salida.size();
			for (int i=0;i<tamLista;i++)
			{
				ClaveValor claveValorActual = salida.get(i);
				String clave = claveValorActual.getClave().trim();
				String valor = claveValorActual.getValor().trim();
				mapaClaveValor.put(clave, valor);
			}
			
			int tamListaDatos = listaDatosTraducir.size();
			for (int i=0;i<tamListaDatos;i++)
			{
				String datoEntrada = listaDatosTraducir.get(i);
				String valor = mapaClaveValor.containsKey(datoEntrada)? mapaClaveValor.get(datoEntrada) : STR_VACIO;
				resultado.add(valor);
			}
		}
		return resultado;		
	}	
	
	public List<ClaveValor> traducirMulidiQuery (String tipoDatoMulidi, List<String> estados, String usuario)
	{

		String strListaEstados = convertArray2String(estados);
		String sql ="SELECT G0657_IDENDATO, G0657_TRADUC FROM " + schemaproc + ".SGP_USUARIO, " + schemaproc + ".TXT_MULIDI_GRAL "+
				"WHERE H1186_UID = ? " +
				"AND G0657_CODTRADU = ? " + 
				"AND G0657_IDIOMASC = H1186_IDIOMASC " + //p_idioma_usuario
				"AND G0657_CODPAIS  = H1186_CODPAIS " + //p_pais_usuario
				"AND G0657_IDENDATO IN ({strListaEstados}) " + //N6563_ESTPAGO
				"AND G0657_CONCEPCT = '001' " + 
				"AND G0657_INTIPTRA = '0'";
		
		sql = sql.replace("{strListaEstados}", strListaEstados);
		
		Object[] params = new Object[] {usuario, tipoDatoMulidi};
		
		 return jdbcTemplate.query(sql, params, new ClaveValorMapper());
	}
	
	public List<String> obtenerUltimaNota (List<ConsultaPagosCreados_S> listaPagos)
	{
		
		List<String> resultado = new ArrayList<>(0);
		Map <String, String> mapaPagoNota = new HashMap<> (0);
		
		int tamListaPagos = listaPagos.size();
		if (tamListaPagos>0)
		{
			int numIters = tamListaPagos/MAX_DATOS_QUERY + 1;
			
			for (int i = 0;i<numIters;i++)
			{
				StringBuilder sbListaPagos = new StringBuilder();
				
				int tamMin = Math.min(MAX_DATOS_QUERY*(i+1),tamListaPagos);
				
				for (int j=i*MAX_DATOS_QUERY;j<tamMin;j++)
				{
					String concatenar = (j>i*MAX_DATOS_QUERY) ? ", ": STR_VACIO;
					concatenar=concatenar.concat("'".concat(listaPagos.get(j).getRefSistema()).concat("'"));
					sbListaPagos.append(concatenar);
				}
				String strListaPagos = sbListaPagos.toString();
				
				String sql = "SELECT O2765_RFTRANS, O2760_ANOTAS FROM " + schemaproc + ".SGP_NOTA " + 
						"RIGHT JOIN( " + 
						"SELECT O2765_RFTRANS, MAX(O2765_CDNOTA) AS CODNOTA FROM " + schemaproc + ".SGP_R_NOTA_PAG " + 
						"WHERE O2765_RFTRANS IN ("+ strListaPagos +") " + 
						"GROUP BY O2765_RFTRANS " + 
						") PAGNOTA " + 
						"ON (SGP_NOTA.O2760_CDNOTA = PAGNOTA.CODNOTA)";
				
				Object[] params = new Object[] {};
				
				List<ClaveValor> resultadoQuery = jdbcTemplate.query(sql, params, new ClaveValorMapper());
				
				for (ClaveValor elem : resultadoQuery)
				{
					String idPago = elem.getClave();
					String nota = elem.getValor();
					
					mapaPagoNota.put(idPago, nota);
				}
			}		
			
			for (int i = 0;i<tamListaPagos;i++)
			{
				String idPago = listaPagos.get(i).getRefSistema();
				String nota = mapaPagoNota.containsKey(idPago) ? mapaPagoNota.get(idPago):STR_VACIO;
				resultado.add(nota);
			}
		}
		return resultado;
	}
	
	
	
	private List prepararPagina(int numPagina, int numPorPagina,
			List listaCompleta) {
		
		List salida = new ArrayList<>(0);

		int tamListaCompleta = listaCompleta.size();
		if (tamListaCompleta>(numPagina*numPorPagina))
		{
			int ini = numPagina*numPorPagina;
			int fin = ini+numPorPagina;
			if (fin>listaCompleta.size())
			{
				fin = listaCompleta.size();
			}
			for (int i=ini;i<fin;i++)
			{
				Object elemento = listaCompleta.get(i);
				salida.add(elemento);
			}
		}
		return salida;
	}
	
	private List<CalcularCutOff_S> obtenerCutOffs (String tokenBks, List<ConsultaPagosCreados_S> listaPagosCreados)
	{
		CalcularCutOffResponse calcularCutOffResponse = new CalcularCutOffResponse();
		
		CalcularCutOffRequest calcularCutOffRequest = new CalcularCutOffRequest();
		CalcularCutOffIn datosEntrada = new CalcularCutOffIn();	
		
		if (!listaPagosCreados.isEmpty())
		{
			int tamListaDatosPagos = listaPagosCreados.size();
			for (int i=0;i<tamListaDatosPagos;i++)
			{
				ConsultaPagosCreados_S datosPago = listaPagosCreados.get(i);
	
				BigDecimal importe = datosPago.getImporte();
				String divisa = datosPago.getDivisa();
				ImporteType impT = new ImporteType(importe, divisa);			
				
				CalcularCutOffDatosE datosCutOff = new CalcularCutOffDatosE();
				datosCutOff.setCodMedioPag(datosPago.getCodMedioPago());
				datosCutOff.setIdCuenta(datosPago.getCuenta());
				datosCutOff.setCodEnt(datosPago.getCodEnt());
				datosCutOff.setMontoDivisa(impT);
				datosCutOff.setIndTransTED(STR_VACIO);

				datosEntrada.addEntrada(datosCutOff);
			}
		
			calcularCutOffRequest.getRequestData().setCalcularCutOff(datosEntrada);
			calcularCutOffRequest.setToken(tokenBks);
			
			calcularCutOffResponse=calcularCutOff(calcularCutOffRequest);
		}
		return calcularCutOffResponse.getMethodResult();
		
	}
	

	private List<DatosPagoWarehousing> obtenerListadoWarehouse (String uidLogado, String tokenBks)
	{
		IdiomaUsuario idiomaUsuario = obtenerIdiomaUsuario(uidLogado);	
		
		List<ConsultaPagosCreados_S> listaPagosCreados = getPagosUsuarioAutorizProcedure(uidLogado, idiomaUsuario);		
		
		List<CalcularCutOff_S> listaCutOffs = listaPagosCreados.isEmpty() ? new ArrayList<> (0) : obtenerCutOffs(tokenBks, listaPagosCreados);
		
		List<String> listaNotas = listaPagosCreados.isEmpty() ? new ArrayList<> (0) :obtenerUltimaNota (listaPagosCreados);

		List<DatosPagoWarehousing> listaSalida = listaPagosCreados.isEmpty() ? new ArrayList<>() : completarSalida (listaPagosCreados, listaCutOffs, listaNotas);		
		
		closeConnection ();
		return listaSalida;
	}
	
	private String obtenerIndStopPayment (ConsultaPagosCreados_S datosPago, CalcularCutOff_S datosCutOff)
	{
		String indPermisoSTP = datosPago.getIndStopPayment();
		
		String retorno = indPermisoSTP;
		if (STR_S.equals(indPermisoSTP))
		{
			Calendar fechaCutOff = Calendar.getInstance();
			Calendar fechaPago = Calendar.getInstance();
			//recuperamos el pago para saber si está en el map de permisos stopPayment

			//ponemos la fechaPago en un calendar y le ponemos la hora 05:00
			// si fechaCutOff es menor que fechaPago

			Calendar fechOrg = Calendar.getInstance();
			fechOrg.setTime(datosCutOff.getCutOff().getFechaPaisOrigen());
			fechaCutOff.setTime(datosCutOff.getCutOff().getFechaCutOff());

			fechaPago.setTime(datosPago.getFecha());

			fechaCutOff.set(Calendar.HOUR_OF_DAY, 5);
			fechaCutOff.set(Calendar.MINUTE, 0);
			fechaCutOff.set(Calendar.SECOND, 0);
			fechaCutOff.set(Calendar.MILLISECOND, 0);

			if (!(fechaCutOff.get(Calendar.DAY_OF_MONTH)==fechaPago.get(Calendar.DAY_OF_MONTH) && 
					fechaCutOff.get(Calendar.MONTH)==fechaPago.get(Calendar.MONTH) &&
					fechaCutOff.get(Calendar.YEAR)==fechaPago.get(Calendar.YEAR))){
				//si no es la misma fecha
				//hay que comparar que la fecha de cutoff sea anterior a la fecha del pago
				//hay que comparar que la fecha de cutoff sea anterior a la fecha del pago
				if(fechaCutOff.after(fechaPago))
				{
					retorno = STR_N;
				}
				else 
				{
					retorno = STR_S;
				}
			}
			else{
				//si es el mismo dia hora cutoff tiene que ser anteiror a la del pago
				if(fechaCutOff.after(fechOrg))
				{
					retorno = STR_S;
				} 
				else
				{
					retorno = STR_N;
				}
			}
		}
		return retorno;
	}
	
	private List<DatosPagoWarehousing> completarSalida(List<ConsultaPagosCreados_S> listaPagos, List<CalcularCutOff_S> listaCutOffs, List<String> listaNotas) {
		
		List<DatosPagoWarehousing> salida = new ArrayList<> (0);

		int tamListaPagos = listaPagos.size();
		
		for (int i=0;i<tamListaPagos;i++)
		{
			ConsultaPagosCreados_S pago = listaPagos.get(i);
			
			DatosPagoWarehousing nuevoPago = new DatosPagoWarehousing();
			nuevoPago.setRftrans(pago.getRefSistema());
			nuevoPago.setIndNota(pago.getIndNota());
			nuevoPago.setUltimaNota(listaNotas.get(i));
			nuevoPago.setIndImp(pago.getIndImp());
			nuevoPago.setIdEstado(pago.getIdEstado());
			nuevoPago.setCodExtracto(pago.getCodExtracto());
			nuevoPago.setNomBenef(pago.getNomBenef());
			nuevoPago.setCodBeneficiario(pago.getCodBeneficiario());
			nuevoPago.setIdAutorizacion(pago.getIdAutorizacionBeneficiario());
			nuevoPago.setImporte(pago.getImporte());
			nuevoPago.setDivisa(pago.getDivisa());
			nuevoPago.setFecha(pago.getFecha());
			nuevoPago.setRefCliente(pago.getRefCliente());
			nuevoPago.setIndicadorUpload(pago.getIndicadorUpload());
			nuevoPago.setCodPais(pago.getPais());
			nuevoPago.setCodMedioPago(pago.getCodMedioPago());
			nuevoPago.setDescEstPago(pago.getDescEstPago());
			nuevoPago.setCuentaOrdenante(pago.getCuenta());
			nuevoPago.setAliasCuentaOrdenante(pago.getAliasCuentaOrdenante());
			nuevoPago.setIndStopPayment(obtenerIndStopPayment(pago, listaCutOffs.get(i)));	
			
			salida.add(nuevoPago);
		}
		return salida;
	}
	public ListaPagosWarehouseResponse getListaPagosWarehouseImp(ListaWarehouseRequest request){		

			// Obtenemos el usuario logado
		
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	                Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails)auth.getDetails();
			uidLogado = santanderUD.getUid();			
		}
			
			String tokenBks = request.getTokenBks();
			int numPagina = request.getNumPagina();
			int numPorPagina = request.getNumPorPagina();
						
			// Comprobamos si el usuario tiene firma
			String uidToken = listaPagosHelperService.comprobarTokenSKeyUsu(uidLogado);
			uidToken = uidToken==null ? STR_VACIO : uidToken.trim();
			
			if(uidToken != null && uidToken.equals(uidLogado)) {
			
				ListaPagosWarehouseResponse salida = new ListaPagosWarehouseResponse();
								
				List<DatosPagoWarehousing> listaCompleta = obtenerListadoWarehouse(uidLogado, tokenBks);				
				Collections.sort(listaCompleta);
				Integer totalRegistros = listaCompleta.size();
				
				return prepararSalida(numPagina, numPorPagina, salida, listaCompleta, totalRegistros);
			}
			else
			{
				ListaPagosWarehouseResponse listaPagosWarehouseResponse = new ListaPagosWarehouseResponse();
				listaPagosWarehouseResponse.setStatus(STR_KO);
				listaPagosWarehouseResponse.setMessage(STR_ERROR_NO_FIRMA);
				return listaPagosWarehouseResponse;
			}
	}
	private ListaPagosWarehouseResponse prepararSalida(int numPagina, int numPorPagina,
			ListaPagosWarehouseResponse salida, List<DatosPagoWarehousing> listaCompleta, Integer totalRegistros) {
		List<DatosPagoWarehousing> listaSalida = prepararPagina (numPagina-1, numPorPagina, listaCompleta);
		
		if (!listaCompleta.isEmpty())
		{
			salida.setListaDatosPagosWarehousing(listaSalida);
			salida.setPagina(numPagina);
			salida.setTotalPagos(totalRegistros);
			
			comprobarErrorPagina(salida, listaSalida);
			
			salida.setListaDatosPagosWarehousing(listaSalida);
			salida.setPagina(numPagina);
			salida.setTotalPagos(totalRegistros);

			return salida;
		}
		else {
			ListaPagosWarehouseResponse listaPagosWarehouseResponse = new ListaPagosWarehouseResponse();
			listaPagosWarehouseResponse.setStatus(STR_KO);
			listaPagosWarehouseResponse.setMessage(STR_ERROR_NO_HAY_DATOS);
			return listaPagosWarehouseResponse;
		}
	}
	
	private List<DatosLotesWarehousing> obtenerDivisasConvertidas (List<DatosLotesWarehousing> listaLotes, String monConsolidacion, String tokenBKS)
	{
		List<ListaImportes> listaGruposImportes = new ArrayList<ListaImportes>(0);
		int tamLotes = listaLotes.size();
		for (int i=0;i<tamLotes;i++)
		{
			ListaImportes listaImportes  = new ListaImportes();
			String divisaInicial = listaLotes.get(i).getDivisaLote();
			BigDecimal importeInicial = listaLotes.get(i).getImpLote();
			
			com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType importeAnadir = new com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType(importeInicial, divisaInicial);		
			Importe imp = new Importe(importeAnadir);
			listaImportes.addImporte(imp);
				
			listaGruposImportes.add(listaImportes);
		}		
		
		
		ConversionDivisaRequest conversionDivisaRequest = new ConversionDivisaRequest();
		conversionDivisaRequest.getRequestData().getConversionDivisa().getEntrada().setDivisaConsolidacion(monConsolidacion);
		conversionDivisaRequest.getRequestData().getConversionDivisa().getEntrada().setListaGruposImportes(listaGruposImportes);
		conversionDivisaRequest.setToken(tokenBKS);
		
		ConversionDivisaResponse conversionDivisaResponse = conversionDivisaHelperService.conversionDivisa(conversionDivisaRequest);
		
		if (conversionDivisaResponse.getMethodResult().getListaImportes().size()==listaLotes.size())
		{
			for (int i=0;i<tamLotes;i++)
			{
				
				listaLotes.get(i).setImpLote(conversionDivisaResponse.getMethodResult().getListaImportes().get(i).getIMPORTE());
				listaLotes.get(i).setDivisaLote(conversionDivisaResponse.getMethodResult().getListaImportes().get(i).getDIVISA());
			}
		}

		return listaLotes;				
	}
	
	public List<String> obtenerListaDivisas (String monConsolidacion, List <DatosLotesWarehousing> listaSalida)
	{

		Set<String> hsDivisas = new HashSet<String>(0);
		List<String> retorno = new ArrayList<String>(0);
		for (DatosLotesWarehousing datosLote : listaSalida)
		{
			String divisa = datosLote.getDivisaLote().trim();
			if (!hsDivisas.contains(divisa))
			{				
				hsDivisas.add(divisa);
			}
		}

		if (!STR_VACIO.equals(monConsolidacion))
		{
			hsDivisas.add(monConsolidacion);
		}
		if (!hsDivisas.isEmpty())
		{
			hsDivisas.add(STR_EUR);
			hsDivisas.add(STR_USD);
			hsDivisas.add(STR_GBP);
			
			retorno.add(STR_EUR);
			retorno.add(STR_USD);
			retorno.add(STR_GBP);
			
			Iterator<String> itDivisas = hsDivisas.iterator();
			while (itDivisas.hasNext())
			{
				String divisa = itDivisas.next();
				if (!retorno.contains(divisa))
				{
					retorno.add(divisa);
					hsDivisas.add(divisa);
				}
			}
		}
		return retorno;
	}
	
	private ListaLotesWarehouseResponse prepararSalidaLotes(int numPagina, int numPorPagina,
			ListaLotesWarehouseResponse salida, List<DatosLotesWarehousing> listaCompleta, Integer totalRegistros, String tokenBks, String monConsolidacion, boolean resumen) {
		List <String> listaDivisas = new ArrayList <String>(0);
		List <DatosLotesWarehousing> listaSalida = new ArrayList <DatosLotesWarehousing>(0);

			listaSalida = prepararPagina (numPagina-1, numPorPagina, listaCompleta);
		if (!resumen)
		{
			listaSalida = obtenerDivisasConvertidas(listaSalida, monConsolidacion, tokenBks);
			if (STR_VACIO.equals(monConsolidacion) && !listaSalida.isEmpty())
			{
				monConsolidacion=listaSalida.get(0).getDivisaLote();
			}
			listaDivisas = obtenerListaDivisas(monConsolidacion, listaSalida);
			salida.setListaDivisas(listaDivisas);
		}
		if (!listaCompleta.isEmpty())
		{
			salida.setListaDatosLotesWarehousing(listaSalida);
			salida.setPagina(numPagina);
			salida.setTotalLotes(totalRegistros);
			
			comprobarErrorPagina(salida, listaSalida);
			
			salida.setListaDatosLotesWarehousing(listaSalida);
			salida.setPagina(numPagina);
			salida.setTotalLotes(totalRegistros);

			return salida;
		}
		else {
			ListaLotesWarehouseResponse listaLotesWarehouseResponse = new ListaLotesWarehouseResponse();
			listaLotesWarehouseResponse.setStatus(STR_KO);
			listaLotesWarehouseResponse.setMessage(STR_ERROR_NO_HAY_DATOS);
			return listaLotesWarehouseResponse;
		}
	}
	
	private void comprobarErrorPagina(Object salida, List listaSalida) {
		
		
		if (salida instanceof ListaPagosWarehouseResponse)
		{
			if (listaSalida.isEmpty())
			{
				((ListaPagosWarehouseResponse) salida).setStatus(STR_KO);
				((ListaPagosWarehouseResponse) salida).setMessage(STR_ERROR_PARAMETROS);
			}
			else
			{
				((ListaPagosWarehouseResponse) salida).setStatus(STR_OK);
				((ListaPagosWarehouseResponse) salida).setMessage(STR_MSG_OK);
			}
		}
		else
		{
			if (listaSalida.isEmpty())
			{
				((ListaLotesWarehouseResponse) salida).setStatus(STR_KO);
				((ListaLotesWarehouseResponse) salida).setMessage(STR_ERROR_PARAMETROS);
			}
			else
			{
				((ListaLotesWarehouseResponse) salida).setStatus(STR_OK);
				((ListaLotesWarehouseResponse) salida).setMessage(STR_MSG_OK);
			}
		}
	}
	
	public IdiomaUsuario obtenerIdiomaUsuario (String uid)
	{
		String sql = "SELECT H1186_IDIOMASC, H1186_CODPAIS FROM " + schemaproc + ".SGP_USUARIO WHERE H1186_UID= ?";
	
		// Rellenamos con espacios
		uid = String.format("%1$-30s", uid);
		
		Object[] params = new Object[] {uid};
		
		List<IdiomaUsuario> resultadoQuery = jdbcTemplate.query(sql, params, new IdiomaUsuarioMapper());
		
		if (!resultadoQuery.isEmpty())
		{
			return resultadoQuery.get(0);
		}
		else 
		{
			return null;
		}
	}
	
	public List<ConsultaPagosCreados_S> getPagosUsuarioAutorizProcedure (String uidLogado, IdiomaUsuario idiomaUsuario)
	{
		List<ConsultaPagosCreados_S> salida = new ArrayList<>();
		List<SqlParameter> prmtrsList = new ArrayList<>();
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR)); //p_usuario
	        prmtrsList.add(new SqlParameter(OracleTypes.DATE)); 	//p_fecha_desde
	        prmtrsList.add(new SqlParameter(OracleTypes.DATE));	//p_fecha_hasta
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_monto_desde
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_monto_hasta
	        prmtrsList.add(new SqlParameter(OracleTypes.DECIMAL));	//p_monto_desde
	        prmtrsList.add(new SqlParameter(OracleTypes.DECIMAL));	//p_monto_hasta
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_cod_pais
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_pais
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_ref_cliente
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ref_cliente
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_nom_benef
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_nom_benef
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_cuenta_debito
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_cuenta_debito
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_metodo_pago
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_lista_cod_metodo_pago
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_estado
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_lista_id_estado_pago
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_primera_busq
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_id_lote
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_idioma_usuario
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_pais_usuario
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_origen
	        prmtrsList.add(new SqlOutParameter(STR_RESULT, OracleTypes.CURSOR));	//p_cursor
	    
	        // Calculamos las fechas desde hoy hasta 90 dias
	        Calendar cal = Calendar.getInstance();
			Date hoy = new Date();
			cal.setTime(hoy);
			cal.add(Calendar.DAY_OF_YEAR, 90);
			
			SimpleDateFormat formatFecha = new SimpleDateFormat(STR_FORMATO_FECHA);
			
			String fechaIni = formatFecha.format(hoy.getTime());
			String fechaFin = formatFecha.format(cal.getTime());
	        BigDecimal impDesde = new BigDecimal(STR_0_00);
	        BigDecimal impHasta = new BigDecimal(STR_0_00);
	        
        Map<String, Object> datos = jdbcTemplate.call(new CallableStatementCreator() {
  	      
        public CallableStatement createCallableStatement(Connection connection) throws SQLException {        

        int numParam = 0;
        
        String query = "{call " + schemaproc + ".PKG_LISTADO.GET_PAGOS (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}"; 
        CallableStatement callableStatement = connection.prepareCall(query);
        callableStatement.setString(++numParam, uidLogado);                      //p_usuario
        callableStatement.setDate(++numParam, java.sql.Date.valueOf(fechaIni));  //p_fecha_desde
        callableStatement.setDate(++numParam, java.sql.Date.valueOf(fechaFin));  //p_fecha_hasta
        callableStatement.setString(++numParam, STR_N);                            //p_ind_monto_desde
        callableStatement.setString(++numParam, STR_N);                            //p_ind_monto_hasta
        callableStatement.setBigDecimal(++numParam, impDesde);                   //p_monto_desde
        callableStatement.setBigDecimal(++numParam, impHasta);                   //p_monto_hasta
        callableStatement.setString(++numParam, STR_N);                        //p_ind_cod_pais
        callableStatement.setString(++numParam, STR_VACIO);                        //p_pais
        callableStatement.setString(++numParam, STR_N);                           //p_ind_ref_cliente
        callableStatement.setString(++numParam, STR_VACIO);                     //p_ref_cliente
        callableStatement.setString(++numParam, STR_N);                           //p_ind_nom_benef
        callableStatement.setString(++numParam, STR_VACIO);                     //p_nom_benef
        callableStatement.setString(++numParam, STR_N);                           //p_ind_cuenta_debito
        callableStatement.setString(++numParam, STR_VACIO);                     //p_cuenta_debito
        callableStatement.setString(++numParam, STR_N);                           //p_ind_metodo_pago
        callableStatement.setString(++numParam, STR_VACIO);                     //p_lista_cod_metodo_pago
        callableStatement.setString(++numParam, STR_N);                         //p_ind_estado
        callableStatement.setString(++numParam, STR_VACIO);                       //p_lista_id_estado_pago
        callableStatement.setString(++numParam, STR_N);                           //p_ind_primera_busq
        callableStatement.setString(++numParam, STR_VACIO);                          //p_id_lote
        callableStatement.setString(++numParam, idiomaUsuario.getIdioma());                         //p_idioma_usuario
        callableStatement.setString(++numParam, idiomaUsuario.getPais());                          //p_pais_usuario
        callableStatement.setString(++numParam, "W");                          //p_ind_origen
        callableStatement.registerOutParameter(++numParam, OracleTypes.CURSOR);                //cursor (OracleTypes.CURSOR = -10)
        return callableStatement;

        }
        }, prmtrsList);
        
        if(datos.containsKey(STR_RESULT)) {
        	        	
        	List<Map<String, Object>> listaObjetos = (List<Map<String, Object>>)datos.get(STR_RESULT);
        	
        	for (int i = 0; i < listaObjetos.size(); i++) {
        		
        		ConsultaPagosCreados_S datosPagoCreado  = rellenarDatos (listaObjetos.get(i));        		
        		salida.add(datosPagoCreado);     		
        	}
        	
        }
        return salida;
	}
	
	private ConsultaPagosCreados_S rellenarDatos(Map<String, Object> map) {
			SimpleDateFormat formatFecha = new SimpleDateFormat(STR_FORMATO_FECHA);
			
			ConsultaPagosCreados_S datosPagoWarehousing = new ConsultaPagosCreados_S();
			
			String idPago 	= String.valueOf(map.get("N6563_RFTRANS"));
			String moneda	= String.valueOf(map.get("N6563_CODMONSWI"));
			
			BigDecimal monto = new BigDecimal (String.valueOf(map.get("N6563_CANTPAGL")));
			monto = monto.setScale(2, RoundingMode.HALF_UP);
			
			Date fecVal;
			try {
				fecVal = formatFecha.parse(String.valueOf(map.get("N6563_FEC_VAL")));
			} catch (ParseException exc) {
				fecVal = null;
			}
	
	        String refCli 	= 	String.valueOf(map.get("N6563_CLIREFER"));
	        String medPago 	=	String.valueOf(map.get("N6563_CDMEDPAG"));
	
			String idEstado		= String.valueOf(map.get("N6563_ESTPAGO"));
			String codCtaEx 	= String.valueOf(map.get("H1162_CODCTAEX"));
			String aliasCuenta 	= STR_NULL.equals(String.valueOf(map.get("H5204_ALITE15"))) ? STR_VACIO: String.valueOf(map.get("H5204_ALITE15"));
			
			int entidadCuenta = Integer.parseInt(String.valueOf(map.get("H1162_CENTBSGP")));
			
			String nombreS1_N2897	= String.valueOf(map.get("N2897_NOMBENS1"));
			String nombreC_N2897	= String.valueOf(map.get("N2897_NOMBENC"));
			String nombreS1_O2785	= String.valueOf(map.get("O2785_NOMBENS1"));
			String nombreC_N6564 	= String.valueOf(map.get("N6564_NOMBENC"));
			
			String pais 	= String.valueOf(map.get("N6563_CODPAIS"));
			int claben 		= Integer.parseInt(String.valueOf(map.get("N6563_CLABEN")));
				
			int idauth;
			try {
				idauth = Integer.parseInt(String.valueOf(map.get("N2897_IDAUTH")));
			} catch (NumberFormatException e) {
				idauth=0;
			}		
			int acuencot 	= Integer.parseInt(String.valueOf(map.get("N6563_ACUENCOT")));
			
			String indModifi 	= String.valueOf(map.get("N6563_INMODIFI"));
			String indUplPago	= String.valueOf(map.get("INDUPL_PAGO"));
			String indNotaPago	= String.valueOf(map.get("INDNOTA_PAGO"));
			String indStopPayment = String.valueOf(map.get("PERMISO_STP"));
			
			String estado		= String.valueOf(map.get("ESTADO_TRAD"));
			
			// SetData
			datosPagoWarehousing.setIndNota(indNotaPago.trim());
			datosPagoWarehousing.setIndImp(indModifi.trim());
			datosPagoWarehousing.setIndicadorUpload(indUplPago.trim());
			datosPagoWarehousing.setIndStopPayment(indStopPayment.trim());
			datosPagoWarehousing.setIdEstado(idEstado.trim());
			datosPagoWarehousing.setAliasCuentaOrdenante(aliasCuenta.trim());
			datosPagoWarehousing.setCodExtracto(codCtaEx.trim());
			datosPagoWarehousing.setCodEnt(entidadCuenta);
			
			datosPagoWarehousing.setCodBeneficiario(claben);
			datosPagoWarehousing.setIdAutorizacionBeneficiario(idauth);
			String nombre;
			if (claben==0) {
				//Si el campo CDMEDPAG de SGP_PAGO no es el de MT101
				if (medPago.equals(STR_MT101)){
					//se toma el campo NOMBENC de la tabla SGP_PAGO_MAN
					nombre = nombreC_N6564;
				} else {
					//se toma el campo NOMBENS1 de la tabla SGP_PAG_MANL
					nombre = nombreS1_O2785;
				}
			} else {
				if (medPago.equals(STR_MT101)){
					//se toma el campo NOMBENC de la tabla SGP_BENEFIC cuyo CLABEN sea igual al CLABEN de SGP_PAGO
					nombre = nombreC_N2897;
				} else {
					//se toma el campo NOMBENS1 de la tabla SGP_BENEFIC cuyo CLABEN sea igual al CLABEN de SGP_PAGO
					nombre = nombreS1_N2897;
				}
			}
			datosPagoWarehousing.setDivisa(moneda.trim());
			datosPagoWarehousing.setImporte(monto);
			datosPagoWarehousing.setFecha(fecVal);
			datosPagoWarehousing.setNomBenef(nombre.trim());
			datosPagoWarehousing.setRefSistema(idPago.trim());
			datosPagoWarehousing.setRefCliente(refCli.trim());
			datosPagoWarehousing.setCodMedioPago(medPago.trim());
			datosPagoWarehousing.setCuenta(acuencot);
			datosPagoWarehousing.setPais(pais.trim());
			datosPagoWarehousing.setDescEstPago(estado.trim());
	
			return datosPagoWarehousing;
	}

	public ListaLotesWarehouseResponse getListaLotesWarehouseImp(ListaLotesWarehouseRequest request, boolean resumen) {
	// Obtenemos el usuario logado
	
	String uidLogado = STR_VACIO;
	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
			 auth instanceof JwtAuthenticationToken &&
               Objects.nonNull(auth.getDetails())) {
	
		JwtDetails santanderUD = (JwtDetails) auth.getDetails();
		uidLogado = santanderUD.getUid();
	 }
		String tokenBks = request.getTokenBks();
		String monConsolidacion = request.getMonedaConsolidacion();
		if (monConsolidacion==null)
		{
			monConsolidacion=STR_VACIO;
		}
		int numPagina = request.getNumPagina();
		int numPorPagina = request.getNumPorPagina();
					
		// Comprobamos si el usuario tiene firma
		String uidToken = listaPagosHelperService.comprobarTokenSKeyUsu(uidLogado);
		uidToken = uidToken==null ? STR_VACIO : uidToken.trim();
		
		if(uidToken != null && uidToken.equals(uidLogado)) {
		
			ListaLotesWarehouseResponse salida = new ListaLotesWarehouseResponse();

			List<DatosLotesWarehousing> listaCompleta = obtenerListadoLotesWarehouse(uidLogado, tokenBks);	

			Collections.sort(listaCompleta);
			Integer totalRegistros = listaCompleta.size();
			
			return prepararSalidaLotes(numPagina, numPorPagina, salida, listaCompleta, totalRegistros, tokenBks, monConsolidacion, resumen);
		}
		else
		{
			ListaLotesWarehouseResponse listaLotesWarehouseResponse = new ListaLotesWarehouseResponse();
			listaLotesWarehouseResponse.setStatus(STR_KO);
			listaLotesWarehouseResponse.setMessage(STR_ERROR_NO_FIRMA);
			return listaLotesWarehouseResponse;
		}
	}
	private List<DatosLotesWarehousing> obtenerListadoLotesWarehouse(String uidLogado, String tokenBks)  {
		IdiomaUsuario idiomaUsuario = obtenerIdiomaUsuario(uidLogado);	
		
		List<ConsultaPagosCreados_S> listaPagosCreados=new ArrayList<ConsultaPagosCreados_S>(0);
		
		List<DatosPagoLoteW> listaPagosLoteCreados = getPagosLotesUsuarioAutorizProcedure(uidLogado, idiomaUsuario, listaPagosCreados);	
		
		List<CalcularCutOff_S> listaCutOffs = listaPagosCreados.isEmpty() ? new ArrayList<> (0) : obtenerCutOffs(tokenBks, listaPagosCreados);
		
		List<DatosLotesWarehousing> listaSalida = listaPagosLoteCreados.isEmpty() ? new ArrayList<>() : fusionarLotes (listaPagosLoteCreados, listaCutOffs);		
		
		closeConnection ();

		return listaSalida;
	}
	

	private List<DatosLotesWarehousing> fusionarLotes(List<DatosPagoLoteW> listaPagosLoteCreados,
			List<CalcularCutOff_S> listaCutOffs) {

		List<DatosLotesWarehousing> salida = new ArrayList<DatosLotesWarehousing>(0);
		
		Calendar fechaCutOff = Calendar.getInstance();
		Calendar fechaPago = Calendar.getInstance();

		int tamLista = listaPagosLoteCreados.size();
		Set <String> lotesSinStop = new HashSet<String>(0);
		Map<String, DatosPagoLoteW> mapaIdLoteDatos = new HashMap<String, DatosPagoLoteW> (0);	
		List<String> listaLotes = new ArrayList<String>(0);

		for (int x=0;x<tamLista;x++)
		{
			boolean stopPay = true;
			DatosPagoLoteW datosLote = listaPagosLoteCreados.get(x);
			DatosPagoDeLoteW datosPago = listaPagosLoteCreados.get(x).getDatosPagoDeLote();
			CalcularCutOff datosCutOffPago = listaCutOffs.get(x).getCutOff();
			
			String idLote = datosLote.getLote().trim();
			String estadoPago = datosPago.getEstPago().trim();
			
			if (!mapaIdLoteDatos.containsKey(idLote))
			{
				mapaIdLoteDatos.put(idLote, datosLote);
				listaLotes.add(idLote);
			}
			
			if (!lotesSinStop.contains(idLote) && STR_S.equals(datosPago.getIndStopPayment()))
			{
				Calendar fechOrg = Calendar.getInstance();
				fechOrg.setTime(datosCutOffPago.getFechaPaisOrigen());
				fechaCutOff.setTime(datosCutOffPago.getFechaCutOff());		
				fechaPago.setTime(datosPago.getFecValPago());
				fechaCutOff.set(Calendar.HOUR_OF_DAY,5);
				fechaCutOff.set(Calendar.MINUTE, 0);
				fechaCutOff.set(Calendar.SECOND, 0);
				fechaCutOff.set(Calendar.MILLISECOND,0);

				//ponemos la fechade Cutoff en un calendar y le ponemos la hora 05:00

				if (!(fechaCutOff.get(Calendar.DAY_OF_MONTH)==fechaPago.get(Calendar.DAY_OF_MONTH) && 
						fechaCutOff.get(Calendar.MONTH)==fechaPago.get(Calendar.MONTH) &&
						fechaCutOff.get(Calendar.YEAR)==fechaPago.get(Calendar.YEAR)))
				{
					//si no es la misma fecha
					//hay que comparar que la fecha de cutoff sea anterior a la fecha del pago
					//hay que comparar que la fecha de cutoff no sea anterior a la fecha del pago
					if(fechaPago.before(fechaCutOff))
					{
						if (!estadoPago.equals("AC")){
						stopPay= false;
					}}
				}
				else
				{
					//si es el mismo dia comparo cutOff con fecha del pais de origen
					if(fechaCutOff.before(fechOrg))
					{
						stopPay= false;
					}
				}

			} 
			else 
			{
				stopPay = false;
			}
			
			if (!stopPay)
			{
				lotesSinStop.add(idLote);
			}
		}

		int tamListaLotes = listaLotes.size();
		for (int i=0;i<tamListaLotes;i++)
		{
			
			DatosLotesWarehousing datosLoteAnadir = new DatosLotesWarehousing();			
			
			String idLote = listaLotes.get(i);
			DatosPagoLoteW datosLote = mapaIdLoteDatos.get (idLote);
			
			datosLoteAnadir.setIndImportado(datosLote.getIndImp());
			datosLoteAnadir.setIndNotas(datosLote.getIndNota());
			datosLoteAnadir.setIndicadorUpload(datosLote.getIndUpl());
			datosLoteAnadir.setNomLote(datosLote.getNombreLote());
			datosLoteAnadir.setCodEstLote(datosLote.getIdEstado());
			datosLoteAnadir.setCodPais(datosLote.getCodPais());
			datosLoteAnadir.setImpLote(datosLote.getMonto());
			datosLoteAnadir.setDivisaLote(datosLote.getMoneda());
			datosLoteAnadir.setFechaLote(datosLote.getFecha());
			datosLoteAnadir.setTotalPagos(datosLote.getTotalPagos());
			datosLoteAnadir.setIdLote(datosLote.getLote());
			datosLoteAnadir.setIndSalario(datosLote.getIndSalarios());
			datosLoteAnadir.setIndicadorCbs(datosLote.getIndCbl());
			datosLoteAnadir.setDescEstLote(datosLote.getEstado());			
			datosLoteAnadir.setIndBulk(datosLote.getIndBulk());
			
			
			boolean estadoLotePe = "PE".equals(datosLote.getIdEstado().trim());
			String indStop = (lotesSinStop.contains(idLote) || !estadoLotePe) ? STR_N : STR_S ;
			
			datosLoteAnadir.setIndStopPayment(indStop);
			
			salida.add(datosLoteAnadir);
		}
		return salida;
		
	}
	public List<DatosPagoLoteW> getPagosLotesUsuarioAutorizProcedure (String uidLogado, IdiomaUsuario idiomaUsuario, List<ConsultaPagosCreados_S> listaPagosCreados)
	{
		List<DatosPagoLoteW> salida = new ArrayList<>();
		List<SqlParameter> prmtrsList = new ArrayList<>();
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR)); //p_usuario
	        prmtrsList.add(new SqlParameter(OracleTypes.DATE)); 	//p_fecha_desde
	        prmtrsList.add(new SqlParameter(OracleTypes.DATE));	//p_fecha_hasta
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_monto_desde
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_monto_hasta
	        prmtrsList.add(new SqlParameter(OracleTypes.DECIMAL));	//p_monto_desde
	        prmtrsList.add(new SqlParameter(OracleTypes.DECIMAL));	//p_monto_hasta
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_cod_pais
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_pais
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_ref_cliente
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ref_cliente
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_nom_benef
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_nom_benef
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_cuenta_debito
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_cuenta_debito
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_ind_metodo_pago
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_lista_cod_metodo_pago
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_idioma_usuario
	        prmtrsList.add(new SqlParameter(OracleTypes.VARCHAR));	//p_pais_usuario	        
	        prmtrsList.add(new SqlOutParameter(STR_RESULT, OracleTypes.CURSOR));	//p_cursor
	    
	        // Calculamos las fechas desde hoy hasta 90 dias
	        Calendar cal = Calendar.getInstance();
			Date hoy = new Date();
			cal.setTime(hoy);
			cal.add(Calendar.DAY_OF_YEAR, 90);
			
			SimpleDateFormat formatFecha = new SimpleDateFormat(STR_FORMATO_FECHA);
			
			String fechaIni = formatFecha.format(hoy.getTime());
			String fechaFin = formatFecha.format(cal.getTime());
	        BigDecimal impDesde = new BigDecimal(STR_0_00);
	        BigDecimal impHasta = new BigDecimal(STR_0_00);
	        
        Map<String, Object> datos = jdbcTemplate.call(new CallableStatementCreator() {
  	      
        public CallableStatement createCallableStatement(Connection connection) throws SQLException {        

        int numParam = 0;
        
        String query = "{call " + schemaproc + ".PKG_LISTADO.GET_PAGOS_LOTES_TRANS_W (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
        CallableStatement callableStatement = connection.prepareCall(query);
        callableStatement.setString(++numParam, uidLogado);                      //p_usuario
        callableStatement.setDate(++numParam, java.sql.Date.valueOf(fechaIni));  //p_fecha_desde
        callableStatement.setDate(++numParam, java.sql.Date.valueOf(fechaFin));  //p_fecha_hasta
        callableStatement.setString(++numParam, STR_N);                            //p_ind_monto_desde
        callableStatement.setString(++numParam, STR_N);                            //p_ind_monto_hasta
        callableStatement.setBigDecimal(++numParam, impDesde);                   //p_monto_desde
        callableStatement.setBigDecimal(++numParam, impHasta);                   //p_monto_hasta
        callableStatement.setString(++numParam, STR_N);                        	//p_ind_cod_pais
        callableStatement.setString(++numParam, STR_VACIO);                     //p_pais
        callableStatement.setString(++numParam, STR_N);                           //p_ind_ref_cliente
        callableStatement.setString(++numParam, STR_VACIO);                     //p_ref_cliente
        callableStatement.setString(++numParam, STR_N);                           //p_ind_nom_benef
        callableStatement.setString(++numParam, STR_VACIO);                     //p_nom_benef
        callableStatement.setString(++numParam, STR_N);                           //p_ind_cuenta_debito
        callableStatement.setString(++numParam, STR_VACIO);                     //p_cuenta_debito
        callableStatement.setString(++numParam, STR_N);                           //p_ind_metodo_pago
        callableStatement.setString(++numParam, STR_VACIO);                     //p_lista_cod_metodo_pago
        callableStatement.setString(++numParam, idiomaUsuario.getIdioma());                         //p_idioma_usuario
        callableStatement.setString(++numParam, idiomaUsuario.getPais());                          //p_pais_usuario
        callableStatement.registerOutParameter(++numParam, OracleTypes.CURSOR);                //cursor (OracleTypes.CURSOR = -10)
        return callableStatement;

        }
        }, prmtrsList);
        
        if(datos.containsKey(STR_RESULT)) {
        	        	
        	List<Map<String, Object>> listaObjetos = (List<Map<String, Object>>)datos.get(STR_RESULT);
        	
        	for (int i = 0; i < listaObjetos.size(); i++) {
        		
        		DatosPagoLoteW datosPagoCreado  = rellenarDatosPagosLote (listaObjetos.get(i), listaPagosCreados);        		
        		salida.add(datosPagoCreado);     		
        	}
        	
        }
        return salida;
	}
	
	private DatosPagoLoteW rellenarDatosPagosLote(Map<String, Object> map, List<ConsultaPagosCreados_S> listaPagosCreados) {
		SimpleDateFormat formatFecha = new SimpleDateFormat(STR_FORMATO_FECHA);
		
		DatosPagoLoteW datosPagoLote;
		datosPagoLote = new DatosPagoLoteW();
		
		//Datos lote
		String lote = String.valueOf(map.get("O2046_NULOTE"));
		String idEstado = String.valueOf(map.get("O2046_ESTPAGO"));
		String nombreLote = String.valueOf(map.get("O2046_DESCRI50"));
		String codPais = String.valueOf(map.get("O2046_CODPAIS"));
		String moneda = String.valueOf(map.get("O2046_CODMONSWI"));
		
		BigDecimal monto = new BigDecimal(String.valueOf(map.get("O2046_IMPLOTE2")));
		monto = monto.setScale(2, RoundingMode.HALF_UP);
		
		Date fecVal;
		try {
			fecVal = formatFecha.parse(String.valueOf(map.get("O2046_FECHALOT")));
		} catch (ParseException e1) {
			fecVal=null;
		} 

		int totalPagos 	= Integer.parseInt(String.valueOf(map.get("O2046_TOTPAGOS")));
		String indBulk 		= String.valueOf(map.get("O2046_BATCH_B"));
		String indSalarios 	= String.valueOf(map.get("O2046_IND_NOM"));

		String indImp 		= Integer.parseInt(String.valueOf(map.get("NUM_IMP_LOTE"))) >0 	? STR_S : STR_N;
		String indUpl 		= Integer.parseInt(String.valueOf(map.get("NUM_UPL_LOTE"))) >0 	? STR_S : STR_N;
		String indNota  	= Integer.parseInt(String.valueOf(map.get("NUM_NOTA_LOTE")))>0 	? STR_S : STR_N;
		String indCbl 		= Integer.parseInt(String.valueOf(map.get("NUM_CBL_LOTE"))) >0 	? STR_N :  STR_S;
		
		int tamEliminables = Integer.parseInt(String.valueOf(map.get("NUM_ELI_LOTE")));
		String indEli 		= tamEliminables == totalPagos 	? STR_S : STR_N;

		String estado		= String.valueOf(map.get("ESTADO_TRAD"));	
		
		int acre = Integer.parseInt(String.valueOf(map.get("O2046_TOTPAGOSACRE")));
		BigDecimal montoAcre = new BigDecimal(String.valueOf(map.get("O2046_LOTEIMPACRE")));
		montoAcre = montoAcre.setScale(2, RoundingMode.HALF_UP);
		
		//Datos pago		
		String idPago = String.valueOf(map.get("N6563_RFTRANS"));
		String estPago = String.valueOf(map.get("N6563_ESTPAGO"));
		String medPago = String.valueOf(map.get("N6563_CDMEDPAG"));
		int codEnt = Integer.parseInt(String.valueOf(map.get("H1162_CENTBSGP")));
		int cuenta = Integer.parseInt(String.valueOf(map.get("N6563_ACUENCOT")));
		BigDecimal montoPago = new BigDecimal(String.valueOf(map.get("N6563_CANTPAGL")));
		montoPago = montoPago.setScale(2, RoundingMode.HALF_UP);
		String divisa = String.valueOf(map.get("N6563_CODMONSWI"));
		String indStopPayment = String.valueOf(map.get("PERMISO_STP"));
		Date fecValPago;
		try {
			fecValPago = formatFecha.parse(String.valueOf(map.get("N6563_FEC_VAL")));
		} catch (ParseException e) {
			fecValPago=null;
		}		
		
		datosPagoLote.setLote(lote);
		datosPagoLote.setIdEstado(idEstado);
		datosPagoLote.setNombreLote(nombreLote);
		datosPagoLote.setCodPais(codPais);
		datosPagoLote.setMoneda(moneda);
		datosPagoLote.setMonto(monto);
		datosPagoLote.setFecha(fecVal);
		datosPagoLote.setTotalPagos(totalPagos);
		datosPagoLote.setIndBulk(indBulk);
		datosPagoLote.setIndSalarios(indSalarios);
		datosPagoLote.setIndImp(indImp);
		datosPagoLote.setIndUpl(indUpl);
		datosPagoLote.setIndNota(indNota);
		datosPagoLote.setIndCbl(indCbl);
		datosPagoLote.setTamEliminables(tamEliminables);
		datosPagoLote.setIndEli(indEli);
		datosPagoLote.setEstado(estado);
		datosPagoLote.setNumPagosAutRech(acre);
		datosPagoLote.setMontoAcre(montoAcre);
		datosPagoLote.setDivAcre(moneda);
		
		
		DatosPagoDeLoteW datosPagoDeLote = new DatosPagoDeLoteW();
		ConsultaPagosCreados_S datosPagosCreados = new ConsultaPagosCreados_S();
		
		datosPagoDeLote.setIdPago(idPago);
		datosPagoDeLote.setEstPago(estPago);
		datosPagoDeLote.setMedPago(medPago);
		datosPagoDeLote.setCodEnt(codEnt);
		datosPagoDeLote.setCuenta(cuenta);
		datosPagoDeLote.setMontoPago(montoPago);
		datosPagoDeLote.setDivisa(divisa);
		datosPagoDeLote.setIndStopPayment(indStopPayment);
		datosPagoDeLote.setFecValPago(fecValPago);
		
		datosPagosCreados.setRefSistema(idPago);
		datosPagosCreados.setCuenta(cuenta);
		datosPagosCreados.setCodMedioPago(medPago);
		datosPagosCreados.setCodEnt(codEnt);
		datosPagosCreados.setImporte(montoPago);
		datosPagosCreados.setDivisa(divisa);
		datosPagosCreados.setIndStopPayment(indStopPayment);
		datosPagosCreados.setFecha(fecValPago);
		
		listaPagosCreados.add(datosPagosCreados);		
		datosPagoLote.setDatosPagoDeLote(datosPagoDeLote);

		return datosPagoLote;
	}
}
