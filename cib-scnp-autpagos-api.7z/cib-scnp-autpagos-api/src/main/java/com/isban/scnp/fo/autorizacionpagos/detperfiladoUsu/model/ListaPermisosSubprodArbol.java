package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaPermisosSubprodArbol {

	private PermisosSubprodArbol pemisos;

	public PermisosSubprodArbol getPemisos() {
		return pemisos;
	}

	public void setPemisos(PermisosSubprodArbol pemisos) {
		this.pemisos = pemisos;
	}
	
}
