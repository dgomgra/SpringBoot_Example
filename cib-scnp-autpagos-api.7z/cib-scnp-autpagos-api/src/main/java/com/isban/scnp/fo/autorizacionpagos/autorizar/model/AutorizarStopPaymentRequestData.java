package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarStopPaymentRequestData {
	private AutorizarStopPaymentIn autorizarStopPayment = new AutorizarStopPaymentIn();

	public AutorizarStopPaymentRequestData() {
		super();
	}

	public AutorizarStopPaymentIn getAutorizarStopPayment() {
		return autorizarStopPayment;
	}
}
