package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

public class ObtArchivoSentRol {
	
	private int idArchivo;
	private String idComp;
	private int codSentencia;
	private int idAutorizacion;
	private int aNOrden;
	private int aNumFim;
	private String aTipAGru;
	private int tament;
	private int aNOrdenGrp;
	private int codrol;
	
	public int getIdArchivo() {
		return idArchivo;
	}
	
	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}
	
	public String getIdComp() {
		return idComp;
	}
	
	public void setIdComp(String idComp) {
		this.idComp = idComp;
	}
	
	
	public int getaNOrden() {
		return aNOrden;
	}
	
	public void setaNOrden(int aNOrden) {
		this.aNOrden = aNOrden;
	}
	
	public int getaNumFim() {
		return aNumFim;
	}
	
	public void setaNumFim(int aNumFim) {
		this.aNumFim = aNumFim;
	}
	
	public String getaTipAGru() {
		return aTipAGru;
	}
	
	public void setaTipAGru(String aTipAGru) {
		this.aTipAGru = aTipAGru;
	}
	
	public int getTament() {
		return tament;
	}
	
	public void setTament(int tament) {
		this.tament = tament;
	}
	
	public int getaNOrdenGrp() {
		return aNOrdenGrp;
	}
	
	public void setaNOrdenGrp(int aNOrdenGrp) {
		this.aNOrdenGrp = aNOrdenGrp;
	}
	
	public int getCodrol() {
		return codrol;
	}
	
	public void setCodrol(int codrol) {
		this.codrol = codrol;
	}

	public int getCodSentencia() {
		return codSentencia;
	}

	public void setCodSentencia(int codSentencia) {
		this.codSentencia = codSentencia;
	}

	public int getIdAutorizacion() {
		return idAutorizacion;
	}

	public void setIdAutorizacion(int idAutorizacion) {
		this.idAutorizacion = idAutorizacion;
	}
	
}	
