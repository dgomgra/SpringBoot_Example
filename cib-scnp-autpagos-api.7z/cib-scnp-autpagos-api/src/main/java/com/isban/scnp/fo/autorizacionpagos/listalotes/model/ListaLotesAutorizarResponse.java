package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class ListaLotesAutorizarResponse {
	private String status;
	private String message;
	private List<DatosLote> listaDatosLote;
	private List<String> listaDivisas;
	private int totalLotes;
	private int pagina;		
	
	public ListaLotesAutorizarResponse() {
		super();
		status=new String();
		message=new String();
		listaDatosLote=new ArrayList<DatosLote>(0);
		totalLotes=0;
		pagina=0;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<DatosLote> getListaDatosLote() {
		return listaDatosLote;
	}
	public void setListaDatosLote(List<DatosLote> listaDatosLote) {
		this.listaDatosLote = listaDatosLote;
	}	
	public List<String> getListaDivisas() {
		return listaDivisas;
	}
	public void setListaDivisas(List<String> listaDivisas) {
		this.listaDivisas = listaDivisas;
	}
	public int getTotalLotes() {
		return totalLotes;
	}
	public void setTotalLotes(int totalLotes) {
		this.totalLotes = totalLotes;
	}
	public int getPagina() {
		return pagina;
	}
	public void setPagina(int pagina) {
		this.pagina = pagina;
	}
	
}
