package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaCuentasArbol {

	private CuentasArbol cuentasArbol;

	public CuentasArbol getCuentasArbol() {
		return cuentasArbol;
	}

	public void setCuentasArbol(CuentasArbol cuentasArbol) {
		this.cuentasArbol = cuentasArbol;
	}
	
	
}
