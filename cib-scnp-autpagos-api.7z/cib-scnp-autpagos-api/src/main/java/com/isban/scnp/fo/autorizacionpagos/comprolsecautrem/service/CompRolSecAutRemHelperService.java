package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service;

import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ArchivoPolitica;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.IdArchivoGrupoEmp;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRol;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRolFirmado;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;

/**
 * 
 * Interfaz del servicio de comprobacion de roles en sentencias de autorazacion de Autorizacion Remota
 * 
 * @author dagonzalez
 *
 */
public interface CompRolSecAutRemHelperService {
	
	/**
	 * Operacion principal del servicio que comprueba si el usuario está en la secuencia de autorizacion de una lista de archivos
	 * 
	 * @param uid
	 * @param codigoGrupoEmpresarial
	 * @param lista idArchivo
	 * @return 
	 */
	public List<ArchivoPolitica> comprobarRolSecuenciaAutRA (String uid, int codigoGrupoEmpresarial, List<ArchivoAR> idArchivo);
	
	
	
	/**
	 * Consulta SQL que consulta las tablas SGP_ARCH_FIRMAM, SGP_R_ARCH_FIRM 
	 * Obtiene los archivos y su codigo de setencia asociado para los archivos y rol que le pasemos
	 * Filtrado por "O9251_FIRMADO = 'S'
	 * 
	 * @param codigoRolUsuario
	 * @param listaArchivosComprobados
	 * @return (idArchivo, codSentencia, idAuth)
	 */
	public List<ObtArchivoSentRolFirmado> obtArchivosSentRolFirmado(int codigoRolUsuario, List<Integer> listaArchivosComprobados);
	
	/**
	 * Consulta SQL a las tablas SGP_R_ARCH_SEN, SGP_POL_SENTEN, SGP_POL_SEN_GRP
	 * Obtiene los archivos que tienen alguna sentencia de politica de autorizacion asociada al pago
	 * cuyo rol es el mismo que el del usuario y que no están completadas
	 * 
	 * Filtrado por O9249_IDCOMP= 'N'
	 * 
	 * @param listaArchivosComprobados
	 * @return
	 */
	public List<ObtArchivoSentRol> obtArchivosSentRol(List<Integer> listaArchivosComprobados);
	
	
	
	/**
	 * Consulta SQL a la tabla SGP_PERF_USU que obtiene el rol del usuario
	 * Filtrado por H1241_CRSITUAC = 'H' y H1241_IDACTIVO = 'S'
	 * 
	 * @param uid
	 * @return int - H1241_CODIGROL
	 */
	public int obtRolUsuario(String uid);

	
	/**
	 * Consulta SQL a la tabla SGP_ARCH_REMOT que obtiene el grupo empresarial de los archivos que le pasemos
	 * 
	 * @param idArchivos
	 * @return (idArchivo y GrupoEmp)
	 */
	public List<IdArchivoGrupoEmp> obtGrupoEmpArchivos(List<ArchivoAR> idArchivos);
	
	/**
	 * Consulta SQL a las tablas SGP_ARCH_FIRENM, SGP_ARCH_FIRMAM, SGP_R_ARCH_FIRM
	 * Filtrando por O9252_INDFIROK a 'S'
	 * Que devuelve los archivos que ya tienen una firma OK del usuario
	 * 
	 * @param uid
	 * @param idArchivos
	 * @return
	 */
	public List<Integer> obtArchivosFirmaOKUsuario(String uid, List<Integer> idArchivos);
	
	
}
