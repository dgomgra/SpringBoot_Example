/**
 * @author Vector ITC Group
 *
 */
package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.impl;