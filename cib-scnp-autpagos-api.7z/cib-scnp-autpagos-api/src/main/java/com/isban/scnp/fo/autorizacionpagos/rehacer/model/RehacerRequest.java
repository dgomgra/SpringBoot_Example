package com.isban.scnp.fo.autorizacionpagos.rehacer.model;

import java.util.List;

public class RehacerRequest {
	
	private List<String> listaIds;
	private String tipo;
	private String nota;
	private String tokenBks;
	
	
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}
	public String getNota() {
		return nota;
	}
	public void setNota(String nota) {
		this.nota = nota;
	}
	public List<String> getListaIds() {
		return listaIds;
	}
	public void setListaIds(List<String> listaIds) {
		this.listaIds = listaIds;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
}
