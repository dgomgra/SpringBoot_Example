package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class DatosProducto {
	
	private int codigoProducto;
	private int codigoSubProducto;
	private int ordenProducto;
	private int ordenSubproducto;
	public int getCodigoProducto() {
		return codigoProducto;
	}
	public void setCodigoProducto(int codigoProducto) {
		this.codigoProducto = codigoProducto;
	}
	public int getCodigoSubProducto() {
		return codigoSubProducto;
	}
	public void setCodigoSubProducto(int codigoSubProducto) {
		this.codigoSubProducto = codigoSubProducto;
	}
	public int getOrdenProducto() {
		return ordenProducto;
	}
	public void setOrdenProducto(int ordenProducto) {
		this.ordenProducto = ordenProducto;
	}
	public int getOrdenSubproducto() {
		return ordenSubproducto;
	}
	public void setOrdenSubproducto(int ordenSubproducto) {
		this.ordenSubproducto = ordenSubproducto;
	}

}
