/**
 * 
 */
/**
 * @author sgbosca
 *
 */
package com.isban.scnp.fo.autorizacionpagos.listalotes.model;