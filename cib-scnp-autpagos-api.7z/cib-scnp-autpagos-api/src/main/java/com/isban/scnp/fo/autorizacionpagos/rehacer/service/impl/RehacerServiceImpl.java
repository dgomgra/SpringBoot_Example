package com.isban.scnp.fo.autorizacionpagos.rehacer.service.impl;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.Nota;
import com.isban.scnp.fo.autorizacionpagos.autorizar.service.AutorizarHelperService;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerRequest;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerRequestBks;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.idPago;
import com.isban.scnp.fo.autorizacionpagos.rehacer.service.RehacerHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RehacerServiceImpl implements RehacerHelperService {
	
	private static final String STR_REHACERPAGOSLOTES = "RehacerPagosLotes";
	private static final String STR_VACIO = "";
	private static final String STR_ERROR = "error";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_LOTES = "lotes";
	private static final String STR_PAGOS = "pagos";
	
	@Value("${urlBks}")
    protected String urlBks;
	
	@Autowired
	private ListaWarehouseHelperService listaWarehouseHelperService;
	
	@Autowired
	private AutorizarHelperService autorizarHelperService;
	
	@Autowired
	private ApiRestTemplate apiRestTemplate;
	
	@Override
	public void rehacerImpl(RehacerRequest rehacerRequest) {
		
		String token = rehacerRequest.getTokenBks();
		
		//	Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
		
		RehacerRequestBks requestBks = construirEntradaBks(rehacerRequest, uidLogado);		
		
		String json = null;
		try {
			json = "{\"rehacerPagosLotes\":{\"entrada\":"
					+ convertToJson(requestBks)
					+ "}}";
		} catch (JsonProcessingException e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_REHACERPAGOSLOTES + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			json = STR_VACIO;
		}
		String datosPeticion=json;
		String peticionRehacer = urlBks + "/json/F_GBMSGF_FOMovil_E/1?authenticationType=token&requestData="+json+"&token=" + token;
		URI uriPeticionRehacer = UriComponentsBuilder.fromUriString(peticionRehacer).build().encode().toUri();
		
		AsyncRestTemplate restTemplatePost = apiRestTemplate.getAsyncRestTemplate();
		ListenableFuture<ResponseEntity<Object>> response =  restTemplatePost.exchange(uriPeticionRehacer, HttpMethod.GET, null, Object.class);
		
		response.addCallback(new ListenableFutureCallback<ResponseEntity<Object>>() {
		    @Override
		    public void onSuccess(ResponseEntity<Object> result) {                
		        log.debug("Se ha realizado la petición al host "+ uriPeticionRehacer.getHost()+":"+uriPeticionRehacer.getPort()+uriPeticionRehacer.getPath());
		    }

		    @Override
		    public void onFailure(Throwable ex) {
		    	log.error("Error al conectar con host "+ uriPeticionRehacer.getHost()+":"+uriPeticionRehacer.getPort()+uriPeticionRehacer.getPath());
		    	log.error("Datos de la petición: "	+ datosPeticion);
		    	log.error("Respuesta del servidor: "+ ex.getMessage());	
		    }
		});
	}
	
	private RehacerRequestBks construirEntradaBks(RehacerRequest request, String uidLogado) {
		RehacerRequestBks requestBks = new RehacerRequestBks();

		if (request.getTipo().equals(STR_PAGOS)){
			for (int i=0;i<request.getListaIds().size();i++) {
				requestBks.getListaIdPago().add(new idPago(request.getListaIds().get(i)));
			}
		}else if (request.getTipo().equals(STR_LOTES)){
			List lotesNombres = autorizarHelperService.obtenerListaNombres(request.getTipo(), request.getListaIds());
			for (int i=0;i<request.getListaIds().size();i++) {
				requestBks.setListaIdLoteNombre(lotesNombres);
			}
		}

		Nota nota = new Nota();
		if (request.getNota() != null && request.getNota().length()>0) {
			nota.setDetalle(request.getNota());
			List<String> lista = new ArrayList<>();
			lista.add("RH");
			nota.setAsunto(listaWarehouseHelperService.traducirMulidi("ESTADO_PAGO_PSGP", lista, uidLogado).get(0));
			requestBks.setNota(nota);
		}
		return requestBks;
	}

	private String convertToJson (Object o) throws JsonProcessingException 
	{
		//Object to JSON in String
		
		ObjectMapper mapper = new ObjectMapper();		
			
		return mapper.writeValueAsString(o);
	}

}
