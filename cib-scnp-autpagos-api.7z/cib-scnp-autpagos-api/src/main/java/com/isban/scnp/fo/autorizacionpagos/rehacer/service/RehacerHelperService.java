package com.isban.scnp.fo.autorizacionpagos.rehacer.service;

import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerRequest;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerResponseData;


/**
 * Interfaz del servicio rehacer
 * 
 * @author dagonzalez
 *
 */
public interface RehacerHelperService {
	
	/**
	 * Operación principal via REST que cambia el estado de los pagos o lotes de entrada a Rehacer
	 *  
	 * @param rehacerRequest - lista de codigos, tipo y nota
	 */
	
	public void rehacerImpl (RehacerRequest rehacerRequest);
		
	
}
