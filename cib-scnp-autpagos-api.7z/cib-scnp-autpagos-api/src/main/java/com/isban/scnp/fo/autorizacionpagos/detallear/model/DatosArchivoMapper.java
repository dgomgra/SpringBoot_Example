package com.isban.scnp.fo.autorizacionpagos.detallear.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosArchivoMapper implements RowMapper<DatosArchivo> {

	@Override
	public DatosArchivo mapRow(ResultSet rs, int rowNum) throws SQLException {

		DatosArchivo datos = new DatosArchivo();
		datos.setPais(rs.getString("O9248_CODPAIS"));
		datos.setNumTransac(rs.getInt("O9248_NUM_TRANS"));
		datos.setMonto(rs.getBigDecimal("O9248_IMPPAISMON"));
		datos.setDivisa(rs.getString("O9248_CODMONSWI"));
		
		return datos;
	}

}
