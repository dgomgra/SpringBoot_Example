package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

import java.util.ArrayList;
import java.util.List;

public class CuentasArbol {

	private String codPais;
	private String nombreCorporate;
	private String cuentaExtracto;
	private String codigoDivisa;
	private int codigoCuenta;
	private List<ListaPermisosMetPagoArbol> permisosSubprod;
	
	public CuentasArbol() {
		permisosSubprod = new ArrayList<>(0);
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getNombreCorporate() {
		return nombreCorporate;
	}
	public void setNombreCorporate(String nombreCorporate) {
		this.nombreCorporate = nombreCorporate;
	}
	public String getCuentaExtracto() {
		return cuentaExtracto;
	}
	public void setCuentaExtracto(String cuentaExtracto) {
		this.cuentaExtracto = cuentaExtracto;
	}
	public String getCodigoDivisa() {
		return codigoDivisa;
	}
	public void setCodigoDivisa(String codigoDivisa) {
		this.codigoDivisa = codigoDivisa;
	}
	public int getCodigoCuenta() {
		return codigoCuenta;
	}
	public void setCodigoCuenta(int codigoCuenta) {
		this.codigoCuenta = codigoCuenta;
	}
	public List<ListaPermisosMetPagoArbol> getPermisosSubprod() {
		return permisosSubprod;
	}
	public void setPermisosSubprod(List<ListaPermisosMetPagoArbol> permisosSubprod) {
		this.permisosSubprod = permisosSubprod;
	}
	
	
}
