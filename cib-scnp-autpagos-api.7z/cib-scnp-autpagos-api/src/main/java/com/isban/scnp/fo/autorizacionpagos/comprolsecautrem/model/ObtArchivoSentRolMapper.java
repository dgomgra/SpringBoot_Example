package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ObtArchivoSentRolMapper implements RowMapper<ObtArchivoSentRol>{

	@Override
	public ObtArchivoSentRol mapRow(ResultSet rs, int rowNum) throws SQLException {
		ObtArchivoSentRol resultado = new ObtArchivoSentRol();
		resultado.setIdArchivo(rs.getInt("O9249_IDARCH"));
		resultado.setIdComp(rs.getString("O9249_IDCOMP"));
		resultado.setCodSentencia(rs.getInt("O9249_CPOLSENTE"));
		resultado.setIdAutorizacion(rs.getInt("O9249_IDAUTH"));
		resultado.setaNOrden(rs.getInt("N2921_ANORDEN"));
		resultado.setaNumFim(rs.getInt("N2919_ANUMFIRM"));
		resultado.setaTipAGru(rs.getString("N2921_ATIPAGRU"));
		resultado.setTament(rs.getInt("N2921_TAMENT"));
		resultado.setaNOrdenGrp(rs.getInt("N2919_ANORDEN"));
		resultado.setCodrol(rs.getInt("N2919_CODIGROL"));
		return resultado;
	}

}
