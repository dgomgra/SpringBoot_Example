package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConversionDivisaResponse {
	private ConversionDivisaOut methodResult;

	public ConversionDivisaOut getMethodResult() {
		return methodResult;
	}

	public void setMethodResult(ConversionDivisaOut methodResult) {
		this.methodResult = methodResult;
	}
}

