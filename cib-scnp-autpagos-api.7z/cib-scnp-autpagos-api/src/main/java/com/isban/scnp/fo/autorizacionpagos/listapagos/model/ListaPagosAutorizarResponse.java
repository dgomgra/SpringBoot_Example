package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class ListaPagosAutorizarResponse {
	
	private String status;
	private String message;
	private List<DatosPagoAutorizar> listaDatosPagosAutorizar;
	private int numTotalPagos;
	private int numPagActual;
	
	public ListaPagosAutorizarResponse() {
		listaDatosPagosAutorizar = new ArrayList<>(0);
	}
	
	public int getNumTotalPagos() {
		return numTotalPagos;
	}
	public void setNumTotalPagos(int numTotalPagos) {
		this.numTotalPagos = numTotalPagos;
	}
	public int getNumPagActual() {
		return numPagActual;
	}
	public void setNumPagActual(int numPagActual) {
		this.numPagActual = numPagActual;
	}
	public List<DatosPagoAutorizar> getListaDatosPagosAutorizar() {
		return listaDatosPagosAutorizar;
	}
	public void setListaDatosPagosAutorizar(List<DatosPagoAutorizar> listaDatosPagosAutorizar) {
		this.listaDatosPagosAutorizar = listaDatosPagosAutorizar;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
