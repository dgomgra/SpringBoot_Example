package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.util.ArrayList;
import java.util.List;

public class PagosUsuarioAutorizProcedureOut {
	
	private List<DatosPagoAutorizarProc> datosPagosAutorizar;
	private List<String> pagosLib;
	private List<String> pagosSinLib;
	
	public List<DatosPagoAutorizarProc> getDatosPagosAutorizar() {
		return datosPagosAutorizar;
	}
	public void setDatosPagosAutorizar(List<DatosPagoAutorizarProc> datosPagosAutorizar) {
		this.datosPagosAutorizar = datosPagosAutorizar;
	}
	public List<String> getPagosLib() {
		return pagosLib;
	}
	public void setPagosLib(List<String> pagosLib) {
		this.pagosLib = pagosLib;
	}
	public List<String> getPagosSinLib() {
		return pagosSinLib;
	}
	public void setPagosSinLib(List<String> pagosSinLib) {
		this.pagosSinLib = pagosSinLib;
	}
	public PagosUsuarioAutorizProcedureOut() {
		super();
		datosPagosAutorizar = new ArrayList<>(0);
		pagosLib = new ArrayList<>(0);
		pagosSinLib = new ArrayList<>(0);
	}
	
	
}
