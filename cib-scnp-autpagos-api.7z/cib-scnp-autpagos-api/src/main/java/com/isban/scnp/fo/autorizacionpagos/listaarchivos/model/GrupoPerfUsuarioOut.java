package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

public class GrupoPerfUsuarioOut {

	private int codGrupoUsu;
	private int idAuthUsu;
	

	/** Constructor basico con el grupo de usuarios y el IDAuth del usuario
	 * @param codGrupoUsu
	 * @param IDAuthUsu
	 */
	public GrupoPerfUsuarioOut(int codGrupoUsu, int idAuthUsu) {
		this.codGrupoUsu = codGrupoUsu;
		this.idAuthUsu = idAuthUsu;
	}

	/**	
	 * 	Código del grupo de usuarios al que pertenece el usuario 
	 * 	(0 Si no pertenece a ninguno)
	 * 	@return codGrupoUsu
	 */
	public int getCodGrupoUsu() {
		return codGrupoUsu;
	}

	/** 
	 * 	IDAuth del usuario
	 * 	@return IDAuthUsu
	 */
	public int getIDAuthUsu() {
		return idAuthUsu;
	}
	
}
