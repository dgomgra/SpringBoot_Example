package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarStopPaymentIn {
	private AutorizarStopPayment_E entrada;

	public AutorizarStopPaymentIn() {
		super();
	}

	public AutorizarStopPayment_E getEntrada() {
		return entrada;
	}

	public void setEntrada(AutorizarStopPayment_E entrada) {
		this.entrada = entrada;
	}
}
