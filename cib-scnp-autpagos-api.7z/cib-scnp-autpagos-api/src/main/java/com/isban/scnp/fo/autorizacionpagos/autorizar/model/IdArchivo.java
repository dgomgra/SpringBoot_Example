package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class IdArchivo {
	private int idArchivo;

	
	public IdArchivo(int idArchivo) {
		super();
		this.setIdArchivo(idArchivo);
	}

	public int getIdArchivo() {
		return idArchivo;
	}

	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}	
}
