package com.isban.scnp.fo.autorizacionpagos.common.model;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.common.service.CommonHelperService;

public class MessageSerializer extends JsonSerializer<String>{
	
	@Autowired
	private AppContext appContext;
	
	@Autowired
	private CommonHelperService commonHelperService;

	@Override
	public void serialize(String value, JsonGenerator gen, SerializerProvider serializers)
			throws IOException{
		
		String traduc = "OK";
		if (!"OK".equals(value))
		{
			if (appContext.getUserData()!=null)
			{
				String idioma = appContext.getUserData().getIdioma();
				String pais = appContext.getUserData().getCodPais();
				traduc = commonHelperService.obtenerTraducCodError(value, idioma, pais);
			}
			else
			{
				traduc="";
			}
		}
		gen.writeString(traduc);	
	}
}
