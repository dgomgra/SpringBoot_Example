
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

 /**************************************************************************
 * 
 * Los getters de esta clase deben tener JsonProperty y el nombre del dato 
 * JsonPropertyOrder hará que se mantenga en ese orden
 * 
 ***************************************************************************/

@JsonPropertyOrder({ "idiomaIso", "dialectoIso"})
public class Language {

	private String idiomaIso;
	private String dialectoIso;

	@JsonProperty("IDIOMA_ISO")
	public String getIdiomaIso() {
		return idiomaIso;
	}

	public void setIdiomaIso(String idiomaIso) {
		this.idiomaIso = idiomaIso;
	}

	@JsonProperty("DIALECTO_ISO")
	public String getDialectoIso() {
		return dialectoIso;
	}

	public void setDialectoIso(String dialectoIso) {
		this.dialectoIso = dialectoIso;
	}
}
