package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

public class DatosFirmaCuentaBenOut {
	private String digitosCuentaBen;

	public String getDigitosCuentaBen() {
		return digitosCuentaBen;
	}

	public void setDigitosCuentaBen(String digitosCuentaBen) {
		this.digitosCuentaBen = digitosCuentaBen;
	}

}
