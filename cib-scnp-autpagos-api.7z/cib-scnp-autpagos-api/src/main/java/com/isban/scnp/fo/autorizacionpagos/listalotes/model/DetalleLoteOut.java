package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

import java.math.BigDecimal;
import java.util.Date;

public class DetalleLoteOut {

	private String numLote;
	private String estadoLote;
	private String nombreLote;
	private String pais;
	private String divisa;
	private BigDecimal monto;
	private int numPagos;
	private Date fecha;
	
	public String getNumLote() {
		return numLote;
	}
	public void setNumLote(String numLote) {
		this.numLote = numLote;
	}
	public String getEstadoLote() {
		return estadoLote;
	}
	public void setEstadoLote(String estadoLote) {
		this.estadoLote = estadoLote;
	}
	public String getNombreLote() {
		return nombreLote;
	}
	public void setNombreLote(String nombreLote) {
		this.nombreLote = nombreLote;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	public BigDecimal getMonto() {
		return monto;
	}
	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}
	public int getNumPagos() {
		return numPagos;
	}
	public void setNumPagos(int numPagos) {
		this.numPagos = numPagos;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
}
