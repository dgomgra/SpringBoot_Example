package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.math.BigDecimal;
import java.util.Date;

public class DatosPagoAutorizarProc {
	
	private String rftrans;
	private String idEstado;
	private BigDecimal importe;
	private String divisa;
	private Date fecha;
	private String refCliente;
	private String codMedioPago;
	private int claben;
	private String n2897_nombens1;
	private String n2897_nombenc;
	private String o2785_nombens1;
	private String n6564_nombenc;
	private int codCuenta;
	private int idAuto;
	private String pais;
	private String indImp;
	private String indNota;
	private String indicadorUpload;
	private String codExtracto;
	private String descEstPago;
	
	public String getRftrans() {
		return rftrans;
	}
	public void setRftrans(String rftrans) {
		this.rftrans = rftrans;
	}
	public String getIdEstado() {
		return idEstado;
	}
	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getRefCliente() {
		return refCliente;
	}
	public void setRefCliente(String refCliente) {
		this.refCliente = refCliente;
	}
	public String getCodMedioPago() {
		return codMedioPago;
	}
	public void setCodMedioPago(String codMedioPago) {
		this.codMedioPago = codMedioPago;
	}
	public int getClaben() {
		return claben;
	}
	public void setClaben(int claben) {
		this.claben = claben;
	}
	public String getN2897_nombens1() {
		return n2897_nombens1;
	}
	public void setN2897_nombens1(String n2897_nombens1) {
		this.n2897_nombens1 = n2897_nombens1;
	}
	public String getN2897_nombenc() {
		return n2897_nombenc;
	}
	public void setN2897_nombenc(String n2897_nombenc) {
		this.n2897_nombenc = n2897_nombenc;
	}
	public String getO2785_nombens1() {
		return o2785_nombens1;
	}
	public void setO2785_nombens1(String o2785_nombens1) {
		this.o2785_nombens1 = o2785_nombens1;
	}
	public String getN6564_nombenc() {
		return n6564_nombenc;
	}
	public void setN6564_nombenc(String n6564_nombenc) {
		this.n6564_nombenc = n6564_nombenc;
	}
	public int getCodCuenta() {
		return codCuenta;
	}
	public void setCodCuenta(int codCuenta) {
		this.codCuenta = codCuenta;
	}
	public int getIdAuto() {
		return idAuto;
	}
	public void setIdAuto(int idAuto) {
		this.idAuto = idAuto;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getIndImp() {
		return indImp;
	}
	public void setIndImp(String indImp) {
		this.indImp = indImp;
	}
	public String getIndNota() {
		return indNota;
	}
	public void setIndNota(String indNota) {
		this.indNota = indNota;
	}
	public String getIndicadorUpload() {
		return indicadorUpload;
	}
	public void setIndicadorUpload(String indicadorUpload) {
		this.indicadorUpload = indicadorUpload;
	}
	public String getCodExtracto() {
		return codExtracto;
	}
	public void setCodExtracto(String codExtracto) {
		this.codExtracto = codExtracto;
	}
	public String getDescEstPago() {
		return descEstPago;
	}
	public void setDescEstPago(String descEstPago) {
		this.descEstPago = descEstPago;
	}

}
