package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class ClaveValor {
	private String clave;
	private String valor;
	public String getClave() {
		return clave;
	}
	
	public ClaveValor(String clave, String valor) {
		super();
		this.setClave(clave);
		this.setValor(valor);
	}

	public void setClave(String clave) {
		this.clave = clave;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}	
}
