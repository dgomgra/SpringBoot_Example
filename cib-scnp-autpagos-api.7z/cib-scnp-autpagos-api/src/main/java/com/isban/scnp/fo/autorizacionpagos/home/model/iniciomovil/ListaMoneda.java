
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class ListaMoneda {

    private String divisa;

    public String getDivisa() {
        return divisa;
    }

    public void setDivisa(String divisa) {
        this.divisa = divisa;
    }

}
