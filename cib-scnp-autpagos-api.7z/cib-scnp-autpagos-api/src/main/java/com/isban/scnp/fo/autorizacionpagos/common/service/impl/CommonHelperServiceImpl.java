package com.isban.scnp.fo.autorizacionpagos.common.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuarioMapper;
import com.isban.scnp.fo.autorizacionpagos.common.model.TraducCodErrorMapper;
import com.isban.scnp.fo.autorizacionpagos.common.service.CommonHelperService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommonHelperServiceImpl implements CommonHelperService{
	private static final String STR_MSG_ERROR_GENERAL = "Se ha producido un error general.";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	public DatosUsuario obtenerDatosUsuario(String uid) {		
		String sql = "SELECT H1185_NFORMCAN, H1184_NFORMFEC, H1186_IDIOMASC, H1186_CODPAIS, H1186_CRIPTOVIRT FROM " + schemaproc + ".SGP_USUARIO, " + schemaproc + ".SGP_FORMCANT, " + schemaproc + ".SGP_FORMFECHA " + 
					 "WHERE H1186_UID = ? " + 
					 "AND H1186_CFORMCAN = H1185_CFORMCAN AND H1186_CFORMFEC = H1184_CFORMFEC";
		
		// Rellenamos con espacios
		uid = String.format("%1$-30s", uid);

		Object[] params = new Object[] {uid};
		
		List<DatosUsuario> datosUsuario = jdbcTemplate.query(sql, params, new DatosUsuarioMapper());
		return datosUsuario.get(0);
	}
	
	public String obtenerTraducCodError(String codError, String idioma, String codPais) {
		String salida = "";
		
		try {
			codError = String.format("%1$-40s", codError);
			String sql = "SELECT G0658_TRADUC FROM " + schemaproc + ".TXT_MULIDI_ARQ "
					+ "WHERE G0658_CODTRADU = 'CODIGO_ERROR_APP         ' "
					+ "AND G0658_IDIOMASC = ? "
					+ "AND G0658_CODPAIS = ? "
					+ "AND G0658_IDENDATO = ? "
					+ "AND G0658_ACRONAPL = 'GBMSGF'";
			
			Object[] params = new Object[] {idioma, codPais, codError};
			
			List<String> datosUsuario = jdbcTemplate.query(sql, params, new TraducCodErrorMapper());		
			
			if(!datosUsuario.isEmpty() && datosUsuario.get(0)!=null)
			{
				salida = datosUsuario.get(0).trim();
			}
		} catch (DataAccessException e) {
			salida=STR_MSG_ERROR_GENERAL;
			log.debug("Se establece el valor por defecto", e);
		}
		
		return salida;
	}
}
