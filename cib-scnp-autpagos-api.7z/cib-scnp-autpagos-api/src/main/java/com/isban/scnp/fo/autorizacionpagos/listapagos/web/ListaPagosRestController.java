package com.isban.scnp.fo.autorizacionpagos.listapagos.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * Servicio de listado de pagos pendientes de autorizar
 * 
 * @author Vector
 *
 */

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "AutorizacionPagosRestController")
public class ListaPagosRestController {

	
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_LISTA_DE_PAGOS = "Lista de pagos";
	private static final String STR_ERROR = "error";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";

	private static final String STR_KO = "KO";

	@Autowired
	private ListaPagosHelperService listaPagosHelperService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
    	binder.setDisallowedFields("administrator");
	}
	
	
	/**
	 * Metodo rest que lista los pagos pendientes de autorizar
	 * 
	 * @param listaPagosAutorizarRequest
	 * @return
	 */
	@RequestMapping(value = "/v1/listadoPagosAutorizar", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get list of payments")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	@PostMapping
	public ResponseEntity<ListaPagosAutorizarResponse> getListaPagosAutorizar(@RequestBody ListaPagosAutorizarRequest listaPagosAutorizarRequest){
		
		try {
		
			log.debug("REST POST call received in /v1/listadoPagosAutorizar ",
					listaPagosAutorizarRequest.getNumPorPagina(),
					listaPagosAutorizarRequest.getNumPagina(),
					listaPagosAutorizarRequest.getIdLote(),
					listaPagosAutorizarRequest.getPais());
			
			ListaPagosAutorizarResponse listaPagosAutorizarResponse = listaPagosHelperService.getListaPagosAutorizarImp(listaPagosAutorizarRequest);
			return new ResponseEntity<>(listaPagosAutorizarResponse, HttpStatus.OK);
			
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_PAGOS + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			ListaPagosAutorizarResponse listaPagosAutorizarResponse = new ListaPagosAutorizarResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				listaPagosAutorizarResponse.setStatus(STR_KO);
				listaPagosAutorizarResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(listaPagosAutorizarResponse, HttpStatus.UNAUTHORIZED);
			}else {
				listaPagosAutorizarResponse.setStatus(STR_KO);
				listaPagosAutorizarResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(listaPagosAutorizarResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_PAGOS + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			ListaPagosAutorizarResponse listaPagosAutorizarResponse = new ListaPagosAutorizarResponse();
			listaPagosAutorizarResponse.setStatus(STR_KO);
			listaPagosAutorizarResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(listaPagosAutorizarResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
