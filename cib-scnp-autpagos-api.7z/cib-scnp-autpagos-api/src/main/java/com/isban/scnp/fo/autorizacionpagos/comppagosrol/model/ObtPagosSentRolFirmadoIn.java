package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

import java.util.List;

public class ObtPagosSentRolFirmadoIn {

	private int codRol;
	private List<String> listaRftrans;
	
	public int getCodRol() {
		return codRol;
	}
	public void setCodRol(int codRol) {
		this.codRol = codRol;
	}
	public List<String> getListaRftrans() {
		return listaRftrans;
	}
	public void setListaRftrans(List<String> listaRftrans) {
		this.listaRftrans = listaRftrans;
	}
	
}
