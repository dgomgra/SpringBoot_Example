package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

public class CompPagosRolUsuPendFirmaOut {

	private String rftrans;
	private int codSentencia;
	private int idAutorizacion;
	
	public String getRftrans() {
		return rftrans;
	}
	public void setRftrans(String rftrans) {
		this.rftrans = rftrans;
	}
	public int getCodSentencia() {
		return codSentencia;
	}
	public void setCodSentencia(int codSentencia) {
		this.codSentencia = codSentencia;
	}
	public int getIdAutorizacion() {
		return idAutorizacion;
	}
	public void setIdAutorizacion(int idAutorizacion) {
		this.idAutorizacion = idAutorizacion;
	}	
	
}
