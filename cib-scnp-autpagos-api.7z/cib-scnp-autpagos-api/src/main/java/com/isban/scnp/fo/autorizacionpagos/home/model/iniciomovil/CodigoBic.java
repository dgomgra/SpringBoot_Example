
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**************************************************************************
 * 
 * Los getters de esta clase deben tener JsonProperty y el nombre del dato 
 * JsonPropertyOrder hará que se mantenga en ese orden
 * 
 ***************************************************************************/

@JsonPropertyOrder({ "entidadBic", "paisBic", "locatorBic", "branchBic"})
public class CodigoBic {

	private String entidadBic;
	private String paisBic;
	private String locatorBic;
	private String branchBic;

	@JsonProperty("ENTIDAD_BIC")
	public String getENTIDADBIC() {
		return entidadBic;
	}

	public void setENTIDADBIC(String eNTIDADBIC) {
		this.entidadBic = eNTIDADBIC;
	}
	@JsonProperty("PAIS_BIC")
	public String getPAISBIC() {
		return paisBic;
	}

	public void setPAISBIC(String pAISBIC) {
		this.paisBic = pAISBIC;
	}
	@JsonProperty("LOCATOR_BIC")
	public String getLOCATORBIC() {
		return locatorBic;
	}

	public void setLOCATORBIC(String lOCATORBIC) {
		this.locatorBic = lOCATORBIC;
	}

	@JsonProperty("BRANCH")
	public String getBRANCH() {
		return branchBic;
	}

	public void setBRANCH(String bRANCH) {
		this.branchBic = bRANCH;
	}
}
