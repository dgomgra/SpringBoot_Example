/**
 * 
 */
/**
 * @author dagonzalez
 *
 */
package com.isban.scnp.fo.autorizacionpagos.rehacer;