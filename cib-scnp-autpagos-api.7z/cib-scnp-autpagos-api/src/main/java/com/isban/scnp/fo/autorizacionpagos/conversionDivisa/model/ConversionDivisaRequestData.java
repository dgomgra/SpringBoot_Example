package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

public class ConversionDivisaRequestData {
	private ConversionDivisaIn conversionDivisa;
	
	public ConversionDivisaRequestData ()
	{
		super();
		conversionDivisa = new ConversionDivisaIn();
	}

	public ConversionDivisaIn getConversionDivisa() {
		return conversionDivisa;
	}

	public void setConversionDivisa(ConversionDivisaIn conversionDivisa) {
		this.conversionDivisa = conversionDivisa;
	}
}
