/**
 * 
 */
/**
 * @author Daniel
 *
 */
package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.component;