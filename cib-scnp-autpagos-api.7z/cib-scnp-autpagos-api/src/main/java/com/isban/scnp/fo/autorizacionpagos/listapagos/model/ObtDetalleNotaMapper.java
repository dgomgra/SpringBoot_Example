package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ObtDetalleNotaMapper implements RowMapper<ObtDetalleNotaOut>{

	@Override
	public ObtDetalleNotaOut mapRow(ResultSet rs, int row) throws SQLException {
		ObtDetalleNotaOut obtDetalleNotaOut = new ObtDetalleNotaOut();
		obtDetalleNotaOut.setO2765_CDNOTA(rs.getInt("O2760_CDNOTA"));
		obtDetalleNotaOut.setO2760_ANOTAS(rs.getString("O2760_ANOTAS"));
		obtDetalleNotaOut.setO2760_NOTES_TS(rs.getTimestamp("O2760_NOTES_TS"));
		return obtDetalleNotaOut;
	}
}
