package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.io.IOException;
import java.math.BigDecimal;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializable;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;

public class ImporteType implements JsonSerializable {

	private BigDecimal IMPORTE;
	private String DIVISA;
	
	public ImporteType(BigDecimal importe, String divisa) {
		super();
		this.setIMPORTE(importe);
		this.setDIVISA(divisa);
	}
	
	public ImporteType() {
		super();
		this.IMPORTE=BigDecimal.valueOf(0.0);
		this.DIVISA=new String();
	}

	public BigDecimal getIMPORTE() {
		return IMPORTE;
	}

	public void setIMPORTE(BigDecimal iMPORTE) {
		IMPORTE = iMPORTE;
	}

	public String getDIVISA() {
		return DIVISA;
	}

	public void setDIVISA(String dIVISA) {
		DIVISA = dIVISA;
	}

	/*
	 * (non-Javadoc)
	 * @see com.fasterxml.jackson.databind.JsonSerializable#serialize(com.fasterxml.jackson.core.JsonGenerator, com.fasterxml.jackson.databind.SerializerProvider)
	 * Se implementa este mét0do para la generación de las propiedades del dato completamente en mayúsculas
	 */
	
	@Override
	public void serialize(JsonGenerator gen, SerializerProvider serializers) throws IOException {
		//Para evitar error de mapeo en BKS
		String bdtemp = this.getIMPORTE().toString();
		if (bdtemp.endsWith(".00"))
		{
			bdtemp=bdtemp.replace(".00", "");
		}
		
		gen.writeStartObject();
		gen.writeStringField("IMPORTE", bdtemp);
		gen.writeStringField("DIVISA", this.getDIVISA());
		gen.writeEndObject();
		
	}

	@Override
	public void serializeWithType(JsonGenerator gen, SerializerProvider serializers, TypeSerializer typeSer)
			throws IOException {
		//este metodo no se necesita
	}

}
