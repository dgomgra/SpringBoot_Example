package com.isban.scnp.fo.autorizacionpagos.common.service;

import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;

public interface CommonHelperService {

	public DatosUsuario obtenerDatosUsuario(String uidLogado);
	
	public String obtenerTraducCodError(String codError, String idioma, String codPais);
	
}
