package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service;

import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaWarehouseRequest;

public interface ListaWarehouseHelperService {
	public ListaPagosWarehouseResponse getListaPagosWarehouseImp(ListaWarehouseRequest request);
	public List<String> traducirMulidi (String tipoDatoMulidi, List<String> listaDatosTraducir, String usuario);
	public ListaLotesWarehouseResponse getListaLotesWarehouseImp(ListaLotesWarehouseRequest listaWarehouseRequest, boolean resumen);
}
