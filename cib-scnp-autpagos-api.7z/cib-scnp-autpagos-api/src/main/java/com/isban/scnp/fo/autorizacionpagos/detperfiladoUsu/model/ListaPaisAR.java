package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaPaisAR {

	private String codPais;

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	
}
