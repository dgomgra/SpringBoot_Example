package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosFirmaCuentaBenMapper implements RowMapper<DatosFirmaCuentaBenOut>{
	@Override
	public DatosFirmaCuentaBenOut mapRow(ResultSet rs, int row) throws SQLException {
		DatosFirmaCuentaBenOut datosFirmaCuentaBenOut = new DatosFirmaCuentaBenOut();
		datosFirmaCuentaBenOut.setDigitosCuentaBen(rs.getString("Cuenta Beneficiario"));
		return datosFirmaCuentaBenOut;
	}

}
