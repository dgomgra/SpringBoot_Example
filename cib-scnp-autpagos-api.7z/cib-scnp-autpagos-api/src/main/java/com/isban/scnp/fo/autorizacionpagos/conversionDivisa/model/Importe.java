package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

public class Importe {
	private ImporteType importe;

	public Importe() {
		super();
		importe = new ImporteType();
	}	

	public Importe(ImporteType importe) {
		super();
		this.importe = importe;
	}

	public ImporteType getImporte() {
		return importe;
	}

	public void setImporte(ImporteType importe) {
		this.importe = importe;
	}
}
