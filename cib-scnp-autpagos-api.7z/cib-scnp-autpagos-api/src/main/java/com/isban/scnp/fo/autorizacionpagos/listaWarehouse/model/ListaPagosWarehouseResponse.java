package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class ListaPagosWarehouseResponse {
	private String status;
	private String message;
	private List<DatosPagoWarehousing> listaDatosPagosWarehousing;
	private int totalPagos;
	private int pagina;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<DatosPagoWarehousing> getListaDatosPagosWarehousing() {
		return listaDatosPagosWarehousing;
	}
	public void setListaDatosPagosWarehousing(List<DatosPagoWarehousing> listaDatosPagosWarehousing) {
		this.listaDatosPagosWarehousing = listaDatosPagosWarehousing;
	}
	public int getTotalPagos() {
		return totalPagos;
	}
	public void setTotalPagos(int totalLotes) {
		this.totalPagos = totalLotes;
	}
	public int getPagina() {
		return pagina;
	}
	public void setPagina(int pagina) {
		this.pagina = pagina;
	}
}
