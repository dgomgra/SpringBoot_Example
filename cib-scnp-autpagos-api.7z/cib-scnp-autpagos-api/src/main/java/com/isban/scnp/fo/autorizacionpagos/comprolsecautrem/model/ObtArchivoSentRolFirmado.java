package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

public class ObtArchivoSentRolFirmado {
	
	private int idArch;
	private int codSentencia;
	private int idAuth;
	
	public ObtArchivoSentRolFirmado(int idArch, int codSentencia, int idAuth) {
		this.setIdArch(idArch);
		this.setCodSentencia(codSentencia);
		this.setIdAuth(idAuth);
	}

	public int getIdArch() {
		return idArch;
	}
	
	public void setIdArch(int idArch) {
		this.idArch = idArch;
	}
	
	public int getCodSentencia() {
		return codSentencia;
	}
	
	public void setCodSentencia(int codSentencia) {
		this.codSentencia = codSentencia;
	}
	
	public int getIdAuth() {
		return idAuth;
	}
	
	public void setIdAuth(int idAuth) {
		this.idAuth = idAuth;
	}
}
