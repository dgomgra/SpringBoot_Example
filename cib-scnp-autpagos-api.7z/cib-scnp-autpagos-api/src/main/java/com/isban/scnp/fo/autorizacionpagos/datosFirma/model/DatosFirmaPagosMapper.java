package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosFirmaPagosMapper implements RowMapper<BigDecimal>{

	@Override
	public BigDecimal mapRow(ResultSet rs, int row) throws SQLException {
		return rs.getBigDecimal("N6563_CANTPAGL");
	}

}
