package com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.IdPagoCodCuenta;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtCuentaPagosMapper;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtCuentaPagosOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolFirmadoIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolFirmadoMapper;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolFirmadoOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolMapper;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.CompPagosRolHelperService;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.CuentasArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPermisosMetPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PaisArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ServicioPaisAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.DetPerfiladoUsuarioHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ObtPagosFirmaMapper;


@Service
public class CompPagosRolHelperServiceImpl implements CompPagosRolHelperService {

    
	private static final int MAX_SIZE_QUERY = 1000;
	private static final String STR_VER = "ver";
	private static final String STR_APR = "apr";
	private static final String STR_S = "S";
	private static final int INT_0 = 0;
	private static final String STR_PA = "PA";
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	@Autowired
	private DetPerfiladoUsuarioHelperService detPerfiladoUsuarioHelperService;
	
	@Value("${schema_proc}")
    protected String schemaproc;

	@Override
	public List<CompPagosRolUsuPendFirmaOut> compPagosRolUsuPendFirma(CompPagosRolUsuPendFirmaIn entrada) {
		
		List<CompPagosRolUsuPendFirmaOut> salida = new ArrayList<>();
		
		// Obtenemos los datos del perfilado del usuario logado, llamanado a BKS
		DetPerfiladoUsuarioResponse datosPerfilado = detPerfiladoUsuarioHelperService.detPerfiladoUsuario(entrada.getTokenBks());
		
		// Obtenemos la cuentas de los pagos
		List<ObtCuentaPagosOut> listaCuentasPagos = obtCuentaPagos(entrada.getListaIdPago());
		
		
		// Comprobamos si hay cuentas
		if(!listaCuentasPagos.isEmpty()) {
			
			// Filtramos las cuentas de las que el usuario tenga permisos para firmar
			List<IdPagoCodCuenta> listaPagosYCuentas = compPermCta(datosPerfilado, listaCuentasPagos, entrada.getPagosVerActivos());
			
			// Comprobamos si alguno de los pagos, ya ha sido firmado por el usuario
			List<String> pagosConAutorizacion = new ArrayList<>();
			
			for(int i=0; i<listaPagosYCuentas.size(); i++) {
				pagosConAutorizacion.add(listaPagosYCuentas.get(i).getRftrans());
			}
			List<String> pagosYaFirmados = obtPagosFirmaOKUsuarioInt(entrada.getUid(), pagosConAutorizacion);
			
			// Filtramos los pagos que ya esten firmados previamente
			List<String> listaPagosTemp = filtraPagosFirmados(pagosConAutorizacion, pagosYaFirmados);
			
			// Obtenemos las sentencias de los roles
			List<ObtPagosSentRolOut> pagosSentRol = obtPagosSentRol(listaPagosTemp);
			
			// Obtenemos las sentencias de los roles firmadas
			ObtPagosSentRolFirmadoIn datos = new ObtPagosSentRolFirmadoIn();
			datos.setCodRol(datosPerfilado.getMethodResult().getCodigoRol());
			datos.setListaRftrans(listaPagosTemp);
			List<ObtPagosSentRolFirmadoOut> pagosSentRolFirmado = obtPagosSentRolFirmado(datos);
			
			// Obtenemos la lista final con los pagos tengan sentecias del rol del usuario pendiente de firmar
			salida = comprobarRoles(pagosSentRol, pagosSentRolFirmado, datosPerfilado);
			
			return salida;
		}else {
			return salida;
		}		
	}
	
	public List<ObtCuentaPagosOut> obtCuentaPagos(List<String> listaRfTrans) {
		
		List<String> listaTemp = new ArrayList<>();
		List<ObtCuentaPagosOut> salida = new ArrayList<>();
		List<ObtCuentaPagosOut> salidaTemp = new ArrayList<>();
		
		int tamListaRfTrans = listaRfTrans.size();
		if (tamListaRfTrans>0)
		{
			int numIters = tamListaRfTrans/MAX_SIZE_QUERY + ((tamListaRfTrans%MAX_SIZE_QUERY)>0? 1:0);

			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaRfTrans);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaRfTrans.get(j));
					
				}
				
				salidaTemp = obtCuentaPagosPriv(listaTemp);
				
				int tamListaTemp = salidaTemp.size();
				for (int j = 0; j < tamListaTemp; j++) {
					salida.add(salidaTemp.get(j));
				}
				
			}
		}
		
		return salida;
		
	}
	
	private List<ObtCuentaPagosOut> obtCuentaPagosPriv(List<String> listaRfTrans){
		String sql = "SELECT N6563_RFTRANS, N6563_ACUENCOT FROM " + schemaproc + ".SGP_PAGO WHERE N6563_RFTRANS IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", listaRfTrans);
		
		return  namedParameterJdbcTemplate.query(sql, params, new ObtCuentaPagosMapper());
	}
	
	public List<ObtPagosSentRolOut> obtPagosSentRol(List<String> listaRfTrans) {
		
		List<String> listaTemp = new ArrayList<>();
		List<ObtPagosSentRolOut> salida = new ArrayList<>();
		List<ObtPagosSentRolOut> salidaTemp = new ArrayList<>();
		
		int tamListaRfTrans = listaRfTrans.size();
		if (tamListaRfTrans>0)
		{
			int numIters = tamListaRfTrans/MAX_SIZE_QUERY + ((tamListaRfTrans%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaRfTrans);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaRfTrans.get(j));
					
				}
				
				salidaTemp = obtPagosSentRolPriv(listaTemp);
				
				int tamListaTemp = salidaTemp.size();
				for (int j = 0; j < tamListaTemp; j++) {
					salida.add(salidaTemp.get(j));
				}
				
			}
		}
		
		return salida;
		
	}
	
	private List<ObtPagosSentRolOut> obtPagosSentRolPriv(List<String> listaRfTrans) {
		
		String sql = "SELECT N6567_RFTRANS, N6567_CPOLSENTE, N6567_IDAUTH, N6567_IDCOMP, " +
				"N2921_ANORDEN, N2919_ANUMFIRM, N2921_ATIPAGRU, N2921_TAMENT, N2919_ANORDEN, N2919_CODIGROL " +
				"FROM " + schemaproc + ".SGP_R_PAGO_SEN, " + schemaproc + ".SGP_POL_SENTEN, " + schemaproc + ".SGP_POL_SEN_GRP " + 
				"WHERE N6567_CPOLSENTE = N2921_CPOLSENTE AND N2921_CPOLSENTE= N2919_CPOLSENTE AND N6567_IDAUTH= N2921_IDAUTH AND " +
				"N2921_IDAUTH= N2919_IDAUTH AND N6567_IDCOMP= 'N' AND N6567_RFTRANS IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", listaRfTrans);
		return  namedParameterJdbcTemplate.query(sql, params, new ObtPagosSentRolMapper());
		
	}
	
	public List<ObtPagosSentRolFirmadoOut> obtPagosSentRolFirmado(ObtPagosSentRolFirmadoIn entrada){
		
		List<String> listaTemp = new ArrayList<>();
		List<ObtPagosSentRolFirmadoOut> salida = new ArrayList<>();
		List<ObtPagosSentRolFirmadoOut> salidaTemp = new ArrayList<>();
		
		int tamListaRfTrans = entrada.getListaRftrans().size();
		if (tamListaRfTrans>0)
		{
			int numIters = tamListaRfTrans/MAX_SIZE_QUERY + ((tamListaRfTrans%MAX_SIZE_QUERY)>0? 1:0);

			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaRfTrans);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(entrada.getListaRftrans().get(j));
					
				}
				
				salidaTemp = obtPagosSentRolFirmadoPriv(listaTemp, entrada.getCodRol());
				
				int tamListaTemp = salidaTemp.size();
				for (int j = 0; j < tamListaTemp; j++) {
					salida.add(salidaTemp.get(j));
				}
				
			}
		}
		
		return salida;
		
	}
	
	private List<ObtPagosSentRolFirmadoOut> obtPagosSentRolFirmadoPriv(List<String> listaRftsrans, int rol){
		
		String sql = "SELECT O2787_RFTRANS, O2787_CPOLSENTE, O2787_IDAUTH " + 
				"FROM " + schemaproc + ".SGP_PAGO_FIRMAM, " + schemaproc + ".SGP_R_PAG_FIRM " + 
				"WHERE O2787_CDFIRMA= O2754_CDFIRMA " + 
				"AND O2754_FIRMADO = 'S' " + 
				"AND O2754_CODIGROL = :rol AND O2787_RFTRANS IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("rol", String.valueOf(rol));
		params.addValue("ids", listaRftsrans);
		
		return  namedParameterJdbcTemplate.query(sql, params, new ObtPagosSentRolFirmadoMapper());
		
	}
	
	public List<IdPagoCodCuenta> compPermCta(DetPerfiladoUsuarioResponse perfilado, List<ObtCuentaPagosOut> listaCuentasPagos, String pagosVerActivos) {
		int numeroServicios = perfilado.getMethodResult().getListadoServicios().size();

		Map<String, String> cuentasConPermisoApr = new HashMap<>();

		//Buscamos en el perfilado el producto asociado. 	
		for(int indiceServicio=INT_0; indiceServicio<numeroServicios; indiceServicio++)
		{		
			ServicioPaisAR servicio = perfilado.getMethodResult().getListadoServicios().get(indiceServicio).getServicio();		
			String codigoServicio = servicio.getCodServicio();

			if(codigoServicio.equals(STR_PA))
			{					
				//Recorremos las cuentas por paises.
				int numPaises = servicio.getListaPais().size();
				for(int indicePais = INT_0; indicePais < numPaises; indicePais++)
				{
					//Para cada pais
					PaisArbol cuentasPais = servicio.getListaPais().get(indicePais).getPais();
					//recorremos cuentas
					int numCuentas = cuentasPais.getListaCuentas().size();
					for(int indiceCuenta = INT_0; indiceCuenta < numCuentas; indiceCuenta++)
					{				
						CuentasArbol cuenta =  cuentasPais.getListaCuentas().get(indiceCuenta).getCuentasArbol();
						//buscamos permiso "apr"
						boolean encontradoApr = false;
						int numPermisos =cuenta.getPermisosSubprod().size();
						int indicePermisos = INT_0;
						while((indicePermisos<numPermisos) && (!encontradoApr))
						{
							ListaPermisosMetPagoArbol permisos = cuenta.getPermisosSubprod().get(indicePermisos);
							String permiso = permisos.getPermisosSubprod().getCodPermiso().trim();

							if (pagosVerActivos.equals(STR_S)){
								if(permiso.equalsIgnoreCase(STR_APR) || permiso.equalsIgnoreCase(STR_VER)) {                                                   
									encontradoApr = true;
									//Lo almacenamos, para formar la salida.
									String acuencot = String.valueOf(cuenta.getCodigoCuenta());
									cuentasConPermisoApr.put(acuencot, acuencot);                                  
								}                                 
							}else{
								if(permiso.equalsIgnoreCase(STR_APR)){                                                   
									encontradoApr = true;
									//Lo almacenamos, para formar la salida.
									String acuencot = String.valueOf(cuenta.getCodigoCuenta());
									cuentasConPermisoApr.put(acuencot, acuencot);                                  
								}
							}
							indicePermisos++;
						}										
					}			
				}		
			}		
		}

		List<IdPagoCodCuenta> listaPagoYCuentaConPermiso = new ArrayList<>();
		

		int tamPagoyCuenta = listaCuentasPagos.size();
		for(int indicePagoYCuenta = 0; indicePagoYCuenta<tamPagoyCuenta; indicePagoYCuenta++)
		{
			IdPagoCodCuenta idPagoCodCuenta = new IdPagoCodCuenta();
			ObtCuentaPagosOut cuenta = listaCuentasPagos.get(indicePagoYCuenta);		
			String acuencod = String.valueOf(cuenta.getAcuencod());
			if(cuentasConPermisoApr.containsKey(acuencod))
			{	
				idPagoCodCuenta.setAcuencot(cuenta.getAcuencod());
				idPagoCodCuenta.setRftrans(cuenta.getRftrans());
				
				listaPagoYCuentaConPermiso.add(idPagoCodCuenta);
			}
		}
		return listaPagoYCuentaConPermiso;
	}
	
	public List<String> filtraPagosFirmados(List<String> listaPagosSinFiltrar, List<String> listaPagosFirmados){
		
		List<String> listaPagosFiltrada = new ArrayList<>();
		
		if(listaPagosFirmados.isEmpty()) {
			// Si no hay pagos firmados previamente, la lista final contendra todos los pagos
			listaPagosFiltrada = listaPagosSinFiltrar;
		}else {
			// Añadimos los pagos firmados a un mapa
			Map<String, String> listaPagosFirmadosMap = new HashMap<>();
			
			for (int i = 0; i < listaPagosFirmados.size(); i++) {
				listaPagosFirmadosMap.put(listaPagosFirmados.get(i), listaPagosFirmados.get(i));
			}
			
			// Recorremos la lista de pagos sin filtrar
			for (int j = 0; j < listaPagosSinFiltrar.size(); j++) {
				if(!listaPagosFirmadosMap.containsKey(listaPagosSinFiltrar.get(j))) {
					listaPagosFiltrada.add(listaPagosSinFiltrar.get(j));
				}
			}
		}
		
		return listaPagosFiltrada;
		
	}
	
	public List<CompPagosRolUsuPendFirmaOut> comprobarRoles(List<ObtPagosSentRolOut> pagosSenRol, List<ObtPagosSentRolFirmadoOut> sentenciasFirmas, DetPerfiladoUsuarioResponse perfilado) {
		List<CompPagosRolUsuPendFirmaOut> salida = new ArrayList<>();
		
		int rolUsu = perfilado.getMethodResult().getCodigoRol();

		List<ObtPagosSentRolOut> pagosAux = new ArrayList<>();
		List<ObtPagosSentRolOut> pagosFinal = new ArrayList<>();
		String pagoF = "";
		int anordenF =0;
		String pagoN = "";
		int anordenN =0;
		int numFirmas=0;
		//calculamos por pago el numero de roles necesarios
		//si coincide o mayor eliminamos el pago

		Map<String, Integer> firmasPorPagoRol = new HashMap<>(0);
		//limpiamos la lista de sentencias y nos quedamos con la menor
		for(int i =0;i<pagosSenRol.size();i++){
			pagoN=pagosSenRol.get(i).getRftrans();
			anordenN=pagosSenRol.get(i).getAnorden();
			if(pagoF.equals(pagoN)){
				//si continuamos en el mismo pago
				//comprobamos si cambiamos de anorden
				if(anordenF==anordenN){
					//si no cambiamos de anorden y no cambiamos de pago nos quedamos con el pago
					//comprobamos que si exise con el mismo anordenGRP ATIPGRU="O" y mismo rol aumentamos anumfirm del que ya existe y no añadimos
					pagosAux=sumaOrAnadeRolesPago(pagosSenRol.get(i),pagosAux);
				}

				if(i==pagosSenRol.size()-1){
					numFirmas=calculaFirmasRol(pagosAux, rolUsu);
					if(numFirmas>0){
						//añadimos si numFirmas mayor 0. Si numFirmas es 0 el rol no existe en la sentencia
						firmasPorPagoRol.put(pagosAux.get(0).getRftrans(), numFirmas);
					}
					//es la ultima iteración
					for(int j = 0;j<pagosAux.size();j++){
						pagosFinal.add(pagosAux.get(j));

					}
					pagosAux.clear();
				}

			}else{
				//hemos pasado al siguiente pago o es el primero, por lo que cogemos su primer anorden y nos quedamos con el pago
				//añadimos directamente
				pagoF=pagoN;
				anordenF=anordenN;
				if(i!=0){
					numFirmas=calculaFirmasRol(pagosAux, rolUsu);
					if(numFirmas>0){
						//añadimos si numFirmas mayor 0. Si numFirmas es 0 el rol no existe en la sentencia
						firmasPorPagoRol.put(pagosAux.get(0).getRftrans(), numFirmas);
					}

					//hemos cambiado de pago
					for(int j = 0;j<pagosAux.size();j++){
						pagosFinal.add(pagosAux.get(j));

					}
					pagosAux.clear();
				}

				pagosAux.add(pagosSenRol.get(i));

				if(i==pagosSenRol.size()-1 && i!=0){
					numFirmas=calculaFirmasRol(pagosAux, rolUsu);
					if(numFirmas>0){
						//añadimos si numFirmas mayor 0. Si numFirmas es 0 el rol no existe en la sentencia
						firmasPorPagoRol.put(pagosAux.get(0).getRftrans(), numFirmas);
					}

					//hemos cambiado de pago
					for(int j = 0;j<pagosAux.size();j++){
						pagosFinal.add(pagosAux.get(j));

					}
					pagosAux.clear();
				}


				if(pagosSenRol.size()==1){

					//solo hay un pago con una sentencia sabemos que no está firmada
					//o hay un pago con una sentencia y no es el unico pago

					numFirmas=calculaFirmasRol(pagosAux, rolUsu);
					if (numFirmas!=0 || pagosAux.size()>0){
						pagosFinal.add(pagosAux.get(i));
						firmasPorPagoRol.put(pagosAux.get(0).getRftrans(), numFirmas);
					}
				}

			}
		}

		//comprobamos si tenemos que quitar pagos
		//Nos quedamos con las sentencias firmadas solo de la menor sentecia de autorización que es la unica que nos interesa



		int tamSentenciasFirma = sentenciasFirmas.size();


		int tamPagosFinal = pagosFinal.size();

		for(int z=tamSentenciasFirma-1;z>=0;z--){
			boolean existe=false;
			String pagoFirm = sentenciasFirmas.get(z).getRftrans();
			String cpolFirm = String.valueOf(sentenciasFirmas.get(z).getCodSentencia());
			String idAuthFirm = String.valueOf(sentenciasFirmas.get(z).getIdAutorizacion());

			for (int x=0;x<tamPagosFinal;x++){
				String pagoSentencia = pagosFinal.get(x).getRftrans();
				String cpolSentencia = String.valueOf(pagosFinal.get(x).getCodSentencia());
				String idAuthSentencia = String.valueOf(pagosFinal.get(x).getIdAutorizacion());
				if(pagoSentencia.equals(pagoFirm)&&cpolSentencia.equals(cpolFirm)&&idAuthSentencia.equals(idAuthFirm)){
					existe=true;

				}
			}
			if(!existe){
				//si no coincide la sentencia para el pago la eliminamos.
				sentenciasFirmas.remove(z);
			}
		}

		//calculamos el nuevo tamaño
		tamSentenciasFirma=sentenciasFirmas.size();

		//los que no están en firmasPorPagoRol no van a la salida, ya que no existe rol
		//ahora tenemos que comprobar si ha cumplido todas las firmas
		Map sentenciasFirmadasRol = new HashMap(0);
		for (int y=0;y<tamSentenciasFirma;y++){
			String pagoFirm = sentenciasFirmas.get(y).getRftrans();

			if(sentenciasFirmadasRol.containsKey(pagoFirm)){
				//si contiene la clave sumamos uno
				Integer firmPag = (Integer)sentenciasFirmadasRol.get(pagoFirm);
				sentenciasFirmadasRol.put(pagoFirm,firmPag+1);
			}else{
				//si no lo añadimos con uno
				sentenciasFirmadasRol.put(pagoFirm,1);
			}

		}

		Map pagosBorrar = new HashMap(0);
		String key=null;
		Iterator it = firmasPorPagoRol.keySet().iterator();
		while (it.hasNext()) {
			key=(String)it.next(); //en n tenemos el valor
			if(sentenciasFirmadasRol.containsKey(key)){
				Integer firmados = (Integer)sentenciasFirmadasRol.get(key);
				Integer firmadosMax = (Integer)firmasPorPagoRol.get(key);
				if(firmados>=firmadosMax){
					if(!pagosBorrar.containsKey(key)){
						pagosBorrar.put(key,key);
					}

				}
			}

		}
		//borramos
		Iterator itBorrar = pagosBorrar.keySet().iterator();
		while (itBorrar.hasNext()) {
			key=(String)itBorrar.next();
			if(firmasPorPagoRol.containsKey(key)){
				firmasPorPagoRol.remove(key);
			}

		}	
		//firmasPorPagoRol contiene los pagos que hay que devolver
		//tenemos que cargar la salida rellenando la sentencia

		//pagos a filtrar
		for (int z=0;z<pagosFinal.size();z++){
			//si el pago existe lo añadimos a la salida sin duplicarlos
			String pagoSalida = pagosFinal.get(z).getRftrans();


			if(firmasPorPagoRol.containsKey(pagoSalida)){
				String polSente = String.valueOf(pagosFinal.get(z).getCodSentencia());
				String autoSente = String.valueOf(pagosFinal.get(z).getIdAutorizacion());
				CompPagosRolUsuPendFirmaOut pagosSalida = new CompPagosRolUsuPendFirmaOut();

				pagosSalida.setRftrans(pagoSalida);
				pagosSalida.setCodSentencia(Integer.parseInt(polSente));
				pagosSalida.setIdAutorizacion(Integer.parseInt(autoSente));

				salida.add(pagosSalida);
				//eliminamos el pago para no duplicarlo a la salida
				firmasPorPagoRol.remove(pagoSalida);

			}

		}
		
		return salida;
	}
	
	public List<ObtPagosSentRolOut> sumaOrAnadeRolesPago(ObtPagosSentRolOut sentencia, List<ObtPagosSentRolOut> listaSentencia)
	{

		int tamLista = listaSentencia.size();
		boolean anadido = false;
		String atipagru= sentencia.getAtipagru();
		int anordengrp=sentencia.getAnordengrp();
		int codigRol = sentencia.getRol();
		int anumfirm = sentencia.getAnumfirm();


		for(int i=0;i<tamLista;i++){
			if(!anadido){
				int anordengrpLst = listaSentencia.get(i).getAnordengrp();
				int rolLst = listaSentencia.get(i).getRol();
				if(atipagru.equals("O") && anordengrp==anordengrpLst && codigRol==rolLst){
					//sumamos anumfirm
					int anumFirmLst =  listaSentencia.get(i).getAnumfirm();
					listaSentencia.get(i).setAnumfirm(anumFirmLst+anumfirm);

				}else if(atipagru.equals("A") && anordengrp==anordengrpLst && codigRol==rolLst){
					//NO sumamos anumfirm, actualizamos al mayor.
					int anumFirmLst =  listaSentencia.get(i).getAnumfirm();
					if (anumfirm>anumFirmLst){
						listaSentencia.get(i).setAnumfirm(anumfirm);
					}

				}else {
					//añadimos
					listaSentencia.add(sentencia);
					anadido=true;
				}
			}
		}


		return listaSentencia;	

	}
	
	public int calculaFirmasRol(List<ObtPagosSentRolOut> listaSentencia, int rol)
	{
		int firmasMax=0;
		//calculamos el numero de firmas maximo de un rol
		String tipoAgru="";

		int rolLista=0;
		//eliminamos los roles que no aplican para buscar el mayor.
		for(int j=listaSentencia.size()-1;j>=0;j--){
			rolLista=listaSentencia.get(j).getRol();
			if(rol!=rolLista){
				//eliminamos el registro
				listaSentencia.remove(j);
			}
		}


		for(int i=0;i<listaSentencia.size();i++){

			tipoAgru=listaSentencia.get(i).getAtipagru();
			int numFirmas = listaSentencia.get(i).getAnumfirm();
			if(tipoAgru.equals("A")){
				firmasMax+=numFirmas;


			}else{

				//OR
				//calculamos el mayor

				if(numFirmas>firmasMax){
					firmasMax=numFirmas;
				}
			}	


		}

		//si es AND sumamos los roles

		//si es OR es el numero máximo por grupo 

		//si firmas es 0 es que no existe el rol en la sentencia
		return firmasMax;


	}
	
	
	public List<String> obtPagosFirmaOKUsuarioInt(String uid, List<String> listaPagos) {
		
		List<String> listaTempPagFirm = new ArrayList<>();
		List<String> salidaPagFirm = new ArrayList<>();
		List<String> salidaTempPagFirm = new ArrayList<>();
		
		int tamListaRfTransPagFirm = listaPagos.size();
		if (tamListaRfTransPagFirm>0)
		{
			int numIters = tamListaRfTransPagFirm/1000 + ((tamListaRfTransPagFirm%1000)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMinPagFirm = Math.min(1000*(i+1),tamListaRfTransPagFirm);
				listaTempPagFirm.clear();
				for (int j=i*1000;j<tamMinPagFirm;j++)
				{
					listaTempPagFirm.add(listaPagos.get(j));	
					
				}
				
				salidaTempPagFirm = obtPagosFirmaOKUsuarioPrivado(uid, listaTempPagFirm);
				
				int tamListaTempPagFirm = salidaTempPagFirm.size();
				for (int j = 0; j < tamListaTempPagFirm; j++) {
					salidaPagFirm.add(salidaTempPagFirm.get(j));
				}
				
			}
		}
		
		return salidaPagFirm;
	}
	
	private List<String> obtPagosFirmaOKUsuarioPrivado(String uidPagFirm, List<String> listaPagosPagFirm) {
		
		String sqlPagFirm = "SELECT O2787_RFTRANS FROM " + schemaproc + ".SGP_PAGO_FIRENM, " + schemaproc + ".SGP_PAGO_FIRMAM, " + schemaproc + ".SGP_R_PAG_FIRM " + 
				"WHERE O2753_CDFIRMA = O2754_CDFIRMA " + 
				"AND O2754_CDFIRMA = O2787_CDFIRMA " + 
				"AND O2754_UID = :uid " + 
				"AND O2753_INDFIROK = 'S' " + 
				"AND O2787_RFTRANS IN (:idPagos)";

		// Rellenamos con espacios
		uidPagFirm = String.format("%1$-30s", uidPagFirm);
		
		if(listaPagosPagFirm.isEmpty()) {
			listaPagosPagFirm.add("");
		}
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("uid", uidPagFirm)
		.addValue("idPagos", listaPagosPagFirm);
		return namedParameterJdbcTemplate.query(sqlPagFirm, params, new ObtPagosFirmaMapper());	
	
	}

}
