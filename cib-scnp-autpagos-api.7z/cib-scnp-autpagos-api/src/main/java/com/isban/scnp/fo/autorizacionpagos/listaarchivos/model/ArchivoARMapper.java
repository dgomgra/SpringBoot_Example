package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class ArchivoARMapper implements RowMapper<ArchivoAR>{

	@Override
	public ArchivoAR mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ArchivoAR datosDelArchivo = new ArchivoAR();
		datosDelArchivo.setIdArchivo(rs.getInt("O9247_IDARCH"));
		datosDelArchivo.setFecha(rs.getTimestamp("O9247_FEC_ARCH"));
		datosDelArchivo.setEstado(rs.getString("O9247_ESTARCH"));
		datosDelArchivo.setNombre(rs.getString("O9247_NOMARCHAUT").trim());
		datosDelArchivo.setNumTransacciones(rs.getInt("O9247_NUM_TRANS"));
		
		return datosDelArchivo;
		
	}

}
