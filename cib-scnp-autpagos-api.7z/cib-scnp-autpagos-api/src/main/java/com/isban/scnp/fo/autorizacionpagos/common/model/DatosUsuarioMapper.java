package com.isban.scnp.fo.autorizacionpagos.common.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosUsuarioMapper implements RowMapper<DatosUsuario>{

	@Override
	public DatosUsuario mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new DatosUsuario(
				rs.getString("H1185_NFORMCAN").trim(), 
				rs.getString("H1184_NFORMFEC").trim(), 
				rs.getString("H1186_IDIOMASC"), 
				rs.getString("H1186_CODPAIS"), 
				rs.getString("H1186_CRIPTOVIRT")
				);
	}
}
