package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.math.BigDecimal;
import java.util.Date;

public class ConsultaPagosCreados_S {
	private String idEstado;
	private BigDecimal importe;
	private String divisa;
	private Date fecha;
	private String refCliente;
	private String refSistema;
	private String codMedioPago;
	private String  indImp;
	private String indNota;
	private String indicadorUpload;
	private String indStopPayment;
	private String aliasCuentaOrdenante;
	private String codExtracto;
	private int codEnt;
	private int codBeneficiario;
	private int idAutorizacionBeneficiario;
	private String nomBenef;
	private int cuenta;
	private String pais;
	private String descEstPago;
	
	public ConsultaPagosCreados_S() {
		super();
	}

	public String getIdEstado() {
		return idEstado;
	}

	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public String getDivisa() {
		return divisa;
	}

	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getRefCliente() {
		return refCliente;
	}

	public void setRefCliente(String refCliente) {
		this.refCliente = refCliente;
	}

	public String getRefSistema() {
		return refSistema;
	}

	public void setRefSistema(String refSistema) {
		this.refSistema = refSistema;
	}

	public String getCodMedioPago() {
		return codMedioPago;
	}

	public void setCodMedioPago(String codMedioPago) {
		this.codMedioPago = codMedioPago;
	}

	public String getIndImp() {
		return indImp;
	}

	public void setIndImp(String indImp) {
		this.indImp = indImp;
	}
	
	public String getIndNota() {
		return indNota;
	}

	public void setIndNota(String indNota) {
		this.indNota = indNota;
	}

	public String getIndicadorUpload() {
		return indicadorUpload;
	}

	public void setIndicadorUpload(String indicadorUpload) {
		this.indicadorUpload = indicadorUpload;
	}
	public String getIndStopPayment() {
		return indStopPayment;
	}

	public void setIndStopPayment(String indStopPayment) {
		this.indStopPayment = indStopPayment;
	}
	
	public String getAliasCuentaOrdenante() {
		return aliasCuentaOrdenante;
	}

	public void setAliasCuentaOrdenante(String aliasCuentaOrdenante) {
		this.aliasCuentaOrdenante = aliasCuentaOrdenante;
	}

	public String getCodExtracto() {
		return codExtracto;
	}

	public void setCodExtracto(String codExtracto) {
		this.codExtracto = codExtracto;
	}

	public int getCodEnt() {
		return codEnt;
	}

	public void setCodEnt(int codEnt) {
		this.codEnt = codEnt;
	}

	public int getCodBeneficiario() {
		return codBeneficiario;
	}

	public void setCodBeneficiario(int codBeneficiario) {
		this.codBeneficiario = codBeneficiario;
	}

	public int getIdAutorizacionBeneficiario() {
		return idAutorizacionBeneficiario;
	}

	public void setIdAutorizacionBeneficiario(int idAutorizacionBeneficiario) {
		this.idAutorizacionBeneficiario = idAutorizacionBeneficiario;		
	}
	
	public String getNomBenef() {
		return nomBenef;
	}

	public void setNomBenef(String nomBenef) {
		this.nomBenef = nomBenef;
	}

	public int getCuenta() {
		return cuenta;
	}

	public void setCuenta(int cuenta) {
		this.cuenta = cuenta;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getDescEstPago() {
		return descEstPago;
	}

	public void setDescEstPago(String descEstPago) {
		this.descEstPago = descEstPago;
	}
}
