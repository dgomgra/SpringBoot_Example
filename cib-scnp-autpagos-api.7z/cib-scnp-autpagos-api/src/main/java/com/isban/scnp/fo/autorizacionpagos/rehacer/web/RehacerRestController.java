package com.isban.scnp.fo.autorizacionpagos.rehacer.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerRequest;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerResponseData;
import com.isban.scnp.fo.autorizacionpagos.rehacer.service.RehacerHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "RehacerRestController", description = "Operations pertaining to Rehacer Operation")
public class RehacerRestController {
	
	private static final String STR_KO = "KO";
	private static final String STR_ERROR = "error";
	private static final String STR_ESPACIO = " ";
	private static final String STR_AUTORIZAR = "Autorizar";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";
	private static final String STR_MSG_OK = "OK";
	
	@Autowired
	private RehacerHelperService rehacerHelperService;
	
	@PostMapping(value = "/v1/rehacer", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Rehacer operation")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	
	public ResponseEntity<RehacerResponseData> getRehacer(@RequestBody RehacerRequest request){
		try
		{
			log.debug("REST POST call received in /v1/rehacer {} {} {} {}",
					request.getListaIds(),
					request.getNota(),
					request.getTokenBks()
					);
			RehacerResponseData rehacerResponseData = new RehacerResponseData();
			rehacerHelperService.rehacerImpl(request);
			rehacerResponseData.setStatus("OK");
			rehacerResponseData.setMessage(STR_MSG_OK);
			return new ResponseEntity<>(rehacerResponseData, HttpStatus.OK);
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_AUTORIZAR + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			RehacerResponseData respuesta = new RehacerResponseData();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(respuesta, HttpStatus.UNAUTHORIZED);
			}else {
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
			}			
		}catch(Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_AUTORIZAR + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			RehacerResponseData respuesta = new RehacerResponseData();
			respuesta.setStatus(STR_KO);
			respuesta.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
