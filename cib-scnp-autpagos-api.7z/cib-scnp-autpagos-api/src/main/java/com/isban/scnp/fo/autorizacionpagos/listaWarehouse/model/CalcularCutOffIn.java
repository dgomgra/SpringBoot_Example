package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.util.ArrayList;
import java.util.List;

public class CalcularCutOffIn {

	private List<CalcularCutOff_E> entrada;
	
	public CalcularCutOffIn() {
		super();
		this.setEntrada(new ArrayList<CalcularCutOff_E>(0));
	}

	public List<CalcularCutOff_E> getEntrada() {
		return entrada;
	}

	public void setEntrada(List<CalcularCutOff_E> entrada) {
		this.entrada = entrada;
	}
	public void addEntrada (CalcularCutOffDatosE cutOffAnadir)
	{
		CalcularCutOff_E nuevo = new CalcularCutOff_E();
		nuevo.setCalcularCutOff(cutOffAnadir);		
		entrada.add(nuevo);
	}
}
