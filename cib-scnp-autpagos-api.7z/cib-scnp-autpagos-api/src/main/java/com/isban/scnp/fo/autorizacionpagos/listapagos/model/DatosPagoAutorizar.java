package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;

public class DatosPagoAutorizar implements Comparable<DatosPagoAutorizar>{
	
	private String rftrans;
	private String indNota;
	private String  indImp;
	private String idEstado;
	private String codExtracto;
	private int codBeneficiario;
	private int idAutorizacion;
	private String nomBenef;
	private BigDecimal importe;
	private String divisa;
	private Date fecha;
	private String refCliente;
	private String indicadorUpload;
	private String codPais;
	private String codMedioPago;
	private String descEstPago;
	private int cuentaOrdenante;
	private String descNota;
	
	public String getRftrans() {
		return rftrans;
	}
	public void setRftrans(String rftrans) {
		this.rftrans = rftrans;
	}
	public String getIndNota() {
		return indNota;
	}
	public void setIndNota(String indNota) {
		this.indNota = indNota;
	}
	public String getIndImp() {
		return indImp;
	}
	public void setIndImp(String indImp) {
		this.indImp = indImp;
	}
	public String getIdEstado() {
		return idEstado;
	}
	public void setIdEstado(String idEstado) {
		this.idEstado = idEstado;
	}
	public String getCodExtracto() {
		return codExtracto;
	}
	public void setCodExtracto(String codExtracto) {
		this.codExtracto = codExtracto;
	}
	public int getCodBeneficiario() {
		return codBeneficiario;
	}
	public void setCodBeneficiario(int codBeneficiario) {
		this.codBeneficiario = codBeneficiario;
	}
	public int getIdAutorizacion() {
		return idAutorizacion;
	}
	public void setIdAutorizacion(int idAutorizacion) {
		this.idAutorizacion = idAutorizacion;
	}
	public String getNomBenef() {
		return nomBenef;
	}
	public void setNomBenef(String nomBenef) {
		this.nomBenef = nomBenef;
	}
	@JsonSerialize(using = AmountSerializer.class)
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	@JsonSerialize(using = DateSerializer.class)
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getRefCliente() {
		return refCliente;
	}
	public void setRefCliente(String refCliente) {
		this.refCliente = refCliente;
	}
	public String getIndicadorUpload() {
		return indicadorUpload;
	}
	public void setIndicadorUpload(String indicadorUpload) {
		this.indicadorUpload = indicadorUpload;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getCodMedioPago() {
		return codMedioPago;
	}
	public void setCodMedioPago(String codMedioPago) {
		this.codMedioPago = codMedioPago;
	}
	public String getDescEstPago() {
		return descEstPago;
	}
	public void setDescEstPago(String descEstPago) {
		this.descEstPago = descEstPago;
	}
	public int getCuentaOrdenante() {
		return cuentaOrdenante;
	}
	public void setCuentaOrdenante(int cuentaOrdenante) {
		this.cuentaOrdenante = cuentaOrdenante;
	}
	public String getDescNota() {
		return descNota;
	}
	public void setDescNota(String descNota) {
		this.descNota = descNota;
	}

	@Override
	public int compareTo(DatosPagoAutorizar datos) {
		return datos.getFecha().compareTo(getFecha());		
	}
	
	@Override
	public boolean equals(Object o) {
		boolean retorno=false;

		if (o != null && this.getClass()==o.getClass())
		{
			DatosPagoAutorizar dl = (DatosPagoAutorizar) o ;
			retorno = getRftrans().equals(dl.getRftrans());
		}
		return retorno;
	}
	@Override
	public int hashCode() 
	{
		 return getRftrans().hashCode();
	}
	
}

