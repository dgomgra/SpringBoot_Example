package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

import java.math.BigDecimal;

public class MonedasArchivos {

	private int idArchivo;
	private String moneda;
	private BigDecimal importe;
	
	public MonedasArchivos(int idArchivo, String moneda, BigDecimal importe) {
		this.setIdArchivo(idArchivo);
		this.setMoneda(moneda);
		this.setImporte(importe);
	}
	public int getIdArchivo() {
		return idArchivo;
	}
	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	
}
