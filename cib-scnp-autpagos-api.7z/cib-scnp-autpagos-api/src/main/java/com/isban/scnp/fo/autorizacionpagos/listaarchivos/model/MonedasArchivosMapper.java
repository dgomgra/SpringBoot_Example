package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class MonedasArchivosMapper implements RowMapper<MonedasArchivos>{

	@Override
	public MonedasArchivos mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new MonedasArchivos(rs.getInt("O9248_IDARCH"), rs.getString("O9248_CODMONSWI"), rs.getBigDecimal("O9248_IMPPAISMON"));
	}

}
