package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class IdLoteNombre {
	private String idLote;
	private String nomLote;
	
	
	public IdLoteNombre() {
		super();
	}
	public IdLoteNombre(String idLote, String nomLote) {
		super();
		this.idLote = idLote;
		this.nomLote = nomLote;
	}
	public String getIdLote() {
		return idLote;
	}
	public void setIdLote(String idLote) {
		this.idLote = idLote;
	}
	public String getNomLote() {
		return nomLote;
	}
	public void setNomLote(String nomLote) {
		this.nomLote = nomLote;
	}	
}
