package com.isban.scnp.fo.autorizacionpagos.detallear.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;

public class DatosArchivo {
	private String pais;
	private Integer numTransac;
	private BigDecimal monto;
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public Integer getNumTransac() {
		return numTransac;
	}
	public void setNumTransac(Integer numTransac) {
		this.numTransac = numTransac;
	}
	@JsonSerialize(using = AmountSerializer.class)
	public BigDecimal getMonto() {
		return monto;
	}
	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	private String divisa;
	
	
}
