package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ObtArchivoSentRolFirmadoMapper implements RowMapper<ObtArchivoSentRolFirmado>{

	@Override
	public ObtArchivoSentRolFirmado mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new ObtArchivoSentRolFirmado(rs.getInt("O9250_IDARCH"), rs.getInt("O9250_CPOLSENTE"), rs.getInt("O9250_IDAUTH")); 
	}

}
