package com.isban.scnp.fo.autorizacionpagos.comppagosrol.service;

import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;

public interface CompPagosRolHelperService {
	
	public List<CompPagosRolUsuPendFirmaOut> compPagosRolUsuPendFirma(CompPagosRolUsuPendFirmaIn entrada); 

}
