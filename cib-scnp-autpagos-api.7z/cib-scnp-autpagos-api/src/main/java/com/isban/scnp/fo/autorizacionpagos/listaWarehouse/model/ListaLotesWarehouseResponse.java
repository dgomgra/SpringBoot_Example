package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class ListaLotesWarehouseResponse {
	private String status;
	private String message;
	private List<DatosLotesWarehousing> listaDatosLotesWarehousing;
	private List<String> listaDivisas;
	private int totalLotes;
	private int pagina;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<DatosLotesWarehousing> getListaDatosLotesWarehousing() {
		return listaDatosLotesWarehousing;
	}
	public void setListaDatosLotesWarehousing(List<DatosLotesWarehousing> listaDatosLotesWarehousing) {
		this.listaDatosLotesWarehousing = listaDatosLotesWarehousing;
	}	
	public List<String> getListaDivisas() {
		return listaDivisas;
	}
	public void setListaDivisas(List<String> listaDivisas) {
		this.listaDivisas = listaDivisas;
	}
	public int getTotalLotes() {
		return totalLotes;
	}
	public void setTotalLotes(int totalLotes) {
		this.totalLotes = totalLotes;
	}
	public int getPagina() {
		return pagina;
	}
	public void setPagina(int pagina) {
		this.pagina = pagina;
	}	
	
}
