package com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.CompPagosRolHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ComprobarTokenMapper;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.DatosPagoAutorizar;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.DatosPagoAutorizarProc;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaNombres;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ObtDetalleNotaMapper;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ObtDetalleNotaOut;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ObtNotasMapper;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ObtPagosFirmaMapper;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.PagosUsuarioAutorizProcedureOut;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ListaPagosHelperServiceImpl implements ListaPagosHelperService{

	private static final String STR_MT = "MT";
	private static final String STR_CERO = "0";
	private static final String STR_XXX = "XXX";
	private static final String STR_FORMATO_FECHA = "yyyy-MM-dd";
	private static final String STR_KO = "KO";
	private static final String STR_OK = "OK";
	private static final String STR_VACIO = "";
	private static final String STR_S = "S";
	private static final String STR_RESULT = "result";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_LISTA_DE_PAGOS = "Lista de pagos";
	private static final String STR_ERROR = "error";
	private static final String STR_ERROR_NO_FIRMA = "0023";
	private static final String STR_ERROR_NO_HAY_DATOS = "0000";
	private static final String STR_MSG_OK = "OK";
	
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    
	@Autowired
	private CompPagosRolHelperService compPagosRolHelperService;
	
	@Value("${schema_proc}")
    protected String schemaproc;
    
	
	private void closeConnection ()
	{
		try {
			if (jdbcTemplate!=null)
			{
				jdbcTemplate.getDataSource().getConnection().close();
			}
		} catch (SQLException e) {			
		}
	}
	
	@Override
	public ListaPagosAutorizarResponse getListaPagosAutorizarImp(
			ListaPagosAutorizarRequest listaPagosAutorizarRequest) {

		// Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
			
		// Comprobamos si el usuario tiene firma
		String uidToken = comprobarTokenSKeyUsu(uidLogado);
		
		if(uidToken != null) {
			// Invocamos al procedimiento que obtiene los pagos para autorizar
			String idLote = listaPagosAutorizarRequest.getIdLote();
			String pais = listaPagosAutorizarRequest.getPais();
			PagosUsuarioAutorizProcedureOut datosPagos = getPagosUsuarioAutorizProcedure(uidLogado, idLote, pais);
			
			// Si hay pagos pendientes de autorizar
			if(!datosPagos.getDatosPagosAutorizar().isEmpty()) {
				// Rellenamos los datos de salida
				ListaPagosAutorizarResponse salidaTemp = rellenarDatos(datosPagos);
				
				// Rellenamos la lista aux de Pagos Cuenta
				List<Integer> listaPagosCuenta = rellenarPagosCuenta(datosPagos);
				
				// Rellenamos la lista de nombres
				List<ListaNombres> nombres = rellenarListaNombres(datosPagos) ;
				
				// Comprobamos si alguno de los pagos, ya ha sido firmado por el usuario de la lista de pagos liberados
				List<String> pagosYaFirmados = obtPagosFirmaOKUsuario(uidLogado, datosPagos.getPagosLib());
				
				// Consultamos los pagos cuyo rol cumple con la sentencia del rol del usuario logado
				List<String> listaIdPago = new ArrayList<>();
				for (int i = 0; i < datosPagos.getDatosPagosAutorizar().size(); i++) {
					listaIdPago.add(datosPagos.getDatosPagosAutorizar().get(i).getRftrans());
				}
				CompPagosRolUsuPendFirmaIn compPagosRolUsuPendFirmaIn = new CompPagosRolUsuPendFirmaIn();
				compPagosRolUsuPendFirmaIn.setListaIdPago(listaIdPago);
				compPagosRolUsuPendFirmaIn.setPagosVerActivos(STR_S);
				
				compPagosRolUsuPendFirmaIn.setTokenBks(listaPagosAutorizarRequest.getTokenBks());
				compPagosRolUsuPendFirmaIn.setUid(uidToken);
				List<CompPagosRolUsuPendFirmaOut> pagosConRolOk = compPagosRolHelperService.compPagosRolUsuPendFirma(compPagosRolUsuPendFirmaIn);
				
				List<String> listaPagosFiltrados = new ArrayList<>();
				for (int j = 0; j < pagosConRolOk.size(); j++) {
					listaPagosFiltrados.add(pagosConRolOk.get(j).getRftrans());
				}
				
				
				// Preparamos los datos para la salida
				String divisa = STR_VACIO;
				ListaPagosAutorizarResponse salida = tratarDatos(listaPagosFiltrados, salidaTemp, listaPagosCuenta, nombres, pagosYaFirmados, divisa);
				
				// Rellenamos la descripción de la nota de aquellos pagos que la tengan
				salida = rellenarNotas(salida);
				
				// Devolvemos los datos de la paginacion
				salida = datosPaginacion(salida, listaPagosAutorizarRequest);
				salida.setStatus(STR_OK);
				salida.setMessage(STR_MSG_OK);
				closeConnection();
				return salida;
			}else {
				closeConnection();
				log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_PAGOS + STR_DOS_PUNTOS_Y_ESPACIO + STR_ERROR_NO_FIRMA);
				ListaPagosAutorizarResponse listaPagosAutorizarResponse = new ListaPagosAutorizarResponse();
				listaPagosAutorizarResponse.setStatus(STR_KO);
				listaPagosAutorizarResponse.setMessage(STR_ERROR_NO_HAY_DATOS);
				return listaPagosAutorizarResponse;
			}
		}else {
			closeConnection();
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_DE_PAGOS + STR_DOS_PUNTOS_Y_ESPACIO + STR_ERROR_NO_FIRMA);
			ListaPagosAutorizarResponse listaPagosAutorizarResponse = new ListaPagosAutorizarResponse();
			listaPagosAutorizarResponse.setStatus(STR_KO);
			listaPagosAutorizarResponse.setMessage(STR_ERROR_NO_FIRMA);
			return listaPagosAutorizarResponse;
		}
	}
	
	public String comprobarTokenSKeyUsu(String uid) {
		
		String sql = "SELECT H1186_UID FROM " + schemaproc + ".SGP_USUARIO, " + schemaproc + ".SGP_GRUPO_EMP WHERE H1186_UID = ? "
				+ "AND H1186_CDEMGR= H1196_CDEMGR AND ((H1196_TIPTOKEN='3' AND H1186_TOKENCIF='S' "
				+ "AND TRIM(H1186_ID3SKEY) is NOT NULL) OR  ((H1196_TIPTOKEN='V' AND H1186_INDVASCO='S' "
				+ "AND TRIM(H1186_VASCOID) is NOT NULL)))";

		// Rellenamos con espacios
		uid = String.format("%1$-30s", uid);
		
		Object[] params = new Object[] {uid};
		List<String> lista = jdbcTemplate.query(sql, params, new ComprobarTokenMapper());
		
		int tamLista = lista.size();
		
		if(tamLista > 0) {
			return lista.get(0);
		}else {
			return null;
		}
		
	}
	
	public PagosUsuarioAutorizProcedureOut getPagosUsuarioAutorizProcedure(String uidLogado, String idLote, String pais){
		PagosUsuarioAutorizProcedureOut salida = new PagosUsuarioAutorizProcedureOut();
		 List<SqlParameter> prmtrsList = new ArrayList<>();
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.DATE));
	        prmtrsList.add(new SqlParameter(Types.DATE));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.DECIMAL));
	        prmtrsList.add(new SqlParameter(Types.DECIMAL));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlParameter(Types.VARCHAR));
	        prmtrsList.add(new SqlOutParameter(STR_RESULT, -10));
	        
	        // Calculamos las fechas desde hoy hasta 90 dias
	        Calendar cal = Calendar.getInstance();
			Date hoy = new Date();
			cal.setTime(hoy);
			cal.add(Calendar.DAY_OF_YEAR, 90);
			
			SimpleDateFormat formatFecha = new SimpleDateFormat(STR_FORMATO_FECHA);
			
			//java.sql.Date fechaIni = java.sql.Date.valueOf("2018-10-02");
			String fechaIni = formatFecha.format(hoy.getTime());
			String fechaFin = formatFecha.format(cal.getTime());
	        BigDecimal impDesde = new BigDecimal("0.00");
	        BigDecimal impHasta = new BigDecimal("0.00");

	        Map<String, Object> datos = jdbcTemplate.call(new CallableStatementCreator() {

	      
	        public CallableStatement createCallableStatement(Connection connection) throws SQLException {
	        String lote = "                ";
	        if(idLote != null && !STR_VACIO.equals(idLote)) {
	        	lote = idLote;
	        }
	        
	        String indPais = "N";
	        String codPais = STR_VACIO;
	        if(pais != null && !STR_VACIO.equals(pais)) {
	        	indPais = STR_S;
	        	codPais = pais;
	        }

	        String query = "{call " + schemaproc + ".PKG_OBTPAGOS_AUT.get_pagos_usuario_autoriz (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
	        CallableStatement callableStatement = connection.prepareCall(query);
	        callableStatement.setString(1, uidLogado);                      //p_usuario
	        callableStatement.setDate(2, java.sql.Date.valueOf(fechaIni));  //p_fecha_desde
	        callableStatement.setDate(3, java.sql.Date.valueOf(fechaFin));  //p_fecha_hasta
	        callableStatement.setString(4, "N");                            //p_ind_monto_desde
	        callableStatement.setString(5, "N");                            //p_ind_monto_hasta
	        callableStatement.setBigDecimal(6, impDesde);                   //p_monto_desde
	        callableStatement.setBigDecimal(7, impHasta);                   //p_monto_hasta
	        callableStatement.setString(8, indPais);                        //p_ind_cod_pais
	        callableStatement.setString(9, codPais);                        //p_pais
	        callableStatement.setString(10, "N");                           //p_ind_ref_cliente
	        callableStatement.setString(11, STR_VACIO);                     //p_ref_cliente
	        callableStatement.setString(12, "N");                           //p_ind_nom_benef
	        callableStatement.setString(13, STR_VACIO);                     //p_nom_benef
	        callableStatement.setString(14, "N");                           //p_ind_cuenta_debito
	        callableStatement.setString(15, STR_VACIO);                     //p_cuenta_debito
	        callableStatement.setString(16, "N");                           //p_ind_metodo_pago
	        callableStatement.setString(17, STR_VACIO);                     //p_lista_cod_metodo_pago
	        callableStatement.setString(18, STR_S);                         //p_ind_estado
	        callableStatement.setString(19, "LA,AP");                       //p_lista_id_estado_pago
	        callableStatement.setString(20, "N");                           //p_ind_primera_busq
	        callableStatement.setString(21, "apr,ver");                     //p_lista_permisos
	        callableStatement.setString(22, lote);                          //p_id_lote
	        callableStatement.setString(23, "3");                           //p_ind_llamada_est
	        callableStatement.setString(24, " es");                         //p_idioma_usuario
	        callableStatement.setString(25, "ES");                          //p_pais_usuario
	        callableStatement.registerOutParameter(26, -10);                //cursor (OracleTypes.CURSOR = -10)
	        return callableStatement;

	        }
	        }, prmtrsList);
	        
			if(datos.containsKey(STR_RESULT)) {
			List<Map<String, Object>> listaObjetos = (List<Map<String, Object>>)datos.get(STR_RESULT);
			
			List<DatosPagoAutorizarProc> datosPagosAutorizar = new ArrayList<>();
			List<String> pagosLib = new ArrayList<>();
			List<String> pagosSinLib = new ArrayList<>();
			
			for (int i = 0; i < listaObjetos.size(); i++) {
				DatosPagoAutorizarProc datosPagoAutorizarProc = new DatosPagoAutorizarProc();
				datosPagoAutorizarProc.setRftrans(String.valueOf(listaObjetos.get(i).get("N6563_RFTRANS")));
				datosPagoAutorizarProc.setIdEstado(String.valueOf(listaObjetos.get(i).get("N6563_ESTPAGO")));
				String importe = String.valueOf(listaObjetos.get(i).get("N6563_CANTPAGL"));
				datosPagoAutorizarProc.setImporte(new BigDecimal(importe));
				datosPagoAutorizarProc.setDivisa(String.valueOf(listaObjetos.get(i).get("N6563_CODMONSWI")));
				Date fecha;
				try {
					fecha = formatFecha.parse(String.valueOf(listaObjetos.get(i).get("N6563_FEC_VAL")));
				} catch (ParseException exc) {
					fecha = null;
				}
				datosPagoAutorizarProc.setFecha(fecha);
				datosPagoAutorizarProc.setRefCliente(String.valueOf(listaObjetos.get(i).get("N6563_CLIREFER")));
				datosPagoAutorizarProc.setCodMedioPago(String.valueOf(listaObjetos.get(i).get("N6563_CDMEDPAG")));
				String claben = String.valueOf(listaObjetos.get(i).get("N6563_CLABEN"));
				datosPagoAutorizarProc.setClaben(Integer.parseInt(claben));
				datosPagoAutorizarProc.setN2897_nombens1(String.valueOf(listaObjetos.get(i).get("N2897_NOMBENS1")));
				datosPagoAutorizarProc.setN2897_nombenc(String.valueOf(listaObjetos.get(i).get("N2897_NOMBENC")));
				datosPagoAutorizarProc.setO2785_nombens1(String.valueOf(listaObjetos.get(i).get("O2785_NOMBENS1")));
				datosPagoAutorizarProc.setN6564_nombenc(String.valueOf(listaObjetos.get(i).get("N6564_NOMBENC")));
				String codCuenta = String.valueOf(listaObjetos.get(i).get("N6563_ACUENCOT"));
				datosPagoAutorizarProc.setCodCuenta(Integer.parseInt(codCuenta));
				String idAuto = String.valueOf(listaObjetos.get(i).get("N6563_IDAUTH"));
				datosPagoAutorizarProc.setIdAuto(Integer.parseInt(idAuto));
				datosPagoAutorizarProc.setPais(String.valueOf(listaObjetos.get(i).get("N6563_CODPAIS")));
				datosPagoAutorizarProc.setIndImp(String.valueOf(listaObjetos.get(i).get("N6563_INMODIFI")));
				datosPagoAutorizarProc.setIndNota(String.valueOf(listaObjetos.get(i).get("INDNOTA_PAGO")));
				datosPagoAutorizarProc.setIndicadorUpload(String.valueOf(listaObjetos.get(i).get("INDUPL_PAGO")));
				datosPagoAutorizarProc.setCodExtracto(String.valueOf(listaObjetos.get(i).get("H1162_CODCTAEX")));
				datosPagoAutorizarProc.setDescEstPago(String.valueOf(listaObjetos.get(i).get("ESTADO_TRAD")));
				datosPagosAutorizar.add(datosPagoAutorizarProc);
				
				String indLib = String.valueOf(listaObjetos.get(i).get("INDLIB"));
				
				if(STR_S.equals(indLib)) {
					pagosLib.add(datosPagoAutorizarProc.getRftrans());
				}else {
					pagosSinLib.add(datosPagoAutorizarProc.getRftrans());
				}
			}
			
			salida.setDatosPagosAutorizar(datosPagosAutorizar);
			salida.setPagosLib(pagosLib);
			salida.setPagosSinLib(pagosSinLib);
			
		}
	        
	        return salida;
	}

	@Override
	public List<String> obtPagosFirmaOKUsuario(String uid, List<String> listaPagos) {
		
		List<String> listaTemp = new ArrayList<>();
		List<String> salida = new ArrayList<>();
		List<String> salidaTemp = new ArrayList<>();
		
		int tamListaRfTrans = listaPagos.size();
		if (tamListaRfTrans>0)
		{
			int numIters = tamListaRfTrans/1000 + ((tamListaRfTrans%1000)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(1000*(i+1),tamListaRfTrans);
				listaTemp.clear();
				for (int j=i*1000;j<tamMin;j++)
				{
					listaTemp.add(listaPagos.get(j));	
					
				}
				
				salidaTemp = obtPagosFirmaOKUsuarioPriv(uid, listaTemp);
				
				int tamListaTemp = salidaTemp.size();
				for (int j = 0; j < tamListaTemp; j++) {
					salida.add(salidaTemp.get(j));
				}
				
			}
		}
		
		return salida;
	}
	
	private List<String> obtPagosFirmaOKUsuarioPriv(String uid, List<String> listaPagos) {
		
		String sql = "SELECT O2787_RFTRANS FROM " + schemaproc + ".SGP_PAGO_FIRENM, " + schemaproc + ".SGP_PAGO_FIRMAM, " + schemaproc + ".SGP_R_PAG_FIRM " + 
				"WHERE O2753_CDFIRMA = O2754_CDFIRMA " + 
				"AND O2754_CDFIRMA = O2787_CDFIRMA " + 
				"AND O2754_UID = :uid " + 
				"AND O2753_INDFIROK = 'S' " + 
				"AND O2787_RFTRANS IN (:idPagos)";

		// Rellenamos con espacios
		uid = String.format("%1$-30s", uid);
		
		if(listaPagos.isEmpty()) {
			listaPagos.add(STR_VACIO);
		}
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("uid", uid)
		.addValue("idPagos", listaPagos);
		return namedParameterJdbcTemplate.query(sql, params, new ObtPagosFirmaMapper());	
	
	}
	
	public String obtNotas(String rftrans){
		String salida = STR_VACIO;
		Date fecha = null;
		String sql = "SELECT O2765_CDNOTA FROM " + schemaproc + ".SGP_R_NOTA_PAG WHERE O2765_RFTRANS = ?";
		
		Object[] params = new Object[] {rftrans};
		List<String> listaIdNota = jdbcTemplate.query(sql, params, new ObtNotasMapper());
		
		int tamListaNotas =  listaIdNota.size();
		
		
		for (int i = 0; i < tamListaNotas; i++) {
			int nota = Integer.parseInt(listaIdNota.get(i));
			ObtDetalleNotaOut detalle = obtDetalleNota(nota);
			
			Date fechaTemp = detalle.getO2760_NOTES_TS();
			String descTemp = detalle.getO2760_ANOTAS();
			
			if(fecha != null) {
				if(fecha.before(fechaTemp)) {
					fecha = fechaTemp;
					salida = descTemp;
				}
			}else {
				fecha = fechaTemp;
				salida = descTemp;
			}
		}
		
		return salida;
	}
	
	public ObtDetalleNotaOut obtDetalleNota(int idNota) {
		ObtDetalleNotaOut salida = new ObtDetalleNotaOut();
		String sql = "SELECT O2760_CDNOTA, O2760_ANOTAS, O2760_NOTES_TS " +
				"FROM " + schemaproc + ".SGP_NOTA " + 
				"WHERE O2760_CDNOTA= ?";
		
		Object[] params = new Object[] {idNota};
		List<ObtDetalleNotaOut> listaDetalleNota = jdbcTemplate.query(sql, params, new ObtDetalleNotaMapper());
		
		if(!listaDetalleNota.isEmpty()) { 
			salida =  listaDetalleNota.get(0);
		}
		
		return salida;
	}
	
	public ListaPagosAutorizarResponse rellenarDatos(PagosUsuarioAutorizProcedureOut datosPagos) {
		ListaPagosAutorizarResponse salida = new ListaPagosAutorizarResponse();
		
		List<DatosPagoAutorizar> listaDatos = new ArrayList<>();
		
		for (int i = 0; i < datosPagos.getDatosPagosAutorizar().size(); i++) {
			DatosPagoAutorizar datos = new DatosPagoAutorizar();
			datos.setRftrans(datosPagos.getDatosPagosAutorizar().get(i).getRftrans());
			datos.setIdEstado(datosPagos.getDatosPagosAutorizar().get(i).getIdEstado());
			datos.setImporte(datosPagos.getDatosPagosAutorizar().get(i).getImporte());
			datos.setFecha(datosPagos.getDatosPagosAutorizar().get(i).getFecha());
			datos.setRefCliente(datosPagos.getDatosPagosAutorizar().get(i).getRefCliente());
			datos.setCodPais(datosPagos.getDatosPagosAutorizar().get(i).getPais());
			datos.setCodMedioPago(datosPagos.getDatosPagosAutorizar().get(i).getCodMedioPago());
			datos.setIndImp(datosPagos.getDatosPagosAutorizar().get(i).getIndImp());
			datos.setIndNota(datosPagos.getDatosPagosAutorizar().get(i).getIndNota());
			datos.setIndicadorUpload(datosPagos.getDatosPagosAutorizar().get(i).getIndicadorUpload());
			datos.setCuentaOrdenante(datosPagos.getDatosPagosAutorizar().get(i).getCodCuenta());
			datos.setCodExtracto(datosPagos.getDatosPagosAutorizar().get(i).getCodExtracto());
			datos.setIdAutorizacion(datosPagos.getDatosPagosAutorizar().get(i).getIdAuto());
			datos.setCodBeneficiario(datosPagos.getDatosPagosAutorizar().get(i).getClaben());
			datos.setDivisa(datosPagos.getDatosPagosAutorizar().get(i).getDivisa());
			datos.setDescEstPago(datosPagos.getDatosPagosAutorizar().get(i).getDescEstPago());
			
			listaDatos.add(datos);
		}
		
		salida.setListaDatosPagosAutorizar(listaDatos);
		
		return salida;
	}
	
	/**
	 * 
	 * @param datosPagos
	 * @return
	 */
	public List<Integer> rellenarPagosCuenta(PagosUsuarioAutorizProcedureOut datosPagos) {
		List<Integer> salida = new ArrayList<>();
		
		for (int i = 0; i < datosPagos.getDatosPagosAutorizar().size(); i++) {
			salida.add(datosPagos.getDatosPagosAutorizar().get(i).getCodCuenta());
		}
		
		return salida;
	}
	
	public List<ListaNombres> rellenarListaNombres(PagosUsuarioAutorizProcedureOut datosPagos) {
		List<ListaNombres> salida = new ArrayList<>();
		
		for (int i = 0; i < datosPagos.getDatosPagosAutorizar().size(); i++) {
			ListaNombres nombres = new ListaNombres();
			nombres.setN2897_nombenc(datosPagos.getDatosPagosAutorizar().get(i).getN2897_nombenc());
			nombres.setN2897_nombens1(datosPagos.getDatosPagosAutorizar().get(i).getN2897_nombens1());
			nombres.setN6564_nombenc(datosPagos.getDatosPagosAutorizar().get(i).getN6564_nombenc());
			nombres.setO2785_nombens1(datosPagos.getDatosPagosAutorizar().get(i).getO2785_nombens1());
			nombres.setCodMedioPago(datosPagos.getDatosPagosAutorizar().get(i).getCodMedioPago());
			
			salida.add(nombres);
		}		
		
		return salida;
	}
	
	public ListaPagosAutorizarResponse tratarDatos(List<String> listaPagosFiltrados, ListaPagosAutorizarResponse salida, 
			List<Integer> listaPagosCuenta, List<ListaNombres> nombres, List<String> pagosYaFirmados, String divisa) {

		List<DatosPagoAutorizar> listaPagos = salida.getListaDatosPagosAutorizar();

		//Creamos un HashMap para meter los pagos buenos con los que comparar
		Map<String, String> pagosFiltrados = new HashMap<>();
		int tamPagosOk = listaPagosFiltrados.size();		
		for(int i=0;  i<tamPagosOk; i++){
			String pagoOk = listaPagosFiltrados.get(i);
			pagosFiltrados.put(pagoOk, pagoOk);
		}

		// Recorremos los pagos de salida y eliminamos los que no esten en el HashMap
		int tamPagos = listaPagos.size();
		for(int i=tamPagos-1;  i>=0; i--){
			if(!pagosFiltrados.containsKey(listaPagos.get(i).getRftrans())){				
				//Borramos los pagos de salida
				listaPagos.remove(i);
				//Borramos de la lista de cuentas que le vamos a pasar a extracto
				listaPagosCuenta.remove(i);
				nombres.remove(i);
			}
		}
		
		//Creamos un HashMap para meter los pagos firmados por el usuario para eliminarlos de la salida
		Map<String,String> pagosFirmadosUsuario = new HashMap<>();
		int tamPagosFirmados = pagosYaFirmados.size();
		for(int i=0; i<tamPagosFirmados; i++){
			String pagoFirmado = pagosYaFirmados.get(i);
			pagosFirmadosUsuario.put(pagoFirmado, pagoFirmado);
		}

		// Recorremos los pagos de salida y eliminamos los queesten en el HashMap de firmados por usuario
		tamPagos = listaPagos.size();
		for(int i=tamPagos-1; i>=0; i--){
			if(pagosFirmadosUsuario.containsKey(listaPagos.get(i).getRftrans())){
				//Borramos los pagos de salida
				listaPagos.remove(i);
				// Borramos de la lista de cuentas que le vamos a pasar a extracto
				listaPagosCuenta.remove(i);
				nombres.remove(i);
			}
		}
		
		String monedaEntrada = divisa;
		
		if (!monedaEntrada.equals(STR_XXX) && !monedaEntrada.equals(STR_VACIO)){
			int tamPagosAut = listaPagos.size();
			for (int i=0;i<tamPagosAut;i++){
				if (!listaPagos.get(i).getDivisa().equals(monedaEntrada)){
					listaPagos.remove(i);
					nombres.remove(i);
					listaPagosCuenta.remove(i);
					tamPagosAut = listaPagos.size();
					i+=-1;
				}					
			}
		}
		
		

		String nombre;
		int tamSalida = listaPagos.size();
		if (tamSalida == 0){
			salida.setStatus(STR_KO);
		} else {
			for (int i=0; i<tamSalida; i++){
				//Se recupera el CLABEN
				String claben = String.valueOf(listaPagos.get(i).getCodBeneficiario());
				//Se recupera el CDMEDPAG
				String cdmedpag = nombres.get(i).getCodMedioPago();
				//Si CLABEN de SGP_PAGO es NULL
				if (claben.equals(STR_CERO)) {
					//Si el campo CDMEDPAG de SGP_PAGO no es el de MT101
					if (cdmedpag.equals(STR_MT)){
						//se toma el campo NOMBENC de la tabla SGP_PAGO_MAN
						nombre = nombres.get(i).getN6564_nombenc();
					} else {
						//se toma el campo NOMBENS1 de la tabla SGP_PAG_MANL
						nombre = nombres.get(i).getO2785_nombens1();
					}
				} else {
					if (cdmedpag.equals(STR_MT)){
						//se toma el campo NOMBENC de la tabla SGP_BENEFIC cuyo CLABEN sea igual al CLABEN de SGP_PAGO
						nombre = nombres.get(i).getN2897_nombenc();
					} else {
						//se toma el campo NOMBENS1 de la tabla SGP_BENEFIC cuyo CLABEN sea igual al CLABEN de SGP_PAGO
						nombre = nombres.get(i).getN2897_nombens1();
					}
				}
				//Se informa el nombenef de salida
				listaPagos.get(i).setNomBenef(nombre);
			}				
			salida.setListaDatosPagosAutorizar(listaPagos); 
		}
		
		
		return salida;
	
	}
	
	public ListaPagosAutorizarResponse rellenarNotas(ListaPagosAutorizarResponse salida) {
		
		int tamListaCuentas = salida.getListaDatosPagosAutorizar().size();
		
		for (int i = 0; i < tamListaCuentas; i++) {
			String tieneNota = salida.getListaDatosPagosAutorizar().get(i).getIndNota();
			
			if(STR_S.equals(tieneNota)) {
				// Si tiene nota, añadimos el código rftrans al mapa
				String rftrans = salida.getListaDatosPagosAutorizar().get(i).getRftrans();
				String detalle = obtNotas(rftrans);
				salida.getListaDatosPagosAutorizar().get(i).setDescNota(detalle);
				
			}else {
				salida.getListaDatosPagosAutorizar().get(i).setDescNota(STR_VACIO);
			}
			
		}
		
		return salida;
	}
	
	public ListaPagosAutorizarResponse datosPaginacion(ListaPagosAutorizarResponse salida,
			ListaPagosAutorizarRequest request) {
		
		List<DatosPagoAutorizar> listaDatosPagosAutorizarTemp = salida.getListaDatosPagosAutorizar();
		salida.setNumTotalPagos(salida.getListaDatosPagosAutorizar().size());
		salida.setNumPagActual(request.getNumPagina());
		
		int numPorPagina =  request.getNumPorPagina();
		int numPagina = request.getNumPagina();
		
		int inicio = (numPorPagina * numPagina) - numPorPagina;
		int fin = numPorPagina * numPagina;
		
		if(fin > listaDatosPagosAutorizarTemp.size()) {
			fin = listaDatosPagosAutorizarTemp.size();
		}
		
		
		// Ordenamos la lista de datos por fecha
		Collections.sort(listaDatosPagosAutorizarTemp);
		
		// Seleccionamos el tramos de datos a devolver
		List<DatosPagoAutorizar> listaDatosPagosAutorizarFinal = listaDatosPagosAutorizarTemp.subList(inicio, fin);
		
		
		salida.setListaDatosPagosAutorizar(listaDatosPagosAutorizarFinal);
		
		return salida;
	}
}
