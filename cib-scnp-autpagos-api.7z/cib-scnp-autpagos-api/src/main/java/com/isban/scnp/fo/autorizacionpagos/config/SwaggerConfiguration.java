package com.isban.scnp.fo.autorizacionpagos.config;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



/**
 * Swagger 2 configuration class. It generates API REST documentation available
 * by default at http://localhost:8080/swagger-ui.html
 * 
 * @author Vector ITC Group
 */
@Configuration
public class SwaggerConfiguration {

	@Value("${es.santander.nuar.util.security.enabled:false}")
	protected boolean securityEnabled;

	private static final String ENDPOINTS_REGEX = "/authorization.*";

	/**
	 * Swagger bean
	 * 
	 * @return {@link Docket}
	 */
	@Bean
	public GroupedOpenApi applicationAPI() {

	      return GroupedOpenApi.builder()
	              .group("springshop-public")
	              .pathsToMatch(ENDPOINTS_REGEX)
	              .build();
	 
	}

}
