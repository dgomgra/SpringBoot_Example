package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;


public class ObtCuentaPagosOut {
	
	private String rftrans;
	private int acuencod;
	
	public String getRftrans() {
		return rftrans;
	}
	public void setRftrans(String rftrans) {
		this.rftrans = rftrans;
	}
	public int getAcuencod() {
		return acuencod;
	}
	public void setAcuencod(int acuencod) {
		this.acuencod = acuencod;
	}
	
}
