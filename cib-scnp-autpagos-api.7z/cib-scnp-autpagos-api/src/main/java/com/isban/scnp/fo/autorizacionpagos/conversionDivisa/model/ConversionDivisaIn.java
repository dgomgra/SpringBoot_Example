package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

public class ConversionDivisaIn {
	private ConversionDivisa_E entrada;

	public ConversionDivisaIn() {
		super();
		entrada=new ConversionDivisa_E();
	}
	public ConversionDivisa_E getEntrada() {
		return entrada;
	}

	public void setEntrada(ConversionDivisa_E entrada) {
		this.entrada = entrada;
	}
}
