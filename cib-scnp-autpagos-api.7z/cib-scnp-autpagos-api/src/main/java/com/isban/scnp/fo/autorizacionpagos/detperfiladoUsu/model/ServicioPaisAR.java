package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

import java.util.ArrayList;
import java.util.List;

public class ServicioPaisAR {

	private String codServicio;
	private String necesCuenta;
	private String necesTip;
	private List<ListaPaisArbol> listaPais;
	private List<ListaPermisosSubprodArbol> listaPermisosSinMetodos;
	private List<ListaPaisAR> listaPaisesAR;
	
	public ServicioPaisAR() {
		listaPais = new ArrayList<>(0);
		listaPermisosSinMetodos = new ArrayList<>(0);
		listaPaisesAR = new ArrayList<>(0);
	}
	
	public String getCodServicio() {
		return codServicio;
	}
	public void setCodServicio(String codServicio) {
		this.codServicio = codServicio;
	}
	public String getNecesCuenta() {
		return necesCuenta;
	}
	public void setNecesCuenta(String necesCuenta) {
		this.necesCuenta = necesCuenta;
	}
	public String getNecesTip() {
		return necesTip;
	}
	public void setNecesTip(String necesTip) {
		this.necesTip = necesTip;
	}
	public List<ListaPaisArbol> getListaPais() {
		return listaPais;
	}
	public void setListaPais(List<ListaPaisArbol> listaPais) {
		this.listaPais = listaPais;
	}
	public List<ListaPermisosSubprodArbol> getListaPermisosSinMetodos() {
		return listaPermisosSinMetodos;
	}
	public void setListaPermisosSinMetodos(List<ListaPermisosSubprodArbol> listaPermisosSinMetodos) {
		this.listaPermisosSinMetodos = listaPermisosSinMetodos;
	}
	public List<ListaPaisAR> getListaPaisesAR() {
		return listaPaisesAR;
	}
	public void setListaPaisesAR(List<ListaPaisAR> listaPaisesAR) {
		this.listaPaisesAR = listaPaisesAR;
	}
	
	
}
