
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

import java.util.List;

public class MonedaArbol {

    private String divisaCuenta;
    private String sumBookBalance;
    private String sumValueBalance;
    private List<Listacuentasarbol> listacuentasarbol = null;

    public String getDivisaCuenta() {
        return divisaCuenta;
    }

    public void setDivisaCuenta(String divisaCuenta) {
        this.divisaCuenta = divisaCuenta;
    }

    public String getSumBookBalance() {
        return sumBookBalance;
    }

    public void setSumBookBalance(String sumBookBalance) {
        this.sumBookBalance = sumBookBalance;
    }

    public String getSumValueBalance() {
        return sumValueBalance;
    }

    public void setSumValueBalance(String sumValueBalance) {
        this.sumValueBalance = sumValueBalance;
    }

    public List<Listacuentasarbol> getListacuentasarbol() {
        return listacuentasarbol;
    }

    public void setListacuentasarbol(List<Listacuentasarbol> listacuentasarbol) {
        this.listacuentasarbol = listacuentasarbol;
    }

}
