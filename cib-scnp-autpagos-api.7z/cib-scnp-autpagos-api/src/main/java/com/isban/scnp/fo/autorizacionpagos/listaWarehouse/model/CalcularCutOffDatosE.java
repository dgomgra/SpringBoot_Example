package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class CalcularCutOffDatosE {
	private String codMedioPag;
	private int codEnt;
	private int idCuenta;
	private ImporteType montoDivisa;
	private String indTransTED;
	
	
	public CalcularCutOffDatosE() {
		super();
	}
	public String getCodMedioPag() {
		return codMedioPag;
	}
	public void setCodMedioPag(String codMedioPag) {
		this.codMedioPag = codMedioPag;
	}
	public int getCodEnt() {
		return codEnt;
	}
	public void setCodEnt(int codEnt) {
		this.codEnt = codEnt;
	}
	public int getIdCuenta() {
		return idCuenta;
	}
	public void setIdCuenta(int idCuenta) {
		this.idCuenta = idCuenta;
	}
	public ImporteType getMontoDivisa() {
		return montoDivisa;
	}
	public void setMontoDivisa(ImporteType montoDivisa) {
		this.montoDivisa = montoDivisa;
	}
	public String getIndTransTED() {
		return indTransTED;
	}
	public void setIndTransTED(String indTransTED) {
		this.indTransTED = indTransTED;
	}
}
