package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class ListaWarehouseRequest {
	private int numPagina;
	private int numPorPagina;
	private String tokenBks;
	public int getNumPagina() {
		return numPagina;
	}
	public void setNumPagina(int numPagina) {
		this.numPagina = numPagina;
	}
	public int getNumPorPagina() {
		return numPorPagina;
	}
	public void setNumPorPagina(int numPorPagina) {
		this.numPorPagina = numPorPagina;
	}
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}	
}
