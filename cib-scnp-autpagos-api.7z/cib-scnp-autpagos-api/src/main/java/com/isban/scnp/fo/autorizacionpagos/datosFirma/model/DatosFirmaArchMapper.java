package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosFirmaArchMapper implements RowMapper<DatosFirmaArchOut>{

	@Override
	public DatosFirmaArchOut mapRow(ResultSet rs, int row) throws SQLException {
		DatosFirmaArchOut datosFirmaArchOut = new DatosFirmaArchOut();
		datosFirmaArchOut.setImporte(rs.getBigDecimal("O9248_IMPPAISMON"));
		datosFirmaArchOut.setNumPagos(rs.getInt("O9248_NUM_TRANS"));
		return datosFirmaArchOut;
	}

}
