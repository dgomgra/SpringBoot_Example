package com.isban.scnp.fo.autorizacionpagos.common.component;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.common.service.CommonHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@Component
@RequestScope
public class AppContext {

	@Autowired
	private CommonHelperService chs;
	
	private DatosUsuario userData;
	
	public DatosUsuario getUserData() {
		if (userData == null) {
			
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
					 auth instanceof JwtAuthenticationToken &&
		                Objects.nonNull(auth.getDetails())) {
			
				JwtDetails santanderUD = (JwtDetails) auth.getDetails();
				String uidLogado = santanderUD.getUid();
				userData = chs.obtenerDatosUsuario(uidLogado);
			}
		}
		return userData;
	}


	public void setUserData(DatosUsuario userData) {
		this.userData = userData;
	}
	
	
}
