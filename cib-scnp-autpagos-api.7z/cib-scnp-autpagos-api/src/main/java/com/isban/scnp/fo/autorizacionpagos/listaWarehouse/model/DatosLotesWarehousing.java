package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;

public class DatosLotesWarehousing implements Comparable<DatosLotesWarehousing>{
	
	private String idLote;
	private String codEstLote;
	private String nomLote;
	private String codPais;
	private BigDecimal impLote;
	private String divisaLote;
	private Date fechaLote;
	private long totalPagos;
	private String indImportado;
	private String indNotas;
	private String indicadorUpload;
	private String indSalario;
	private String descEstLote;
	private String indicadorCbs;
	private String indBulk;
	private String indStopPayment;

	
	public String getIdLote() {
		return idLote;
	}
	public void setIdLote(String idLote) {
		this.idLote = idLote;
	}
	public String getCodEstLote() {
		return codEstLote;
	}
	public void setCodEstLote(String codEstLote) {
		this.codEstLote = codEstLote;
	}
	public String getNomLote() {
		return nomLote;
	}
	public void setNomLote(String nomLote) {
		this.nomLote = nomLote;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	@JsonSerialize(using = AmountSerializer.class)	
	public BigDecimal getImpLote() {
		return impLote;
	}
	public void setImpLote(BigDecimal impLote) {
		this.impLote = impLote;
	}
	public String getDivisaLote() {
		return divisaLote;
	}
	public void setDivisaLote(String divisaLote) {
		this.divisaLote = divisaLote;
	}
	@JsonSerialize(using = DateSerializer.class)
	public Date getFechaLote() {
		return fechaLote;
	}
	public void setFechaLote(Date fechaLote) {
		this.fechaLote = fechaLote;
	}
	public long getTotalPagos() {
		return totalPagos;
	}
	public void setTotalPagos(long totalPagos) {
		this.totalPagos = totalPagos;
	}
	public String getIndImportado() {
		return indImportado;
	}
	public void setIndImportado(String indImportado) {
		this.indImportado = indImportado;
	}
	public String getIndNotas() {
		return indNotas;
	}
	public void setIndNotas(String indNotas) {
		this.indNotas = indNotas;
	}
	public String getIndicadorUpload() {
		return indicadorUpload;
	}
	public void setIndicadorUpload(String indicadorUpload) {
		this.indicadorUpload = indicadorUpload;
	}
	public String getIndSalario() {
		return indSalario;
	}
	public void setIndSalario(String indSalario) {
		this.indSalario = indSalario;
	}
	public String getDescEstLote() {
		return descEstLote;
	}
	public void setDescEstLote(String descEstLote) {
		this.descEstLote = descEstLote;
	}
	public String getIndicadorCbs() {
		return indicadorCbs;
	}
	public void setIndicadorCbs(String indicadorCbs) {
		this.indicadorCbs = indicadorCbs;
	}
	public String getIndBulk() {
		return indBulk;
	}
	public void setIndBulk(String indBulk) {
		this.indBulk = indBulk;
	}
	public String getIndStopPayment() {
		return indStopPayment;
	}
	public void setIndStopPayment(String indStopPayment) {
		this.indStopPayment = indStopPayment;
	}
	@Override
	public int compareTo(DatosLotesWarehousing o) {
		int comparaFecha =   getFechaLote().compareTo(o.getFechaLote());
		if (comparaFecha==0)
		{
			return getIdLote().compareTo(o.getIdLote());
		}
		else
		{
			return comparaFecha;
		}
	}
	@Override
	public boolean equals(Object o) {
		boolean retorno=false;

		if (o != null && this.getClass()==o.getClass())
		{
			DatosLotesWarehousing dp = (DatosLotesWarehousing) o ;
			retorno = getIdLote().equals(dp.getIdLote());
		}
		return retorno;
	}
	@Override
	public int hashCode() 
	{
		 return getIdLote().hashCode();
	}
}
