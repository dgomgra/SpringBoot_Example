package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarRAIn {
	private AutorizarRA_E entrada;

	
	public AutorizarRAIn() {
		super();
		entrada = new AutorizarRA_E();
	}

	public AutorizarRA_E getEntrada() {
		return entrada;
	}

	public void setEntrada(AutorizarRA_E entrada) {
		this.entrada = entrada;
	}
}
