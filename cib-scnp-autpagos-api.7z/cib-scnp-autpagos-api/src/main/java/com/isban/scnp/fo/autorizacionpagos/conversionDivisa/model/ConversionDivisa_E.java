package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

import java.util.ArrayList;
import java.util.List;

public class ConversionDivisa_E {
	private static final String STR_VACIO = "";
	private String divisaConsolidacion;
	private List<ListaImportes> listaGruposImportes;
	
	public ConversionDivisa_E() {
		super();
		divisaConsolidacion=STR_VACIO;
		this.listaGruposImportes = new ArrayList<ListaImportes>(0);
	}
	public String getDivisaConsolidacion() {
		return divisaConsolidacion;
	}
	public void setDivisaConsolidacion(String divisaConsolidacion) {
		this.divisaConsolidacion = divisaConsolidacion;
	}
	public List<ListaImportes> getListaGruposImportes() {
		return listaGruposImportes;
	}
	public void setListaGruposImportes(List<ListaImportes> listaGruposImportes) {
		this.listaGruposImportes = listaGruposImportes;
	}
	public void addListaImportes (ListaImportes l)
	{
		listaGruposImportes.add(l);
	}
}
