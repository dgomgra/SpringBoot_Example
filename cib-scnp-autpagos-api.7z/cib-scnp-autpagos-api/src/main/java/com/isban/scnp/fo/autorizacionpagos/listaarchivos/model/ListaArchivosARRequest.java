package com.isban.scnp.fo.autorizacionpagos.listaarchivos.model;

public class ListaArchivosARRequest {
	
	private int numPagina;
	private int numPorPagina;
	private String monConsolidacion;
	private String tokenBks;

	public int getNumPagina() {
		return numPagina;
	}
	public void setNumPagina(int numPagina) {
		this.numPagina = numPagina;
	}
	public int getNumPorPagina() {
		return numPorPagina;
	}
	public void setNumPorPagina(int numPorPagina) {
		this.numPorPagina = numPorPagina;
	}
	public String getMonConsolidacion() {
		return monConsolidacion;
	}
	public void setMonConsolidacion(String monConsolidacion) {
		this.monConsolidacion = monConsolidacion;
	}
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}
}
