package com.isban.scnp.fo.autorizacionpagos.datosFirma.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaArchMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaArchOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaLotesMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaLotesOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaPagosMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaRequest;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaResponse;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.DatosFirmaHelperService;

@Service
public class DatosFirmaHelperServiceImpl implements DatosFirmaHelperService{

	private static final String STR_F = "F";
	private static final String STR_V = "V";
	private static final String STR_S = "S";
	private static final String STR_MSG_OK = "OK";
	private static final String STR_OK = "OK";
	private static final String STR_AR = "ar";
	private static final String STR_LOTES = "lotes";
	private static final String STR_PAGOS = "pagos";
	private static final int MAX_SIZE_QUERY = 1000;
	
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplateSimple;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Autowired
	private AppContext appContext;

	
	@Override
	public DatosFirmaResponse getDatosFirma(DatosFirmaRequest datosFirmaRequest) {
		DatosFirmaResponse datosFirmaResponse = new DatosFirmaResponse();
		String tipo = datosFirmaRequest.getTipo();
		
		String tipoCripto = appContext.getUserData().getTipoCripto();
		if (STR_S.equals(tipoCripto))
		{
			datosFirmaResponse.setTipoCripto(STR_V);
		}else {
			datosFirmaResponse.setTipoCripto(STR_F);
		}
		
		if(STR_PAGOS.equalsIgnoreCase(tipo)) {
			datosFirmaResponse.setImporte(getDatosFirmaPagos(datosFirmaRequest.getListaIds()));
			datosFirmaResponse.setNumPagos(datosFirmaRequest.getListaIds().size());
			
			boolean paisPermitido = false;
			if(datosFirmaResponse.getNumPagos() == 1) {
				String paisPago = getPaisPago(datosFirmaRequest.getListaIds().get(0));
				String[ ] listCountry = {"ES", "PT", "IT", "FR", "DE", "GB"};
				List<String> arrayCountry= Arrays.asList(listCountry);
				if(arrayCountry.contains(paisPago)) {
					paisPermitido = true;
				}
			}
			
			if(datosFirmaResponse.getNumPagos() == 1 && datosFirmaResponse.getTipoCripto().equals(STR_V) && paisPermitido) {
				String id = datosFirmaRequest.getListaIds().get(0);
				List<DatosFirmaCuentaBenOut> listaCuenta = new ArrayList<>();	
				listaCuenta = getDatosDigitosCuentaBenQuery(id);	
				if(!listaCuenta.isEmpty() && listaCuenta != null && listaCuenta.get(0).getDigitosCuentaBen() != null) {
						String digitosCuenta = listaCuenta.get(0).getDigitosCuentaBen().trim();
						digitosCuenta = digitosCuenta.substring(digitosCuenta.length()-4,digitosCuenta.length());							
						datosFirmaResponse.setUltimosDigitosCuentaBen(digitosCuenta);						
				}
				
			} 

			
		}else if(STR_LOTES.equalsIgnoreCase(tipo)){
			DatosFirmaLotesOut datosFirma = getDatosFirmaLotes(datosFirmaRequest.getListaIds());
			
			String importeFinal = String.valueOf(datosFirma.getImporte());
			
			// Quitamos la parte decimal si tiene
			int puntoDec = importeFinal.indexOf(".");
			if(puntoDec > -1) {
				importeFinal = importeFinal.substring(0, puntoDec);
			}
			
			if(importeFinal.length() > 15) {
				importeFinal = importeFinal.substring(0, 15);
			}
			datosFirmaResponse.setImporte(importeFinal);
			datosFirmaResponse.setNumPagos(datosFirma.getNumPagos());
		}else if(STR_AR.equalsIgnoreCase(tipo)) {
			DatosFirmaArchOut datosFirma = getDatosFirmaArch(datosFirmaRequest.getListaIds());
			
			String importeFinal = String.valueOf(datosFirma.getImporte());
			
			// Quitamos la parte decimal si tiene
			int puntoDec = importeFinal.indexOf(".");
			if(puntoDec > -1) {
				importeFinal = importeFinal.substring(0, puntoDec);
			}
			
			if(importeFinal.length() > 15) {
				importeFinal = importeFinal.substring(0, 15);
			}
			datosFirmaResponse.setImporte(importeFinal);
			datosFirmaResponse.setNumPagos(datosFirma.getNumPagos());
		}
		datosFirmaResponse.setStatus(STR_OK);
		datosFirmaResponse.setMessage(STR_MSG_OK);
		return datosFirmaResponse;
	}

	@Override
	public String getDatosFirmaPagos(List<String> listaIds) {
		List<String> listaTemp = new ArrayList<>();
		List<BigDecimal> salida = new ArrayList<>();		
		List<BigDecimal> salidaParcial = new ArrayList<>();
		
		int tamListaIds = listaIds.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaIds.get(j));
					
				}
				
				salidaParcial = getDatosFirmaPagosQuery (listaTemp);
				
				salida.addAll(salidaParcial);
			
			}
		}
		
		
		BigDecimal salidaTemp = new BigDecimal(0);
		
		int tamLista = salida.size();
		
		for (int i = 0; i < tamLista; i++) {
			BigDecimal importe = salida.get(i);
			salidaTemp = salidaTemp.add(importe);
		}
		
		 String salidaStr = String.valueOf(salidaTemp);
		 
		// Quitamos la parte decimal si tiene
		int puntoDec = salidaStr.indexOf(".");
		if(puntoDec > -1) {
			salidaStr = salidaStr.substring(0, puntoDec);
		}
		 
		 if(salidaStr.length() > 15) {
			 salidaStr = salidaStr.substring(0, 15);
		 }
		 
		 return salidaStr;
	}
	
	
	private List<BigDecimal> getDatosFirmaPagosQuery(List<String> listaIds) {
		String sql = "SELECT N6563_CANTPAGL FROM " + schemaproc + ".SGP_PAGO WHERE N6563_RFTRANS IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", listaIds);
		return jdbcTemplate.query(sql, params, new DatosFirmaPagosMapper());
	}
	
	
	@Override
	public DatosFirmaLotesOut getDatosFirmaLotes(List<String> listaIds) {
	
		List<String> listaTemp = new ArrayList<>();
		List<DatosFirmaLotesOut> lista = new ArrayList<>();		
		List<DatosFirmaLotesOut> salidaTemp = new ArrayList<>();
		
		int tamListaIds = listaIds.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaIds.get(j));
					
				}
				
				salidaTemp = getDatosFirmaLotesQuery (listaTemp);
				
				lista.addAll(salidaTemp);
			
			}
		}
		
		DatosFirmaLotesOut salida = new DatosFirmaLotesOut();
		BigDecimal importeTotal = new BigDecimal(0);
		int pagosTotal = 0;
		int tamLista = lista.size();
		
		for (int i = 0; i < tamLista; i++) {
			BigDecimal importe = lista.get(i).getImporte();
			importeTotal = importeTotal.add(importe);
			pagosTotal = pagosTotal + lista.get(i).getNumPagos();
		}
		
		salida.setImporte(importeTotal);
		salida.setNumPagos(pagosTotal);
		
		return salida;
		
	}
	
	private List<DatosFirmaLotesOut> getDatosFirmaLotesQuery(List<String> listaIds) {
		String sql = "SELECT O2046_IMPLOTE2, O2046_TOTPAGOS FROM " + schemaproc + ".SGP_LOTE WHERE O2046_NULOTE IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", listaIds);
				
		return jdbcTemplate.query(sql, params, new DatosFirmaLotesMapper());
	}

	
	@Override
	public DatosFirmaArchOut getDatosFirmaArch(List<String> listaIds) {
		
		List<String> listaTemp = new ArrayList<>();
		List<DatosFirmaArchOut> lista = new ArrayList<>();		
		List<DatosFirmaArchOut> salidaTemp = new ArrayList<>();
		
		int tamListaIds = listaIds.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaIds.get(j));
					
				}
				
				salidaTemp = getDatosFirmaArchQuery (listaTemp);
				
				lista.addAll(salidaTemp);
			
			}
		}
		
		
		DatosFirmaArchOut salida = new DatosFirmaArchOut();
		BigDecimal importeTotal = new BigDecimal(0);
		int pagosTotal = 0;
		int tamLista = lista.size();
		
		for (int i = 0; i < tamLista; i++) {
			BigDecimal importe = lista.get(i).getImporte();
			importeTotal = importeTotal.add(importe);
			pagosTotal = pagosTotal + lista.get(i).getNumPagos();
		}
		
		salida.setImporte(importeTotal);
		salida.setNumPagos(pagosTotal);
		
		
		return salida;
		
	}
	
	private List<DatosFirmaArchOut> getDatosFirmaArchQuery(List<String> listaIds) {
		String sql = "SELECT O9248_NUM_TRANS, O9248_IMPPAISMON FROM " + schemaproc + ".SGP_ARCH_PAIMON WHERE O9248_IDARCH IN (:ids)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", listaIds);
			
		return jdbcTemplate.query(sql, params, new DatosFirmaArchMapper());
	}
	
	public List<DatosFirmaCuentaBenOut> getDatosDigitosCuentaBenQuery(String id) {				
		String sql = "SELECT CASE WHEN pag.N6563_CDMEDPAG IN ('SE','SU') THEN EXTRACTVALUE (XMLTYPE.CREATEXML (NVL (TRIM (loc.O2785_DAT_XML), xmltype ('<ROWS></ROWS>'))),"
	            + "'/CdtTrfTxInf/CdtrAcct/Id/IBAN') ELSE EXTRACTVALUE (XMLTYPE.CREATEXML (NVL (TRIM (loc.O2785_DAT_XML), xmltype ('<ROWS></ROWS>'))), '/CdtTrfTxInf/CdtrAcct/Id/Othr/Id') "
	            + "END AS " + "\"Cuenta Beneficiario\" " + "FROM " + schemaproc + ".sgp_pago pag LEFT JOIN " + schemaproc + ".SGP_PAG_MANL loc ON (pag.N6563_RFTRANS = loc.O2785_RFTRANS) WHERE pag.N6563_ALTAMAN='S' "
	            + "AND N6563_RFTRANS= :idPago union all ( SELECT N6542_CTALOC50 " +"\"Cuenta Beneficiario\" "+ "FROM "+ schemaproc + ".SGP_PAGO LEFT JOIN SGPOWN.SGP_BENEFIC ON (N6563_CLABEN=N2897_CLABEN AND N6563_IDAUTH=N2897_IDAUTH) "
	            + "LEFT JOIN " + schemaproc + ".SGP_BEN_CTAR ON (N6563_CLABEN=N6542_CLABEN) and (N6563_IDAUTH=N6542_IDAUTH) AND (N6542_BENCTA = N6563_BENCTA) LEFT JOIN " + schemaproc + ".SGP_CUENTA cta ON (N6563_ACUENCOT = H1162_ACUENCOT) "
	            +  "WHERE N6563_ALTAMAN='N' AND N6563_RFTRANS= :idPago)";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("idPago", id);
			
		return jdbcTemplate.query(sql, params, new DatosFirmaCuentaBenMapper());
	}
	
	public String getPaisPago(String idPago) {				
		String sql = "SELECT N2912_CDGPAISBIC " + 
				"FROM " + schemaproc + ".SGP_PAGO, " + schemaproc + ".SGP_CUENTA, " + schemaproc + ".SGP_ENTBANCARIA " + 
				"WHERE N6563_RFTRANS = ? " + 
				"AND N6563_ACUENCOT = H1162_ACUENCOT " + 
				"AND H1162_CENTBSGP = N2912_CENTBSGP";
		
		Object[] params = new Object[] { idPago };
		
		return jdbcTemplateSimple.queryForObject(sql, params, String.class);
	}
	
}
