package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequestData;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.ConversionDivisaHelperService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ConversionDivisaHelperServiceImpl implements ConversionDivisaHelperService {
	private static final String STR_VACIO = "";
	private static final String STR_ERROR = "error";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_CONVERSION_DIVISAS = "Conversion de divisas";
	
	@Value("${urlBks}")
    protected String urlBks;	
	
	@Autowired
	private ApiRestTemplate apiRestTemplate;

	public ConversionDivisaResponse conversionDivisa(ConversionDivisaRequest request) {
		
		String token = request.getToken();
		String json = null;
		try {
			json = convertToJson(request.getRequestData());
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_CONVERSION_DIVISAS + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			json = STR_VACIO;
		}
		
        String urlConversionDivisa = urlBks + "/json/F_GBMSGF_FOComunPagos_E/1?authenticationType=token&requestData="+json+"&token=" + token;
		
        URI uriConversionDivisa = UriComponentsBuilder.fromUriString(urlConversionDivisa).build().encode().toUri();
        RestTemplate restTemplatePost = apiRestTemplate.getRestTemplate();
        ResponseEntity<ConversionDivisaResponse> response = restTemplatePost.exchange(uriConversionDivisa, HttpMethod.GET, null, ConversionDivisaResponse.class);
        return response.getBody();
	}

	
	private String convertToJson (ConversionDivisaRequestData o) throws JsonProcessingException 
	{
		//Object to JSON in String
		
		ObjectMapper mapper = new ObjectMapper();		
			
		return mapper.writeValueAsString(o);
	
	}
}
