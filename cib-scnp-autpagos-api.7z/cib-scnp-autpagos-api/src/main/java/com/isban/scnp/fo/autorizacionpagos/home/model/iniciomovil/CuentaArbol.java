
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class CuentaArbol {

    private Integer codigoCuenta;
    private String aliasCuentaPerfilado;
    private String aliasEntidad;
    private String bookDate;
    private String bookBalance;
    private String valueDate;
    private String valueBalance;
    private String divisa;
    private String cuentaExtracto;
    private String nombreEmisora;
    private CodigoBic codigoBic;

    public Integer getCodigoCuenta() {
        return codigoCuenta;
    }

    public void setCodigoCuenta(Integer codigoCuenta) {
        this.codigoCuenta = codigoCuenta;
    }

    public String getAliasCuentaPerfilado() {
        return aliasCuentaPerfilado;
    }

    public void setAliasCuentaPerfilado(String aliasCuentaPerfilado) {
        this.aliasCuentaPerfilado = aliasCuentaPerfilado;
    }

    public String getAliasEntidad() {
        return aliasEntidad;
    }

    public void setAliasEntidad(String aliasEntidad) {
        this.aliasEntidad = aliasEntidad;
    }

    public String getBookDate() {
        return bookDate;
    }

    public void setBookDate(String bookDate) {
        this.bookDate = bookDate;
    }

    public String getBookBalance() {
        return bookBalance;
    }

    public void setBookBalance(String bookBalance) {
        this.bookBalance = bookBalance;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getValueBalance() {
        return valueBalance;
    }

    public void setValueBalance(String valueBalance) {
        this.valueBalance = valueBalance;
    }

    public String getDivisa() {
        return divisa;
    }

    public void setDivisa(String divisa) {
        this.divisa = divisa;
    }

    public String getCuentaExtracto() {
        return cuentaExtracto;
    }

    public void setCuentaExtracto(String cuentaExtracto) {
        this.cuentaExtracto = cuentaExtracto;
    }

    public String getNombreEmisora() {
        return nombreEmisora;
    }

    public void setNombreEmisora(String nombreEmisora) {
        this.nombreEmisora = nombreEmisora;
    }

    public CodigoBic getCodigoBic() {
        return codigoBic;
    }

    public void setCodigoBic(CodigoBic codigoBic) {
        this.codigoBic = codigoBic;
    }

}
