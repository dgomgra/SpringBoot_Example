package com.isban.scnp.fo.autorizacionpagos.common.component;

import org.springframework.stereotype.Component;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

@Component
public class ApiRestTemplate {

	public RestTemplate getRestTemplate() {
		RestTemplate rest = new RestTemplate();
		return rest;
	}
	
	public AsyncRestTemplate getAsyncRestTemplate() {
		AsyncRestTemplate rest = new AsyncRestTemplate();
		return rest;
	}
}
