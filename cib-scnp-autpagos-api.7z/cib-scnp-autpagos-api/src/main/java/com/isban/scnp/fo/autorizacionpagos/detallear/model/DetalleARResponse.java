package com.isban.scnp.fo.autorizacionpagos.detallear.model;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class DetalleARResponse {
	private String status;
	private String message;
	private DetalleArchivo detalleArchivo;
	private List<DatosArchivo> listaDatosArchivo;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public DetalleArchivo getDetalleArchivo() {
		return detalleArchivo;
	}
	public void setDetalleArchivo(DetalleArchivo detalleArchivo) {
		this.detalleArchivo = detalleArchivo;
	}
	public List<DatosArchivo> getListaDatosArchivo() {
		return listaDatosArchivo;
	}
	public void setListaDatosArchivo(List<DatosArchivo> listaDatosArchivo) {
		this.listaDatosArchivo = listaDatosArchivo;
	}	
}
