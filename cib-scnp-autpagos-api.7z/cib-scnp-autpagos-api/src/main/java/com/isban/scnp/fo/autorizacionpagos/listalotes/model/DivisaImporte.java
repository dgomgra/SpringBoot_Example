package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;

public class DivisaImporte {

	private String divisa;
	private BigDecimal importe;
	private int numPagos = 0;
	
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	@JsonSerialize(using = AmountSerializer.class)
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	public int getNumPagos() {
		return numPagos;
	}
	public void setNumPagos(int numPagos) {
		this.numPagos = numPagos;
	}
	
}
