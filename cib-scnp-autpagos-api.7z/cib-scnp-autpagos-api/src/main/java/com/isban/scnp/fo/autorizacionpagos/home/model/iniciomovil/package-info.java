/**
 * 
 */
/**
 * @author dagonzalez
 *
 */
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;