package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

public class ArchivoPolitica {

	private int	idArchivo;
	private int codSentencia;
	private int idAutorizacion;
	
	public int getIdArchivo() {
		return idArchivo;
	}
	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}
	public int getCodSentencia() {
		return codSentencia;
	}
	public void setCodSentencia(int codSentencia) {
		this.codSentencia = codSentencia;
	}
	public int getIdAutorizacion() {
		return idAutorizacion;
	}
	public void setIdAutorizacion(int idAutorizacion) {
		this.idAutorizacion = idAutorizacion;
	}
}
