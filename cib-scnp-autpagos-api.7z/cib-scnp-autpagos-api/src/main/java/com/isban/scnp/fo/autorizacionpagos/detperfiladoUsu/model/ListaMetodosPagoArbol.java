package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaMetodosPagoArbol {

	private MetodosPagoArbol metodosPago;

	public MetodosPagoArbol getMetodosPago() {
		return metodosPago;
	}

	public void setMetodosPago(MetodosPagoArbol metodosPago) {
		this.metodosPago = metodosPago;
	}
}
