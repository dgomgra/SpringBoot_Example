package com.isban.scnp.fo.autorizacionpagos.detallear.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARRequest;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARResponse;
import com.isban.scnp.fo.autorizacionpagos.detallear.service.DetalleARHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "AutorizacionLotesRestController", description = "Operations pertaining to Batches Authorization")
public class DetalleARRestController {

	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_DETALLE_ARCHIVOS = "Detalle de archivos";
	private static final String STR_ERROR = "error";
	private static final String STR_KO = "KO";
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";
	
	@Autowired
	private DetalleARHelperService detalleARHelperService;
	
	
	@RequestMapping(value = "/v1/detalleAR", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get a remote authorization file details")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	public ResponseEntity<DetalleARResponse> getDetalleAR (@RequestBody DetalleARRequest detalleArRequest)
	{
		try{ 
			log.debug("REST POST call received in /v1/detalleAR {}",
					detalleArRequest.getIdArchivo());	

			DetalleARResponse detalleARResponse = detalleARHelperService.getDetalleARImpl(detalleArRequest);
			return new ResponseEntity<>(detalleARResponse, HttpStatus.OK);
		
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_DETALLE_ARCHIVOS + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			DetalleARResponse detalleARResponse = new DetalleARResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				detalleARResponse.setStatus(STR_KO);
				detalleARResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(detalleARResponse, HttpStatus.UNAUTHORIZED);
			}else {
				detalleARResponse.setStatus(STR_KO);
				detalleARResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(detalleARResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_DETALLE_ARCHIVOS + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			DetalleARResponse detalleARResponse = new DetalleARResponse();
			detalleARResponse.setStatus(STR_KO);
			detalleARResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(detalleARResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
