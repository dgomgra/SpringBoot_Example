package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

public class ObtPagosSentRolOut {

		private String rftrans;
		private String idComp;
		private int codSentencia;
		private int idAutorizacion;
		private int anorden;
		private int anumfirm;
		private String atipagru;
		private int tament;
		private int anordengrp;
		private int rol;
		
		public String getRftrans() {
			return rftrans;
		}
		public void setRftrans(String rftrans) {
			this.rftrans = rftrans;
		}
		public String getIdComp() {
			return idComp;
		}
		public void setIdComp(String idComp) {
			this.idComp = idComp;
		}
		public int getCodSentencia() {
			return codSentencia;
		}
		public void setCodSentencia(int codSentencia) {
			this.codSentencia = codSentencia;
		}
		public int getIdAutorizacion() {
			return idAutorizacion;
		}
		public void setIdAutorizacion(int idAutorizacion) {
			this.idAutorizacion = idAutorizacion;
		}
		public int getAnorden() {
			return anorden;
		}
		public void setAnorden(int anorden) {
			this.anorden = anorden;
		}
		public int getAnumfirm() {
			return anumfirm;
		}
		public void setAnumfirm(int anumfirm) {
			this.anumfirm = anumfirm;
		}
		public String getAtipagru() {
			return atipagru;
		}
		public void setAtipagru(String atipagru) {
			this.atipagru = atipagru;
		}
		public int getTament() {
			return tament;
		}
		public void setTament(int tament) {
			this.tament = tament;
		}
		public int getAnordengrp() {
			return anordengrp;
		}
		public void setAnordengrp(int anordengrp) {
			this.anordengrp = anordengrp;
		}
		public int getRol() {
			return rol;
		}
		public void setRol(int rol) {
			this.rol = rol;
		}	
}
