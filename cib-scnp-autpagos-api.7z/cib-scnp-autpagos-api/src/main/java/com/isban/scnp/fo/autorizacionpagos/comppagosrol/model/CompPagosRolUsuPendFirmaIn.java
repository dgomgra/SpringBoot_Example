package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

import java.util.List;


public class CompPagosRolUsuPendFirmaIn {

	private List<String> listaIdPago;
	private String pagosVerActivos;
	private String uid;
	private String tokenBks;
	
	public List<String> getListaIdPago() {
		return listaIdPago;
	}
	public void setListaIdPago(List<String> listaIdPago) {
		this.listaIdPago = listaIdPago;
	}
	public String getPagosVerActivos() {
		return pagosVerActivos;
	}
	public void setPagosVerActivos(String pagosVerActivos) {
		this.pagosVerActivos = pagosVerActivos;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}
	
}
