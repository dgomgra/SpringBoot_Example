
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class ArbolBalance {

    private PaisArbol paisArbol;
    
    public PaisArbol getPaisArbol() {
        return paisArbol;
    }

    public void setPaisArbol(PaisArbol paisArbol) {
        this.paisArbol = paisArbol;
    }

}
