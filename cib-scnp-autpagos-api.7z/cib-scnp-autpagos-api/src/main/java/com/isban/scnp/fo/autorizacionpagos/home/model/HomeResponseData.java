package com.isban.scnp.fo.autorizacionpagos.home.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.InicioMovilResponse;

public class HomeResponseData {

	private InicioMovilResponse inicioMovil;
	private int cantidadPagos;
	private int cantidadLotes;
	private int candidadWarehouse;
	private int cantidadWarehouseLotes;
	private int cantidadArchivosR;
	private String status;
	private String message;
	private String nombreFormatoCantidad;
	
	public int getCantidadPagos() {
		return cantidadPagos;
	}
	public void setCantidadPagos(int cantidadPagos) {
		this.cantidadPagos = cantidadPagos;
	}
	public int getCantidadLotes() {
		return cantidadLotes;
	}
	public void setCantidadLotes(int cantidadLotes) {
		this.cantidadLotes = cantidadLotes;
	}
	public int getcantidadArchivosR() {
		return cantidadArchivosR;
	}
	public void setcantidadArchivosR(int cantidadArchivosR) {
		this.cantidadArchivosR = cantidadArchivosR;
	}
	public int getCantidadWarehouseLotes() {
		return cantidadWarehouseLotes;
	}
	public void setCantidadWarehouseLotes(int cantidadWarehouseLotes) {
		this.cantidadWarehouseLotes = cantidadWarehouseLotes;
	}
	public InicioMovilResponse getInicioMovil() {
		return inicioMovil;
	}
	public void setInicioMovil(InicioMovilResponse inicioMovil) {
		this.inicioMovil = inicioMovil;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCandidadWarehouse() {
		return candidadWarehouse;
	}
	public void setCandidadWarehouse(int candidadWarehouse) {
		this.candidadWarehouse = candidadWarehouse;
	}
	public String getNombreFormatoCantidad() {
		return nombreFormatoCantidad;
	}
	public void setNombreFormatoCantidad(String nombreFormatoCantidad) {
		this.nombreFormatoCantidad = nombreFormatoCantidad;
	}
}
