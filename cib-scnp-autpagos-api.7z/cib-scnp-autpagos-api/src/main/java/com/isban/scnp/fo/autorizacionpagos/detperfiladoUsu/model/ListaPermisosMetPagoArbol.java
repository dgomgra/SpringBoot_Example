package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaPermisosMetPagoArbol {

	private PermisosMetPagoArbol permisosSubprod;

	public PermisosMetPagoArbol getPermisosSubprod() {
		return permisosSubprod;
	}

	public void setPermisosSubprod(PermisosMetPagoArbol permisosSubprod) {
		this.permisosSubprod = permisosSubprod;
	}
	
	
}
