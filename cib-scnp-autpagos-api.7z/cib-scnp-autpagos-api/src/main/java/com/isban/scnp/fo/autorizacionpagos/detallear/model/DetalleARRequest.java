package com.isban.scnp.fo.autorizacionpagos.detallear.model;

public class DetalleARRequest {
	private int idArchivo;
	private String tokenBks;

	public int getIdArchivo() {
		return idArchivo;
	}

	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}

	public String getTokenBks() {
		return tokenBks;
	}

	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}	
}
