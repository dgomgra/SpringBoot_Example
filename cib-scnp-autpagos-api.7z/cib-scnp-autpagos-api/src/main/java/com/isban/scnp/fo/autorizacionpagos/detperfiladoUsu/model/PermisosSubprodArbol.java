package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class PermisosSubprodArbol {

	private String codPermiso;
	private int codigoSubproducto;
	
	public String getCodPermiso() {
		return codPermiso;
	}
	public void setCodPermiso(String codPermiso) {
		this.codPermiso = codPermiso;
	}
	public int getCodigoSubproducto() {
		return codigoSubproducto;
	}
	public void setCodigoSubproducto(int codigoSubproducto) {
		this.codigoSubproducto = codigoSubproducto;
	}
}
