package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

import java.util.ArrayList;
import java.util.List;

public class PaisArbol {

	private String codPais;
	private List<ListaCuentasArbol> listaCuentas;
	
	public PaisArbol() {
		listaCuentas = new ArrayList<>(0);
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public List<ListaCuentasArbol> getListaCuentas() {
		return listaCuentas;
	}
	public void setListaCuentas(List<ListaCuentasArbol> listaCuentas) {
		this.listaCuentas = listaCuentas;
	}
	
	
}
