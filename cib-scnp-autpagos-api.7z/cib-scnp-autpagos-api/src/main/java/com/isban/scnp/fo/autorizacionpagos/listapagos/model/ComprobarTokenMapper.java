package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class ComprobarTokenMapper implements RowMapper<String> {
		
	@Override
	public String mapRow(ResultSet rs, int row) throws SQLException {
		return rs.getString("H1186_UID");
	}

}
