package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class Nota {
	private static final String STR_VACIO = "";
	private String asunto;
	private String detalle;
	
	
	public Nota() {
		super();
		asunto=STR_VACIO;
		detalle=STR_VACIO;
	}
	
	
	public Nota(String asunto, String detalle) {
		super();
		this.asunto = asunto;
		this.detalle = detalle;
	}

	public String getAsunto() {
		return asunto;
	}
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	public String getDetalle() {
		return detalle;
	}
	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}
}
