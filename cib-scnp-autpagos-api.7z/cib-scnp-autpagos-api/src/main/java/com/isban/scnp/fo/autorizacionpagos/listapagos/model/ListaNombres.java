package com.isban.scnp.fo.autorizacionpagos.listapagos.model;

public class ListaNombres {

	private String n2897_nombens1;
	private String n2897_nombenc;
	private String o2785_nombens1;
	private String n6564_nombenc;
	private String codMedioPago;
	
	public String getN2897_nombens1() {
		return n2897_nombens1;
	}
	public void setN2897_nombens1(String n2897_nombens1) {
		this.n2897_nombens1 = n2897_nombens1;
	}
	public String getN2897_nombenc() {
		return n2897_nombenc;
	}
	public void setN2897_nombenc(String n2897_nombenc) {
		this.n2897_nombenc = n2897_nombenc;
	}
	public String getO2785_nombens1() {
		return o2785_nombens1;
	}
	public void setO2785_nombens1(String o2785_nombens1) {
		this.o2785_nombens1 = o2785_nombens1;
	}
	public String getN6564_nombenc() {
		return n6564_nombenc;
	}
	public void setN6564_nombenc(String n6564_nombenc) {
		this.n6564_nombenc = n6564_nombenc;
	}
	public String getCodMedioPago() {
		return codMedioPago;
	}
	public void setCodMedioPago(String codMedioPago) {
		this.codMedioPago = codMedioPago;
	}

}
