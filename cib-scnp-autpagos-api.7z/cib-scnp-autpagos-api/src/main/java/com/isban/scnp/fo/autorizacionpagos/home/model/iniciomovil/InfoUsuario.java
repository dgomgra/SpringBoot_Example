
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class InfoUsuario {

    private Object nombre;
    private Object apellidos;
    private Object login;
    private Object ultimoAcceso;
    
    public Object getNombre() {
        return nombre;
    }

    public void setNombre(Object nombre) {
        this.nombre = nombre;
    }

    public Object getApellidos() {
        return apellidos;
    }

    public void setApellidos(Object apellidos) {
        this.apellidos = apellidos;
    }

    public Object getLogin() {
        return login;
    }

    public void setLogin(Object login) {
        this.login = login;
    }

    public Object getUltimoAcceso() {
        return ultimoAcceso;
    }

    public void setUltimoAcceso(Object ultimoAcceso) {
        this.ultimoAcceso = ultimoAcceso;
    }

   

}
