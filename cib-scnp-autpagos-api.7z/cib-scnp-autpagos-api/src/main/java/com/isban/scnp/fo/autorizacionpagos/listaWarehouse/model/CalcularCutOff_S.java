package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class CalcularCutOff_S {
	
	private CalcularCutOff cutOff;

	public CalcularCutOff getCutOff() {
		return cutOff;
	}

	public void setCutOff(CalcularCutOff cutOff) {
		this.cutOff = cutOff;
	}
}
