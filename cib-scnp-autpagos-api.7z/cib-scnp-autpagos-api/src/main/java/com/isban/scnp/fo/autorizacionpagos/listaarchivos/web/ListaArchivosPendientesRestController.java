package com.isban.scnp.fo.autorizacionpagos.listaarchivos.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.ListaArchivosPendientesHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "ListaArchivosPendientesRestController", description = "Operations pertaining to Remote Authorization")

public class ListaArchivosPendientesRestController {

	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_OPERATION_NAME = "Listado archivos pendientes RA";
	private static final String STR_ERROR = "error";
	private static final String STR_KO = "KO";
	private static final String STR_COD_ERROR_CREDENCIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";


	// Local
	@Autowired
	private ListaArchivosPendientesHelperService listaArchivosPendientesHelperService;
	
	/**
	 * Operacion que nos devolverá los ficheros pendientes de autorizacion remota
	 * <br><strong>Con paginacion</strong>
	 * 
	 * @param page 					Número de pagina a consultar
	 * @param size					Tamaño de resultados a devolver
	 * @param monConsolidacion		Moneda a la que convertir los importes
	 * @return
	 */
	
	
	@PostMapping(value = "/v1/listadoARautorizar", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "List of pending R.A. files")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	public ResponseEntity<ListaArchivosPendientesResponse> getListaPagosAutorizar(
			@RequestBody ListaArchivosARRequest request){
		try
		{
			log.debug("REST POST call received in /v1/listadoARautorizar {} {} {} {}",
					request.getMonConsolidacion(),
					request.getNumPagina(),
					request.getNumPorPagina(),
					request.getTokenBks()
					);
			
			ListaArchivosPendientesResponse laap = listaArchivosPendientesHelperService.getListaArchivosPendientes(request, false);			
            return new ResponseEntity<>(laap, HttpStatus.OK);
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_OPERATION_NAME + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			ListaArchivosPendientesResponse respuesta = new ListaArchivosPendientesResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENCIAL) > -1) {	
				respuesta.setListaArchivos(null);
				respuesta.setListaDivisas(null);
				respuesta.setNumFichTotales(0);
				respuesta.setNumPaginaActual(0);
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(respuesta, HttpStatus.UNAUTHORIZED);
			}else {
				respuesta.setListaArchivos(null);
				respuesta.setListaDivisas(null);
				respuesta.setNumFichTotales(0);
				respuesta.setNumPaginaActual(0);
				respuesta.setStatus(STR_KO);
				respuesta.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
			}			
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_OPERATION_NAME + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			ListaArchivosPendientesResponse respuesta = new ListaArchivosPendientesResponse();
			respuesta.setListaArchivos(null);
			respuesta.setListaDivisas(null);
			respuesta.setNumFichTotales(0);
			respuesta.setNumPaginaActual(0);
			respuesta.setStatus(STR_KO);
			respuesta.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
}
