package com.isban.scnp.fo.autorizacionpagos.common.model;

import java.io.IOException;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;

public class AmountSerializer extends JsonSerializer<BigDecimal>{
	
	private static final int INT_CERO = 0;
	private static final int INT_UNO = 1;
	private static final int INT_TRES = 3;
	private static final String VACIO = "";
	private static final String STR_CERO = "0";
	private static final String STR_CEROCOMACEROCERO = "0,00";
	private static final String STR_COMA = ",";
	private static final String COMACEROCERO = ",00";
	private static final String FORMATO_UNO = "#########.##";
	private static final String FORMATO_DOS = "#########,##";
	private static final String FORMATO_TRES = "###,###,###.##";
	private static final String FORMATO_CUATRO = "###.###.###,##";
	private static final String STR_PUNTO = ".";
	private static final char CHAR_PUNTO = '.';
	private static final char CHAR_COMA = ',';
	
	@Autowired
	private AppContext appContext;

	@Override
	public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider serializers)
			throws IOException{
		String format = appContext.getUserData().getFormatoCantidad();
		String importe = value.toString().replace(CHAR_PUNTO,CHAR_COMA);
		gen.writeString(formatearCantidad(importe,format));
	}

	
	
	/**
	 * Funcion de formateo de fechas de listaLotesPagos (Principal de pagos iniciacion)
	 * 
	 * @param s_cantidad
	 * @param formatoCant
	 * @return
	 */
	private String formatearCantidad (String s_cantidad, String formatoCant)
	{
		formatoCant = formatoCant.trim();
		String signo = VACIO;
	    if(s_cantidad.equals(STR_CERO)||s_cantidad.length()==INT_CERO){
	    	s_cantidad=STR_CEROCOMACEROCERO;		
	    }

		int parteDecimal = s_cantidad.indexOf(STR_COMA);
		if (parteDecimal<INT_CERO){
			s_cantidad = s_cantidad.concat(COMACEROCERO);
		} else{
			String decimalCorto = s_cantidad.substring(INT_CERO,parteDecimal);
			String decimal=s_cantidad.substring(parteDecimal+INT_UNO, s_cantidad.length());
			if(decimal.length()==INT_UNO){
				decimal=decimal+STR_CERO;
			}
			if(decimal.charAt(0)=='-'){
				signo = "-";
				decimal = decimal.substring(INT_UNO);
			}
			if(decimalCorto.charAt(0)=='-'){
				signo = "-";
				decimalCorto=decimalCorto.substring(INT_UNO);
			}
			s_cantidad = decimalCorto.concat(STR_COMA).concat(decimal);
		}
		if(formatoCant.equalsIgnoreCase(FORMATO_UNO))
		{
			int dec = s_cantidad.indexOf(STR_COMA);
			String decimal = s_cantidad.substring(dec+INT_UNO, s_cantidad.length());
			String entero = s_cantidad.substring(INT_CERO, dec);
			
			int i=INT_CERO;
			int j=INT_CERO;
			String ant = VACIO;
			String desp = VACIO;
			while (i<entero.length() && i>=INT_CERO){
				i = entero.indexOf(STR_PUNTO);
				if(i>INT_CERO){
					ant = entero.substring(j, i);
					desp = entero.substring(i+INT_UNO, entero.length());
					entero= ant.concat(desp);
				}
			}
			s_cantidad = entero.concat(STR_PUNTO).concat(decimal);
		}else if(formatoCant.equalsIgnoreCase(FORMATO_DOS)){
			//FORMATO DOS - 
		}else if(formatoCant.equalsIgnoreCase(FORMATO_TRES)){ 
		
				//FORMATO_TRES
			int dec = s_cantidad.indexOf(STR_COMA);
			String decimal = s_cantidad.substring(dec+INT_UNO, s_cantidad.length());
			String entero = s_cantidad.substring(INT_CERO, dec);
			int tamCant = entero.length();
			String cantAux = VACIO;
			int i=tamCant;
			for(;i>INT_TRES;i-=INT_TRES){
				if(i!=tamCant){
					cantAux= entero.substring(i-INT_TRES,i)+CHAR_PUNTO+cantAux;
				}else{
					cantAux= entero.substring(i-INT_TRES,i);
				}
				if(i-INT_TRES<=INT_TRES){
					cantAux= entero.substring(INT_CERO,i-INT_TRES)+CHAR_PUNTO+cantAux;
				}
			}
			if(!cantAux.equals(VACIO)){
				entero=cantAux;
			}
			String antes = entero.replace(CHAR_PUNTO,CHAR_COMA);
			s_cantidad = antes.concat(STR_PUNTO).concat(decimal);
		}else if(formatoCant.equalsIgnoreCase(FORMATO_CUATRO)){
			// FORMATO_CUATRO
			int dec = s_cantidad.indexOf(STR_COMA);
			String decimal = s_cantidad.substring(dec+INT_UNO, s_cantidad.length());
			String entero = s_cantidad.substring(INT_CERO, dec);
			int tamCant = entero.length();
			String cantAux = VACIO;
			int i=tamCant;
			for(;i>INT_TRES;i-=INT_TRES){
				if(i!=tamCant){
					cantAux= entero.substring(i-INT_TRES,i)+CHAR_PUNTO+cantAux;
				}else{
					cantAux= entero.substring(i-INT_TRES,i);
				}
				if(i-INT_TRES<=INT_TRES){
					cantAux= entero.substring(INT_CERO,i-INT_TRES)+CHAR_PUNTO+cantAux;
				}
			}
			if(!cantAux.equals(VACIO)){
				entero=cantAux;
			}
			s_cantidad = entero.concat(STR_COMA).concat(decimal);
		}else {
			// FORMATO_DEFECTO
			int dec = s_cantidad.indexOf(STR_COMA);
			String decimal = s_cantidad.substring(dec+INT_UNO, s_cantidad.length());
			String entero = s_cantidad.substring(INT_CERO, dec);

			int k=INT_CERO;
			int l=INT_CERO;
			String ant = VACIO;
			String desp = VACIO;
			while (k<entero.length() && k>=INT_CERO){
				k = entero.indexOf(STR_PUNTO);
				if(k>INT_CERO){
					ant = entero.substring(l, k);
					desp = entero.substring(k+INT_UNO, entero.length());
					entero= ant.concat(desp);
				}
			}
			
			s_cantidad = entero.concat(STR_COMA).concat(decimal);
		}
		s_cantidad = signo.concat(s_cantidad);
		return s_cantidad;	
	}
}
