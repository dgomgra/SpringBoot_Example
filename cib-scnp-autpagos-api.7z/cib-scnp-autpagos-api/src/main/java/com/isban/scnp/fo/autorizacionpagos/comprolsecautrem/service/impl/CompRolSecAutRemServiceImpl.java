package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ArchivoPolitica;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.IdArchivoGrupoEmp;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.IdArchivoGrupoEmpMapper;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRol;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRolFirmado;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRolFirmadoMapper;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRolMapper;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service.CompRolSecAutRemHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.IntegerMapper;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;

/**
 * Implementacion del servicio de comprobacion de roles en sentencias de autorazacion de Autorizacion Remota
 * 
 * @author dagonzalez
 *
 */
@Service
public class CompRolSecAutRemServiceImpl implements CompRolSecAutRemHelperService{

	private static final String STR_O = "O";
	private static final String STR_A = "A";
	private static final String STR_N = "N";
	private static final String STR_S = "S";
	private static final String STR_VACIO = "";
	private static final int MAX_SIZE_QUERY = 1000;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${schema_proc}")
    protected String schemaproc;

	@Override
	public List<ArchivoPolitica> comprobarRolSecuenciaAutRA(String uid, int codigoGrupoEmpresarial, List<ArchivoAR> idArchivos) {

		List<ArchivoPolitica> salida = new ArrayList<>();		
		
		int codigoRolUsuario = obtRolUsuario(uid);

		List<IdArchivoGrupoEmp> listaArchivosGrupoEmp = obtGrupoEmpArchivos(idArchivos);
		List<Integer> listaArchivosSinCodGrup = new ArrayList<>();

		for (int i=0;i<listaArchivosGrupoEmp.size();i++) {
			if (codigoGrupoEmpresarial == listaArchivosGrupoEmp.get(i).getCodGrupoEmp()) {
				listaArchivosSinCodGrup.add(listaArchivosGrupoEmp.get(i).getIdArchivo());
			}
		}

		if(!listaArchivosSinCodGrup.isEmpty()) {

			List<Integer> archivosFirmaOK = obtArchivosFirmaOKUsuario(uid, listaArchivosSinCodGrup);
			if (!archivosFirmaOK.isEmpty()) {

				List<Integer> listaArchivosComprobados = new ArrayList<>();

				for (int j=0;j<listaArchivosSinCodGrup.size();j++) {
					int idArchivo = listaArchivosSinCodGrup.get(j);
					String indEncontrado = STR_N;
					for (int k=0;k<archivosFirmaOK.size();k++) {
						int idArchivoFirma = archivosFirmaOK.get(k);
						if (idArchivo == idArchivoFirma) {
							indEncontrado = STR_S;
							k=archivosFirmaOK.size();
						}
					}

					if (STR_N.equals(indEncontrado))
					{
						listaArchivosComprobados.add(idArchivo);
					}
				}

				listaArchivosSinCodGrup.clear();
				listaArchivosSinCodGrup.addAll(listaArchivosComprobados);
			}

			List<ObtArchivoSentRol> listaArchivosSentRol = obtArchivosSentRol(listaArchivosSinCodGrup);

			List<ObtArchivoSentRolFirmado> listaIdArchivoCodRol = obtArchivosSentRolFirmado(codigoRolUsuario, listaArchivosSinCodGrup);

			int archivoF 	= 0;
			int anordenF 	= 0;
			int archivoN 	= 0;
			int anordenN 	= 0;
			int numFirmas 	= 0;

			Map<Integer, Integer> firmasPorArchivosRol = new HashMap<>();

			List<ObtArchivoSentRol> listaAux 	= new ArrayList<>();
			List<ObtArchivoSentRol> listaFinal 	= new ArrayList<>();

			for (int l=0;l<listaArchivosSentRol.size();l++)
			{
				archivoN = listaArchivosSentRol.get(l).getIdArchivo();
				anordenN = listaArchivosSentRol.get(l).getaNOrden();

				if (archivoF == archivoN) {
					//si continuamos en el mismo pago
					//comprobamos si cambiamos de anorden
					if (anordenF == anordenN)
					{	
						//si no cambiamos de anorden y no cambiamos de pago nos quedamos con el pago
						//comprobamos que si exise con el mismo anordenGRP ATIPGRU="O" y mismo rol aumentamos anumfirm del que ya existe y no añadimos
						listaAux = sumaOrAnadeRolesPago(listaArchivosSentRol.get(l), listaAux);
					}

					if(l==listaArchivosSentRol.size()-1){
						numFirmas	=	calculaFirmasRol(listaAux, codigoRolUsuario);
						if(numFirmas>0){
							//añadimos si numFirmas mayor 0. Si numFirmas es 0 el rol no existe en la sentencia
							firmasPorArchivosRol.put(listaAux.get(0).getIdArchivo(), numFirmas);
						}
						//es la ultima iteración
						for(int j = 0;j<listaAux.size();j++){
							listaFinal.add(listaAux.get(j));

						}
						listaAux.clear();
					}				
				}else {
					//hemos pasado al siguiente pago o es el primero, por lo que cogemos su primer anorden y nos quedamos con el pago
					//añadimos directamente
					archivoF=archivoN;
					anordenF=anordenN;
					if(l!=0){
						numFirmas=calculaFirmasRol(listaAux, codigoRolUsuario);
						if(numFirmas>0){
							//añadimos si numFirmas mayor 0. Si numFirmas es 0 el rol no existe en la sentencia
							firmasPorArchivosRol.put(listaAux.get(0).getIdArchivo(), numFirmas);
						}

						//hemos cambiado de pago
						for(int j = 0;j<listaAux.size();j++){
							listaFinal.add(listaAux.get(j));

						}
						listaAux.clear();
					}

					listaAux.add(listaArchivosSentRol.get(l));

					if(l==listaArchivosSentRol.size()-1 && l!=0){
						numFirmas=calculaFirmasRol(listaAux, codigoRolUsuario);
						if(numFirmas>0){
							//añadimos si numFirmas mayor 0. Si numFirmas es 0 el rol no existe en la sentencia
							firmasPorArchivosRol.put(listaAux.get(0).getIdArchivo(), numFirmas);
						}

						//hemos cambiado de pago
						for(int j = 0;j<listaAux.size();j++){
							listaFinal.add(listaAux.get(j));

						}
						listaAux.clear();
					}

					if(listaArchivosSentRol.size()==1){
						//solo hay un pago con una sentencia sabemos que no está firmada
						//o hay un pago con una sentencia y no es el unico pago

						numFirmas=calculaFirmasRol(listaAux, codigoRolUsuario);
						if (numFirmas!=0 || listaAux.size()>0){
							listaFinal.add(listaAux.get(l));
							firmasPorArchivosRol.put(listaAux.get(0).getIdArchivo(), numFirmas);
						}
					}
				}
			}

			int tamSentenciasFirma = listaIdArchivoCodRol.size();
			int tamArchivosFinal = listaFinal.size();

			for(int z=tamSentenciasFirma-1;z>=0;z--){
				boolean existe=false;
				int pagoFirm 	= listaIdArchivoCodRol.get(z).getIdArch();
				int cpolFirm 	= listaIdArchivoCodRol.get(z).getCodSentencia();
				int idAuthFirm 	= listaIdArchivoCodRol.get(z).getIdAuth();

				for (int x=0;x<tamArchivosFinal;x++){

					int pagoSentencia 	= listaFinal.get(x).getIdArchivo();
					int cpolSentencia 	= listaFinal.get(x).getCodSentencia();
					int idAuthSentencia = listaFinal.get(x).getIdAutorizacion();
					if(pagoSentencia == pagoFirm && cpolSentencia == cpolFirm && idAuthSentencia == idAuthFirm){
						existe=true;

					}
				}
				if(!existe){
					//si no coincide la sentencia para el pago la eliminamos.
					listaIdArchivoCodRol.remove(z);
				}
			}

			//calculamos el nuevo tamaño
			tamSentenciasFirma=listaIdArchivoCodRol.size();

			//los que no están en firmasPorPagoRol no van a la salida, ya que no existe rol
			//ahora tenemos que comprobar si ha cumplido todas las firmas
			Map<Integer, Integer> sentenciasFirmadasRol = new HashMap<>();
			for (int y=0;y<tamSentenciasFirma;y++){

				int pagoFirm = listaIdArchivoCodRol.get(y).getIdArch();

				if(sentenciasFirmadasRol.containsKey(pagoFirm)){
					//si contiene la clave sumamos uno
					Integer firmPag = sentenciasFirmadasRol.get(pagoFirm);
					sentenciasFirmadasRol.put(pagoFirm,firmPag+1);
				}else{
					//si no lo añadimos con uno
					sentenciasFirmadasRol.put(pagoFirm,1);
				}

			}

			Map<Integer, Integer> archivosBorrar = new HashMap<>();
			Iterator<Integer> it = firmasPorArchivosRol.keySet().iterator();
			while (it.hasNext()) {
				Integer key=it.next(); //en n tenemos el valor
				if(sentenciasFirmadasRol.containsKey(key)){
					Integer firmados = sentenciasFirmadasRol.get(key);
					Integer firmadosMax = firmasPorArchivosRol.get(key);
					if(firmados>=firmadosMax && !archivosBorrar.containsKey(key)){
							archivosBorrar.put(key,key);
					}
				}

			}
			//borramos
			Iterator<Integer> itBorrar = archivosBorrar.keySet().iterator();
			while (itBorrar.hasNext()) {
				Integer key = itBorrar.next();
				if(firmasPorArchivosRol.containsKey(key)){
					firmasPorArchivosRol.remove(key);
				}

			}	
			//firmasPorPagoRol contiene los pagos que hay que devolver
			//tenemos que cargar la salida rellenando la sentencia

			//pagos a filtrar
			for (int z=0;z<listaFinal.size();z++){
				//si el pago existe lo añadimos a la salida sin duplicarlos
				int archivoSalida = listaFinal.get(z).getIdArchivo();

				if(firmasPorArchivosRol.containsKey(archivoSalida)){

					int polSente 	= listaFinal.get(z).getCodSentencia();
					int autoSente 	= listaFinal.get(z).getIdAutorizacion();
					ArchivoPolitica archivosSalida = new ArchivoPolitica() ;

					archivosSalida.setIdArchivo(archivoSalida);
					archivosSalida.setCodSentencia(polSente);
					archivosSalida.setIdAutorizacion(autoSente);

					salida.add(archivosSalida);
					//eliminamos el pago para no duplicarlo a la salida
					firmasPorArchivosRol.remove(archivoSalida);
				}

			}
		}
		return salida;
	}

	@Override
	public List<ObtArchivoSentRolFirmado> obtArchivosSentRolFirmado(int codigoRolUsuario, List<Integer> listaArchivosComprobados) {
		List<Integer> listaTemp = new ArrayList<>();
		List<ObtArchivoSentRolFirmado> salida = new ArrayList<>();		
		List<ObtArchivoSentRolFirmado> salidaTemp = new ArrayList<>();
		
		int tamListaIds = listaArchivosComprobados.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaArchivosComprobados.get(j));
					
				}
				
				salidaTemp = obtArchivosSentRolFirmadoQuery (codigoRolUsuario, listaTemp);
				
				salida.addAll(salidaTemp);
			
			}
		}
		
		return salida;
	}
	

	private List<ObtArchivoSentRolFirmado> obtArchivosSentRolFirmadoQuery(int codigoRolUsuario, List<Integer> listaArchivosComprobados) {

		String sql = 	"SELECT " +
						"O9250_IDARCH, " +
						"O9250_CPOLSENTE, " +
						"O9250_IDAUTH " +
						"FROM " + schemaproc + ".SGP_ARCH_FIRMAM, " + schemaproc + ".SGP_R_ARCH_FIRM " +
						"WHERE "+
						"O9250_CDFIRMARCH = O9251_CDFIRMARCH AND " +
						"O9250_IDARCH IN (" + getStringOfIntegerList(listaArchivosComprobados) + ") AND " +
						"O9251_CODIGROL= ? AND " +
						"O9251_FIRMADO = 'S'";

		Object[] params = new Object[] {codigoRolUsuario};

		return jdbcTemplate.query(sql, params, new ObtArchivoSentRolFirmadoMapper());
	}

	@Override
	public List<ObtArchivoSentRol> obtArchivosSentRol(List<Integer> listaArchivosComprobados) {
		List<Integer> listaTemp = new ArrayList<>();
		List<ObtArchivoSentRol> salida = new ArrayList<>();		
		List<ObtArchivoSentRol> salidaTemp = new ArrayList<>();
		
		int tamListaIds = listaArchivosComprobados.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(listaArchivosComprobados.get(j));
					
				}
				
				salidaTemp = obtArchivosSentRolQuery (listaTemp);
				
				salida.addAll(salidaTemp);
			
			}
		}
		
		return salida;
	}
	

	private List<ObtArchivoSentRol> obtArchivosSentRolQuery(List<Integer> listaArchivosComprobados) {
		String sql = "SELECT " + 
				"O9249_IDARCH, " + 
				"O9249_CPOLSENTE, " + 
				"O9249_IDAUTH, " + 
				"O9249_IDCOMP, " + 
				"N2921_ANORDEN, " + 
				"N2919_ANUMFIRM, " + 
				"N2919_CODIGROL, " + 
				"N2921_TAMENT , " + 
				"N2919_ANORDEN, " + 
				"N2921_ATIPAGRU " +
				"FROM " + schemaproc + ".SGP_R_ARCH_SEN, " + schemaproc + ".SGP_POL_SENTEN, " + schemaproc + ".SGP_POL_SEN_GRP " +
				"WHERE O9249_CPOLSENTE = N2921_CPOLSENTE AND N2921_CPOLSENTE= N2919_CPOLSENTE AND " +
				"O9249_IDAUTH= N2921_IDAUTH AND N2921_IDAUTH= N2919_IDAUTH AND " +
				"O9249_IDARCH IN ("+  getStringOfIntegerList(listaArchivosComprobados)  +") AND " +
				"O9249_IDCOMP= 'N' ORDER BY O9249_IDARCH, N2921_ANORDEN";

		return jdbcTemplate.query(sql, new ObtArchivoSentRolMapper());
	}

	@Override
	public int obtRolUsuario(String uid)
	{
		String sql = 	"SELECT H1241_CODIGROL " +
						"FROM 	" + schemaproc + ".SGP_PERF_USU " + 
						"WHERE 	H1241_UID = ? " + 
						"AND 	H1241_CRSITUAC = 'H' AND H1241_IDACTIVO = 'S'";

		String uidFormateado = String.format("%1$-30s", uid);
		Object[] params = new Object[] {uidFormateado};
		List<Integer> resultadoQuery = jdbcTemplate.query(sql, params, new IntegerMapper());

		if (resultadoQuery!=null && !resultadoQuery.isEmpty())
		{
			int tamLista = resultadoQuery.size();

			if(tamLista > 0) {
				return resultadoQuery.get(0);
			}else {
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	
	@Override
	public List<IdArchivoGrupoEmp> obtGrupoEmpArchivos(List<ArchivoAR> idArchivos) {
		String sql = 	"SELECT O9247_IDARCH, O9247_CDEMGR " + 
						"FROM 	" + schemaproc + ".SGP_ARCH_REMOT " +
						"WHERE 	O9247_IDARCH = ?";

		List<IdArchivoGrupoEmp> listaIdArchivoGrupoEmp = new ArrayList<>();

		for (int i=0;i<idArchivos.size();i++) {
			Object[] params = new Object[] {idArchivos.get(i).getIdArchivo()};
			listaIdArchivoGrupoEmp.add(	(IdArchivoGrupoEmp) jdbcTemplate.query(sql, params, new IdArchivoGrupoEmpMapper()).get(0));
		}
		
		return listaIdArchivoGrupoEmp;
	}

	
	@Override
	public List<Integer> obtArchivosFirmaOKUsuario(String uid, List<Integer> idArchivos){
		List<Integer> listaTemp = new ArrayList<>();
		List<Integer> salida = new ArrayList<>();		
		List<Integer> salidaTemp = new ArrayList<>();
		
		int tamListaIds = idArchivos.size();
		if (tamListaIds>0)
		{
			int numIters = tamListaIds/MAX_SIZE_QUERY + ((tamListaIds%MAX_SIZE_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				int tamMin = Math.min(MAX_SIZE_QUERY*(i+1),tamListaIds);
				listaTemp.clear();
				for (int j=i*MAX_SIZE_QUERY;j<tamMin;j++)
				{
					listaTemp.add(idArchivos.get(j));
					
				}
				
				salidaTemp = obtArchivosFirmaOKUsuarioQuery (uid, listaTemp);
				
				salida.addAll(salidaTemp);
			
			}
		}
		
		return salida;
	}
	

	private List<Integer> obtArchivosFirmaOKUsuarioQuery(String uid, List<Integer> idArchivos){

		String sql = 	"SELECT O9250_IDARCH " + 
						"FROM 	" + schemaproc + ".SGP_ARCH_FIRENM, " + schemaproc + ".SGP_ARCH_FIRMAM, " + schemaproc + ".SGP_R_ARCH_FIRM " +
						"WHERE 	O9252_CDFIRMARCH = O9251_CDFIRMARCH AND " +
						"O9251_CDFIRMARCH = O9250_CDFIRMARCH AND " +
						"O9251_UID = ? AND " +
						"O9252_INDFIROK = 'S' AND "+
						"O9250_IDARCH IN (" + getStringOfIntegerList(idArchivos) + ")";
		
		String uidFormateado = String.format("%1$-30s", uid);
		Object[] params = new Object[] {uidFormateado};

		return jdbcTemplate.query(sql, params, new IntegerMapper());
	}



	private int calculaFirmasRol(List<ObtArchivoSentRol> listaAux, int rol) {

		int firmasMax=0;
		//calculamos el numero de firmas maximo de un rol
		String tipoAgru=STR_VACIO;
		int rolLista=0;
		for(int j=listaAux.size()-1;j>=0;j--){
			rolLista=listaAux.get(j).getCodrol();
			if(rol!=rolLista){
				//eliminamos el registro
				listaAux.remove(j);
			}
		}
		
		for(int i=0;i<listaAux.size();i++){
			tipoAgru=listaAux.get(i).getaTipAGru();
			int numFirmas = listaAux.get(i).getaNumFim();
			if(STR_A.equals(tipoAgru)){
				firmasMax+=numFirmas;
			}else{
				//OR
				//calculamos el mayor
				if(numFirmas>firmasMax){
					firmasMax=numFirmas;
				}
			}
		}
		//si es AND sumamos los roles
		//si es OR es el numero máximo por grupo 
		//si firmas es 0 es que no existe el rol en la sentencia
		
		return firmasMax;
	}
	
	
	private List<ObtArchivoSentRol> sumaOrAnadeRolesPago(ObtArchivoSentRol sentencia, List<ObtArchivoSentRol> listaAux) {

		int tamLista = listaAux.size();
		boolean anadido = false;

		String atipagru = sentencia.getaTipAGru();
		int anordengrp = sentencia.getaNOrden();
		int codigRol = sentencia.getCodrol();
		int anumFirm = sentencia.getaNumFim();

		for (int i=0;i<tamLista;i++){
			if (!anadido) {
				int anordengrpLst 	= listaAux.get(i).getaNOrdenGrp();
				int rolLst			= listaAux.get(i).getCodrol();
				if(STR_O.equals(sentencia.getaTipAGru()) && anordengrp==anordengrpLst && codigRol==rolLst){
					//sumamos anumfirm
					int anumFirmLst =  listaAux.get(i).getaNumFim();
					listaAux.get(i).setaNumFim(anumFirmLst+anumFirm);

				}else if(STR_A.equals(atipagru) && anordengrp==anordengrpLst && codigRol==rolLst){
					//NO sumamos anumfirm, actualizamos al mayor.
					int anumFirmLst =  listaAux.get(i).getaNumFim();
					if (anumFirm>anumFirmLst){
						listaAux.get(i).setaNumFim(anumFirm);
					}

				}else {
					//añadimos
					listaAux.add(sentencia);
					anadido=true;
				}
			}			
		}

		return listaAux;
	}
	
	/**	Metodo privado para la conversion de una lista de ints a cadena
	 * 
	 * @param idArchivos
	 * @return
	 */
	private String getStringOfIntegerList(List<Integer> idArchivos) {
		StringBuilder commaSepValueBuilder = new StringBuilder();
		for ( int i = 0; i< idArchivos.size(); i++){
			//append the value into the builder
			commaSepValueBuilder.append(idArchivos.get(i));

			//if the value is not the last element of the list then append the comma(,) as well
			if ( i != idArchivos.size()-1){
				commaSepValueBuilder.append(", ");
			}
		}
		// Si no hay valores añadimos un valor vacio para que no falle la sentencia IN
		if (commaSepValueBuilder.toString().equals(STR_VACIO)) {
			commaSepValueBuilder.append("''");
		}
		return commaSepValueBuilder.toString();
	}


}




