package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class ListaLotesWarehouseRequest {
	private int numPagina;
	private int numPorPagina;
	private String monedaConsolidacion;
	private String tokenBks;
	public int getNumPagina() {
		return numPagina;
	}
	public void setNumPagina(int numPagina) {
		this.numPagina = numPagina;
	}
	public int getNumPorPagina() {
		return numPorPagina;
	}
	public void setNumPorPagina(int numPorPagina) {
		this.numPorPagina = numPorPagina;
	}	
	public String getMonedaConsolidacion() {
		return monedaConsolidacion;
	}
	public void setMonedaConsolidacion(String monedaConsolidacion) {
		this.monedaConsolidacion = monedaConsolidacion;
	}
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}	
}
