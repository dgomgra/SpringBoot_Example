package com.isban.scnp.fo.autorizacionpagos.listalotes.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DatosPagoLoteDivisaMapper implements RowMapper<DatosPagoLoteDivisa>{

	@Override
	public DatosPagoLoteDivisa mapRow(ResultSet rs, int rowNum) throws SQLException {
		DatosPagoLoteDivisa retorno = new DatosPagoLoteDivisa();
		retorno.setIdPago(rs.getString("N6563_RFTRANS"));
		retorno.setIdLote(rs.getString("N6563_NULOTE"));
		retorno.setDivisaPago(rs.getString("N6563_CODMONSWI"));		
		return retorno;
	}
	
}
