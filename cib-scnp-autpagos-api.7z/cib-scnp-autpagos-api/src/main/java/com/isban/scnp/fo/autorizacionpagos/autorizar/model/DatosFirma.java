package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

import java.math.BigDecimal;

public class DatosFirma {
	private String key;
	private int numPagos;
	private BigDecimal importeTotal;
	
	
	public DatosFirma() {
		super();
		numPagos = 0;
		importeTotal = BigDecimal.valueOf(0.0d);
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public int getNumPagos() {
		return numPagos;
	}
	public void setNumPagos(int numPagos) {
		this.numPagos = numPagos;
	}
	public BigDecimal getImporteTotal() {
		return importeTotal;
	}
	public void setImporteTotal(BigDecimal importeTotal) {
		this.importeTotal = importeTotal;
	}
}
