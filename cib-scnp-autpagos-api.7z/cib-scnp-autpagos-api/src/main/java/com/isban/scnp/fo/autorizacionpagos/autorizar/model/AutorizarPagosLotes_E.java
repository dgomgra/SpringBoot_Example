package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

import java.util.ArrayList;
import java.util.List;

public class AutorizarPagosLotes_E {
	private static final String STR_VACIO = "";
	private String indAutorizar;
	private DatosFirma datosFirma; 
	private List <IdPagoNombreK> listaIdPagoNombre;
	private List <IdLoteNombreK> listaIdLoteNombre;
	private Nota nota;
	
	
	public AutorizarPagosLotes_E() {
		super();
		indAutorizar = STR_VACIO;
		datosFirma = new DatosFirma();
		listaIdPagoNombre = new ArrayList <>();
		listaIdLoteNombre = new ArrayList <>();
		nota = new Nota();
	}
	public String getIndAutorizar() {
		return indAutorizar;
	}
	public void setIndAutorizar(String indAutorizar) {
		this.indAutorizar = indAutorizar;
	}
	public DatosFirma getDatosFirma() {
		return datosFirma;
	}
	public void setDatosFirma(DatosFirma datosFirma) {
		this.datosFirma = datosFirma;
	}
	public List<IdPagoNombreK> getListaIdPagoNombre() {
		return new ArrayList<IdPagoNombreK>(listaIdPagoNombre);
	}
	public void setListaIdPagoNombre(List<IdPagoNombreK> listaIdPagoNombre) {
		this.listaIdPagoNombre = new ArrayList<IdPagoNombreK>(listaIdPagoNombre);
	}
	public List<IdLoteNombreK> getListaIdLoteNombre() {
		return new ArrayList<IdLoteNombreK>(this.listaIdLoteNombre);
	}
	public void setListaIdLoteNombre(List<IdLoteNombreK> listaIdLoteNombre) {		
		this.listaIdLoteNombre = new ArrayList<IdLoteNombreK>(listaIdLoteNombre);
	}
	public Nota getNota() {
		return nota;
	}
	public void setNota(Nota nota) {
		this.nota = nota;
	}	
}
