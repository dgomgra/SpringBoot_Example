
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

import java.util.List;

public class PaisArbol {

    private String codPais;
    private String nombrePais;
    private String divisaUsuario;
    private String sumBookBalanceDivUsu;
    private String sumValueBalanceDivUsu;
    private List<ListaMonedasArbol> listaMonedasArbol = null;

    public String getCodPais() {
        return codPais;
    }

    public void setCodPais(String codPais) {
        this.codPais = codPais;
    }

    public String getNombrePais() {
        return nombrePais;
    }

    public void setNombrePais(String nombrePais) {
        this.nombrePais = nombrePais;
    }

    public String getDivisaUsuario() {
        return divisaUsuario;
    }

    public void setDivisaUsuario(String divisaUsuario) {
        this.divisaUsuario = divisaUsuario;
    }

    public String getSumBookBalanceDivUsu() {
        return sumBookBalanceDivUsu;
    }

    public void setSumBookBalanceDivUsu(String sumBookBalanceDivUsu) {
        this.sumBookBalanceDivUsu = sumBookBalanceDivUsu;
    }

    public String getSumValueBalanceDivUsu() {
        return sumValueBalanceDivUsu;
    }

    public void setSumValueBalanceDivUsu(String sumValueBalanceDivUsu) {
        this.sumValueBalanceDivUsu = sumValueBalanceDivUsu;
    }

    public List<ListaMonedasArbol> getListaMonedasArbol() {
        return listaMonedasArbol;
    }

    public void setListaMonedasArbol(List<ListaMonedasArbol> listaMonedasArbol) {
        this.listaMonedasArbol = listaMonedasArbol;
    }

}
