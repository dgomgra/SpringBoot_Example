package com.isban.scnp.fo.autorizacionpagos.detallear.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;

public class DetalleArchivo {
	private Date fecha;
	private String estadoArchivo;
	private String descEstado;
	private String nombre;
	private int numTransac;
	private BigDecimal monto;
	private String divisa;
	private String motivoRechazo;
	@JsonSerialize(using = DateSerializer.class)
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getEstadoArchivo() {
		return estadoArchivo;
	}
	public void setEstadoArchivo(String estadoArchivo) {
		this.estadoArchivo = estadoArchivo;
	}
	public String getDescEstado() {
		return descEstado;
	}
	public void setDescEstado(String descEstado) {
		this.descEstado = descEstado;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNumTransac() {
		return numTransac;
	}
	public void setNumTransac(int numTransac) {
		this.numTransac = numTransac;
	}
	@JsonSerialize(using = AmountSerializer.class)
	public BigDecimal getMonto() {
		return monto;
	}
	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}	
	public String getDivisa() {
		return divisa;
	}
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	public String getMotivoRechazo() {
		return motivoRechazo;
	}
	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}
}
