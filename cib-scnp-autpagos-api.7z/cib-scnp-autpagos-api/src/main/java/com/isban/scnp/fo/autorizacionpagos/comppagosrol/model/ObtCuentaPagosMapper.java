package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

public class ObtCuentaPagosMapper implements RowMapper<ObtCuentaPagosOut> {

	private static final String STR_N6563_ACUENCOT = "N6563_ACUENCOT";
	private static final String STR_N6563_RFTRANS = "N6563_RFTRANS";

	@Override
	public ObtCuentaPagosOut mapRow(ResultSet rs, int row) throws SQLException {
		ObtCuentaPagosOut obtCuentaPagosOut = new ObtCuentaPagosOut();
		
		obtCuentaPagosOut.setRftrans(rs.getString(STR_N6563_RFTRANS));
		obtCuentaPagosOut.setAcuencod(rs.getInt(STR_N6563_ACUENCOT));
		return obtCuentaPagosOut;
	}

}
