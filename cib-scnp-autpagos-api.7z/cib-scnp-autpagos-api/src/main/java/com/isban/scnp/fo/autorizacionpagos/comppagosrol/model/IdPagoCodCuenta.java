package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

public class IdPagoCodCuenta {

	private String rftrans;
	private int acuencot;
	
	public String getRftrans() {
		return rftrans;
	}
	public void setRftrans(String rftrans) {
		this.rftrans = rftrans;
	}
	public int getAcuencot() {
		return acuencot;
	}
	public void setAcuencot(int acuencot) {
		this.acuencot = acuencot;
	}
}
