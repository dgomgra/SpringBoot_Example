package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service;

import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;

public interface ConversionDivisaHelperService {
	public ConversionDivisaResponse conversionDivisa (ConversionDivisaRequest entrada);
}
