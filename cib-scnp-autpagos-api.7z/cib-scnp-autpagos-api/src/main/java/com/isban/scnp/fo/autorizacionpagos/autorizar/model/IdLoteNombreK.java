package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT ,use = JsonTypeInfo.Id.NAME)
public class IdLoteNombreK {
	private IdLoteNombre idLoteNombre;

	public IdLoteNombreK() {
		super();
		idLoteNombre=new IdLoteNombre();
	}

	public IdLoteNombre getIdLoteNombre() {
		return idLoteNombre;
	}

	public void setIdLoteNombre(IdLoteNombre idLoteNombre) {
		this.idLoteNombre = idLoteNombre;
	}
	
	
}
