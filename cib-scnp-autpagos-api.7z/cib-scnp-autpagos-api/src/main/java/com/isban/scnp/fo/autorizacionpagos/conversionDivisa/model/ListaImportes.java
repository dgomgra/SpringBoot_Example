package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

import java.util.ArrayList;
import java.util.List;

public class ListaImportes {
	private List<Importe> listaImportes;

	public ListaImportes() {
		super();
		listaImportes=new ArrayList<Importe>(0);
	}
	
	public List<Importe> getListaImportes() {
		return listaImportes;
	}

	public void setListaImportes(List<Importe> listaImportes) {
		this.listaImportes = listaImportes;
	}
	
	public void addImporte (Importe i)
	{
		listaImportes.add(i);
	}
}
