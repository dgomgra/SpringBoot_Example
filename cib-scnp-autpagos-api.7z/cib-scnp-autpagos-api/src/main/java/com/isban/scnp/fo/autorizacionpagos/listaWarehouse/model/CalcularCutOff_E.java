package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class CalcularCutOff_E {

	private CalcularCutOffDatosE calcularCutOff;

	public CalcularCutOffDatosE getCalcularCutOff() {
		return calcularCutOff;
	}

	public void setCalcularCutOff(CalcularCutOffDatosE calcularCutOff) {
		this.calcularCutOff = calcularCutOff;
	}
}
