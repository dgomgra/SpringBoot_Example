package com.isban.scnp.fo.autorizacionpagos.home.service.impl;

import java.net.URI;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeRequest;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeResponseData;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.InicioMovilResponse;
import com.isban.scnp.fo.autorizacionpagos.home.service.HomeHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.ListaArchivosPendientesHelperService;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.ListaLotesHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@Service
public class HomeServiceImpl implements HomeHelperService{

	private static final String STR_OK = "OK";
	private static final String STR_MSG_OK = "OK";
	private static final String STR_VACIO = "";

	@Value("${urlBks}")
    protected String urlBks;
	
	@Autowired
	private AppContext appContext;
	
	@Autowired
	private ListaPagosHelperService servicioPagos;
	
	@Autowired
	private ListaWarehouseHelperService servicioWarehouse;
	
	@Autowired
	private ListaArchivosPendientesHelperService servicioArchivos;
	
	@Autowired
	private ListaLotesHelperService servicioLotes;
	
	@Autowired
	private ApiRestTemplate apiRestTemplate;
		
	@Override
	public HomeResponseData getHome(HomeRequest request) {

		String tokenBks = request.getTokenBks();

		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
		 
		/* Obtener arbol de balances */
		InicioMovilResponse balances = this.getBalancesMovil(tokenBks, request.getMonConsolidacion());

		/* Obtener cantidad de pagos */
		ListaPagosAutorizarRequest lprcRequest = new ListaPagosAutorizarRequest();
		lprcRequest.setNumPagina(1);
		lprcRequest.setNumPorPagina(1);
		lprcRequest.setTokenBks(tokenBks);
		ListaPagosAutorizarResponse lpa = servicioPagos.getListaPagosAutorizarImp(lprcRequest);


		/* Obtener cantidad de lotes */
		ListaLotesRequest llRequest = new ListaLotesRequest();
		llRequest.setNumPagina(1);
		llRequest.setNumPorPagina(1);
		llRequest.setTokenBks(tokenBks);
		ListaLotesAutorizarResponse llar = servicioLotes.getListaLotesAutorizarByPage(llRequest, true);


		/* Obtener cantidad de warehouse */
		ListaWarehouseRequest lwrcRequest = new ListaWarehouseRequest();
		lwrcRequest.setNumPagina(1);
		lwrcRequest.setNumPorPagina(1);
		lwrcRequest.setTokenBks(tokenBks);
		ListaPagosWarehouseResponse lpwr = servicioWarehouse.getListaPagosWarehouseImp(lwrcRequest);
		
		/* Obtener cantidad de lotes warehouse */		
		ListaLotesWarehouseRequest lwrlcRequest = new ListaLotesWarehouseRequest();
		lwrlcRequest.setNumPagina(1);
		lwrlcRequest.setNumPorPagina(1);
		lwrlcRequest.setTokenBks(tokenBks);
		ListaLotesWarehouseResponse lwrlcR = servicioWarehouse.getListaLotesWarehouseImp(lwrlcRequest, true);

		/* Obtener cantidad de ficherosPendientes -- en modo resumen */		
		ListaArchivosARRequest laprcRequest = new ListaArchivosARRequest();
		laprcRequest.setTokenBks(tokenBks);
		ListaArchivosPendientesResponse lap = servicioArchivos.getListaArchivosPendientes(laprcRequest, true); 

		/* Salida */
		HomeResponseData respuesta = new HomeResponseData();
		respuesta.setNombreFormatoCantidad(appContext.getUserData().getFormatoCantidad());
		respuesta.setInicioMovil(balances);
		respuesta.setStatus(STR_OK);
		respuesta.setMessage(STR_MSG_OK);
		respuesta.setCantidadPagos(lpa.getNumTotalPagos());
		respuesta.setCantidadLotes(llar.getTotalLotes());
		respuesta.setCandidadWarehouse(lpwr.getTotalPagos());
		respuesta.setCantidadWarehouseLotes(lwrlcR.getTotalLotes());
		respuesta.setcantidadArchivosR(lap.getNumFichTotales());

		return respuesta;

	}

	
	@Override
	public InicioMovilResponse getBalancesMovil(String token, String monConsolidacion) {

		String peticionJson = "{\"inicioMovil\":{\"entrada\":{";
		if (monConsolidacion != null && monConsolidacion.length()>0)
		{
			peticionJson=peticionJson.concat("\"moneda\":");
			peticionJson=peticionJson.concat("\"" + monConsolidacion + "\"");
		}
		peticionJson=peticionJson.concat("}}}");
		String urlPeticionBalances = urlBks + "/json/F_GBMSGF_FOMovil_E/1?authenticationType=token&requestData="+peticionJson+"&token=" + token;
		URI uriPeticionBalances = UriComponentsBuilder.fromUriString(urlPeticionBalances).build().encode().toUri();

		RestTemplate restTemplatePost = apiRestTemplate.getRestTemplate();

		return restTemplatePost.exchange(uriPeticionBalances, HttpMethod.GET, null, InicioMovilResponse.class).getBody();

	}
}
