package com.isban.scnp.fo.autorizacionpagos.listalotes.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.CompPagosRolHelperService;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.Importe;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ListaImportes;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.ConversionDivisaHelperService;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DatosLote;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DatosPagoLoteDivisa;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DatosPagoLoteDivisaMapper;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteMapper;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteOut;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DivisaImporte;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.ListaLotesHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

import oracle.jdbc.internal.OracleTypes;

@Service
public class ListaLotesHelperServiceImpl implements ListaLotesHelperService {

	private static final String STR_3 = "3";
	private static final String STR_2 = "2";
	private static final String STR_1 = "1";
	private static final String STR_LA = "LA";
	private static final String STR_AP = "AP";
	private static final String STR_AU = "AU";
	private static final String STR_COMA = ",";
	private static final String STR_EUR = "EUR";
	private static final String STR_GBP = "GBP";
	private static final String STR_USD = "USD";
	private static final String STR_KO = "KO";
	private static final String STR_OK = "OK";
	private static final String STR_RESULT = "result";
	private static final String STR_SI = "S";
	private static final String STR_NO = "N";
	private static final String STR_VACIO = "";
	private static final String STR_FECHA_MAX = "9999-12-31";
	private static final String STR_FECHA_MIN = "0001-01-01";
	private static final String STR_FORMATO_FECHA = "yyyy-MM-dd";
	private static final String STR_ERROR_NO_HAY_DATOS = "0000";
	private static final String STR_ERROR_PARAMETROS = "0053";
	private static final String STR_ERROR_NO_FIRMA = "0023";
	private static final String STR_MSG_OK = "OK";
	private static final int MAX_DATOS_QUERY = 1000;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ConversionDivisaHelperService conversionDivisaHelperService;
	
	@Autowired
	private ListaPagosHelperService listaPagosHelperService;
	
	@Autowired
	private CompPagosRolHelperService compPagosRolHelperService;
	
	@Value("${schema_proc}")
    protected String schemaproc;	
	
	public List<DatosPagoLoteDivisa> obtDivisasPagos (List<String> listaPagos)
	{
		List<DatosPagoLoteDivisa> resultado = new ArrayList<>(0);
	
		int tamListaPagos = listaPagos.size();
		if (tamListaPagos>0)
		{
			int numIters = tamListaPagos/MAX_DATOS_QUERY + ((tamListaPagos%MAX_DATOS_QUERY)>0? 1:0);
			
			for (int i = 0;i<numIters;i++)
			{
				StringBuilder sbListaPagos = new StringBuilder();
				
				int tamMin = Math.min(MAX_DATOS_QUERY*(i+1),tamListaPagos);
			
				for (int j=i*MAX_DATOS_QUERY;j<tamMin;j++)
				{
					String concatenar = (j>i*MAX_DATOS_QUERY) ? ", ": STR_VACIO;
					concatenar=concatenar.concat("'").concat(listaPagos.get(j).concat("'"));
					sbListaPagos.append(concatenar);
				}
				String strListaPagos = sbListaPagos.toString();

				String sql = "SELECT N6563_RFTRANS, N6563_CODMONSWI, N6563_NULOTE FROM " + schemaproc + ".SGP_PAGO WHERE N6563_RFTRANS IN ( "+strListaPagos+" )";
				
				Object[] params = new Object[] {};
				
				resultado.addAll(jdbcTemplate.query(sql, params, new DatosPagoLoteDivisaMapper()));
			}
		}
		return resultado;
	}
	
	public DetalleLoteOut getDetalleLote(String numLote) {
		DetalleLoteOut salida = new DetalleLoteOut();
		String sql = "SELECT O2046_NULOTE,O2046_CODPAIS,O2046_CODMONSWI,O2046_ESTPAGO, " + 
				"O2046_FECHALOT,O2046_IMPLOTE2,O2046_DESCRI50, O2046_TOTPAGOS " + 
				"FROM " + schemaproc + ".SGP_LOTE " + 
				"WHERE O2046_NULOTE=?";
		
		Object[] params = new Object[] {numLote};
		List<DetalleLoteOut> listaDetalleLote = jdbcTemplate.query(sql, params, new DetalleLoteMapper());
		
		if(!listaDetalleLote.isEmpty()) { 
			salida =  listaDetalleLote.get(0);
		}
		
		return salida;
	}
	
	public Map<String, Object> getPagosLotesUsuarioAutorizProcedure(String pusuario) {

		List<SqlParameter> prmtrsList = new ArrayList<>();
		
        prmtrsList.add(new SqlParameter(Types.VARCHAR));        //p_usuario
        prmtrsList.add(new SqlParameter(Types.DATE));			//p_fecha_desde
        prmtrsList.add(new SqlParameter(Types.DATE));			//p_fecha_hasta
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_monto_desde
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_monto_hasta
        prmtrsList.add(new SqlParameter(Types.DECIMAL));		//p_monto_desde
        prmtrsList.add(new SqlParameter(Types.DECIMAL));        //p_monto_hasta
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_cod_pais
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_pais
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_ref_cliente
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ref_cliente
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_nom_benef
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_nom_benef
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_cuenta_debito
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_cuenta_debito
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_metodo_pago
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_lista_cod_metodo_pago
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_estado
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_lista_id_estado_pago
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_primera_busq
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_lista_permisos
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_id_lote
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_ind_llamada_est
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_idioma_usuario
        prmtrsList.add(new SqlParameter(Types.VARCHAR));		//p_pais_usuario
        prmtrsList.add(new SqlOutParameter(STR_RESULT, OracleTypes.CURSOR));		//p_cursor
        
        // Calculamos las fechas desde hoy hasta 90 dias
        Calendar cal = Calendar.getInstance();
		java.util.Date hoy = new java.util.Date();
		cal.setTime(hoy);
		cal.add(Calendar.DAY_OF_YEAR, 90);
        
        SimpleDateFormat formatFecha = new SimpleDateFormat(STR_FORMATO_FECHA);	        
        String pFechaDesde = formatFecha.format(hoy.getTime());
        String pFechaHasta = formatFecha.format(cal.getTime());
        Date dFechadesde = java.sql.Date.valueOf(pFechaDesde);  
        Date dFechahasta = java.sql.Date.valueOf(pFechaHasta);
 
        BigDecimal bdMontodesde = new BigDecimal("0.00");
        BigDecimal bdMontohasta = new BigDecimal("0.00");
        
        String pIndmontodesde = STR_NO;
        String pIndmontohasta = STR_NO;

        String pPais = STR_VACIO;
        String pIndCodpais = STR_NO;

        String pRefcliente = STR_VACIO;
        String pIndrefcliente = STR_NO;

        String pNombenef = STR_VACIO;
        String pIndnombenef = STR_NO;
        
        String pCuentadebito = STR_VACIO;
        String pIndCuentadebito = STR_NO;
        
        String pListacodmetodopago=STR_VACIO;
        String pIndmetodopago =  STR_NO;  
        
        String pIndpRimerabusq = (STR_FECHA_MIN.equals(pFechaDesde) && STR_FECHA_MAX.equals(pFechaHasta)) ? STR_SI : STR_NO;
        
        String pListaidestadopago = STR_VACIO;
        List<String> estadosYLlamada = obtIndLlamadaYEstados(pListaidestadopago, pIndpRimerabusq);
        
        String paramListaidestadopago = estadosYLlamada.get(0);

        String pIndestado = STR_SI;
             
        String pListapermisos = "ver,apr";
        String pIdlote = STR_NO;
        String pIndllamadaest =  estadosYLlamada.get(1);
        String pIdiomausuario = " es";
        String pPaisusuario = "ES";
        
        
        return jdbcTemplate.call(new CallableStatementCreator() {
       
        	public CallableStatement createCallableStatement(Connection connection) throws SQLException {
	        int numParam=0;
	        
	        String query = "{call " + schemaproc + ".PKG_OBTPAGOS_AUT.get_pagos_lotes_autoriz (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
	        CallableStatement callableStatement = connection.prepareCall(query);
	        
	        callableStatement.setString(++numParam, pusuario);
	        callableStatement.setDate(++numParam, dFechadesde);
	        callableStatement.setDate(++numParam, dFechahasta);
	        callableStatement.setString(++numParam, pIndmontodesde);
	        callableStatement.setString(++numParam, pIndmontohasta);
	        callableStatement.setBigDecimal(++numParam, bdMontodesde);
	        callableStatement.setBigDecimal(++numParam, bdMontohasta);
	        callableStatement.setString(++numParam, pIndCodpais);
	        callableStatement.setString(++numParam, pPais);
	        callableStatement.setString(++numParam, pIndrefcliente);	        	        
	        callableStatement.setString(++numParam, pRefcliente);
	        callableStatement.setString(++numParam, pIndnombenef);
	        callableStatement.setString(++numParam, pNombenef);
	        callableStatement.setString(++numParam, pIndCuentadebito);
	        callableStatement.setString(++numParam, pCuentadebito);
	        callableStatement.setString(++numParam, pIndmetodopago);
	        callableStatement.setString(++numParam, pListacodmetodopago);
	        callableStatement.setString(++numParam, pIndestado);
	        callableStatement.setString(++numParam, paramListaidestadopago);
	        callableStatement.setString(++numParam, pIndpRimerabusq);
	        callableStatement.setString(++numParam, pListapermisos);
	        callableStatement.setString(++numParam, pIdlote);
	        callableStatement.setString(++numParam, pIndllamadaest);
	        callableStatement.setString(++numParam, pIdiomausuario);
	        callableStatement.setString(++numParam, pPaisusuario);
	        callableStatement.registerOutParameter(++numParam,  OracleTypes.CURSOR);
	        
	        return callableStatement;

	        }
	    }, prmtrsList);
	}
	
	public DetalleLoteResponse getDetalleLoteImp(DetalleLoteRequest detalleLoteRequest)
	{
		DetalleLoteResponse salida = new DetalleLoteResponse();
		DetalleLoteOut detalle = getDetalleLote(detalleLoteRequest.getNumLote());
		
		salida.setDivisa(detalle.getDivisa());
		salida.setEstadoLote(detalle.getEstadoLote());
		salida.setFecha(detalle.getFecha());
		salida.setMonto(detalle.getMonto());
		salida.setNombreLote(detalle.getNombreLote());
		salida.setNumLote(detalle.getNumLote());
		salida.setNumPagos(detalle.getNumPagos());
		salida.setPais(detalle.getPais());

		ListaPagosAutorizarRequest listaPagosAutorizarRequest = new ListaPagosAutorizarRequest();
		listaPagosAutorizarRequest.setIdLote(detalleLoteRequest.getNumLote());
		listaPagosAutorizarRequest.setPais(detalle.getPais());
		listaPagosAutorizarRequest.setNumPagina(1);
		listaPagosAutorizarRequest.setNumPorPagina(99999);
		listaPagosAutorizarRequest.setTokenBks(detalleLoteRequest.getTokenBks());
		ListaPagosAutorizarResponse pagos = listaPagosHelperService.getListaPagosAutorizarImp(listaPagosAutorizarRequest);
		
		Map<String, DivisaImporte> mapDivisaImporte = new HashMap<>();
		int tamListaPagos = pagos.getListaDatosPagosAutorizar().size();
		
		for (int i = 0; i < tamListaPagos; i++) {
			String divisa = pagos.getListaDatosPagosAutorizar().get(i).getDivisa();
			BigDecimal importe = pagos.getListaDatosPagosAutorizar().get(i).getImporte();
			
			if(mapDivisaImporte.containsKey(divisa)){
				BigDecimal importeAnt = mapDivisaImporte.get(divisa).getImporte();
				BigDecimal nuevoImporte = importeAnt.add(importe);
				int numPagosAnt = mapDivisaImporte.get(divisa).getNumPagos();
				int numPagosNuevo = numPagosAnt + 1;	
				DivisaImporte divisaImporte = new DivisaImporte();
				divisaImporte.setDivisa(divisa);
				divisaImporte.setImporte(nuevoImporte);
				divisaImporte.setNumPagos(numPagosNuevo);
				mapDivisaImporte.put(divisa, divisaImporte);
			}else {
				DivisaImporte divisaImporte = new DivisaImporte();
				divisaImporte.setDivisa(divisa);
				divisaImporte.setImporte(importe);
				divisaImporte.setNumPagos(1);
				mapDivisaImporte.put(divisa, divisaImporte);
			}	
		}
		
		List<DivisaImporte> listaAgrup = new ArrayList<>();
		for(Map.Entry<String, DivisaImporte> entry : mapDivisaImporte.entrySet()) {
			DivisaImporte divisaImporte = entry.getValue();
			listaAgrup.add(divisaImporte);
		}
		
		salida.setListaPagos(listaAgrup);
		salida.setStatus(STR_OK);
		salida.setMessage(STR_MSG_OK);
		return salida;
	}
	
	private String convertArray2String (List<?> lista)
	{
		int tamLista= lista.size();
		StringBuilder sb = new StringBuilder();
		for (int i=0;i<tamLista;i++)
		{
			Object elem = lista.get(i);

			if (i>0)
			{
				sb=sb.append(" , ");
			}
			if (elem instanceof String)
			{
				sb=sb.append("'").append(elem).append("'");
			}
			else
			{
				sb=sb.append(elem);
			}
		}
		return sb.toString();
	}
	
	private void obtPagosLotesAutorizar(
			Map<String, String> mapIdPago_IdLote, Map<String, DatosLote> mapIdLote_datosLote,
			Map<String, Object> datosLotes, List<String> listaPagosLib,
			List<String> listaPagosSinLib) {
		List<Map<String, Object>> listaObjetos = (List<Map<String, Object>>)datosLotes.get(STR_RESULT);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		int tamListaObjetos = listaObjetos.size();
		for (int i = 0; i < tamListaObjetos; i++) {
			Map<String, Object> mapDatosFinal = listaObjetos.get(i);
			
			String idPago = mapDatosFinal.get("N6563_RFTRANS").toString();
			String indLib = mapDatosFinal.get("INDLIB").toString();
			
			String idLote = mapDatosFinal.get("O2046_NULOTE").toString();
			String estadoLote = mapDatosFinal.get("O2046_ESTPAGO").toString();
			String nomLote = mapDatosFinal.get("O2046_DESCRI50").toString();
			String pais = mapDatosFinal.get("O2046_CODPAIS").toString();
			String divisa = mapDatosFinal.get("O2046_CODMONSWI").toString();
			BigDecimal monto = new BigDecimal(mapDatosFinal.get("O2046_IMPLOTE2").toString());
			monto = monto.setScale(2, RoundingMode.HALF_UP);
			String indSalario = mapDatosFinal.get("O2046_IND_NOM").toString();
			String fecVal = mapDatosFinal.get("O2046_FECHALOT").toString();
			java.util.Date fechaDB;
			
			try {
				fechaDB = dateFormat.parse(fecVal);
			} catch (ParseException e) {
				fechaDB = null;
			}

			int totalPagos = Integer.parseInt(mapDatosFinal.get("O2046_TOTPAGOS").toString());
			String indBulk = mapDatosFinal.get("O2046_BATCH_B").toString();
			String indImportado = mapDatosFinal.get("INDIMP_LOTE").toString();
			String indUpload = mapDatosFinal.get("INDUPL_LOTE").toString();
			String indNotas = mapDatosFinal.get("INDNOTA_LOTE").toString();
			String indCbs = mapDatosFinal.get("INDCBS_LOTE").toString();
			String descEstLote = mapDatosFinal.get("ESTADO_TRAD").toString();
			
			DatosLote datosLote = new DatosLote ();
			
			datosLote.setIdLote(idLote);
			datosLote.setCodEstLote(estadoLote);
			datosLote.setDescEstLote(descEstLote);
			datosLote.setNomLote(nomLote);
			datosLote.setCodPais(pais);
			datosLote.setImpLote(monto);
			datosLote.setDivisaLote(divisa);
			datosLote.setFechaLote(fechaDB);
			datosLote.setTotalPagos(totalPagos);
			datosLote.setIndImportado(indImportado);
			datosLote.setIndNotas(indNotas);
			datosLote.setIndicadorUpload(indUpload);
			datosLote.setIndSalario(indSalario);
			datosLote.setIndicadorCbs(indCbs);
			datosLote.setIndBulk(indBulk);
			
			if (STR_SI.equals(indLib))
			{
				listaPagosLib.add(idPago);
			}
			else
			{
				listaPagosSinLib.add(idPago);
			}
			
			mapIdPago_IdLote.put(idPago, idLote);
			mapIdLote_datosLote.put(idLote, datosLote);
		}
	}
	
	public List prepararPagina(int numPagina, int numPorPagina,
			List listaCompleta) {
		
		List salida = new ArrayList<>(0);

		int tamListaCompleta = listaCompleta.size();
		if (tamListaCompleta>(numPagina*numPorPagina))
		{
			int ini = numPagina*numPorPagina;
			int fin = ini+numPorPagina;
			if (fin>listaCompleta.size())
			{
				fin = listaCompleta.size();
			}
			for (int i=ini;i<fin;i++)
			{				
				salida.add((Object)listaCompleta.get(i));
			}
		}
		return salida;
	}
	
	private List<String> obtIndLlamadaYEstados (String paramIdEstados, String indPrimeraBusqueda)
	{
		Set<String> hsEstados = new HashSet<String> (0);

		StringBuilder sbEstados = new StringBuilder();
		String indLlamada = STR_VACIO;

		boolean todos = false;
		boolean tieneAU = false;
		boolean tieneAP = false; 
		boolean tieneLA = false;

		List<String> retorno = new ArrayList<String>(0);

		StringTokenizer stEstados = new StringTokenizer (paramIdEstados, STR_COMA);

		while (stEstados.hasMoreTokens())
		{
			String estado = stEstados.nextToken().trim();
			if (!estado.equals(STR_VACIO))
			{
				hsEstados.add(estado);
			}
		}

		if (hsEstados.contains(STR_AU))
		{
			tieneAU=true;
		}
		else if (hsEstados.contains(STR_AP))
		{
			tieneAP=true;
		}
		else if (hsEstados.contains(STR_LA))
		{
			tieneLA=true;
		}

		if (hsEstados.isEmpty()&& STR_NO.equals(indPrimeraBusqueda))
		{
			hsEstados.add(STR_AP);
			hsEstados.add(STR_LA);
			todos = true;
		}

		if (todos)
		{
			hsEstados.remove(STR_AU);
			indLlamada = STR_3;
		}
		else if (tieneAU)
		{
			indLlamada = (tieneLA || tieneAP) ? STR_3 : STR_1;
		}
		else if (tieneLA || tieneAP)
		{
			indLlamada = STR_2;
		}

		Iterator<String> itEstados =  hsEstados.iterator();
		while (itEstados.hasNext())
		{
			if (sbEstados.length()>0)
			{
				sbEstados=sbEstados.append(STR_COMA);
			}
			sbEstados=sbEstados.append(itEstados.next());
		}

		retorno.add(sbEstados.toString());
		retorno.add(indLlamada);

		return retorno;
	}
	
	public List<String> obtenerListaDivisas (String monConsolidacion, List<String> listaPagosObtenidos, Map<String, String> mapaPagoLote, List<DatosLote> listaSalida)
	{
		Map<String, String> mapaPagoDivisa = new HashMap <String, String>(0);
		Set<String> hsLotesSalida = new HashSet<String> (0);		
		for (DatosLote datosLote:listaSalida)
		{
			hsLotesSalida.add (datosLote.getIdLote());
		}
		
		List<DatosPagoLoteDivisa> listaDatosPagoDivisa = obtDivisasPagos (listaPagosObtenidos);	
		
		for (DatosPagoLoteDivisa datosPagoDivisa : listaDatosPagoDivisa)
		{
			String idPago = datosPagoDivisa.getIdPago();
			String divisa = datosPagoDivisa.getDivisaPago();
			mapaPagoDivisa.put(idPago, divisa);
		}
		
		Set<String> hsDivisas = new HashSet<String>(0);
		List<String> retorno = new ArrayList<String>(0);
		for (String idPago : listaPagosObtenidos)
		{
			String idLote = mapaPagoLote.get(idPago);
			String divisa = mapaPagoDivisa.get(idPago);
			if (hsLotesSalida.contains(idLote) && !hsDivisas.contains(divisa))
			{				
				hsDivisas.add(divisa);
			}
		}

		if (!STR_VACIO.equals(monConsolidacion))
		{
			hsDivisas.add(monConsolidacion);
		}
		if (!hsDivisas.isEmpty())
		{
			hsDivisas.add(STR_EUR);
			hsDivisas.add(STR_USD);
			hsDivisas.add(STR_GBP);
			
			retorno.add(STR_EUR);
			retorno.add(STR_USD);
			retorno.add(STR_GBP);
			
			Iterator<String> itDivisas = hsDivisas.iterator();
			while (itDivisas.hasNext())
			{
				String divisa = itDivisas.next();
				if (!retorno.contains(divisa))
				{
					retorno.add(divisa);
					hsDivisas.add(divisa);
				}
			}
		}
		return retorno;
	}
	
	public ListaLotesAutorizarResponse getListaLotesAutorizar(String uidLogado, String monConsolidacion, String tokenBKS, Map<String, String> mapIdPago_IdLote, List<String> listaPagosObtenidos) {
		
		List<DatosLote> salida = new ArrayList<DatosLote> (0);
		
		//Mapas con datos temporales
		Map<String, DatosLote> mapaIdLoteDatos = new HashMap<String, DatosLote>(0);
		Set<String> hsLotesSalida= new HashSet<String>(0);
		
		// Comprobamos si el usuario tiene firma
		String uidToken = listaPagosHelperService.comprobarTokenSKeyUsu(uidLogado);
		
		if(uidToken != null) {
			// Invocamos al procedimiento que obtiene los pagos para autorizar
			Map<String, Object> datosLotes = getPagosLotesUsuarioAutorizProcedure(uidLogado);
			
			// Rellenamos una lista con los id's de los pagos a autorizar
			List<String> listaPagosLib = new ArrayList<String>();
			List<String> listaPagosSinLib = new ArrayList<String>();
			
			if(datosLotes.containsKey(STR_RESULT)) {
				
				
				obtPagosLotesAutorizar(mapIdPago_IdLote, mapaIdLoteDatos,
							datosLotes, listaPagosLib, listaPagosSinLib);

				
				// Comprobamos si alguno de los pagos, ya ha sido firmado por el usuario					
				List<String> pagosYaFirmados = new ArrayList<String>(0);
				if (!listaPagosLib.isEmpty())
				{
					pagosYaFirmados = listaPagosHelperService.obtPagosFirmaOKUsuario(uidLogado, listaPagosLib);
				}
				
				// Consultamos los pagos cuyo rol cumple con la sentencia del rol del usuario logado
				List<CompPagosRolUsuPendFirmaOut> pagosConRolOk = new ArrayList<CompPagosRolUsuPendFirmaOut>(0);
				if (!listaPagosSinLib.isEmpty())
				{
					CompPagosRolUsuPendFirmaIn compPagosRolUsuPendFirmaIn = new CompPagosRolUsuPendFirmaIn();
					compPagosRolUsuPendFirmaIn.setListaIdPago(listaPagosSinLib);
					compPagosRolUsuPendFirmaIn.setPagosVerActivos(STR_SI);
					compPagosRolUsuPendFirmaIn.setTokenBks(tokenBKS);
					pagosConRolOk = compPagosRolHelperService.compPagosRolUsuPendFirma(compPagosRolUsuPendFirmaIn);
				}
				//evaluamos los pagos ya firmados por el usuario para eliminarlos
				
				int tamPagosConRolOK = pagosConRolOk.size();
				for (int i=0;i<tamPagosConRolOK;)
				{
					String idPago = pagosConRolOk.get(i).getRftrans();
					if (pagosYaFirmados.contains(idPago))
					{
						pagosConRolOk.remove(i);
						tamPagosConRolOK=pagosConRolOk.size();
					}
					else
					{
						i++;
					}
				}					
				//comprobamos los lotes que debemos retornar
				for (int i=0;i<tamPagosConRolOK;i++)
				{
					String idPago = pagosConRolOk.get(i).getRftrans();
					if (mapIdPago_IdLote.containsKey(idPago))
					{
						String idLotePago = mapIdPago_IdLote.get(idPago);
						listaPagosObtenidos.add(idPago);
						if (!hsLotesSalida.contains(idLotePago))
						{
							DatosLote datosLotePago = mapaIdLoteDatos.get(idLotePago);
						
							salida.add(datosLotePago);
							hsLotesSalida.add(idLotePago);
						}
					}
					
				}
			}
			
			closeConnection();
			
			ListaLotesAutorizarResponse listaLotesAutorizarResponse = new ListaLotesAutorizarResponse();
			listaLotesAutorizarResponse.setListaDatosLote(salida);
			listaLotesAutorizarResponse.setStatus(STR_OK);
			listaLotesAutorizarResponse.setMessage(STR_MSG_OK);
			return listaLotesAutorizarResponse;
		}
		else
		{
			closeConnection();
			ListaLotesAutorizarResponse listaLotesAutorizarResponse = new ListaLotesAutorizarResponse();
			listaLotesAutorizarResponse.setStatus(STR_KO);
			listaLotesAutorizarResponse.setMessage(STR_ERROR_NO_FIRMA);
			return listaLotesAutorizarResponse;
		}
	}
	
	private void closeConnection() {
		try {
			if (jdbcTemplate!=null)
			{
				jdbcTemplate.getDataSource().getConnection().close();
			}
		} catch (SQLException e) {			
		}
		
	}

	public List<DatosLote> obtenerDivisasConvertidas (List<DatosLote> listaLotes, String monConsolidacion, String tokenBKS)
	{
		List<ListaImportes> listaGruposImportes = new ArrayList<ListaImportes>(0);
		int tamLotes = listaLotes.size();
		for (int i=0;i<tamLotes;i++)
		{
			ListaImportes listaImportes  = new ListaImportes();
			String divisaInicial = listaLotes.get(i).getDivisaLote();
			BigDecimal importeInicial = listaLotes.get(i).getImpLote();
			
			ImporteType importeAnadir = new ImporteType(importeInicial, divisaInicial);		
			Importe imp = new Importe(importeAnadir);
			listaImportes.addImporte(imp);
				
			listaGruposImportes.add(listaImportes);
		}		
		
		
		ConversionDivisaRequest conversionDivisaRequest = new ConversionDivisaRequest();
		conversionDivisaRequest.getRequestData().getConversionDivisa().getEntrada().setDivisaConsolidacion(monConsolidacion);
		conversionDivisaRequest.getRequestData().getConversionDivisa().getEntrada().setListaGruposImportes(listaGruposImportes);
		conversionDivisaRequest.setToken(tokenBKS);
		
		ConversionDivisaResponse conversionDivisaResponse = conversionDivisaHelperService.conversionDivisa(conversionDivisaRequest);
		
		if (conversionDivisaResponse.getMethodResult().getListaImportes().size()==listaLotes.size())
		{
			for (int i=0;i<tamLotes;i++)
			{
				
				listaLotes.get(i).setImpLote(conversionDivisaResponse.getMethodResult().getListaImportes().get(i).getIMPORTE());
				listaLotes.get(i).setDivisaLote(conversionDivisaResponse.getMethodResult().getListaImportes().get(i).getDIVISA());
			}
		}

		return listaLotes;				
	}
	
	public ListaLotesAutorizarResponse getListaLotesAutorizarByPage(ListaLotesRequest listaLotesRequest, boolean resumen ) {	

		// Obtenemos el usuario logado
		String uidLogado = STR_VACIO;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 if (Objects.nonNull(SecurityContextHolder.getContext()) &&
				 auth instanceof JwtAuthenticationToken &&
	               Objects.nonNull(auth.getDetails())) {
		
			JwtDetails santanderUD = (JwtDetails) auth.getDetails();
			uidLogado = santanderUD.getUid();
		 }
		
		int page=listaLotesRequest.getNumPagina();
		int size=listaLotesRequest.getNumPorPagina();
		String monConsolidacion	= listaLotesRequest.getMonedaConsolidacion();
		if (monConsolidacion==null)
		{
			monConsolidacion=STR_VACIO;
		}
		String tokenBks = listaLotesRequest.getTokenBks();
		
		Map<String, String> mapaIdPagoLote = new HashMap<String, String>(0);
		List<String> listaPagosObtenidos = new ArrayList<String>(0);
		
		ListaLotesAutorizarResponse respuestaCompleta = getListaLotesAutorizar(uidLogado, monConsolidacion, tokenBks, mapaIdPagoLote, listaPagosObtenidos);

		if (respuestaCompleta.getStatus()!=null && !respuestaCompleta.getStatus().equals(STR_KO))
		{
			List<DatosLote> listaCompleta = respuestaCompleta.getListaDatosLote();
			int tamListaCompleta = listaCompleta.size();
			
			if (!listaCompleta.isEmpty())
			{
				Collections.sort(listaCompleta);
				
				List<DatosLote> listaSalida = null;
				List <String> listaDivisas = null;
				if (!resumen)
				{
					listaSalida= prepararPagina (page-1, size, listaCompleta);					
					listaSalida = obtenerDivisasConvertidas(listaSalida, monConsolidacion, tokenBks);
					if (STR_VACIO.equals(monConsolidacion) && !listaSalida.isEmpty())
					{
						monConsolidacion=listaSalida.get(0).getDivisaLote();
					}
					listaDivisas = obtenerListaDivisas(monConsolidacion, listaPagosObtenidos, mapaIdPagoLote, listaCompleta);
				}
				
				ListaLotesAutorizarResponse listaLotesAutorizarResponse = new ListaLotesAutorizarResponse();
				listaLotesAutorizarResponse.setListaDatosLote(listaSalida);
				listaLotesAutorizarResponse.setListaDivisas(listaDivisas);
				listaLotesAutorizarResponse.setTotalLotes(tamListaCompleta);
				listaLotesAutorizarResponse.setPagina(page);
				
				if (listaSalida!=null && listaSalida.isEmpty())
				{
					listaLotesAutorizarResponse.setStatus(STR_KO);
					listaLotesAutorizarResponse.setMessage(STR_ERROR_PARAMETROS);
				}
				else
				{
					listaLotesAutorizarResponse.setStatus(STR_OK);
					listaLotesAutorizarResponse.setMessage(STR_MSG_OK);
				}
				
				return listaLotesAutorizarResponse;
			}
			else 
			{
				ListaLotesAutorizarResponse listaLotesAutorizarResponse = new ListaLotesAutorizarResponse();
				List <String> listaDivisas = obtenerListaDivisas(monConsolidacion, listaPagosObtenidos, mapaIdPagoLote, listaCompleta);
				listaLotesAutorizarResponse.setListaDivisas(listaDivisas);
				listaLotesAutorizarResponse.setStatus(STR_KO);
				listaLotesAutorizarResponse.setMessage(STR_ERROR_NO_HAY_DATOS);
				return listaLotesAutorizarResponse;
			}
		}
		else
		{
			return respuestaCompleta;
		}
	}
}
