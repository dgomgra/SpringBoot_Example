package com.isban.scnp.fo.autorizacionpagos.rehacer.model;

public class idPago {

	private String idPago;

	public idPago(String idPago) {
		this.setIdPago(idPago);
	}

	public String getIdPago() {
		return idPago;
	}

	public void setIdPago(String idPago) {
		this.idPago = idPago;
	}
}
