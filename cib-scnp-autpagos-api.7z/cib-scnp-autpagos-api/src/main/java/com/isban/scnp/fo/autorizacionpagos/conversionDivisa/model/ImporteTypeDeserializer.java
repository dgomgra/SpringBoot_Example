package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model;

import java.io.IOException;
import java.math.BigDecimal;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.DoubleNode;
import com.fasterxml.jackson.databind.node.TextNode;

public class ImporteTypeDeserializer extends StdDeserializer<ImporteType> {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ImporteTypeDeserializer() { 
        this(null); 
    } 
 
    public ImporteTypeDeserializer(Class<?> vc) { 
        super(vc); 
    }

	@Override
	public ImporteType deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		
		JsonNode node = p.getCodec().readTree(p);
		JsonNode imp = node.path("importe");
			
		double dblImporte = ((DoubleNode) imp.get("IMPORTE")).doubleValue();
		BigDecimal bdImporte = BigDecimal.valueOf(dblImporte);
		bdImporte=bdImporte.setScale(2, BigDecimal.ROUND_HALF_UP);
		
		String divisa = ((TextNode) imp.get("DIVISA")).textValue();
		
		return new ImporteType(bdImporte, divisa);
	}
}
