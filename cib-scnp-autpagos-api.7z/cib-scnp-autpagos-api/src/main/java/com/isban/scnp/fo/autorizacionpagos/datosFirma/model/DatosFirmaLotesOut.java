package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import java.math.BigDecimal;

public class DatosFirmaLotesOut {

	private int numPagos;
	private BigDecimal importe;
	
	public int getNumPagos() {
		return numPagos;
	}
	public void setNumPagos(int numPagos) {
		this.numPagos = numPagos;
	}
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	
}
