package com.isban.scnp.fo.autorizacionpagos.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.santander.serenity.devstack.util.Constants;

/**
 * Clase principal de donde implementamos las excepciones de seguridad
 *
 */
@Configuration
@EnableWebSecurity
@EnableConfigurationProperties
@ConfigurationProperties("config")
@Order(Constants.DEVSTACK_SECURITY_ORDER -1)
public class ExcludeSecurityConfiguration extends WebSecurityConfigurerAdapter{

	/**
	 * Lista de strings con las direcciones que permitirán el acceso
	 * Si no existe la ruta, no dara error
	 */
	@Value("${config.ignored:}")
	private String[] ignored = new String[0];
	
	@Override
	public void configure(WebSecurity web) throws Exception {
		super.configure(web);
		web.ignoring().antMatchers(ignored);
	}
	
	@Override
    public void configure(HttpSecurity http) throws Exception {
        http.antMatcher("/v2/api-docs").authorizeRequests().anyRequest().permitAll();
    }
}