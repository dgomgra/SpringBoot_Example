package com.isban.scnp.fo.autorizacionpagos.common.model;

public class DatosUsuario {

	private String formatoCantidad;
	private String formatoFecha;
	private String idioma;
	private String codPais;
	private String tipoCripto;
	
	public DatosUsuario(String formatoCantidad, String formatoFecha, String idioma, String codPais, String tipoCripto) {
		this.formatoCantidad = formatoCantidad;
		this.formatoFecha = formatoFecha;
		this.idioma = idioma;
		this.codPais = codPais;
		this.tipoCripto = tipoCripto;
	}
	public String getFormatoCantidad() {
		return formatoCantidad;
	}
	public void setFormatoCantidad(String formatoCantidad) {
		this.formatoCantidad = formatoCantidad;
	}
	public String getFormatoFecha() {
		return formatoFecha;
	}
	public void setFormatoFecha(String formatoFecha) {
		this.formatoFecha = formatoFecha;
	}
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public String getCodPais() {
		return codPais;
	}
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	public String getTipoCripto() {
		return tipoCripto;
	}
	public void setTipoCripto(String tipoCripto) {
		this.tipoCripto = tipoCripto;
	}
	
}
