package com.isban.scnp.fo.autorizacionpagos.comppagosrol.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ObtPagosSentRolMapper implements RowMapper<ObtPagosSentRolOut> {

	private static final String STR_N2919_CODIGROL = "N2919_CODIGROL";
	private static final String STR_N2919_ANORDEN = "N2919_ANORDEN";
	private static final String STR_N2921_TAMENT = "N2921_TAMENT";
	private static final String STR_N2921_ATIPAGRU = "N2921_ATIPAGRU";
	private static final String STR_N2919_ANUMFIRM = "N2919_ANUMFIRM";
	private static final String STR_N2921_ANORDEN = "N2921_ANORDEN";
	private static final String STR_N6567_IDAUTH = "N6567_IDAUTH";
	private static final String STR_N6567_CPOLSENTE = "N6567_CPOLSENTE";
	private static final String STR_N6567_IDCOMP = "N6567_IDCOMP";
	private static final String STR_N6567_RFTRANS = "N6567_RFTRANS";

	@Override
	public ObtPagosSentRolOut mapRow(ResultSet rs, int row) throws SQLException {

		ObtPagosSentRolOut obtPagosSentRolOut = new ObtPagosSentRolOut();
		obtPagosSentRolOut.setRftrans(rs.getString(STR_N6567_RFTRANS));
		obtPagosSentRolOut.setIdComp(rs.getString(STR_N6567_IDCOMP));
		obtPagosSentRolOut.setCodSentencia(rs.getInt(STR_N6567_CPOLSENTE));
		obtPagosSentRolOut.setIdAutorizacion(rs.getInt(STR_N6567_IDAUTH));
		obtPagosSentRolOut.setAnorden(rs.getInt(STR_N2921_ANORDEN));
		obtPagosSentRolOut.setAnumfirm(rs.getInt(STR_N2919_ANUMFIRM));
		obtPagosSentRolOut.setAtipagru(rs.getString(STR_N2921_ATIPAGRU));
		obtPagosSentRolOut.setTament(rs.getInt(STR_N2921_TAMENT));
		obtPagosSentRolOut.setAnordengrp(rs.getInt(STR_N2919_ANORDEN));
		obtPagosSentRolOut.setRol(rs.getInt(STR_N2919_CODIGROL));
		
		return obtPagosSentRolOut;
	}

}