package com.isban.scnp.fo.autorizacionpagos.rehacer.model;

import java.util.ArrayList;
import java.util.List;

import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdLoteNombreK;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.Nota;

public class RehacerRequestBks {
	
	private List<idPago> listaIdPago;
	private List<IdLoteNombreK> listaIdLoteNombre;
	private Nota nota;
	
	public RehacerRequestBks () {
		this.setListaIdPago(new ArrayList<>());
		this.setListaIdLoteNombre(new ArrayList<>());
		this.setNota(new Nota());
	}

	public Nota getNota() {
		return nota;
	}
	public void setNota(Nota nota) {
		this.nota = nota;
	}
	public List<idPago> getListaIdPago() {
		return listaIdPago;
	}
	public void setListaIdPago(List<idPago> listaIdPago) {
		this.listaIdPago = listaIdPago;
	}

	public List<IdLoteNombreK> getListaIdLoteNombre() {
		return listaIdLoteNombre;
	}

	public void setListaIdLoteNombre(List<IdLoteNombreK> listaIdLoteNombre) {
		this.listaIdLoteNombre = listaIdLoteNombre;
	}
	
}
