package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.isban.scnp.fo.autorizacionpagos.common.model.MessageSerializer;

public class DatosFirmaResponse {
	
	private String status;
	private String message;
	private int numPagos;
	private String ultimosDigitosCuentaBen;
	private String importe;
	private String tipoCripto;
	
	public int getNumPagos() {
		return numPagos;
	}
	public void setNumPagos(int numPagos) {
		this.numPagos = numPagos;
	}
	public String getImporte() {
		return importe;
	}
	public void setImporte(String importe) {
		this.importe = importe;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@JsonSerialize(using = MessageSerializer.class)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTipoCripto() {
		return tipoCripto;
	}
	public void setTipoCripto(String tipoCripto) {
		this.tipoCripto = tipoCripto;
	}
	public String getUltimosDigitosCuentaBen() {
		return ultimosDigitosCuentaBen;
	}
	public void setUltimosDigitosCuentaBen(String ultimosDigitosCuentaBen) {
		this.ultimosDigitosCuentaBen = ultimosDigitosCuentaBen;
	}
	
}
