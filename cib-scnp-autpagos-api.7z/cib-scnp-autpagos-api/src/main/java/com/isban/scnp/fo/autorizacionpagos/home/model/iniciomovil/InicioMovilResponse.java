
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

public class InicioMovilResponse {

    private MethodResult methodResult;
   
    public MethodResult getMethodResult() {
        return methodResult;
    }

    public void setMethodResult(MethodResult methodResult) {
        this.methodResult = methodResult;
    }

}
