package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

import java.util.ArrayList;
import java.util.List;

public class AutorizarRA_E {
	private static final String STR_VACIO = "";
	private String indAutorizar;
	private DatosFirma datosFirma;
	private List<IdArchivo> listaIdArchivo;
	private Nota nota;
	
	
	public AutorizarRA_E() {
		super();
		indAutorizar = STR_VACIO;
		this.setDatosFirma(new DatosFirma());
		this.setListaIdArchivo(new ArrayList<>());
		this.setNota(new Nota());
	}
	public String getIndAutorizar() {
		return indAutorizar;
	}

	public void setIndAutorizar(String indAutorizar) {
		this.indAutorizar = indAutorizar;
	}

	public DatosFirma getDatosFirma() {
		return datosFirma;
	}
	public void setDatosFirma(DatosFirma datosFirma) {
		this.datosFirma = datosFirma;
	}	
	public List<IdArchivo> getListaIdArchivo() {
		return listaIdArchivo;
	}
	public void setListaIdArchivo(List<IdArchivo> listaIdArchivo) {
		this.listaIdArchivo = listaIdArchivo;
	}
	public void setListaIdArchivoStr(List<String> listaIdArchivo) {
		List<IdArchivo> listaArchivos = new ArrayList<>(0);
		
		for (String idArchivo : listaIdArchivo)
		{
			listaArchivos.add(new IdArchivo(Integer.valueOf(idArchivo)));
		}		
		this.listaIdArchivo = listaArchivos;
	}
	public Nota getNota() {
		return nota;
	}
	public void setNota(Nota nota) {
		this.nota = nota;
	}	
}
