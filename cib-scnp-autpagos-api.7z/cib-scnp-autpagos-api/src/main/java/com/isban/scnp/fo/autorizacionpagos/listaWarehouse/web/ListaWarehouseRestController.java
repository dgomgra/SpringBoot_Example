package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="authorization")
@Tag(name = "AutorizacionLotesRestController", description = "Operations pertaining to Batches Authorization")
public class ListaWarehouseRestController {
	
	private static final String STR_ERROR = "error";
	private static final String STR_DOS_PUNTOS_Y_ESPACIO = ": ";
	private static final String STR_ESPACIO = " ";
	private static final String STR_LISTA_WAREHOUSE = "Lista de pagos Warehouse";
	private static final String STR_LISTALOTES_WAREHOUSE = "Lista de lotes Warehouse";
	private static final String STR_KO = "KO";
	private static final String STR_COD_ERROR_CREDENTIAL = "50201021";
	private static final String STR_ERROR_CREDENCIAL = "0051";
	private static final String STR_ERROR_GENERAL = "0001";
	
	@Autowired
	private ListaWarehouseHelperService listaWarehouseHelperService;
	
	@RequestMapping(value = "/v1/listadoWarehouseAutorizar", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get list of Warehouse payments")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	
	public ResponseEntity<ListaPagosWarehouseResponse> getListaPagosWarehouse(@RequestBody ListaWarehouseRequest listaWarehouseRequest){		
		try {

			log.debug("REST POST call received in /v1/listadoWarehouseAutorizar {} {}",
					listaWarehouseRequest.getNumPorPagina(),
					listaWarehouseRequest.getNumPagina());

			ListaPagosWarehouseResponse listaPagosWarehouseResponse = listaWarehouseHelperService.getListaPagosWarehouseImp(listaWarehouseRequest);
			return new ResponseEntity<>(listaPagosWarehouseResponse, HttpStatus.OK);
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_WAREHOUSE + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			ListaPagosWarehouseResponse listaPagosWarehouseResponse = new ListaPagosWarehouseResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				listaPagosWarehouseResponse.setStatus(STR_KO);
				listaPagosWarehouseResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(listaPagosWarehouseResponse, HttpStatus.UNAUTHORIZED);
			}else {
				listaPagosWarehouseResponse.setStatus(STR_KO);
				listaPagosWarehouseResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(listaPagosWarehouseResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}			
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTA_WAREHOUSE + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			ListaPagosWarehouseResponse listaPagosWarehouseResponse = new ListaPagosWarehouseResponse();
			listaPagosWarehouseResponse.setStatus(STR_KO);
			listaPagosWarehouseResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(listaPagosWarehouseResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}						 
	}
	
	@RequestMapping(value = "/v1/listaDatosLotesWarehousing", method = RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(description = "Get list of Warehouse batches")
	@ApiResponses(value = { 
			@ApiResponse(responseCode = "200", description = "Success"),
			@ApiResponse(responseCode = "400", description = "Bad Request"), 
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"), 
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "503", description = "Service Unavailable") })
	public ResponseEntity<ListaLotesWarehouseResponse> getListaLotesWarehouse(@RequestBody ListaLotesWarehouseRequest listaLotesWarehouseRequest){		
		try {

			log.debug("REST POST call received in /v1/listaDatosLotesWarehousing {} {} {}",
					listaLotesWarehouseRequest.getNumPorPagina(),
					listaLotesWarehouseRequest.getNumPagina(),
					listaLotesWarehouseRequest.getMonedaConsolidacion());

			ListaLotesWarehouseResponse listaLotesWarehouseResponse = listaWarehouseHelperService.getListaLotesWarehouseImp(listaLotesWarehouseRequest, false);
			return new ResponseEntity<>(listaLotesWarehouseResponse, HttpStatus.OK);
		} catch (HttpServerErrorException  e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTALOTES_WAREHOUSE + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			
			String responseBody = e.getResponseBodyAsString();
			ListaLotesWarehouseResponse listaLotesWarehouseResponse = new ListaLotesWarehouseResponse();
			
			if(responseBody.indexOf(STR_COD_ERROR_CREDENTIAL) > -1) {				
				listaLotesWarehouseResponse.setStatus(STR_KO);
				listaLotesWarehouseResponse.setMessage(STR_ERROR_CREDENCIAL);
				return new ResponseEntity<>(listaLotesWarehouseResponse, HttpStatus.UNAUTHORIZED);
			}else {
				listaLotesWarehouseResponse.setStatus(STR_KO);
				listaLotesWarehouseResponse.setMessage(STR_ERROR_GENERAL);
				return new ResponseEntity<>(listaLotesWarehouseResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}			
		} catch (Exception e) {
			log.error(STR_ERROR + STR_ESPACIO + STR_LISTALOTES_WAREHOUSE + STR_DOS_PUNTOS_Y_ESPACIO + e, e);
			ListaLotesWarehouseResponse listaLotesWarehouseResponse = new ListaLotesWarehouseResponse();
			listaLotesWarehouseResponse.setStatus(STR_KO);
			listaLotesWarehouseResponse.setMessage(STR_ERROR_GENERAL);
			return new ResponseEntity<>(listaLotesWarehouseResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}						 
	}
}
