package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

import java.math.BigDecimal;
import java.util.List;

public class AutorizarRequest {
	private String tipo;
	private String accion;
	private List<String> listaIds;

	private int numeroPagos;
	private BigDecimal montoTotal;
	private String respuestaVasco;
	private String nota;
	private String tokenBks;
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	public List<String> getListaIds() {
		return listaIds;
	}
	public void setListaIds(List<String> listaIds) {
		this.listaIds = listaIds;
	}
	public int getNumeroPagos() {
		return numeroPagos;
	}
	public void setNumeroPagos(int numeroPagos) {
		this.numeroPagos = numeroPagos;
	}
	public BigDecimal getMontoTotal() {
		return montoTotal;
	}
	public void setMontoTotal(BigDecimal montoTotal) {
		this.montoTotal = montoTotal;
	}
	public String getRespuestaVasco() {
		return respuestaVasco;
	}
	public void setRespuestaVasco(String respuestaVasco) {
		this.respuestaVasco = respuestaVasco;
	}
	public String getNota() {
		return nota;
	}
	public void setNota(String nota) {
		this.nota = nota;
	}
	public String getTokenBks() {
		return tokenBks;
	}
	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}
	
}
