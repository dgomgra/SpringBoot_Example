package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class DetPerfiladoUsuarioResponse {

	private DetPerfiladoUsuarioOut methodResult;

	public DetPerfiladoUsuarioOut getMethodResult() {
		return methodResult;
	}

	public void setMethodResult(DetPerfiladoUsuarioOut methodResult) {
		this.methodResult = methodResult;
	}
	
}
