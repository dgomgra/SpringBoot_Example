package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

public class ListaPaisArbol {

	private PaisArbol pais;

	public PaisArbol getPais() {
		return pais;
	}

	public void setPais(PaisArbol pais) {
		this.pais = pais;
	}
	
}
