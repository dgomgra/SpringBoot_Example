package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model;

public class CalcularCutOffRequest {
	private String token;
	private CalcularCutOffRequestData requestData;
	
	
	public CalcularCutOffRequest() {
		super();
		this.setToken("");
		this.setRequestData(new CalcularCutOffRequestData());		
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public CalcularCutOffRequestData getRequestData() {
		return requestData;
	}
	public void setRequestData(CalcularCutOffRequestData requestData) {
		this.requestData = requestData;
	}
}
