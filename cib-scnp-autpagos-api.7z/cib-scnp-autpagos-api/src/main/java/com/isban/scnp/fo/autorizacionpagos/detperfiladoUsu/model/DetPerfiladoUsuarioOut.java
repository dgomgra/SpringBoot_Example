package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DetPerfiladoUsuarioOut {

	private String usuarioMdf;
	private Date fechaMdf;
	private String estado;
	private int codigoRol;
	private int codigoGrupo;
	private String nombreUsuario;
	private String apellidosUsuario;
	private String nombreRol;
	private String idLogin;
	private String nombreLargo;
	private int codigoCliente;
	private String nombreCliente;
	private List<ListaProductos> listaProductos;
	private List<ListaServiciosAR> listadoServicios;
	
	public DetPerfiladoUsuarioOut() {
		listaProductos = new ArrayList<>(0);
		listadoServicios = new ArrayList<>(0);
	}
	
	public String getUsuarioMdf() {
		return usuarioMdf;
	}
	public void setUsuarioMdf(String usuarioMdf) {
		this.usuarioMdf = usuarioMdf;
	}
	public Date getFechaMdf() {
		return fechaMdf;
	}
	public void setFechaMdf(Date fechaMdf) {
		this.fechaMdf = fechaMdf;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public int getCodigoRol() {
		return codigoRol;
	}
	public void setCodigoRol(int codigoRol) {
		this.codigoRol = codigoRol;
	}
	public int getCodigoGrupo() {
		return codigoGrupo;
	}
	public void setCodigoGrupo(int codigoGrupo) {
		this.codigoGrupo = codigoGrupo;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public String getApellidosUsuario() {
		return apellidosUsuario;
	}
	public void setApellidosUsuario(String apellidosUsuario) {
		this.apellidosUsuario = apellidosUsuario;
	}
	public String getNombreRol() {
		return nombreRol;
	}
	public void setNombreRol(String nombreRol) {
		this.nombreRol = nombreRol;
	}
	public String getIdLogin() {
		return idLogin;
	}
	public void setIdLogin(String idLogin) {
		this.idLogin = idLogin;
	}
	public String getNombreLargo() {
		return nombreLargo;
	}
	public void setNombreLargo(String nombreLargo) {
		this.nombreLargo = nombreLargo;
	}
	public int getCodigoCliente() {
		return codigoCliente;
	}
	public void setCodigoCliente(int codigoCliente) {
		this.codigoCliente = codigoCliente;
	}
	public String getNombreCliente() {
		return nombreCliente;
	}
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	public List<ListaProductos> getListaProductos() {
		return listaProductos;
	}
	public void setListaProductos(List<ListaProductos> listaProductos) {
		this.listaProductos = listaProductos;
	}
	public List<ListaServiciosAR> getListadoServicios() {
		return listadoServicios;
	}
	public void setListadoServicios(List<ListaServiciosAR> listadoServicios) {
		this.listadoServicios = listadoServicios;
	}
	
}
