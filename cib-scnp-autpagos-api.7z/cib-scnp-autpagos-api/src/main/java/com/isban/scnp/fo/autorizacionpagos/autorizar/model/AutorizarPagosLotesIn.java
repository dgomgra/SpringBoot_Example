package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarPagosLotesIn {
	private AutorizarPagosLotes_E entrada;

	
	public AutorizarPagosLotesIn() {
		super();
		entrada=new AutorizarPagosLotes_E();
	}

	public AutorizarPagosLotes_E getEntrada() {
		return entrada;
	}

	public void setEntrada(AutorizarPagosLotes_E entrada) {
		this.entrada = entrada;
	}
}
