package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarStopPayment_E {
	private DatosFirma datosFirma;
	private IdPagoNombre idPagoNombre;
	private IdLoteNombre idLoteNombre;
	public AutorizarStopPayment_E() {
		super();
		datosFirma=new DatosFirma();
		idPagoNombre=new IdPagoNombre();
		idLoteNombre=new IdLoteNombre();
	}
	public DatosFirma getDatosFirma() {
		return datosFirma;
	}
	public void setDatosFirma(DatosFirma datosFirma) {
		this.datosFirma = datosFirma;
	}
	public IdPagoNombre getIdPagoNombre() {
		return idPagoNombre;
	}
	public void setIdPagoNombre(IdPagoNombre idPagoNombre) {
		this.idPagoNombre = idPagoNombre;
	}
	public IdLoteNombre getIdLoteNombre() {
		return idLoteNombre;
	}
	public void setIdLoteNombre(IdLoteNombre idLoteNombre) {
		this.idLoteNombre = idLoteNombre;
	}
}
