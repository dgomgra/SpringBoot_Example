
package com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Saldos {

    private String descripcionConversion;
    private List<ListaMoneda> listaMonedas = null;
    private String saldoConsolidadoDisponible;
    private String saldoConsolidadoContable;
    private List<ArbolBalance> arbolBalances = null;

    public String getDescripcionConversion() {
        return descripcionConversion;
    }

    public void setDescripcionConversion(String descripcionConversion) {
        this.descripcionConversion = descripcionConversion;
    }

    public List<ListaMoneda> getListaMonedas() {
        return listaMonedas;
    }

    public void setListaMonedas(List<ListaMoneda> listaMonedas) {
        this.listaMonedas = listaMonedas;
    }

    public String getSaldoConsolidadoDisponible() {
        return saldoConsolidadoDisponible;
    }

    public void setSaldoConsolidadoDisponible(String saldoConsolidadoDisponible) {
        this.saldoConsolidadoDisponible = saldoConsolidadoDisponible;
    }

    public String getSaldoConsolidadoContable() {
        return saldoConsolidadoContable;
    }

    public void setSaldoConsolidadoContable(String saldoConsolidadoContable) {
        this.saldoConsolidadoContable = saldoConsolidadoContable;
    }

    public List<ArbolBalance> getArbolBalances() {
        return arbolBalances;
    }

    public void setArbolBalances(List<ArbolBalance> arbolBalances) {
        this.arbolBalances = arbolBalances;
    }

}
