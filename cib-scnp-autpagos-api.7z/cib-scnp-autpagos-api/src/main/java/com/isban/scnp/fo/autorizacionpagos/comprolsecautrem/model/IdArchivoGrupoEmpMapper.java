package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class IdArchivoGrupoEmpMapper implements RowMapper<IdArchivoGrupoEmp>{

	@Override
	public IdArchivoGrupoEmp mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new IdArchivoGrupoEmp(rs.getInt("O9247_IDARCH"), rs.getInt("O9247_CDEMGR"));
	}

}
