package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class IdPagoNombre {
	private String idPago;
	private String refCliente;
	
	
	public IdPagoNombre() {
		super();
	}	
	public IdPagoNombre(String idPago, String refCliente) {
		super();
		this.idPago = idPago;
		this.refCliente = refCliente;
	}
	public String getIdPago() {
		return idPago;
	}
	public void setIdPago(String idPago) {
		this.idPago = idPago;
	}
	public String getRefCliente() {
		return refCliente;
	}
	public void setRefCliente(String refCliente) {
		this.refCliente = refCliente;
	}	
}
