package com.isban.scnp.fo.autorizacionpagos.autorizar.model;

public class AutorizarPagosLotesRequestData {
	private AutorizarPagosLotesIn autorizarPagosLotes;

	
	public AutorizarPagosLotesRequestData() {
		super();
		this.setAutorizarPagosLotes(new AutorizarPagosLotesIn());
	}

	public AutorizarPagosLotesIn getAutorizarPagosLotes() {
		return autorizarPagosLotes;
	}

	public void setAutorizarPagosLotes(AutorizarPagosLotesIn autorizarPagosLotes) {
		this.autorizarPagosLotes = autorizarPagosLotes;
	}	
}
