package com.isban.scnp.fo.autorizacionpagos.home.model;

public class HomeRequest {
	private String tokenBks;
	private String monConsolidacion;
	
	public String getTokenBks() {
		return tokenBks;
	}

	public void setTokenBks(String tokenBks) {
		this.tokenBks = tokenBks;
	}
	
	public String getMonConsolidacion() {
		return monConsolidacion;
	}
	
	public void setMonConsolidacion(String monConsolidacion) {
		this.monConsolidacion = monConsolidacion;
	}
	
}
