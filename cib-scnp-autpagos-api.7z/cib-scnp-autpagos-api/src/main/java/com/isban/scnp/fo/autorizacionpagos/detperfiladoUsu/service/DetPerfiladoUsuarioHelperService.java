package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service;

import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;

public interface DetPerfiladoUsuarioHelperService {
	
	public DetPerfiladoUsuarioResponse detPerfiladoUsuario(String token);
}
