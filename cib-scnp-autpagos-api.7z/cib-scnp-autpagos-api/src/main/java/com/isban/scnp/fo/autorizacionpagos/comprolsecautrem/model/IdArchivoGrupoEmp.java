package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model;

public class IdArchivoGrupoEmp {
	private int idArchivo;
	private int codGrupoEmp;
	
	public IdArchivoGrupoEmp(int idArchivo, int codGrupoEmp) {
		this.setIdArchivo(idArchivo);
		this.setCodGrupoEmp(codGrupoEmp);
	}
	
	public int getIdArchivo() {
		return idArchivo;
	}
	
	public void setIdArchivo(int idArchivo) {
		this.idArchivo = idArchivo;
	}
	
	public int getCodGrupoEmp() {
		return codGrupoEmp;
	}
	
	public void setCodGrupoEmp(int codGrupoEmp) {
		this.codGrupoEmp = codGrupoEmp;
	}

}
