package com.isban.scnp.fo.autorizacionpagos.listaarchivos.web;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.ListaArchivosPendientesHelperService;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaArchivosPendientesControllerUnitTest {
	private MockMvc mockMvc;
	
	private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	
	
	@Autowired
	private WebApplicationContext webApplicationContext;

	@Autowired
	private ListaArchivosPendientesRestController listaArchivosPendientesRestController;

	@Before
	public void setup() throws Exception{
		leerFichero();
		this.mockMvc = webAppContextSetup(webApplicationContext).build(); 
	}
	
	
	
	

	/**
	 * Test que comprueba la ejecucion con moneda
	 * 
	 * @throws Exception 
	 * 	
	 */
	@Test
	public void getListaArchivosPendientesOkTestConMoneda() throws Exception
	{
		ListaArchivosPendientesResponse respuesta = rellenarRespuesta("OK");
		ListaArchivosPendientesHelperService laphs =  Mockito.mock(ListaArchivosPendientesHelperService.class);
		Mockito.when(laphs.getListaArchivosPendientes(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
		ReflectionTestUtils.setField(listaArchivosPendientesRestController, "listaArchivosPendientesHelperService", laphs);
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("OK", true));
    	
    	String uri = "/authorization/v1/listadoARautorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
	}
	
	/**
	 * Test que comprueba la ejecucion sin moneda
	 * 
	 * @throws Exception 
	 * 	
	 */
	@Test
	public void getListaArchivosPendientesOkTestSinMoneda() throws Exception
	{
		ListaArchivosPendientesResponse respuesta = rellenarRespuesta("OK");
		ListaArchivosPendientesHelperService laphs =  Mockito.mock(ListaArchivosPendientesHelperService.class);
		Mockito.when(laphs.getListaArchivosPendientes(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
		ReflectionTestUtils.setField(listaArchivosPendientesRestController, "listaArchivosPendientesHelperService", laphs);
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("OK", false));
    	
    	String uri = "/authorization/v1/listadoARautorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
	}
	
	/**
	 * Test que comprueba una ejecucion sin estado OK
	 * 
	 * @throws Exception 
	 * 	
	 */
	@Test
	public void getListaArchivosPendientesKO() throws Exception
	{
		ListaArchivosPendientesResponse respuesta = rellenarRespuesta("KO");
		ListaArchivosPendientesHelperService laphs =  Mockito.mock(ListaArchivosPendientesHelperService.class);
		Mockito.when(laphs.getListaArchivosPendientes(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
		ReflectionTestUtils.setField(listaArchivosPendientesRestController, "listaArchivosPendientesHelperService", laphs);
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("KO", false));
    	
    	String uri = "/authorization/v1/listadoARautorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
	}
	
	/**
	 * Test que comprueba la ejecucion cuando se produce una excepcion
	 * 
	 * @throws Exception 
	 * 	
	 */
	@Test
	public void getListaArchivosPendientesException() throws Exception
	{
		ListaArchivosPendientesHelperService laphs =  Mockito.mock(ListaArchivosPendientesHelperService.class);
		Mockito.when(laphs.getListaArchivosPendientes(Mockito.any(), Mockito.anyBoolean())).thenThrow(new NullPointerException("Error occurred"));
		ReflectionTestUtils.setField(listaArchivosPendientesRestController, "listaArchivosPendientesHelperService", laphs);
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("KO", false));
    	
    	String uri = "/authorization/v1/listadoARautorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
	}	
	
	/**
	 * Test que comprueba la ejecucion cuando se produce una excepcion
	 * 
	 * @throws Exception 
	 * 	
	 */
	@Test
	public void getListaArchivosPendientesTest_KOCredencial() throws Exception
	{
		ListaArchivosPendientesHelperService laphs =  Mockito.mock(ListaArchivosPendientesHelperService.class);
		Mockito.when(laphs.getListaArchivosPendientes(Mockito.any(), Mockito.anyBoolean())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		ReflectionTestUtils.setField(listaArchivosPendientesRestController, "listaArchivosPendientesHelperService", laphs);
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("KO", false));
    	
    	String uri = "/authorization/v1/listadoARautorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
    	.andExpect(status().isUnauthorized())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
	}
	
	@Test
	public void getListaArchivosPendientesTest_KOOtro() throws Exception
	{
		ListaArchivosPendientesHelperService laphs =  Mockito.mock(ListaArchivosPendientesHelperService.class);
		Mockito.when(laphs.getListaArchivosPendientes(Mockito.any(), Mockito.anyBoolean())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		ReflectionTestUtils.setField(listaArchivosPendientesRestController, "listaArchivosPendientesHelperService", laphs);
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("KO", false));
    	
    	String uri = "/authorization/v1/listadoARautorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
    	.andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
	}
	
	
	/**
	 * @param tipoResultado
	 * @param conMoneda
	 * @return
	 */
	private ListaArchivosARRequest rellenarEntrada(String tipoResultado, boolean conMoneda) {
		ListaArchivosARRequest peticion = new ListaArchivosARRequest();
		if("OK".equals(tipoResultado)) {
			String ejecucion = "$.ejecucionOK.";
			int numPorPagina = JsonPath.read(jsonFile, 				ejecucion.concat("numPorPagina"));
			int numPagina = JsonPath.read(jsonFile,					ejecucion.concat("numPagina"));
			String tokenBks = JsonPath.read(jsonFile, 				ejecucion.concat("tokenBks"));
    		
    		peticion.setNumPorPagina(numPorPagina);
    		peticion.setNumPagina(numPagina);
    		peticion.setTokenBks(tokenBks);
    		
    		if(conMoneda) {
    			String monConsolidacion = JsonPath.read(jsonFile,	"$.ejecucionOKMoneda.monConsolidacion");
    			peticion.setMonConsolidacion(monConsolidacion);
    		}
		}else {
			String ejecucion = "$.ejecucionKO.";
			int numPorPagina = JsonPath.read(jsonFile, 				ejecucion.concat("numPorPagina"));
			int numPagina = JsonPath.read(jsonFile,					ejecucion.concat("numPagina"));
			String tokenBks = JsonPath.read(jsonFile, 				ejecucion.concat("tokenBks"));
			
			peticion.setNumPorPagina(numPorPagina);
    		peticion.setNumPagina(numPagina);
    		peticion.setTokenBks(tokenBks);
		}		
		return peticion;
	}

	/**
	 * 
	 * Rellenamos una salida con el parametro de respuesta esperado (OK/KO)
	 * 
	 * 
	 * @param respuestaEsperada
	 * @return
	 */
	private ListaArchivosPendientesResponse rellenarRespuesta(String respuestaEsperada) {
		ListaArchivosPendientesResponse salida = new ListaArchivosPendientesResponse();
		if ("OK".equals(respuestaEsperada)) {
			salida.setStatus("OK");
		}else {
			salida.setStatus("KO");
		}
		return salida;
	}
	
	 private void leerFichero() {
	    	try {
	    		File file = new File("src/test/resources/json/ListaArchivosPendientesControllerUnitTest.json");
				fe = new FileInputStream(file);
				isr = new InputStreamReader(fe);
				br = new BufferedReader(isr);
				String cadena;
				while((cadena = br.readLine()) != null){
					System.out.println(cadena);
					jsonFile = jsonFile.concat(cadena);
				}
				
			} catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
	    }
	
	
	
}
