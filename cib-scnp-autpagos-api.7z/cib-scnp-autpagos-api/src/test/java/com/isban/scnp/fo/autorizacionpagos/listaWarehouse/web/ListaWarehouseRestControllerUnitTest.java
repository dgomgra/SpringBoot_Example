package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.ListaWarehouseHelperService;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaWarehouseRestControllerUnitTest {

    @Autowired
    private WebApplicationContext webApplicationContext;
    
    @Autowired
    private ListaWarehouseRestController listaWarehouseRestController;
    
    private MockMvc mockMvc;
    
	private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	private String cadena = "";
    
    @Before
    public void setup() throws Exception{
    	leerFichero();
        this.mockMvc = webAppContextSetup(webApplicationContext).build();     
    }
    
    private void leerFichero() throws Exception{
  //  	try {
    		File file = new File("src/test/resources/json/ListaWarehouseRestControllerUnitTest.json");
			fe = new FileInputStream(file);
			isr = new InputStreamReader(fe);
			br = new BufferedReader(isr);
			
			while((cadena = br.readLine()) != null){
				System.out.println(cadena);
				jsonFile = jsonFile.concat(cadena);
			}
			
	/*	} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}*/
	}

	@Test    
    public void getListaPagosWarehouseOkTest() throws Exception
    {		
    	ListaPagosWarehouseResponse respuesta = rellenarPagosWarehouse ("OK");
    	
    	ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
    	Mockito.when(listaWarehouseHelperService.getListaPagosWarehouseImp(Mockito.any())).thenReturn(respuesta);
    	ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
   
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/listadoWarehouseAutorizar";
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
    }
	
	@Test
	public void getListaPagosWarehouseKoTest() throws Exception
    {		
    	ListaPagosWarehouseResponse respuesta = rellenarPagosWarehouse ("KO");
		
		ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
		Mockito.when(listaWarehouseHelperService.getListaPagosWarehouseImp(Mockito.any())).thenReturn(respuesta);
		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
	   
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
		
		String uri = "/authorization/v1/listadoWarehouseAutorizar";
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
	    .andExpect(status().isOk())
	    .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	    .andDo(print());
	}

	@Test
	public void getListaPagosWarehouseKoTest2() throws Exception
    {
		ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
		Exception ex = new Exception();
		Mockito.when(listaWarehouseHelperService.getListaPagosWarehouseImp(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
		
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
    	
    	String uri = "/authorization/v1/listadoWarehouseAutorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
    }


    @Test
   	public void listaPagosWarehouseTest_KOCredencial() throws Exception {
    	ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
   		
   		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
   		
   		when(listaWarehouseHelperService.getListaPagosWarehouseImp(Mockito.any())).thenThrow(
   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
   		
   		ObjectMapper mapper = new ObjectMapper();
       	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
       	
       	String uri = "/authorization/v1/listadoWarehouseAutorizar";
       	
       	mockMvc.perform(post(uri)
       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.content(jsonInString))
           .andExpect(status().isUnauthorized())
           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
           .andDo(print());
    }
    
    @Test
   	public void listaPagosWarehouseTest_KOOtro() throws Exception {
   		ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
   		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
   		
   		
   		when(listaWarehouseHelperService.getListaPagosWarehouseImp(Mockito.any())).thenThrow(
   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
   		
   		ObjectMapper mapper = new ObjectMapper();
       	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
       	
       	String uri = "/authorization/v1/listadoWarehouseAutorizar";
       	
       	mockMvc.perform(post(uri)
       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.content(jsonInString))
           .andExpect(status().isInternalServerError())
           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
           .andDo(print());
   		
   	}
   	
	private ListaWarehouseRequest rellenarEntrada(String tipo) {		
		ListaWarehouseRequest salida = new ListaWarehouseRequest();
    	if("ok".equals(tipo)) {    		
    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPorPagina");
    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPagina");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
    		
    		salida.setNumPorPagina(numPorPagina);
    		salida.setNumPagina(numPagina);
    		salida.setTokenBks(tokenBks);
    	}else {
    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPorPagina");
    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPagina");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionKO.tokenBks");
    		
    		salida.setNumPorPagina(numPorPagina);
    		salida.setNumPagina(numPagina);
    		salida.setTokenBks(tokenBks);
    	}
    	return salida;
	}
	
	private ListaLotesWarehouseRequest rellenarEntradaLotes(String tipo) {		
		ListaLotesWarehouseRequest salida = new ListaLotesWarehouseRequest();
    	if("ok".equals(tipo)) {    		
    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPorPagina");
    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPagina");
    		String monConsolidacion = JsonPath.read(jsonFile, "$.ejecucionOK.monedaConsolidacion");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
    		
    		salida.setNumPorPagina(numPorPagina);
    		salida.setNumPagina(numPagina);
    		salida.setMonedaConsolidacion(monConsolidacion);
    		salida.setTokenBks(tokenBks);
    	}else {
    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPorPagina");
    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPagina");
    		String monConsolidacion = JsonPath.read(jsonFile, "$.ejecucionKO.monedaConsolidacion");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionKO.tokenBks");
    		
    		salida.setNumPorPagina(numPorPagina);
    		salida.setNumPagina(numPagina);
    		salida.setMonedaConsolidacion(monConsolidacion);
    		salida.setTokenBks(tokenBks);
    	}
    	return salida;
	}
	
	private ListaPagosWarehouseResponse rellenarPagosWarehouse(String tipoPrueba) {
		ListaPagosWarehouseResponse salida = new ListaPagosWarehouseResponse();
    	if("OK".equals(tipoPrueba)) {    		
    		salida.setStatus("OK");
    	}else {
    		salida.setStatus("KO");
    	}    	
    	return salida;
	}    
	
	@Test    
    public void getListaLotesWarehouseOkTest() throws Exception
    {		
    	ListaLotesWarehouseResponse respuesta = rellenarLotesWarehouse ("OK");
    	
    	ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
    	Mockito.when(listaWarehouseHelperService.getListaLotesWarehouseImp(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
    	ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
   
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/listaDatosLotesWarehousing";
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
    }

	private ListaLotesWarehouseResponse rellenarLotesWarehouse(String tipoPrueba) {
		ListaLotesWarehouseResponse salida = new ListaLotesWarehouseResponse();
    	if("OK".equals(tipoPrueba)) {    		
    		salida.setStatus("OK");
    	}else {
    		salida.setStatus("KO");
    	}    	
    	return salida;
	}
	@Test
	public void getListaLotesWarehouseKoTest() throws Exception
    {		
		ListaLotesWarehouseResponse respuesta = rellenarLotesWarehouse("KO");
		
		ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
		Mockito.when(listaWarehouseHelperService.getListaLotesWarehouseImp(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
	   
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntradaLotes("ok"));
		
		String uri = "/authorization/v1/listaDatosLotesWarehousing";
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
	    .andExpect(status().isOk())
	    .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	    .andDo(print());
	}

	@Test
	public void getListaLotesWarehouseKoTest2() throws Exception
    {
		ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
		Exception ex = new Exception();
		Mockito.when(listaWarehouseHelperService.getListaLotesWarehouseImp(Mockito.any(), Mockito.anyBoolean())).thenThrow(new NullPointerException("Error occurred"));
		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
		
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntradaLotes("ko"));
    	
    	String uri = "/authorization/v1/listaDatosLotesWarehousing";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
    }


    @Test
   	public void listaLotesWarehouseTest_KOCredencial() throws Exception {
    	ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
   		
   		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
   		
   		when(listaWarehouseHelperService.getListaLotesWarehouseImp(Mockito.any(), Mockito.anyBoolean())).thenThrow(
   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
   		
   		ObjectMapper mapper = new ObjectMapper();
       	String jsonInString = mapper.writeValueAsString(rellenarEntradaLotes("ok"));
       	
       	String uri = "/authorization/v1/listaDatosLotesWarehousing";
       	
       	mockMvc.perform(post(uri)
       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.content(jsonInString))
           .andExpect(status().isUnauthorized())
           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
           .andDo(print());
    }
    
    @Test
   	public void listaLotesWarehouseTest_KOOtro() throws Exception {
   		ListaWarehouseHelperService listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperService.class);
   		ReflectionTestUtils.setField(listaWarehouseRestController, "listaWarehouseHelperService", listaWarehouseHelperService);
   		
   		
   		when(listaWarehouseHelperService.getListaLotesWarehouseImp(Mockito.any(), Mockito.anyBoolean())).thenThrow(
   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
   		
   		ObjectMapper mapper = new ObjectMapper();
       	String jsonInString = mapper.writeValueAsString(rellenarEntradaLotes("ok"));
       	
       	String uri = "/authorization/v1/listaDatosLotesWarehousing";
       	
       	mockMvc.perform(post(uri)
       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.content(jsonInString))
           .andExpect(status().isInternalServerError())
           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
           .andDo(print());
   		
   	}
}
