package com.isban.scnp.fo.autorizacionpagos.common.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.common.service.impl.CommonHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class CommonHelperServiceBBDDTest {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private CommonHelperServiceImpl commonHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/CommonSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/CommonPurge.sql"));
	}
	
	@Test
	public void obtenerDatosUsuario_Test() {
		when(commonHelperServiceImpl.obtenerDatosUsuario(Mockito.anyString())).thenCallRealMethod();
		ReflectionTestUtils.setField(commonHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(commonHelperServiceImpl, "schemaproc", schemaproc);
		
		DatosUsuario datosUsuario = commonHelperServiceImpl.obtenerDatosUsuario("SGPdanice727718");
		
		assertEquals(datosUsuario.getFormatoCantidad(), "###.###.###,##");
		assertEquals(datosUsuario.getFormatoFecha(), "dd/MM/yyyy");
	}
	
	@Test
	public void obtenerTraducCodErrorOK() {
		
		Mockito.when(commonHelperServiceImpl.obtenerTraducCodError(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenCallRealMethod();
	
		ReflectionTestUtils.setField(commonHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(commonHelperServiceImpl, "schemaproc", schemaproc);
				
		String salida = commonHelperServiceImpl.obtenerTraducCodError("0000", " es", "ES");
		assertThat(salida, notNullValue());
		assertEquals(salida, "No hay registros.");
	}
	
	@Test
	public void obtenerTraducCodErrorTestNoData() {
		
		Mockito.when(commonHelperServiceImpl.obtenerTraducCodError(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenCallRealMethod();

		ReflectionTestUtils.setField(commonHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(commonHelperServiceImpl, "schemaproc", schemaproc);
		
		String salida = commonHelperServiceImpl.obtenerTraducCodError("0001", " es", "ES");
		assertThat(salida, notNullValue());
	}
	
}
