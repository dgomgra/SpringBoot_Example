package com.isban.scnp.fo.autorizacionpagos.listaPagos.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ObtDetalleNotaOut;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl.ListaPagosHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaPagosHelperServiceUnitBBDDTest {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Mock
	ListaPagosHelperServiceImpl listaPagosHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaPagosSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaPagosPurge.sql"));
	}
	
	@Test
	public void comprobarTokenSKeyUsuTest() {
		Mockito.when(listaPagosHelperServiceImpl.comprobarTokenSKeyUsu(Mockito.anyString())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "schemaproc", schemaproc);
		
		String salidaOk = listaPagosHelperServiceImpl.comprobarTokenSKeyUsu("SGPdavidf787753");
		
		assertEquals(salidaOk, "SGPdavidf787753");
		
		String salidaNull = listaPagosHelperServiceImpl.comprobarTokenSKeyUsu("");
		
		assertNull(salidaNull);
		
	}
	
	@Test
	public void obtPagosFirmaOKUsuarioTest() {
		Mockito.when(listaPagosHelperServiceImpl.obtPagosFirmaOKUsuario(Mockito.anyString(), Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> lista = new ArrayList<>();
		lista.add("SGP1811150000038");
		
		List<String> salidaOk = listaPagosHelperServiceImpl.obtPagosFirmaOKUsuario("SGPdavidf787753", lista);
		
		assertEquals(salidaOk.get(0), "SGP1811150000038");
		
		lista.clear();
		List<String> salidaNull = listaPagosHelperServiceImpl.obtPagosFirmaOKUsuario("SGPdavidf787753", lista);
		
		assertEquals(salidaNull.size(), 0);
	}
	
	@Test
	public void obtNotasTest() {
		Mockito.when(listaPagosHelperServiceImpl.obtNotas(Mockito.anyString())).thenCallRealMethod();
		Mockito.when(listaPagosHelperServiceImpl.obtDetalleNota(Mockito.anyInt())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "schemaproc", schemaproc);
		

		
		String salidaOk = listaPagosHelperServiceImpl.obtNotas("SGP1409100000013");
		
		assertEquals(salidaOk.trim(), "Lotes administracion dos");
		
	}
	
	@Test
	public void obtDetalleNotaTest() {
		Mockito.when(listaPagosHelperServiceImpl.obtDetalleNota(Mockito.anyInt())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "schemaproc", schemaproc);
		
		ObtDetalleNotaOut salidaOk = listaPagosHelperServiceImpl.obtDetalleNota(103);
		
		assertEquals(salidaOk.getO2760_ANOTAS().trim(), "Lotes administracion");
		assertEquals(salidaOk.getO2760_NOTES_TS().toString(), "2014-09-29 12:46:17.0");
		assertEquals(salidaOk.getO2765_CDNOTA(), 103);
		
		ObtDetalleNotaOut salidaNull = listaPagosHelperServiceImpl.obtDetalleNota(888);
		
		assertNull(salidaNull.getO2760_ANOTAS());
		assertNull(salidaNull.getO2760_NOTES_TS());
	}
}
