package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;

import com.isban.scnp.fo.autorizacionpagos.Application;

@WithAnonymousUser
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DatosFirmaResponseTest {
	
	@Test
	public void DatosFirmaResponseModelTest() {
		DatosFirmaResponse data = new DatosFirmaResponse();
		data.setImporte("");
		data.setMessage("");
		data.setNumPagos(1);
		data.setStatus("");
		data.setTipoCripto("");
		data.setUltimosDigitosCuentaBen("");
		
		data.getImporte();
		data.getMessage();
		data.getNumPagos();
		data.getStatus();
		data.getTipoCripto();
		data.getUltimosDigitosCuentaBen();
		
		assertNotNull(data);
	}
	

}
