package com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.CuentasArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DatosProducto;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaCuentasArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaMetodosPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPaisAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPaisArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPermisosMetPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPermisosSubprodArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaProductos;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaServiciosAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.MetodosPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PaisArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PermisosMetPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PermisosSubprodArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ServicioPaisAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.impl.DetPerfiladoUsuarioHelperServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class DetPerfiladoUsuarioHelperServiceImplUnitTest {

	@Mock
	private DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperServiceImpl;
	
	@Mock
	private RestTemplate restTemplatePost;
	
	@Mock
	private HttpEntity<String> httpEntity;
	
    
	@Test
	public void detPerfiladoUsuarioTest() {
		// Datos de salida de la llamada a detPerfiladoUsuario
		DetPerfiladoUsuarioResponse detPerfiladoUsuarioResponse = rellenarDetPerfilado();

		
		ResponseEntity<DetPerfiladoUsuarioResponse> responseEntity = new ResponseEntity<DetPerfiladoUsuarioResponse>(detPerfiladoUsuarioResponse,HttpStatus.ACCEPTED);		
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(DetPerfiladoUsuarioResponse.class))).thenReturn(responseEntity);

		ReflectionTestUtils.setField(detPerfiladoUsuarioHelperServiceImpl, "urlBks", "http://wwww.any.com");
		
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		Mockito.when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(detPerfiladoUsuarioHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		Mockito.when(detPerfiladoUsuarioHelperServiceImpl.detPerfiladoUsuario(Mockito.anyString())).thenCallRealMethod();
		
		DetPerfiladoUsuarioResponse salida = detPerfiladoUsuarioHelperServiceImpl.detPerfiladoUsuario("1234");
		
		// Verificamos los valores de retorno
		assertThat(salida.getMethodResult().getApellidosUsuario(), notNullValue());
		assertThat(salida.getMethodResult().getCodigoCliente(), notNullValue());
		assertThat(salida.getMethodResult().getCodigoGrupo(), notNullValue());
		assertThat(salida.getMethodResult().getCodigoRol(), notNullValue());
		assertThat(salida.getMethodResult().getEstado(), notNullValue());
		assertThat(salida.getMethodResult().getFechaMdf(), notNullValue());
		assertThat(salida.getMethodResult().getIdLogin(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios(), notNullValue());
		assertThat(salida.getMethodResult().getListaProductos(), notNullValue());
		assertThat(salida.getMethodResult().getNombreCliente(), notNullValue());
		assertThat(salida.getMethodResult().getNombreLargo(), notNullValue());
		assertThat(salida.getMethodResult().getNombreRol(), notNullValue());
		assertThat(salida.getMethodResult().getNombreUsuario(), notNullValue());
		assertThat(salida.getMethodResult().getUsuarioMdf(), notNullValue());
		assertThat(salida.getMethodResult().getListaProductos().get(0).getProducto().getCodigoProducto(), notNullValue());
		assertThat(salida.getMethodResult().getListaProductos().get(0).getProducto().getCodigoSubProducto(), notNullValue());
		assertThat(salida.getMethodResult().getListaProductos().get(0).getProducto().getOrdenProducto(), notNullValue());
		assertThat(salida.getMethodResult().getListaProductos().get(0).getProducto().getOrdenSubproducto(), notNullValue());
		
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getCodServicio(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getNecesCuenta(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getNecesTip(), notNullValue());
		
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getCodPais(), notNullValue());
		
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getCodigoCuenta(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getCodigoDivisa(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getCodPais(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getCuentaExtracto(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getNombreCorporate(), notNullValue());
		
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().getCodigoSubProducto(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().getCodPermiso(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().getNecesitaCuenta(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().getNecesTipo(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().getListaMetodosPago().get(0).getMetodosPago().getCodMedioPago(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().getListaMetodosPago().get(0).getMetodosPago().getCodTipoPago(), notNullValue());
		
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPermisosSinMetodos().get(0).getPemisos().getCodigoSubproducto(), notNullValue());
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPermisosSinMetodos().get(0).getPemisos().getCodPermiso(), notNullValue());
		
		assertThat(salida.getMethodResult().getListadoServicios().get(0).getServicio().getListaPaisesAR().get(0).getCodPais(), notNullValue());
		
		// Verificamos que se ha llamado al metodo
		verify(detPerfiladoUsuarioHelperServiceImpl, times(1)).detPerfiladoUsuario(Mockito.anyString());
	}
	
	private DetPerfiladoUsuarioResponse rellenarDetPerfilado() {
		DetPerfiladoUsuarioResponse salida = new DetPerfiladoUsuarioResponse();
		DetPerfiladoUsuarioOut detPerfiladoUsuarioOut = new DetPerfiladoUsuarioOut();
		
		detPerfiladoUsuarioOut.setUsuarioMdf("UsuTest");
		detPerfiladoUsuarioOut.setFechaMdf(new Date());
		detPerfiladoUsuarioOut.setEstado("Aceptado");
		detPerfiladoUsuarioOut.setCodigoRol(1);
		detPerfiladoUsuarioOut.setCodigoGrupo(10);
		detPerfiladoUsuarioOut.setNombreUsuario("Usuario");
		detPerfiladoUsuarioOut.setApellidosUsuario("ApellTest");
		detPerfiladoUsuarioOut.setNombreRol("Consultivo");
		detPerfiladoUsuarioOut.setIdLogin("UsoLogin");
		detPerfiladoUsuarioOut.setNombreLargo("UsuTest");
		detPerfiladoUsuarioOut.setCodigoCliente(1256);
		detPerfiladoUsuarioOut.setNombreCliente("NomClientTest");
		
		// lista de productos
		List<ListaProductos> listaProductos = new ArrayList<>();
		ListaProductos productos = new ListaProductos();
		DatosProducto datosProducto = new DatosProducto();
		datosProducto.setCodigoProducto(1234);
		datosProducto.setCodigoSubProducto(25);
		datosProducto.setOrdenProducto(10);
		datosProducto.setOrdenSubproducto(5);
		productos.setProducto(datosProducto);
		listaProductos.add(productos);
		
		// lista de servicios
		List<ListaServiciosAR> listadoServicios = new ArrayList<>();
		ListaServiciosAR serviciosAR = new ListaServiciosAR();
		ServicioPaisAR servicioPaisAR = new ServicioPaisAR();
		servicioPaisAR.setCodServicio("PA");
		servicioPaisAR.setNecesCuenta("S");
		servicioPaisAR.setNecesTip("S");
		
		List<ListaPaisArbol> listaPais = new ArrayList<>();
		ListaPaisArbol listaPaisArbol = new ListaPaisArbol();
		PaisArbol paisArbol = new PaisArbol();
		paisArbol.setCodPais("AR");
		List<ListaCuentasArbol> listaCuentas = new ArrayList<>();
		ListaCuentasArbol listaCuentasArbol = new ListaCuentasArbol();
		CuentasArbol cuentasArbol = new CuentasArbol();
		cuentasArbol.setCodPais("AR");
		cuentasArbol.setNombreCorporate("ISBAN SPAIN");
		cuentasArbol.setCuentaExtracto("0726666666666666666012");
		cuentasArbol.setCodigoDivisa("ARS");
		cuentasArbol.setCodigoCuenta(1229);
		
		List<ListaPermisosMetPagoArbol> permisosSubprod = new ArrayList<>();
		ListaPermisosMetPagoArbol listaPermisosMetPagoArbol = new ListaPermisosMetPagoArbol();
		PermisosMetPagoArbol permisosMetPagoArbol = new PermisosMetPagoArbol();
		permisosMetPagoArbol.setCodigoSubProducto(7);
		permisosMetPagoArbol.setCodPermiso("eli");
		permisosMetPagoArbol.setNecesitaCuenta("S");
		permisosMetPagoArbol.setNecesTipo("S");
		
		List<ListaMetodosPagoArbol> listaMetodosPago = new ArrayList<>();
		ListaMetodosPagoArbol listaMetodosPagoArbol = new ListaMetodosPagoArbol();
		MetodosPagoArbol metodosPagoArbol = new MetodosPagoArbol();
		metodosPagoArbol.setCodMedioPago("CH");
		metodosPagoArbol.setCodTipoPago("PR");
		
		listaMetodosPagoArbol.setMetodosPago(metodosPagoArbol);
		listaMetodosPago.add(listaMetodosPagoArbol);
		permisosMetPagoArbol.setListaMetodosPago(listaMetodosPago);
		listaPermisosMetPagoArbol.setPermisosSubprod(permisosMetPagoArbol);
		permisosSubprod.add(listaPermisosMetPagoArbol);
		cuentasArbol.setPermisosSubprod(permisosSubprod);
		listaCuentasArbol.setCuentasArbol(cuentasArbol);
		listaCuentas.add(listaCuentasArbol);
		paisArbol.setListaCuentas(listaCuentas);
		listaPaisArbol.setPais(paisArbol);
		listaPais.add(listaPaisArbol);
		servicioPaisAR.setListaPais(listaPais);
		
		
		
		List<ListaPermisosSubprodArbol> listaPermisosSinMetodos = new ArrayList<>();
		ListaPermisosSubprodArbol listaPermisosSubprodArbol = new ListaPermisosSubprodArbol();
		PermisosSubprodArbol permisosSubprodArbol = new PermisosSubprodArbol();
		permisosSubprodArbol.setCodPermiso("ver");
		permisosSubprodArbol.setCodigoSubproducto(7);
		
		listaPermisosSubprodArbol.setPemisos(permisosSubprodArbol);
		listaPermisosSinMetodos.add(listaPermisosSubprodArbol);
		
	
		List<ListaPaisAR> listaPaisesAR = new ArrayList<>();
		ListaPaisAR listaPaisAR = new ListaPaisAR();
		listaPaisAR.setCodPais("AR");
		
		listaPaisesAR.add(listaPaisAR);
		
		listaPais.add(listaPaisArbol);
		
		servicioPaisAR.setListaPais(listaPais);
		servicioPaisAR.setListaPermisosSinMetodos(listaPermisosSinMetodos);
		servicioPaisAR.setListaPaisesAR(listaPaisesAR);
		serviciosAR.setServicio(servicioPaisAR);
		listadoServicios.add(serviciosAR);
		
		detPerfiladoUsuarioOut.setListaProductos(listaProductos);
		detPerfiladoUsuarioOut.setListadoServicios(listadoServicios);
		
		salida.setMethodResult(detPerfiladoUsuarioOut);
		
		return salida;
	}
    
}
