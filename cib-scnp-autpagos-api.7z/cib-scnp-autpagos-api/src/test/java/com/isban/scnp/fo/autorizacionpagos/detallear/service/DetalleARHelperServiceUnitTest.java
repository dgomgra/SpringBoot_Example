package com.isban.scnp.fo.autorizacionpagos.detallear.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaOut;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl.ConversionDivisaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DatosArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARRequest;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARResponse;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.service.impl.DetalleARHelperServiceImpl;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DetalleARHelperServiceUnitTest {

	@Mock
	DetalleARHelperServiceImpl detalleARHelperServiceImpl;
	
	@Test
	public void getDetalleAR_OK()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");

		// Servicio externo (listawarehouse)
		ConversionDivisaHelperServiceImpl conversionDivisaHelperService = Mockito.mock(ConversionDivisaHelperServiceImpl.class);
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "conversionDivisaHelperService", conversionDivisaHelperService);
		when(conversionDivisaHelperService.conversionDivisa(any())).thenReturn(retornoDivisa());

		List<DatosArchivo> listaDatos = new ArrayList<>();
		DatosArchivo datosArchivo = new DatosArchivo();
		datosArchivo.setDivisa("EUR");
		datosArchivo.setMonto(new BigDecimal("400"));
		datosArchivo.setNumTransac(1);
		datosArchivo.setPais("ES");
		listaDatos.add(datosArchivo);
		when(detalleARHelperServiceImpl.obtDatosArchivo(anyInt())).thenReturn(listaDatos);
		
		DetalleArchivo detalle = new  DetalleArchivo();
		detalle.setDescEstado("Parcialmente autorizado");
		detalle.setDivisa("EUR");
		detalle.setEstadoArchivo("E0");
		detalle.setMotivoRechazo(null);
		when(detalleARHelperServiceImpl.obtDetalleArchivo(anyInt(),anyString())).thenReturn(detalle);
		
		when(detalleARHelperServiceImpl.getDetalleARImpl(any())).thenCallRealMethod();

		DetalleARRequest peticion = new DetalleARRequest();
		peticion.setIdArchivo(1);
		peticion.setTokenBks("1234");

		DetalleARResponse salida = detalleARHelperServiceImpl.getDetalleARImpl(peticion);
		verify(detalleARHelperServiceImpl, times(1)).getDetalleARImpl(any());
		assertEquals(salida.getMessage(), "OK");
		assertEquals(salida.getStatus(), "OK");
		
	}	
	
	private ConversionDivisaResponse retornoDivisa() {
		ConversionDivisaResponse convDivisaResponse = new ConversionDivisaResponse();
		ConversionDivisaOut convDivisa = new ConversionDivisaOut();
		List<ImporteType> listaImportes = new ArrayList<>();
		ImporteType imp0 = new ImporteType(new BigDecimal(123.45), "EUR");
		listaImportes.add(imp0);
		convDivisa.setListaImportes(listaImportes);
		convDivisaResponse.setMethodResult(convDivisa);
		return convDivisaResponse;
	}

}
