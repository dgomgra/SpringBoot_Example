package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;

import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ArchivoPolitica;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.IdArchivoGrupoEmp;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRol;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service.impl.CompRolSecAutRemServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CompRolSecAutRemHelperServiceUnitTest {
	
	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private CompRolSecAutRemServiceImpl compRolSecAutRemServiceImpl;

	@Test
	public void compRolTest() {
		when(compRolSecAutRemServiceImpl.comprobarRolSecuenciaAutRA(anyString(), anyInt(), any())).thenCallRealMethod();
		List<ArchivoAR> entrada = new ArrayList<>();
		ArchivoAR archivo1 = new ArchivoAR();
		archivo1.setIdArchivo(1);
		entrada.add(archivo1);
		ArchivoAR archivo2 = new ArchivoAR();
		archivo2.setIdArchivo(2);
		entrada.add(archivo2);
		ArchivoAR archivo3 = new ArchivoAR();
		archivo3.setIdArchivo(3);
		entrada.add(archivo3);
		ArchivoAR archivo4 = new ArchivoAR();
		archivo4.setIdArchivo(4);
		entrada.add(archivo4);
		List<IdArchivoGrupoEmp> salidaGrupEmpArchivos = new ArrayList<>();
		salidaGrupEmpArchivos.add(new IdArchivoGrupoEmp(300, 1));
		when(compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(entrada)).thenReturn(salidaGrupEmpArchivos);
		when(compRolSecAutRemServiceImpl.obtRolUsuario(anyString())).thenReturn(1);
		when(compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(any())).thenReturn(salidaGrupoEmpArchivos());
		when(compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario(anyString(),any())).thenReturn(Arrays.asList(1));
		when(compRolSecAutRemServiceImpl.obtArchivosSentRol(any())).thenReturn(salidaSentRol());
		
		
		List<ArchivoPolitica> salida = compRolSecAutRemServiceImpl.comprobarRolSecuenciaAutRA("SGP", 1, entrada);	
		assertEquals(salida.size(),0);
	}

	private List<ObtArchivoSentRol> salidaSentRol() {
		List<ObtArchivoSentRol> archivosSentRol = new  ArrayList<>();
		ObtArchivoSentRol archivo1 = new ObtArchivoSentRol();
		archivo1.setCodSentencia(1);
		archivo1.setIdAutorizacion(1);
		archivo1.setaNOrden(1);
		archivo1.setaTipAGru("O");
		archivo1.setTament(1);
		archivo1.setaNumFim(1);
		archivo1.setIdArchivo(1);
		archivosSentRol.add(archivo1);
		ObtArchivoSentRol archivo2 = new ObtArchivoSentRol();
		archivo2.setCodSentencia(2);
		archivo2.setIdAutorizacion(2);
		archivo2.setaNOrden(1);
		archivo2.setaTipAGru("O");
		archivo2.setTament(1);
		archivo2.setaNumFim(1);
		archivo2.setIdArchivo(2);
		archivosSentRol.add(archivo2);
		ObtArchivoSentRol archivo3 = new ObtArchivoSentRol();
		archivo3.setCodSentencia(3);
		archivo3.setIdAutorizacion(3);
		archivo3.setaNOrden(1);
		archivo3.setaTipAGru("O");
		archivo3.setTament(1);
		archivo3.setaNumFim(1);
		archivo3.setIdArchivo(3);
		archivosSentRol.add(archivo3);
		ObtArchivoSentRol archivo4 = new ObtArchivoSentRol();
		archivo4.setCodSentencia(4);
		archivo4.setIdAutorizacion(4);
		archivo4.setaNOrden(1);
		archivo4.setaTipAGru("O");
		archivo4.setTament(1);
		archivo4.setaNumFim(1);
		archivo4.setIdArchivo(4);
		archivosSentRol.add(archivo4);
		return archivosSentRol;
	}

	private List<IdArchivoGrupoEmp> salidaGrupoEmpArchivos() {
		List<IdArchivoGrupoEmp> archivos = new ArrayList<>();
		IdArchivoGrupoEmp archivo1 = new IdArchivoGrupoEmp(1, 1);
		IdArchivoGrupoEmp archivo2 = new IdArchivoGrupoEmp(2, 1);
		IdArchivoGrupoEmp archivo3 = new IdArchivoGrupoEmp(3, 1);
		IdArchivoGrupoEmp archivo4 = new IdArchivoGrupoEmp(4, 1);
		archivos.add(archivo1);
		archivos.add(archivo2);
		archivos.add(archivo3);
		archivos.add(archivo4);
		return archivos;
	}	
}
