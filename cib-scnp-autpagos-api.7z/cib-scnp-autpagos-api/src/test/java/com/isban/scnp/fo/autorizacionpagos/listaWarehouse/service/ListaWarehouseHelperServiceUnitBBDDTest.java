package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ClaveValor;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ConsultaPagosCreados_S;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.IdiomaUsuario;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl.ListaWarehouseHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaWarehouseHelperServiceUnitBBDDTest {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	ListaWarehouseHelperServiceImpl listaWarehouseHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaWarehouseSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaWarehousePurge.sql"));
	}
	
	@Test
	public void obtenerIdiomaUsuarioTest()
	{
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerIdiomaUsuario(Mockito.anyString())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "schemaproc", schemaproc);

		IdiomaUsuario salidaOk= listaWarehouseHelperServiceImpl.obtenerIdiomaUsuario("USUARIO");
		
		assertNotNull(salidaOk);
		assertNotNull(salidaOk.getIdioma());
		assertNotNull(salidaOk.getPais());
		
		assertThat(salidaOk.getIdioma(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getPais(), org.hamcrest.Matchers.isA(String.class));

		IdiomaUsuario salidaNull = listaWarehouseHelperServiceImpl.obtenerIdiomaUsuario("");		
		assertNull(salidaNull);
	}
	
	@Test
	public void obtenerUltimaNotaTest()
	{
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerUltimaNota(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "schemaproc", schemaproc);
		
		List<ConsultaPagosCreados_S> listaPagos = new ArrayList<ConsultaPagosCreados_S> ();
		
		for (int i=0;i<3;i++)
		{
			ConsultaPagosCreados_S nuevoPago = new ConsultaPagosCreados_S();
			String idPago = "SGP181025000000".concat(String.valueOf(i+1));
			
			nuevoPago.setRefSistema(idPago);
			
			listaPagos.add(nuevoPago);
		}
				
		List<String> salidaOk = listaWarehouseHelperServiceImpl.obtenerUltimaNota(listaPagos);
		
		assertNotNull(salidaOk);
		assertThat(salidaOk.get(0), org.hamcrest.Matchers.isA(String.class));
		assertEquals(salidaOk.get(0), "");
		
		assertThat(salidaOk.get(1), org.hamcrest.Matchers.isA(String.class));
		assertEquals(salidaOk.get(1), "Segunda nota mas actualizada.");
		
		assertThat(salidaOk.get(2), org.hamcrest.Matchers.isA(String.class));
		assertEquals(salidaOk.get(2), "");

		
		listaPagos.clear();
		List<String> salidaVacia = listaWarehouseHelperServiceImpl.obtenerUltimaNota(listaPagos);
		assertNotNull(salidaVacia);
		assertEquals(salidaVacia.size(), 0);		
	}
	@Test
	public void traducirMulidiTest()
	{
		Mockito.when(listaWarehouseHelperServiceImpl.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> estados = new ArrayList<String>(0);
		estados.add("EN");
		
		List<String> salidaOk = listaWarehouseHelperServiceImpl.traducirMulidi("ESTADO_PAGO_PSGP", estados, "USUARIO");
		assertNotNull(salidaOk);
	}
	
	@Test
	public void traducirMulidiQueryTest()
	{
		Mockito.when(listaWarehouseHelperServiceImpl.traducirMulidiQuery(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> estados = new ArrayList<String>(0);
		estados.add("EN");
		
		List<ClaveValor> salidaOk = listaWarehouseHelperServiceImpl.traducirMulidiQuery("ESTADO_PAGO_PSGP", estados, "USUARIO");
		assertNotNull(salidaOk);
		assertEquals(1, salidaOk.size());
		assertEquals("EN", salidaOk.get(0).getClave());
		assertEquals("Sent", salidaOk.get(0).getValor());		
	}
}
