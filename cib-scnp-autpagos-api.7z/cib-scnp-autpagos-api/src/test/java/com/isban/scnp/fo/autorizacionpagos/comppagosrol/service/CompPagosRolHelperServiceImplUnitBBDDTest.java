package com.isban.scnp.fo.autorizacionpagos.comppagosrol.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtCuentaPagosOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolFirmadoIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolFirmadoOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.impl.CompPagosRolHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")

public class CompPagosRolHelperServiceImplUnitBBDDTest {
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private CompPagosRolHelperServiceImpl compPagosRolHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/CompPagosSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/CompPagosPurge.sql"));
	}
	
	@Test
	public void obtCuentaPagosTest() {
		Mockito.when(compPagosRolHelperServiceImpl.obtCuentaPagos(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> listaRfTrans = new ArrayList<>();
		listaRfTrans.add("SGP1707260006979");
		listaRfTrans.add("SGP1707260006980");
		List<ObtCuentaPagosOut> salidaOk = compPagosRolHelperServiceImpl.obtCuentaPagos(listaRfTrans);
		
		
		assertThat(salidaOk.get(0).getAcuencod(), notNullValue());
		assertThat(salidaOk.get(0).getRftrans(), notNullValue());
		
		listaRfTrans.clear();
		listaRfTrans.add("");
		List<ObtCuentaPagosOut> salidaEmpty = compPagosRolHelperServiceImpl.obtCuentaPagos(listaRfTrans);
		
		assertEquals(salidaEmpty.size(), 0);
	}
	
	@Test
	public void obtPagosSentRolTest() {
		Mockito.when(compPagosRolHelperServiceImpl.obtPagosSentRol(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> listaRfTrans = new ArrayList<>();
		listaRfTrans.add("SGP1707210000128");
		listaRfTrans.add("SGP1707210000129");
		List<ObtPagosSentRolOut> salidaOk = compPagosRolHelperServiceImpl.obtPagosSentRol(listaRfTrans);
		
		
		assertThat(salidaOk.get(0).getAnorden(), notNullValue());
		assertThat(salidaOk.get(0).getAnordengrp(), notNullValue());
		assertThat(salidaOk.get(0).getAnumfirm(), notNullValue());
		assertThat(salidaOk.get(0).getRftrans(), notNullValue());
		assertThat(salidaOk.get(0).getIdComp(), notNullValue());
		assertThat(salidaOk.get(0).getCodSentencia(), notNullValue());
		assertThat(salidaOk.get(0).getIdAutorizacion(), notNullValue());
		assertThat(salidaOk.get(0).getAtipagru(), notNullValue());
		assertThat(salidaOk.get(0).getTament(), notNullValue());
		assertThat(salidaOk.get(0).getRol(), notNullValue());
		
		listaRfTrans.clear();
		listaRfTrans.add("");
		List<ObtPagosSentRolOut> salidaEmpty = compPagosRolHelperServiceImpl.obtPagosSentRol(listaRfTrans);
		
		assertEquals(salidaEmpty.size(), 0);
	}
	
	@Test
	public void obtPagosSentRolFirmadoTest() {
		Mockito.when(compPagosRolHelperServiceImpl.obtPagosSentRolFirmado(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "schemaproc", schemaproc);
		
		ObtPagosSentRolFirmadoIn datos = new ObtPagosSentRolFirmadoIn();
		datos.setCodRol(1);
		List<String> lista = new ArrayList<>();
		lista.add("SGP1811150000038");
		lista.add("SGP1811150000040");
		datos.setListaRftrans(lista);
		List<ObtPagosSentRolFirmadoOut> salidaOk = compPagosRolHelperServiceImpl.obtPagosSentRolFirmado(datos);
		
		assertThat(salidaOk.get(0).getRftrans(), notNullValue());
		assertThat(salidaOk.get(0).getCodSentencia(), notNullValue());
		assertThat(salidaOk.get(0).getIdAutorizacion(), notNullValue());
		
		lista.clear();
		lista.add("");
		datos.setListaRftrans(lista);
		datos.setCodRol(0);
		List<ObtPagosSentRolFirmadoOut> salidaEmpty = compPagosRolHelperServiceImpl.obtPagosSentRolFirmado(datos);
		
		assertEquals(salidaEmpty.size(), 0);
	}
	
	@Test
	public void obtPagosFirmaOKUsuarioTest() {
		Mockito.when(compPagosRolHelperServiceImpl.obtPagosFirmaOKUsuarioInt(Mockito.anyString(), Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> lista = new ArrayList<>();
		lista.add("SGP1811150000038");
		
		List<String> salidaOk = compPagosRolHelperServiceImpl.obtPagosFirmaOKUsuarioInt("SGPdavidf787753", lista);
		
		assertEquals(salidaOk.get(0), "SGP1811150000038");
		
		lista.clear();
		List<String> salidaNull = compPagosRolHelperServiceImpl.obtPagosFirmaOKUsuarioInt("SGPdavidf787753", lista);
		
		assertEquals(salidaNull.size(), 0);
	}
}
