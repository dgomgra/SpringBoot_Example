package com.isban.scnp.fo.autorizacionpagos.rehacer.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.client.AsyncRestTemplate;

import com.isban.scnp.fo.autorizacionpagos.autorizar.service.AutorizarHelperService;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl.ListaWarehouseHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerRequest;
import com.isban.scnp.fo.autorizacionpagos.rehacer.service.impl.RehacerServiceImpl;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.Silent.class)
public class RehacerHelperServiceUnitTest {
	
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private RehacerServiceImpl rehacerServiceImpl;
	
	@Mock
	private AsyncRestTemplate restTemplatePost;
	
	@Mock
	private HttpEntity<String> httpEntity;
	
	@Test
	public void rehacerTest_Pagos()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		ReflectionTestUtils.setField(rehacerServiceImpl, "urlBks", "http://wwww.any.com");
		
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(rehacerServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(any(),any(),any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);
		
		doCallRealMethod().when(rehacerServiceImpl).rehacerImpl(any());
		rehacerServiceImpl.rehacerImpl(getRequest("pagos"));		
		verify(rehacerServiceImpl, times(1)).rehacerImpl(any());
		
	}
	
	
	@Test
	public void rehacerTest_Pagos_OK()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		ReflectionTestUtils.setField(rehacerServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(any(),any(),any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);
		
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(rehacerServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withServerError());
		
		
		doCallRealMethod().when(rehacerServiceImpl).rehacerImpl(any());
		rehacerServiceImpl.rehacerImpl(getRequest("pagos"));		
		verify(rehacerServiceImpl, times(1)).rehacerImpl(any());	
	}
	
	@Test
	public void rehacerTest_Pagos_Fail()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		ReflectionTestUtils.setField(rehacerServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(any(),any(),any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);
		
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(rehacerServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess());
		
		doCallRealMethod().when(rehacerServiceImpl).rehacerImpl(any());
		rehacerServiceImpl.rehacerImpl(getRequest("pagos"));		
		verify(rehacerServiceImpl, times(1)).rehacerImpl(any());	
	}
	
	
	
	@Test
	public void rehacerTest_Lotes()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		ReflectionTestUtils.setField(rehacerServiceImpl, "urlBks", "http://wwww.any.com");
		
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(rehacerServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(any(),any(),any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);
		
		AutorizarHelperService autorizarHelperService = Mockito.mock(AutorizarHelperService.class);
		ReflectionTestUtils.setField(rehacerServiceImpl, "autorizarHelperService", autorizarHelperService); 
		Mockito.when(autorizarHelperService.obtenerListaNombres(anyString(), any())).thenReturn(listaNombrePagos());
		
		
		doCallRealMethod().when(rehacerServiceImpl).rehacerImpl(any());
		rehacerServiceImpl.rehacerImpl(getRequest("lotes"));		
		verify(rehacerServiceImpl, times(1)).rehacerImpl(any());
		
	}
	
	private List<String> listaNombrePagos() {
		List<String> nombresLotes = new ArrayList<>();
		nombresLotes.add("Lote1");
		nombresLotes.add("Lote2");
		nombresLotes.add("Lote3");
		return nombresLotes;
	}

	@Test
	public void rehacerTest_PagosNota()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		ReflectionTestUtils.setField(rehacerServiceImpl, "urlBks", "http://wwww.any.com");

		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(rehacerServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(any(),any(),any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(rehacerServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(anyString(), any(), anyString())).thenReturn(traducciones());
		
		
		doCallRealMethod().when(rehacerServiceImpl).rehacerImpl(any());
		rehacerServiceImpl.rehacerImpl(getRequest("pagosNota"));		
		verify(rehacerServiceImpl, times(1)).rehacerImpl(any());
		
	}
	
	@Test
	public void rehacerTest_LotesNota()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		ReflectionTestUtils.setField(rehacerServiceImpl, "urlBks", "http://wwww.any.com");

		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(rehacerServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(any(),any(),any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(rehacerServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(anyString(), any(), anyString())).thenReturn(traducciones());
		
		// Servicio autorizar
		AutorizarHelperService autorizarHelperService = Mockito.mock(AutorizarHelperService.class);
		ReflectionTestUtils.setField(rehacerServiceImpl, "autorizarHelperService", autorizarHelperService); 
		Mockito.when(autorizarHelperService.obtenerListaNombres(anyString(), any())).thenReturn(listaNombrePagos());
		
		doCallRealMethod().when(rehacerServiceImpl).rehacerImpl(any());
		rehacerServiceImpl.rehacerImpl(getRequest("lotesNota"));		
		verify(rehacerServiceImpl, times(1)).rehacerImpl(any());
		
	}

	private List<String> traducciones() {
		List<String> traducciones = new ArrayList<>();
		traducciones.add("Rehacer");
		return traducciones;
	}

	private RehacerRequest getRequest(String tipo) {
		RehacerRequest rehacer = new RehacerRequest();
		List<String> listaIds = new ArrayList<>();
		if ("pagos".equals(tipo)) {
			rehacer.setTipo("pagos");
			listaIds.add("SGP1812180000001");
			listaIds.add("SGP1812180000002");
			listaIds.add("SGP1812180000003");
		}else if ("lotes".equals(tipo)){
			rehacer.setTipo("lotes");
			listaIds.add("L201812180848590");
			listaIds.add("L201812180848591");
			listaIds.add("L201812180848592");
		}
		else if ("pagosNota".equals(tipo)){
			rehacer.setTipo("pagos");
			listaIds.add("SGP1812180000001");
			listaIds.add("SGP1812180000002");
			listaIds.add("SGP1812180000003");
			rehacer.setNota("Esto es una nota de pagos");
		}else if ("lotesNota".equals(tipo)){
			rehacer.setTipo("lotes");
			listaIds.add("L201812180848590");
			listaIds.add("L201812180848591");
			listaIds.add("L201812180848592");
			rehacer.setNota("Esto es una nota de lotes");
		}
		rehacer.setListaIds(listaIds);
		return rehacer;
		
	}
	
	
	
}
