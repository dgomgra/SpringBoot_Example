package com.isban.scnp.fo.autorizacionpagos.datosFirma.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaArchOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaLotesOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.impl.DatosFirmaHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DatosFirmaHelperServiceUnitBBDDTest {

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	DatosFirmaHelperServiceImpl datosFirmaHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/DatosFirmaSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/DatosFirmaPurge.sql"));
	}
	
	@Test
	public void getDatosFirmaPagosTest() {
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaPagos(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "jdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> listaId = new ArrayList<>();
		listaId.add("SGP1707260006979");
		String salidaOk = datosFirmaHelperServiceImpl.getDatosFirmaPagos(listaId);
		
		assertEquals(salidaOk, "145489645454545");
		
		listaId.clear();
		listaId.add("");
		String salidaNull = datosFirmaHelperServiceImpl.getDatosFirmaPagos(listaId);
		
		assertEquals(salidaNull, "0");
	}
	
	@Test
	public void getDatosFirmaLotesTest() {
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaLotes(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "jdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> listaId = new ArrayList<>();
		listaId.add("L201811190848366");
		DatosFirmaLotesOut salidaOk = datosFirmaHelperServiceImpl.getDatosFirmaLotes(listaId);
		
		assertNotNull(salidaOk.getImporte());
		assertNotNull(salidaOk.getNumPagos());
		
		listaId.clear();
		listaId.add("");
		DatosFirmaLotesOut salidaEmpty = datosFirmaHelperServiceImpl.getDatosFirmaLotes(listaId);
		
		assertNotNull(salidaEmpty.getImporte());
		assertNotNull(salidaEmpty.getNumPagos());
	}
	
	@Test
	public void getDatosFirmaArchTest() {
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaArch(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "jdbcTemplate", namedParameterJdbcTemplate);
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> listaId = new ArrayList<>();
		listaId.add("485");
		DatosFirmaArchOut salidaOk = datosFirmaHelperServiceImpl.getDatosFirmaArch(listaId);
		
		assertNotNull(salidaOk.getImporte());
		assertNotNull(salidaOk.getNumPagos());
		
		listaId.clear();
		listaId.add("0");
		DatosFirmaArchOut salidaEmpty = datosFirmaHelperServiceImpl.getDatosFirmaArch(listaId);
		
		assertNotNull(salidaEmpty.getImporte());
		assertNotNull(salidaEmpty.getNumPagos());	
	}
	
	@Test
	public void getDatosDigitosCuentaBenQueryTest() {
		Mockito.when(datosFirmaHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenCallRealMethod();
		
		NamedParameterJdbcTemplate jdbcMock = Mockito.mock(NamedParameterJdbcTemplate.class);
		
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "jdbcTemplate", jdbcMock);
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "schemaproc", schemaproc);
		
		List<DatosFirmaCuentaBenOut> salida = new ArrayList<>();
		
		Mockito.when(jdbcMock.query(Mockito.anyString(), Mockito.any(DatosFirmaCuentaBenMapper.class)))
		.thenReturn(salida);
		
		datosFirmaHelperServiceImpl.getDatosDigitosCuentaBenQuery("");

		
	}
	
	@Test
	public void getPaisPagoTest() {
		Mockito.when(datosFirmaHelperServiceImpl.getPaisPago(Mockito.anyString())).thenCallRealMethod();
		
		JdbcTemplate jdbcMock = Mockito.mock(JdbcTemplate.class);
		
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "jdbcTemplateSimple", jdbcMock);
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "schemaproc", schemaproc);
		
		String salida = "ES";
		
		datosFirmaHelperServiceImpl.getPaisPago("SGP1707260006979");

		
	}
}
