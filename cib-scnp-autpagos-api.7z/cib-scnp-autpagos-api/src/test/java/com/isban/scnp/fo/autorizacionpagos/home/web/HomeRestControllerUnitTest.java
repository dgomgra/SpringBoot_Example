package com.isban.scnp.fo.autorizacionpagos.home.web;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeRequest;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeResponseData;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.ArbolBalance;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.CodigoBic;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.CuentaArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.DatosPantalla;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.InicioMovilResponse;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.ListaMonedasArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.Listacuentasarbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.MethodResult;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.MonedaArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.PaisArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.Saldos;
import com.isban.scnp.fo.autorizacionpagos.home.service.HomeHelperService;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class HomeRestControllerUnitTest {
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Autowired
	private HomeRestController homeRestController;
    
    private MockMvc mockMvc;
    
    private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	private String cadena = "";
	
	@Before
    public void setup() throws Exception{
    	leerFichero();
        this.mockMvc = webAppContextSetup(webApplicationContext).build();     
    }
    
	@Test
	public void getHome() throws Exception {
		
		HomeHelperService homeHelperService = Mockito.mock(HomeHelperService.class);
		Mockito.when(homeHelperService.getHome(Mockito.any())).thenReturn(homeResponseOK());
		ReflectionTestUtils.setField(homeRestController, "homeHelperService", homeHelperService);
		
		String uri = "/authorization/v1/datosHome";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		
		verify(homeHelperService, times(1)).getHome(Mockito.any());
	}
	
	@Test
	public void getHomeSinMoneda() throws Exception {
		
		HomeHelperService homeHelperService = Mockito.mock(HomeHelperService.class);
		Mockito.when(homeHelperService.getHome(Mockito.any())).thenReturn(homeResponseOK());
		ReflectionTestUtils.setField(homeRestController, "homeHelperService", homeHelperService);
		
		String uri = "/authorization/v1/datosHome";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("sinMoneda"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		
		verify(homeHelperService, times(1)).getHome(Mockito.any());
	}
	
	@Test
	public void getHomeException() throws Exception {
		
		HomeHelperService homeHelperService = Mockito.mock(HomeHelperService.class);
		Mockito.when(homeHelperService.getHome(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
		ReflectionTestUtils.setField(homeRestController, "homeHelperService", homeHelperService);
		
		String uri = "/authorization/v1/datosHome";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("sinMoneda"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isInternalServerError())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		verify(homeHelperService, times(1)).getHome(Mockito.any());
	}

	@Test
	public void getHomeTest_KOCredencial() throws Exception {
		HomeHelperService homeHelperService = Mockito.mock(HomeHelperService.class);
		Mockito.when(homeHelperService.getHome(Mockito.any())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		ReflectionTestUtils.setField(homeRestController, "homeHelperService", homeHelperService);
		
		String uri = "/authorization/v1/datosHome";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("sinMoneda"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isUnauthorized())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		verify(homeHelperService, times(1)).getHome(Mockito.any());
	}
	
	@Test
	public void getHomeTest_KOOtro() throws Exception {
		HomeHelperService homeHelperService = Mockito.mock(HomeHelperService.class);
		Mockito.when(homeHelperService.getHome(Mockito.any())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		ReflectionTestUtils.setField(homeRestController, "homeHelperService", homeHelperService);
		
		String uri = "/authorization/v1/datosHome";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("sinMoneda"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isInternalServerError())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		verify(homeHelperService, times(1)).getHome(Mockito.any());
	}
	
	
	@Test
	public void getHome_Balances() throws Exception {
		
		HomeHelperService homeHelperService = Mockito.mock(HomeHelperService.class);
		Mockito.when(homeHelperService.getHome(Mockito.any())).thenReturn(homeResponseBalances());
		ReflectionTestUtils.setField(homeRestController, "homeHelperService", homeHelperService);
		
		String uri = "/authorization/v1/datosHome";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		verify(homeHelperService, times(1)).getHome(Mockito.any());
	}
	
	
	private HomeResponseData homeResponseBalances() {
		HomeResponseData homeResponse = new HomeResponseData();
		InicioMovilResponse inicioMovil = balancesMovilResponse();
		homeResponse.setInicioMovil(inicioMovil);
		homeResponse.setStatus("OK");
		return homeResponse;
	}

	private HomeResponseData homeResponseOK() {
		HomeResponseData homeResponse = new HomeResponseData();
		homeResponse.setStatus("OK");
		return homeResponse;
	}

	private InicioMovilResponse balancesMovilResponse() {
		InicioMovilResponse imr = new InicioMovilResponse();
		MethodResult methodRes = new MethodResult();
		methodRes.setStatus("OK");
		DatosPantalla datosPantalla = new DatosPantalla();
		Saldos saldos = new Saldos();
		List<ArbolBalance> arbolBalances = new ArrayList<>();
		ArbolBalance arbol = new ArbolBalance();
		PaisArbol paisArbol = new PaisArbol();
		paisArbol.setCodPais("ES");
		paisArbol.setDivisaUsuario("EUR");
		List<ListaMonedasArbol> listasMonedasArbol = new ArrayList<>();
		ListaMonedasArbol listaMonedaArbol = new ListaMonedasArbol();
		MonedaArbol monedaArbol = new MonedaArbol();
		monedaArbol.setDivisaCuenta("EUR");
		List<Listacuentasarbol> listascuentasarbol = new ArrayList<>();
		Listacuentasarbol listaCuentaArbol = new Listacuentasarbol();
		CuentaArbol cuenta = new CuentaArbol();
		cuenta.setAliasCuentaPerfilado("alias");
		cuenta.setAliasEntidad("entidad");
		cuenta.setBookBalance(String.valueOf(new BigDecimal(30)));
		cuenta.setBookDate("05/11/2015");
		CodigoBic bic = new CodigoBic();
		bic.setBRANCH("XXX");
		bic.setLOCATORBIC("BO");
		bic.setENTIDADBIC("BSCH");
		bic.setPAISBIC("ES");
		cuenta.setCodigoBic(bic);
		cuenta.setCodigoCuenta(1230);
		cuenta.setCuentaExtracto("ESDASADAS");
		cuenta.setDivisa("EUR");
		cuenta.setNombreEmisora("BANCO SANTANDER");
		cuenta.setValueBalance(String.valueOf(new BigDecimal(30)));
		cuenta.setValueDate("05/11/2015");
		listaCuentaArbol.setCuentaArbol(cuenta);
		listascuentasarbol.add(listaCuentaArbol);
		monedaArbol.setListacuentasarbol(listascuentasarbol );
		monedaArbol.setSumBookBalance(String.valueOf(new BigDecimal(40)));
		monedaArbol.setSumValueBalance(String.valueOf(new BigDecimal(30)));
		listaMonedaArbol.setMonedaArbol(monedaArbol);
		listasMonedasArbol.add(listaMonedaArbol);
		paisArbol.setListaMonedasArbol(listasMonedasArbol);
		arbol.setPaisArbol(paisArbol);
		arbolBalances.add(arbol);
		saldos.setArbolBalances(arbolBalances);
		saldos.setDescripcionConversion("USD=1,07659 31/12/2017; GBP=1,07659 31/12/2017; ARS=10,267 05/01/2015; MXN=17,857 05/01/2015; CLP=737,08 05/01/2015; AUD=0,7782 13/09/2018; BRL=3,2571 05/01/2015");
		datosPantalla.setSaldos(saldos);
		methodRes.setDatosPantalla(datosPantalla);
		imr.setMethodResult(methodRes);
		return imr;
	}

	private HomeRequest rellenarEntrada(String tipo) {
		HomeRequest salida = new HomeRequest();

		if("ok".equals(tipo)) {    		
			String moneda = JsonPath.read(jsonFile, "$.ejecucionOK.monConsolidacion");
			String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
			salida.setMonConsolidacion(moneda);
			salida.setTokenBks(tokenBks);
		}
		else if("sinMoneda".equals(tipo)) {
			String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
			salida.setTokenBks(tokenBks);
		}else {
			String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
			salida.setTokenBks(tokenBks);
		}

		return salida;
	}
	
	
	private void leerFichero() {
		try {
			File file = new File("src/test/resources/json/HomeRestControllerUnitTest.json");
			fe = new FileInputStream(file);
			isr = new InputStreamReader(fe);
			br = new BufferedReader(isr);

			while((cadena = br.readLine()) != null){
				System.out.println(cadena);
				jsonFile = jsonFile.concat(cadena);
			}

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}



}
