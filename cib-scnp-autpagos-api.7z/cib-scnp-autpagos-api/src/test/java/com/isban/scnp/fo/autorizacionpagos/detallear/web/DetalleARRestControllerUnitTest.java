package com.isban.scnp.fo.autorizacionpagos.detallear.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DatosArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARRequest;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleARResponse;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.service.impl.DetalleARHelperServiceImpl;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DetalleARRestControllerUnitTest {
	
	
	@Autowired
    private WebApplicationContext webApplicationContext;
    
    @Autowired
	private DetalleARRestController detalleArRestController;
    
    private MockMvc mockMvc;
    
	private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	private String cadena = "";
    

	@Before
	public void setup() throws Exception{
		leerFichero();
		this.mockMvc = webAppContextSetup(webApplicationContext).build();     
	}

	@Test
	public void detalleARTest_OK() throws Exception {
		DetalleARHelperServiceImpl detalleARHelperServiceImpl = Mockito.mock(DetalleARHelperServiceImpl.class);
		ReflectionTestUtils.setField(detalleArRestController, "detalleARHelperService", detalleARHelperServiceImpl);
		
		when(detalleARHelperServiceImpl.getDetalleARImpl(Mockito.any())).thenReturn(respuesta("OK"));		
			
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/detalleAR";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
	}
	
	@Test
	public void detalleARTest_KO() throws Exception {
		DetalleARHelperServiceImpl detalleARHelperServiceImpl = Mockito.mock(DetalleARHelperServiceImpl.class);
		ReflectionTestUtils.setField(detalleArRestController, "detalleARHelperService", detalleARHelperServiceImpl);
				
		when(detalleARHelperServiceImpl.getDetalleARImpl(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/detalleAR";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
	}
	
	@Test
	public void detalleARTest_KOCredencial() throws Exception {
		DetalleARHelperServiceImpl detalleARHelperServiceImpl = Mockito.mock(DetalleARHelperServiceImpl.class);
		ReflectionTestUtils.setField(detalleArRestController, "detalleARHelperService", detalleARHelperServiceImpl);
		
		
		when(detalleARHelperServiceImpl.getDetalleARImpl(Mockito.any())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/detalleAR";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
	}
	
	@Test
	public void detalleARTest_KOOtro() throws Exception {
		DetalleARHelperServiceImpl detalleARHelperServiceImpl = Mockito.mock(DetalleARHelperServiceImpl.class);
		ReflectionTestUtils.setField(detalleArRestController, "detalleARHelperService", detalleARHelperServiceImpl);
		
		
		when(detalleARHelperServiceImpl.getDetalleARImpl(Mockito.any())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/detalleAR";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
	}
	
	
	
	private DetalleARRequest rellenarEntrada(String tipo) {
		DetalleARRequest request = new DetalleARRequest();
		if("ok".equals(tipo)) {   
			int id = JsonPath.read(jsonFile, "$.ejecucionOK.idArchivo");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
    		request.setIdArchivo(id);
    		request.setTokenBks(tokenBks);
		}
		else if ("ko".equals(tipo))
		{
			int id = JsonPath.read(jsonFile, "$.ejecucionKO.idArchivo");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionKO.tokenBks");
    		request.setIdArchivo(id);
    		request.setTokenBks(tokenBks);
		}
		return request;
	}

	private DetalleARResponse respuesta(String string) {
		DetalleARResponse respuestaOK = new DetalleARResponse();
		DetalleArchivo detalle = new DetalleArchivo();
		detalle.setEstadoArchivo("E1");
		detalle.setDescEstado("Parcialmente autorizado");
		detalle.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000004");
		detalle.setNumTransac(1);
		detalle.setDivisa("EUR");
		detalle.setMotivoRechazo(null);
		respuestaOK.setDetalleArchivo(detalle);
		
		List<DatosArchivo> listaDatosArchivo = new ArrayList<>();
		DatosArchivo datosArchivo = new DatosArchivo();
		datosArchivo.setPais("ES");
		datosArchivo.setNumTransac(1);
		datosArchivo.setDivisa("EUR");
		listaDatosArchivo.add(datosArchivo);
		
		respuestaOK.setListaDatosArchivo(listaDatosArchivo);
		
		respuestaOK.setStatus("OK");
		respuestaOK.setMessage("Operación realizada correctamente");
		
		return respuestaOK;
	}

	private void leerFichero() {
    	try {
    		File file = new File("src/test/resources/json/DetalleARRestControllerUnitTest.json");
			fe = new FileInputStream(file);
			isr = new InputStreamReader(fe);
			br = new BufferedReader(isr);
			
			while((cadena = br.readLine()) != null){
				System.out.println(cadena);
				jsonFile = jsonFile.concat(cadena);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
    }
	
}
