package com.isban.scnp.fo.autorizacionpagos.datosFirma.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaRequest;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaResponse;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.DatosFirmaHelperService;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.impl.DatosFirmaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.detallear.service.impl.DetalleARHelperServiceImpl;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DatosFirmaRestControllerUnitTest {

	@Autowired
    private WebApplicationContext webApplicationContext;
	
	@Autowired
	DatosFirmaRestController datosFirmaRestController;
	
    private MockMvc mockMvc;
    
	private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	private String cadena = "";
	
    @Before
    public void setup() throws Exception{
    	leerFichero();
        this.mockMvc = webAppContextSetup(webApplicationContext).build();     
    }
    
    @Test
    public void getDatosFirmaPagosOkTest() throws Exception{
    	
    	// Se rellenan los datos para DatosFirmaResponse
    	DatosFirmaResponse datosFirmaResponse  = rellenarDatosFirma("OK");
    	
    	DatosFirmaHelperService datosFirmaHelperService = Mockito.mock(DatosFirmaHelperService.class);
    	Mockito.when(datosFirmaHelperService.getDatosFirma(Mockito.any())).thenReturn(datosFirmaResponse);
    	ReflectionTestUtils.setField(datosFirmaRestController, "datosFirmaHelperService", datosFirmaHelperService);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/datosParaFirma";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
    	
    }
    
    @Test
    public void getDatosFirmaPagosKoTest() throws Exception{
    	
    	// Se rellenan los datos para DatosFirmaResponse
    	DatosFirmaResponse datosFirmaResponse  = rellenarDatosFirma("KO");
    	
    	DatosFirmaHelperService datosFirmaHelperService = Mockito.mock(DatosFirmaHelperService.class);
    	Mockito.when(datosFirmaHelperService.getDatosFirma(Mockito.any())).thenReturn(datosFirmaResponse);
    	ReflectionTestUtils.setField(datosFirmaRestController, "datosFirmaHelperService", datosFirmaHelperService);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/datosParaFirma";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
    	
    }
    
    @Test
    public void getDatosFirmaPagosExcepTest() throws Exception{
    	
    	// Se rellenan los datos para DatosFirmaResponse
    	DatosFirmaResponse datosFirmaResponse  = rellenarDatosFirma("KO");
    	
    	DatosFirmaHelperService datosFirmaHelperService = Mockito.mock(DatosFirmaHelperService.class);
    	Exception ex = new Exception();
    	Mockito.when(datosFirmaHelperService.getDatosFirma(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
    	ReflectionTestUtils.setField(datosFirmaRestController, "datosFirmaHelperService", datosFirmaHelperService);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
    	
    	String uri = "/authorization/v1/datosParaFirma";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
    	
    }
    
    @Test
	public void datosFirmaPagosTest_KOCredencial() throws Exception {
    	DatosFirmaHelperServiceImpl datosFirmaHelperServiceImpl = Mockito.mock(DatosFirmaHelperServiceImpl.class);
		
		ReflectionTestUtils.setField(datosFirmaRestController, "datosFirmaHelperService", datosFirmaHelperServiceImpl);
		
		
		when(datosFirmaHelperServiceImpl.getDatosFirma(Mockito.any())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/datosParaFirma";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
	}
	
	@Test
	public void datosFirmaPagosTest_KOOtro() throws Exception {
		DatosFirmaHelperServiceImpl datosFirmaHelperServiceImpl = Mockito.mock(DatosFirmaHelperServiceImpl.class);
		ReflectionTestUtils.setField(datosFirmaRestController, "datosFirmaHelperService", datosFirmaHelperServiceImpl);
		
		
		when(datosFirmaHelperServiceImpl.getDatosFirma(Mockito.any())).thenThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
		
		ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/datosParaFirma";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());
		
	}
    
    private void leerFichero() {
    	try {
    		File file = new File("src/test/resources/json/DatoFirmaControllerUnitTest.json");
			fe = new FileInputStream(file);
			isr = new InputStreamReader(fe);
			br = new BufferedReader(isr);
			
			while((cadena = br.readLine()) != null){
				System.out.println(cadena);
				jsonFile = jsonFile.concat(cadena);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
    }
    
    private DatosFirmaResponse rellenarDatosFirma(String tipoPrueba) {
    	DatosFirmaResponse salida = new DatosFirmaResponse();
    	
    	if("OK".equalsIgnoreCase(tipoPrueba)) {    		
    		salida.setStatus("OK");
    	}else {
    		salida.setStatus("KO");
    	}
    	
    	return salida;
    	
    }
    
    private DatosFirmaRequest rellenarEntrada(String tipoCons) {
    	DatosFirmaRequest salida = new DatosFirmaRequest();
    	
    	if("ok".equals(tipoCons)) {    		
    		String tipo = JsonPath.read(jsonFile, "$.ejecucionOK.tipo");
    		List<String> listaIds = JsonPath.read(jsonFile, "$.ejecucionOK.listaIds");
    		
    		salida.setTipo(tipo);
    		salida.setListaIds(listaIds);

    	}else {
    		String tipo = JsonPath.read(jsonFile, "$.ejecucionKO.tipo");
    		List<String> listaIds = JsonPath.read(jsonFile, "$.ejecucionKO.listaIds");
    		
    		salida.setTipo(tipo);
    		salida.setListaIds(listaIds);
    	}
    	
    	return salida;
    }
}
