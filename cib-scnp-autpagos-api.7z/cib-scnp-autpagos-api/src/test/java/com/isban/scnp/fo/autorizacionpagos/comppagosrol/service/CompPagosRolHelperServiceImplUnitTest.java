package com.isban.scnp.fo.autorizacionpagos.comppagosrol.service;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaIn;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.IdPagoCodCuenta;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtCuentaPagosOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolFirmadoOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.ObtPagosSentRolOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.impl.CompPagosRolHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.CuentasArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaCuentasArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPaisArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPermisosMetPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaServiciosAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PaisArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PermisosMetPagoArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ServicioPaisAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.DetPerfiladoUsuarioHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;

@RunWith(MockitoJUnitRunner.class)
public class CompPagosRolHelperServiceImplUnitTest {

	@Mock
	private CompPagosRolHelperServiceImpl compPagosRolHelperServiceImpl;
	
	@Mock
	private DetPerfiladoUsuarioHelperService detPerfiladoUsuarioHelperService;
	
	@Mock
	private ListaPagosHelperService listaPagosHelperService;
	
	@Test
	public void compPagosRolUsuPendFirmaTest() {
		
		// Retorno de detPerfiladoUsuario
		DetPerfiladoUsuarioResponse datosPerfilado = new DetPerfiladoUsuarioResponse();
		DetPerfiladoUsuarioOut detPerfiladoUsuarioOut = new DetPerfiladoUsuarioOut();
		datosPerfilado.setMethodResult(detPerfiladoUsuarioOut);
		
		// Retorno de obtCuentaPagos
		List<ObtCuentaPagosOut> listaCuentasPagos = new ArrayList<>();
		ObtCuentaPagosOut obtCuentaPagosOut = new ObtCuentaPagosOut();
		listaCuentasPagos.add(obtCuentaPagosOut);
		
		// Retorno de compPermCta
		List<IdPagoCodCuenta> listaPagosYCuentas = new ArrayList<>();
		IdPagoCodCuenta idPagoCodCuenta = new IdPagoCodCuenta();
		listaPagosYCuentas.add(idPagoCodCuenta);
		
		// Retorno de obtPagosFirmaOKUsuario
		List<String> pagosYaFirmados = new ArrayList<>();
		
		// Retorno de filtraPagosFirmados
		List<String> listaPagosTemp = new ArrayList<>();
		
		// Retorno de obtPagosSentRol
		List<ObtPagosSentRolOut> pagosSentRol = new ArrayList<>();
		
		// Retorno de obtPagosSentRolFirmado
		List<ObtPagosSentRolFirmadoOut> pagosSentRolFirmado = new ArrayList<>();
		
		// Retorno de comprobarRoles
		List<CompPagosRolUsuPendFirmaOut> comprobarRolesOut = new ArrayList<>();
		CompPagosRolUsuPendFirmaOut compPagosRolUsuPendFirmaOut = new CompPagosRolUsuPendFirmaOut();
		compPagosRolUsuPendFirmaOut.setRftrans("SGP1811150000038");
		compPagosRolUsuPendFirmaOut.setCodSentencia(147);
		compPagosRolUsuPendFirmaOut.setIdAutorizacion(321);
		comprobarRolesOut.add(compPagosRolUsuPendFirmaOut);
		
		Mockito.when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(datosPerfilado);
		ReflectionTestUtils.setField(compPagosRolHelperServiceImpl, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);
		Mockito.when(compPagosRolHelperServiceImpl.obtCuentaPagos(any())).thenReturn(listaCuentasPagos);
		Mockito.when(compPagosRolHelperServiceImpl.compPermCta(any(), any(), any())).thenReturn(listaPagosYCuentas);
		Mockito.when(compPagosRolHelperServiceImpl.obtPagosFirmaOKUsuarioInt(anyString(), any())).thenReturn(pagosYaFirmados);
		Mockito.when(compPagosRolHelperServiceImpl.filtraPagosFirmados(any(), any())).thenReturn(listaPagosTemp);
		Mockito.when(compPagosRolHelperServiceImpl.obtPagosSentRol(any())).thenReturn(pagosSentRol);
		Mockito.when(compPagosRolHelperServiceImpl.obtPagosSentRolFirmado(any())).thenReturn(pagosSentRolFirmado);
		Mockito.when(compPagosRolHelperServiceImpl.comprobarRoles(any(), any(), any())).thenReturn(comprobarRolesOut);
		Mockito.when(compPagosRolHelperServiceImpl.compPagosRolUsuPendFirma(any())).thenCallRealMethod();
		
		// Datos de entrada de la operacion
		CompPagosRolUsuPendFirmaIn compPagosRolUsuPendFirmaIn = new CompPagosRolUsuPendFirmaIn();
		compPagosRolUsuPendFirmaIn.setListaIdPago(new ArrayList<String>());
		compPagosRolUsuPendFirmaIn.setPagosVerActivos("SGP0000001, SGP0000002");
		compPagosRolUsuPendFirmaIn.setUid("UID");
		compPagosRolUsuPendFirmaIn.setTokenBks("TOKEN");
		List<CompPagosRolUsuPendFirmaOut> salida = compPagosRolHelperServiceImpl.compPagosRolUsuPendFirma(compPagosRolUsuPendFirmaIn);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.get(0).getCodSentencia(), notNullValue());
		assertThat(salida.get(0).getIdAutorizacion(), notNullValue());
		assertThat(salida.get(0).getRftrans(), notNullValue());
		
		// Consulta con la lista vacia
		listaCuentasPagos.clear();
		salida = compPagosRolHelperServiceImpl.compPagosRolUsuPendFirma(compPagosRolUsuPendFirmaIn);
		
		// Verificamos que se ha llamado al metodo 2 veces
		verify(compPagosRolHelperServiceImpl, times(2)).compPagosRolUsuPendFirma(any());
		
		// Verificamos que no retorne un lista vacia
		assertEquals(salida.size(), 0);
		
	}
	
	@Test
	public void compPermCtaTest() {
		
		Mockito.when(compPagosRolHelperServiceImpl.compPermCta(any(), any(), anyString())).thenCallRealMethod();
		
		// Datos de entrada de la operacion
		DetPerfiladoUsuarioResponse perfilado = rellenarDAtosPerfilado();
		
		List<ObtCuentaPagosOut> listaCuentasPagos = new ArrayList<>();
		ObtCuentaPagosOut obtCuentaPagosOut = new ObtCuentaPagosOut();
		obtCuentaPagosOut.setAcuencod(1234);
		obtCuentaPagosOut.setRftrans("SGP1811150000038");
		listaCuentasPagos.add(obtCuentaPagosOut);
		
		String pagosVerActivos = "S";
		
		// Consulta Ok con tipo de permiso apr
		List<IdPagoCodCuenta> salida = compPagosRolHelperServiceImpl.compPermCta(perfilado, listaCuentasPagos, pagosVerActivos);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.get(0).getAcuencot(), notNullValue());
		assertThat(salida.get(0).getRftrans(), notNullValue());
		
		// Consulta Ok con tipo de permiso ver
		perfilado.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().setCodPermiso("ver");
		salida = compPagosRolHelperServiceImpl.compPermCta(perfilado, listaCuentasPagos, pagosVerActivos);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.get(0).getAcuencot(), notNullValue());
		assertThat(salida.get(0).getRftrans(), notNullValue());
		
		// Consulta con un tipo de permiso distinto de apr y ver
		perfilado.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().setCodPermiso("fir");
		salida = compPagosRolHelperServiceImpl.compPermCta(perfilado, listaCuentasPagos, pagosVerActivos);
		
		// Verificamos que la lista esta vacia
		assertEquals(salida.size(), 0);
		
		// Consulta con el indicador de ver activos a N y con permiso apr
		pagosVerActivos = "N";
		perfilado.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().setCodPermiso("apr");
		salida = compPagosRolHelperServiceImpl.compPermCta(perfilado, listaCuentasPagos, pagosVerActivos);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.get(0).getAcuencot(), notNullValue());
		assertThat(salida.get(0).getRftrans(), notNullValue());
		
		// Consulta con el indicador de ver activos a N y con permiso ver
		perfilado.getMethodResult().getListadoServicios().get(0).getServicio().getListaPais().get(0).getPais().getListaCuentas().get(0).getCuentasArbol().getPermisosSubprod().get(0).getPermisosSubprod().setCodPermiso("ver");
		salida = compPagosRolHelperServiceImpl.compPermCta(perfilado, listaCuentasPagos, pagosVerActivos);
		
		// Verificamos que la lista esta vacia
		assertEquals(salida.size(), 0);
		
		// Consulta con un codigo de servicio distinto de Pagos (PA)
		perfilado.getMethodResult().getListadoServicios().get(0).getServicio().setCodServicio("RE");
		salida = compPagosRolHelperServiceImpl.compPermCta(perfilado, listaCuentasPagos, pagosVerActivos);
		
		// Verificamos que la lista esta vacia
		assertEquals(salida.size(), 0);
		
		// Verificamos que se ha llamado al metodo 6 veces
		verify(compPagosRolHelperServiceImpl, times(6)).compPermCta(any(), any(), anyString());
	}
	
	@Test
	public void filtraPagosFirmadosTest() {
		Mockito.when(compPagosRolHelperServiceImpl.filtraPagosFirmados(any(), any())).thenCallRealMethod();
		
		// Datos de entrada de la operacion
		List<String> listaPagosSinFiltrar = new ArrayList<>();
		listaPagosSinFiltrar.add("SGP1503020000001");
		listaPagosSinFiltrar.add("SGP1503020000002");
		listaPagosSinFiltrar.add("SGP1503020000003");
		listaPagosSinFiltrar.add("SGP1503020000004");
		listaPagosSinFiltrar.add("SGP1503020000005");
		List<String> listaPagosFirmados = new ArrayList<>();
		listaPagosFirmados.add("SGP1503020000003");
		listaPagosFirmados.add("SGP1503020000004");
		
		// Consulta con pagos firmados previamente
		List<String> salida = compPagosRolHelperServiceImpl.filtraPagosFirmados(listaPagosSinFiltrar, listaPagosFirmados);
		
		// Verificamos que la lista de pagos final es de 3
		assertEquals(salida.size(), 3);
		
		// Consulta sin pagos firmados previamente
		listaPagosFirmados.clear();
		salida = compPagosRolHelperServiceImpl.filtraPagosFirmados(listaPagosSinFiltrar, listaPagosFirmados);
		
		// Verificamos que la lista de pagos final es de 5
		assertEquals(salida.size(), 5);
		
		// Verificamos que se ha llamado al metodo 2 veces
		verify(compPagosRolHelperServiceImpl, times(2)).filtraPagosFirmados(any(), any());
	}
	
	@Test
	public void comprobarRolesTest() {
		
		// Retorno de sumaOrAnadeRolesPago
		List<ObtPagosSentRolOut> pagosAux = RellenarPagosSentRol(1);
		
		Mockito.when(compPagosRolHelperServiceImpl.calculaFirmasRol(any(), anyInt())).thenReturn(1);
		Mockito.when(compPagosRolHelperServiceImpl.sumaOrAnadeRolesPago(any(), any())).thenReturn(pagosAux);
		Mockito.when(compPagosRolHelperServiceImpl.comprobarRoles(any(), any(), any())).thenCallRealMethod();
		
		// Datos de entrada de la operacion
		List<ObtPagosSentRolOut> pagosSenRol = RellenarPagosSentRol(1);
		List<ObtPagosSentRolFirmadoOut> sentenciasFirmas = RellenarsentenciasFirmas();
		
		DetPerfiladoUsuarioResponse perfilado = new DetPerfiladoUsuarioResponse();
		DetPerfiladoUsuarioOut detPerfiladoUsuarioOut = new DetPerfiladoUsuarioOut();
		detPerfiladoUsuarioOut.setCodigoRol(1);
		perfilado.setMethodResult(detPerfiladoUsuarioOut);
		
		// Prueba 1: Consulta con un pago no firmado y una unica sentencia de pago
		List<CompPagosRolUsuPendFirmaOut> salida = compPagosRolHelperServiceImpl.comprobarRoles(pagosSenRol, sentenciasFirmas, perfilado);
		
		// Verificamos que la lista de salida tiene el pago pendiente de firmar
		assertThat(salida.get(0).getRftrans(), notNullValue());
		assertThat(salida.get(0).getCodSentencia(), notNullValue());
		assertThat(salida.get(0).getIdAutorizacion(), notNullValue());
		
		// Prueba 2: Consulta con un pago que ya esta firmado previamente
		pagosSenRol = RellenarPagosSentRol(2);
		sentenciasFirmas = RellenarsentenciasFirmas();
		salida = compPagosRolHelperServiceImpl.comprobarRoles(pagosSenRol, sentenciasFirmas, perfilado);
		
		// Verificamos que la lista de salida no contiene ningun pago para firmar
		assertEquals(salida.size(), 0);
		
		// Prueba 3: Consulta con un pago que tiene que ser firmado por mas de un rol
		pagosSenRol = RellenarPagosSentRol(3);
		sentenciasFirmas = RellenarsentenciasFirmas();
		salida = compPagosRolHelperServiceImpl.comprobarRoles(pagosSenRol, sentenciasFirmas, perfilado);
		
		// Verificamos que la lista de salida tiene el pago pendiente de firmar
		assertThat(salida.get(0).getRftrans(), notNullValue());
		assertThat(salida.get(0).getCodSentencia(), notNullValue());
		assertThat(salida.get(0).getIdAutorizacion(), notNullValue());
		
		// Prueba 4: Consulta con un pago que necesita mas de una firma del mismo rol
		pagosSenRol = RellenarPagosSentRol(4);
		sentenciasFirmas = RellenarsentenciasFirmas();
		salida = compPagosRolHelperServiceImpl.comprobarRoles(pagosSenRol, sentenciasFirmas, perfilado);
		
		// Verificamos que la lista de salida no contiene ningun pago para firmar
		assertEquals(salida.size(), 0);
		
		// Prueba 5: Consulta con mas de un pago
		pagosSenRol = RellenarPagosSentRol(5);
		sentenciasFirmas = RellenarsentenciasFirmas();
		salida = compPagosRolHelperServiceImpl.comprobarRoles(pagosSenRol, sentenciasFirmas, perfilado);
		
		// Verificamos que la lista de salida tiene el pago pendiente de firmar
		assertThat(salida.get(0).getRftrans(), notNullValue());
		assertThat(salida.get(0).getCodSentencia(), notNullValue());
		assertThat(salida.get(0).getIdAutorizacion(), notNullValue());
		
		// Verificamos que se ha llamado al metodo 5 veces 
		verify(compPagosRolHelperServiceImpl, times(5)).comprobarRoles(any(), any(), any());
	}
	
	@Test
	public void sumaOrAnadeRolesPagoTest() {
		Mockito.when(compPagosRolHelperServiceImpl.sumaOrAnadeRolesPago(any(), any())).thenCallRealMethod();
		
		// Datos de entrada de la operacion
		ObtPagosSentRolOut sentencia = new ObtPagosSentRolOut();
		sentencia.setAtipagru("O");
		sentencia.setAnordengrp(1);
		sentencia.setRol(1);
		sentencia.setAnumfirm(3);
		
		List<ObtPagosSentRolOut> listaSentencia = RellenarPagosSentRol(1);
		
		// Prueba 1: Consulta con el valor atipagru a O
		List<ObtPagosSentRolOut> salida = compPagosRolHelperServiceImpl.sumaOrAnadeRolesPago(sentencia, listaSentencia);
		
		// Verificamos que el valor de anumFirm es igual a la suma de los valores que tiene sentencia y listaSentencia
		assertEquals(salida.get(0).getAnumfirm(), 4);
		
		// Prueba 2: Consulta con el valor atipagru a A
		sentencia.setAtipagru("A");
		listaSentencia = RellenarPagosSentRol(1);
		salida = compPagosRolHelperServiceImpl.sumaOrAnadeRolesPago(sentencia, listaSentencia);
		
		// Verificamos que el valor de anumFirm es igual al que tiene mayor valor de sentencia y listaSentencia
		assertEquals(salida.get(0).getAnumfirm(), 3);
		
		// Prueba 3: Consulta con el valor atipagru que no existe
		sentencia.setAtipagru("X");
		listaSentencia = RellenarPagosSentRol(1);
		salida = compPagosRolHelperServiceImpl.sumaOrAnadeRolesPago(sentencia, listaSentencia);
		
		// Verificamos que se ha añadido una nueva sentencia
		assertEquals(salida.size(), 2);
		
		// Verificamos que se ha llamado al metodo 3 veces
		verify(compPagosRolHelperServiceImpl, times(3)).sumaOrAnadeRolesPago(any(), any());
	}
	
	@Test
	public void calculaFirmasRolTest() {
		Mockito.when(compPagosRolHelperServiceImpl.calculaFirmasRol(any(), anyInt())).thenCallRealMethod();
		
		// Datos de entrada de la operacion
		List<ObtPagosSentRolOut> listaSentencia = RellenarPagosSentRol(5);
		
		// Prueba 1: Consulta de firmas con sentencias del mismo rol
		int salida = compPagosRolHelperServiceImpl.calculaFirmasRol(listaSentencia, 1);
		
		// Verificamos que se ha obtenido un valor mayor que 0
		assertEquals(salida, 11);
		
		// Prueba 2: Consulta de firmas con sentencias de un rol distinto
		salida = compPagosRolHelperServiceImpl.calculaFirmasRol(listaSentencia, 2);
		
		// Verificamos que se ha obtenido un valor 0
		assertEquals(salida, 0);
		
		// Verificamos que se ha llamado al metodo
		verify(compPagosRolHelperServiceImpl, times(2)).calculaFirmasRol(any(), anyInt());
	}
	
	private DetPerfiladoUsuarioResponse rellenarDAtosPerfilado() {
		DetPerfiladoUsuarioResponse salida = new DetPerfiladoUsuarioResponse();
		DetPerfiladoUsuarioOut detPerfiladoUsuarioOut = new DetPerfiladoUsuarioOut();
		List<ListaServiciosAR> listadoServicios = new ArrayList<>();
		ListaServiciosAR listaServiciosAR = new ListaServiciosAR();
		ServicioPaisAR servicioPaisAR = new ServicioPaisAR();
		servicioPaisAR.setCodServicio("PA");
		List<ListaPaisArbol> listaPais = new ArrayList<>();
		ListaPaisArbol listaPaisArbol = new ListaPaisArbol();
		PaisArbol paisArbol = new PaisArbol();
		List<ListaCuentasArbol> listaCuentas = new ArrayList<>();
		ListaCuentasArbol listaCuentasArbol = new ListaCuentasArbol();
		CuentasArbol cuentasArbol = new CuentasArbol();
		List<ListaPermisosMetPagoArbol> permisosSubprod = new ArrayList<>();
		ListaPermisosMetPagoArbol listaPermisosMetPagoArbol = new ListaPermisosMetPagoArbol();
		PermisosMetPagoArbol permisosMetPagoArbol = new PermisosMetPagoArbol();
		permisosMetPagoArbol.setCodPermiso("apr");
		listaPermisosMetPagoArbol.setPermisosSubprod(permisosMetPagoArbol);
		permisosSubprod.add(listaPermisosMetPagoArbol);
		permisosSubprod.add(listaPermisosMetPagoArbol);
		cuentasArbol.setPermisosSubprod(permisosSubprod);
		cuentasArbol.setCodigoCuenta(1234);
		listaCuentasArbol.setCuentasArbol(cuentasArbol);
		listaCuentas.add(listaCuentasArbol);
		paisArbol.setListaCuentas(listaCuentas);
		listaPaisArbol.setPais(paisArbol);
		listaPais.add(listaPaisArbol);
		servicioPaisAR.setListaPais(listaPais);
		listaServiciosAR.setServicio(servicioPaisAR);
		listadoServicios.add(listaServiciosAR);
		detPerfiladoUsuarioOut.setListadoServicios(listadoServicios);
		salida.setMethodResult(detPerfiladoUsuarioOut);
		
		return salida;
	}
	
	private List<ObtPagosSentRolOut> RellenarPagosSentRol(int caso) {
		List<ObtPagosSentRolOut> salida = new ArrayList<>();
		
		if(caso == 1) {
			ObtPagosSentRolOut obtPagosSentRolOut = new ObtPagosSentRolOut();			
			obtPagosSentRolOut.setRftrans("SGP1707210000128");
			obtPagosSentRolOut.setRol(1);
			obtPagosSentRolOut.setIdComp("N");
			obtPagosSentRolOut.setCodSentencia(1);
			obtPagosSentRolOut.setIdAutorizacion(7117798);
			obtPagosSentRolOut.setAnorden(1);
			obtPagosSentRolOut.setAnumfirm(1);
			obtPagosSentRolOut.setAtipagru("A");
			obtPagosSentRolOut.setTament(1);
			obtPagosSentRolOut.setAnordengrp(1);
			salida.add(obtPagosSentRolOut);
		}else if(caso == 2) {
			ObtPagosSentRolOut obtPagosSentRolOut = new ObtPagosSentRolOut();			
			obtPagosSentRolOut.setRftrans("SGP1707210000129");
			obtPagosSentRolOut.setRol(1);
			obtPagosSentRolOut.setIdComp("N");
			obtPagosSentRolOut.setCodSentencia(1);
			obtPagosSentRolOut.setIdAutorizacion(7117798);
			obtPagosSentRolOut.setAnorden(1);
			obtPagosSentRolOut.setAnumfirm(1);
			obtPagosSentRolOut.setAtipagru("A");
			obtPagosSentRolOut.setTament(1);
			obtPagosSentRolOut.setAnordengrp(1);
			salida.add(obtPagosSentRolOut);
		}else if(caso == 3){
			for (int i = 0; i < 2; i++) {		
				ObtPagosSentRolOut obtPagosSentRolOut = new ObtPagosSentRolOut();
				if(i == 0) {				
					obtPagosSentRolOut.setRftrans("SGP1707210000130");
					obtPagosSentRolOut.setRol(1);
				}else if(i == 1){
					obtPagosSentRolOut.setRftrans("SGP1707210000130");
					obtPagosSentRolOut.setRol(2);
				}
				obtPagosSentRolOut.setIdComp("N");
				obtPagosSentRolOut.setCodSentencia(1);
				obtPagosSentRolOut.setIdAutorizacion(7117798);
				obtPagosSentRolOut.setAnorden(1);
				obtPagosSentRolOut.setAnumfirm(1);
				obtPagosSentRolOut.setAtipagru("A");
				obtPagosSentRolOut.setTament(1);
				obtPagosSentRolOut.setAnordengrp(1);
				salida.add(obtPagosSentRolOut);
			}
		}else if(caso == 4){					
			ObtPagosSentRolOut obtPagosSentRolOut = new ObtPagosSentRolOut();				
			obtPagosSentRolOut.setRftrans("SGP1707210000145");
			obtPagosSentRolOut.setRol(1);
			obtPagosSentRolOut.setIdComp("N");
			obtPagosSentRolOut.setCodSentencia(1);
			obtPagosSentRolOut.setIdAutorizacion(7117798);
			obtPagosSentRolOut.setAnorden(1);
			obtPagosSentRolOut.setAnumfirm(1);
			obtPagosSentRolOut.setAtipagru("A");
			obtPagosSentRolOut.setTament(1);
			obtPagosSentRolOut.setAnordengrp(1);
			salida.add(obtPagosSentRolOut);			
		}else {
			for (int i = 0; i < 4; i++) {		
				ObtPagosSentRolOut obtPagosSentRolOut = new ObtPagosSentRolOut();
				if(i == 0) {				
					obtPagosSentRolOut.setRftrans("SGP1707210000132");
					obtPagosSentRolOut.setRol(1);
					obtPagosSentRolOut.setAnordengrp(1);
					obtPagosSentRolOut.setAtipagru("A");
					obtPagosSentRolOut.setAnumfirm(1);
				}else if(i == 1){
					obtPagosSentRolOut.setRftrans("SGP1707210000133");
					obtPagosSentRolOut.setRol(1);
					obtPagosSentRolOut.setAnordengrp(1);
					obtPagosSentRolOut.setAtipagru("B");
					obtPagosSentRolOut.setAnumfirm(1);
				}else if(i == 2){
					obtPagosSentRolOut.setRftrans("SGP1707210000134");
					obtPagosSentRolOut.setRol(1);
					obtPagosSentRolOut.setAnordengrp(2);
					obtPagosSentRolOut.setAtipagru("C");
					obtPagosSentRolOut.setAnumfirm(10);
				}else if(i == 3){
					obtPagosSentRolOut.setRftrans("SGP1707210000135");
					obtPagosSentRolOut.setRol(1);
					obtPagosSentRolOut.setAnordengrp(2);
					obtPagosSentRolOut.setAtipagru("A");
					obtPagosSentRolOut.setAnumfirm(1);
				}
				obtPagosSentRolOut.setIdComp("N");
				obtPagosSentRolOut.setCodSentencia(1);
				obtPagosSentRolOut.setIdAutorizacion(7117798);
				obtPagosSentRolOut.setAnorden(1);
				obtPagosSentRolOut.setTament(1);
				
				salida.add(obtPagosSentRolOut);
			}
		}

		return salida;
	}
	
	private List<ObtPagosSentRolFirmadoOut> RellenarsentenciasFirmas() {
		List<ObtPagosSentRolFirmadoOut> salida = new ArrayList<>();					
		for (int i = 0; i < 5; i++) {			
			ObtPagosSentRolFirmadoOut obtPagosSentRolFirmadoOut = new ObtPagosSentRolFirmadoOut();
			if(i == 0) {				
				obtPagosSentRolFirmadoOut.setRftrans("SGP1707210000129");
			}else if(i == 1) {
				obtPagosSentRolFirmadoOut.setRftrans("SGP1707210000130");
			}else {
				obtPagosSentRolFirmadoOut.setRftrans("SGP1707210000145");
			}
			obtPagosSentRolFirmadoOut.setCodSentencia(1);
			obtPagosSentRolFirmadoOut.setIdAutorizacion(7117798);
			salida.add(obtPagosSentRolFirmadoOut);
		}		
		return salida;
	}
}
