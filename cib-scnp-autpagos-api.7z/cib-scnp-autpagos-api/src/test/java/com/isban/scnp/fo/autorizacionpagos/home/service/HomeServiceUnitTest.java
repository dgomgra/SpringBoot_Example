package com.isban.scnp.fo.autorizacionpagos.home.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeRequest;
import com.isban.scnp.fo.autorizacionpagos.home.model.HomeResponseData;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.ArbolBalance;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.CodigoBic;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.CuentaArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.DatosPantalla;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.InfoUsuario;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.InicioMovilResponse;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.Language;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.ListaMoneda;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.ListaMonedasArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.Listacuentasarbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.MethodResult;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.MonedaArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.PaisArbol;
import com.isban.scnp.fo.autorizacionpagos.home.model.iniciomovil.Saldos;
import com.isban.scnp.fo.autorizacionpagos.home.service.impl.HomeServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl.ListaWarehouseHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.impl.ListaArchivosPendientesServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.impl.ListaLotesHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl.ListaPagosHelperServiceImpl;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class HomeServiceUnitTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private HomeServiceImpl homeServiceImpl;
		
	@Mock
	private RestTemplate restTemplatePost;
	
	@Mock
	private HttpEntity<String> httpEntity;
	
	@Test
	public void homeTest()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
		
		InicioMovilResponse inicioMovilResponse = balancesMovilResponse();
		when(homeServiceImpl.getBalancesMovil(anyString(), anyString())).thenReturn(inicioMovilResponse);
		
		ListaPagosHelperServiceImpl servicioPagos = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(homeServiceImpl, "servicioPagos", servicioPagos);
		ListaWarehouseHelperServiceImpl servicioWarehouse = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(homeServiceImpl, "servicioWarehouse", servicioWarehouse);
		ListaArchivosPendientesServiceImpl servicioArchivos = Mockito.mock(ListaArchivosPendientesServiceImpl.class);		
		ReflectionTestUtils.setField(homeServiceImpl, "servicioArchivos", servicioArchivos);
		ListaLotesHelperServiceImpl servicioLotes = Mockito.mock(ListaLotesHelperServiceImpl.class);
		ReflectionTestUtils.setField(homeServiceImpl, "servicioLotes", servicioLotes);
		
		when(servicioPagos.getListaPagosAutorizarImp(Mockito.any())).thenReturn(responseAutorizar());
		when(servicioWarehouse.getListaPagosWarehouseImp(Mockito.any())).thenReturn(reponseWarehouse());
		when(servicioWarehouse.getListaLotesWarehouseImp(Mockito.any(), anyBoolean())).thenReturn(reponseLotesWarehouse());
		when(servicioArchivos.getListaArchivosPendientes(Mockito.any(), anyBoolean())).thenReturn(responseArchivos());
		when(servicioLotes.getListaLotesAutorizarByPage(Mockito.any(), anyBoolean())).thenReturn(responseLotes());
	
		AppContext appContext = Mockito.mock(AppContext.class);
		when(appContext.getUserData()).thenReturn(new DatosUsuario("###", "##/##/##", " es", "ES","S"));
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(homeServiceImpl, "appContext", appContext);
	
		when(homeServiceImpl.getHome(Mockito.any())).thenCallRealMethod();
		HomeResponseData salida = homeServiceImpl.getHome(homeRequest());
		
		verify(homeServiceImpl, times(1)).getHome(Mockito.any());
		
		verify(homeServiceImpl, times(1)).getBalancesMovil(anyString(), anyString());
		
		assertEquals(salida.getCantidadPagos(),1);
		assertEquals(salida.getCandidadWarehouse(),1);
		assertEquals(salida.getCantidadWarehouseLotes(),1);
		assertEquals(salida.getcantidadArchivosR(),1);
		assertEquals(salida.getCantidadLotes(),1);
		assertEquals(salida.getStatus(),"OK");
	}
	
	@Test
	public void homeBalancesTest()
	{
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");

		
		ReflectionTestUtils.setField(homeServiceImpl, "urlBks", "http://wwww.any.com");
		when(homeServiceImpl.getBalancesMovil(anyString(), anyString())).thenCallRealMethod();
		
		ResponseEntity<InicioMovilResponse> responseEntity = new ResponseEntity<InicioMovilResponse>(balancesMovilResponse(),HttpStatus.ACCEPTED);		
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(InicioMovilResponse.class))).thenReturn(responseEntity);
		
		ListaPagosHelperServiceImpl servicioPagos = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(homeServiceImpl, "servicioPagos", servicioPagos);
		ListaWarehouseHelperServiceImpl servicioWarehouse = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(homeServiceImpl, "servicioWarehouse", servicioWarehouse);
		ListaArchivosPendientesServiceImpl servicioArchivos = Mockito.mock(ListaArchivosPendientesServiceImpl.class);		
		ReflectionTestUtils.setField(homeServiceImpl, "servicioArchivos", servicioArchivos);
		ListaLotesHelperServiceImpl servicioLotes = Mockito.mock(ListaLotesHelperServiceImpl.class);
		ReflectionTestUtils.setField(homeServiceImpl, "servicioLotes", servicioLotes);
		
		when(servicioPagos.getListaPagosAutorizarImp(Mockito.any())).thenReturn(responseAutorizar());
		when(servicioWarehouse.getListaPagosWarehouseImp(Mockito.any())).thenReturn(reponseWarehouse());
		when(servicioWarehouse.getListaLotesWarehouseImp(Mockito.any(), anyBoolean())).thenReturn(reponseLotesWarehouse());
		when(servicioArchivos.getListaArchivosPendientes(Mockito.any(), anyBoolean())).thenReturn(responseArchivos());
		when(servicioLotes.getListaLotesAutorizarByPage(Mockito.any(), anyBoolean())).thenReturn(responseLotes());
		
		AppContext appContext = Mockito.mock(AppContext.class);
		when(appContext.getUserData()).thenReturn(new DatosUsuario("###", "##/##/##", " es", "ES","S"));
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(homeServiceImpl, "appContext", appContext);
		ReflectionTestUtils.setField(homeServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		
		when(homeServiceImpl.getHome(Mockito.any())).thenCallRealMethod();
		HomeResponseData salida = homeServiceImpl.getHome(homeRequest());
		
		verify(homeServiceImpl, times(1)).getHome(Mockito.any());
		
		verify(homeServiceImpl, times(1)).getBalancesMovil(anyString(), anyString());
		
		assertEquals(salida.getCantidadPagos(),1);
		assertEquals(salida.getCandidadWarehouse(),1);
		assertEquals(salida.getCantidadWarehouseLotes(),1); 
		assertEquals(salida.getcantidadArchivosR(),1);
		assertEquals(salida.getCantidadLotes(),1);
		assertEquals(salida.getStatus(),"OK");
	}
	
	
	
	
	
	
	
	private ListaLotesAutorizarResponse responseLotes() {
		ListaLotesAutorizarResponse responseLotes = new ListaLotesAutorizarResponse();
		responseLotes.setTotalLotes(1);
		responseLotes.setStatus("OK");
		responseLotes.setPagina(1);
		responseLotes.setMessage("OK");
		return responseLotes;
	}

	private ListaArchivosPendientesResponse responseArchivos() {
		ListaArchivosPendientesResponse responseArchivos = new ListaArchivosPendientesResponse();
		responseArchivos.setNumFichTotales(1);
		responseArchivos.setMessage("OK");
		responseArchivos.setNumPaginaActual(1);
		responseArchivos.setStatus("OK");
		return responseArchivos;
	}

	private ListaPagosWarehouseResponse reponseWarehouse() {
		ListaPagosWarehouseResponse responseWarehouse = new ListaPagosWarehouseResponse();
		responseWarehouse.setStatus("OK");
		responseWarehouse.setTotalPagos(1);
		responseWarehouse.setPagina(1);
		responseWarehouse.setMessage("OK");
		return responseWarehouse;
	}
	private ListaLotesWarehouseResponse reponseLotesWarehouse() {
		ListaLotesWarehouseResponse responseLotesWarehouse = new ListaLotesWarehouseResponse();
		responseLotesWarehouse.setStatus("OK");
		responseLotesWarehouse.setTotalLotes(1);
		responseLotesWarehouse.setPagina(1);
		responseLotesWarehouse.setMessage("OK");
		return responseLotesWarehouse;
	}
	private ListaPagosAutorizarResponse responseAutorizar() {
		ListaPagosAutorizarResponse response = new ListaPagosAutorizarResponse();
		response.setStatus("OK");
		response.setNumTotalPagos(1);
		response.setMessage("OK");
		response.setNumPagActual(1);
		return response;
	}

	private HomeRequest homeRequest() {
		HomeRequest homeRequest = new HomeRequest();
		homeRequest.setMonConsolidacion("ARS");
		homeRequest.setTokenBks("TOKEN1234");
		return homeRequest;
	}

	private InicioMovilResponse balancesMovilResponse() {
		InicioMovilResponse imr = new InicioMovilResponse();
		MethodResult methodRes = new MethodResult();
		methodRes.setStatus("OK");
		DatosPantalla datosPantalla = new DatosPantalla();
		Saldos saldos = new Saldos();
		List<ArbolBalance> arbolBalances = new ArrayList<>();
		ArbolBalance arbol = new ArbolBalance();
		PaisArbol paisArbol = new PaisArbol();
		paisArbol.setCodPais("ES");
		paisArbol.setDivisaUsuario("EUR");
		paisArbol.setNombrePais("ESPAÑA");
		List<ListaMonedasArbol> listasMonedasArbol = new ArrayList<>();
		ListaMonedasArbol listaMonedaArbol = new ListaMonedasArbol();
		MonedaArbol monedaArbol = new MonedaArbol();
		monedaArbol.setDivisaCuenta("EUR");
		List<Listacuentasarbol> listascuentasarbol = new ArrayList<>();
		Listacuentasarbol listaCuentaArbol = new Listacuentasarbol();
		CuentaArbol cuenta = new CuentaArbol();
		cuenta.setAliasCuentaPerfilado("alias");
		cuenta.setAliasEntidad("entidad");
		cuenta.setBookBalance(String.valueOf(new BigDecimal(30)));
		cuenta.setBookDate("05/11/2015");
		CodigoBic bic = new CodigoBic();
		bic.setBRANCH("XXX");
		bic.setLOCATORBIC("BO");
		bic.setENTIDADBIC("BSCH");
		bic.setPAISBIC("ES");
		cuenta.setCodigoBic(bic);
		cuenta.setCodigoCuenta(1230);
		cuenta.setCuentaExtracto("ESDASADAS");
		cuenta.setDivisa("EUR");
		cuenta.setNombreEmisora("BANCO SANTANDER");
		cuenta.setValueBalance(String.valueOf(new BigDecimal(30)));
		cuenta.setValueDate("05/11/2015");
		listaCuentaArbol.setCuentaArbol(cuenta);
		listascuentasarbol.add(listaCuentaArbol);
		monedaArbol.setListacuentasarbol(listascuentasarbol );
		monedaArbol.setSumBookBalance(String.valueOf(new BigDecimal(40)));
		monedaArbol.setSumValueBalance(String.valueOf(new BigDecimal(30)));
		listaMonedaArbol.setMonedaArbol(monedaArbol);
		listasMonedasArbol.add(listaMonedaArbol);
		paisArbol.setListaMonedasArbol(listasMonedasArbol);
		paisArbol.setSumBookBalanceDivUsu(String.valueOf(new BigDecimal(40)));
		paisArbol.setSumValueBalanceDivUsu(String.valueOf(new BigDecimal(30)));
		arbol.setPaisArbol(paisArbol);
		arbolBalances.add(arbol);
		saldos.setArbolBalances(arbolBalances);
		saldos.setDescripcionConversion("USD=1,07659 31/12/2017; GBP=1,07659 31/12/2017; ARS=10,267 05/01/2015; MXN=17,857 05/01/2015; CLP=737,08 05/01/2015; AUD=0,7782 13/09/2018; BRL=3,2571 05/01/2015");
		saldos.setSaldoConsolidadoContable(String.valueOf(new BigDecimal(40)));
		saldos.setSaldoConsolidadoDisponible(String.valueOf(new BigDecimal(30)));
		List<ListaMoneda> listaMonedas = new ArrayList<>();
		ListaMoneda listaMoneda = new ListaMoneda();
		listaMoneda.setDivisa("EUR");
		listaMonedas.add(listaMoneda);
		saldos.setListaMonedas(listaMonedas);
		datosPantalla.setSaldos(saldos);
		
		methodRes.setDatosPantalla(datosPantalla);
		methodRes.setStatus("OK");
		methodRes.setTipoMensaje("Mensaje OK");
		methodRes.setMessage("Operación realizada correctamente");
		Language language = new Language();
		language.setIdiomaIso(" es");
		language.setDialectoIso("ES");
		methodRes.setLanguage(language);
		methodRes.setPantalla("Balances");
		imr.setMethodResult(methodRes);
		
		InfoUsuario infoUsuario = new InfoUsuario();
		infoUsuario.setLogin("SGPUSUARIO");
		infoUsuario.setNombre("Nombre");
		infoUsuario.setApellidos("Apellido");
		infoUsuario.setUltimoAcceso("Hoy");
		datosPantalla.setInfoUsuario(infoUsuario);
		
		assertEquals(infoUsuario.getLogin(), "SGPUSUARIO");
		assertEquals(infoUsuario.getNombre(), "Nombre");
		assertEquals(infoUsuario.getApellidos(), "Apellido");
		assertEquals(infoUsuario.getUltimoAcceso(), "Hoy");
		
		assertEquals(language.getDialectoIso(), "ES");
		assertEquals(language.getIdiomaIso(), " es");
		assertEquals(listaMoneda.getDivisa(), "EUR");
		return imr;
	}
}
