package com.isban.scnp.fo.autorizacionpagos.listaPagos.service;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.CompPagosRolHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.DatosPagoAutorizar;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.DatosPagoAutorizarProc;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaNombres;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.PagosUsuarioAutorizProcedureOut;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl.ListaPagosHelperServiceImpl;


@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class ListaPagosHelperServiceUnitTest {
	
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private ListaPagosHelperServiceImpl listaPagosHelperServiceImpl;
	
	
	@Test
	public void getListaPagosAutorizarImpTest_Ok() {
		// Salida de la llamada al procedimiento
		PagosUsuarioAutorizProcedureOut procedimientoOut = new PagosUsuarioAutorizProcedureOut();
		DatosPagoAutorizarProc datos = new DatosPagoAutorizarProc();
		List<DatosPagoAutorizarProc> listaDatos = new ArrayList<>();
		listaDatos.add(datos);
		procedimientoOut.setDatosPagosAutorizar(listaDatos);
		
		// Salida de la llamada a tratarDatos
		ListaPagosAutorizarResponse listaPagosAutorizarResponse = new ListaPagosAutorizarResponse();
	
		
		
		// La clase a testear
		ListaPagosHelperServiceImpl mock = Mockito.mock(ListaPagosHelperServiceImpl.class);
		Mockito.when(mock.comprobarTokenSKeyUsu(Mockito.anyString())).thenReturn("token1234");
		Mockito.when(mock.getPagosUsuarioAutorizProcedure(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(procedimientoOut);
		Mockito.when(mock.tratarDatos(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString())).thenReturn(listaPagosAutorizarResponse);
		Mockito.when(mock.rellenarNotas(Mockito.any())).thenReturn(listaPagosAutorizarResponse);
		Mockito.when(mock.datosPaginacion(Mockito.any(), Mockito.any())).thenReturn(listaPagosAutorizarResponse);
		Mockito.when(mock.getListaPagosAutorizarImp(Mockito.any())).thenCallRealMethod();
		
		// Los datos de entrada
		ListaPagosAutorizarRequest requestMock = Mockito.mock(ListaPagosAutorizarRequest.class);
		Mockito.when(requestMock.getIdLote()).thenReturn("");
		Mockito.when(requestMock.getPais()).thenReturn("");
		
		
		// Interfaz compPagosRol
		CompPagosRolHelperService compPagosRolHelperService = Mockito.mock(CompPagosRolHelperService.class);
		List<CompPagosRolUsuPendFirmaOut> pagosConRolOk = new ArrayList<>();
		CompPagosRolUsuPendFirmaOut pagoConRol = new CompPagosRolUsuPendFirmaOut();
		pagosConRolOk.add(pagoConRol);
		pagosConRolOk.add(pagoConRol);
		
		
		Mockito.when(compPagosRolHelperService.compPagosRolUsuPendFirma(Mockito.any())).thenReturn(pagosConRolOk);
		ReflectionTestUtils.setField(mock, "compPagosRolHelperService", compPagosRolHelperService);
		
		ListaPagosAutorizarResponse salida = mock.getListaPagosAutorizarImp(requestMock);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida, notNullValue());
		
		assertThat(salida.getStatus(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getMessage(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getNumPagActual(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.getNumTotalPagos(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.getListaDatosPagosAutorizar(), notNullValue());

		// Verificamos que el codigo es OK
		assertEquals(salida.getStatus(), "OK");

		// Verificamos que se ha llamado al metodo
		verify(mock, times(1)).getListaPagosAutorizarImp(Mockito.any());
	
	}
	
	
	@Test
	public void getListaPagosAutorizarImpTest_SinFirma() {
		// La clase a testear
		ListaPagosHelperServiceImpl mock = Mockito.mock(ListaPagosHelperServiceImpl.class);
		Mockito.when(mock.comprobarTokenSKeyUsu(Mockito.anyString())).thenReturn(null);
		Mockito.when(mock.getListaPagosAutorizarImp(Mockito.any())).thenCallRealMethod();
		
		ListaPagosAutorizarResponse salida = mock.getListaPagosAutorizarImp(Mockito.any());
		
		// Verificamos que el codigo es KO
		assertEquals(salida.getStatus(), "KO");
	}
	
	
	@Test
	public void getListaPagosAutorizarImpTest_SinPagos() {
		// Salida de la llamada al procedimiento
		PagosUsuarioAutorizProcedureOut procedimientoOut = new PagosUsuarioAutorizProcedureOut();
		
		// La clase a testear
		ListaPagosHelperServiceImpl mock = Mockito.mock(ListaPagosHelperServiceImpl.class);
		Mockito.when(mock.comprobarTokenSKeyUsu(Mockito.anyString())).thenReturn("");
		Mockito.when(mock.getPagosUsuarioAutorizProcedure(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(procedimientoOut);
		Mockito.when(mock.getListaPagosAutorizarImp(Mockito.any())).thenCallRealMethod();
		
		// Los datos de entrada
		ListaPagosAutorizarRequest requestMock = Mockito.mock(ListaPagosAutorizarRequest.class);
		Mockito.when(requestMock.getIdLote()).thenReturn("");
		Mockito.when(requestMock.getPais()).thenReturn("");
		
		ListaPagosAutorizarResponse salida = mock.getListaPagosAutorizarImp(requestMock);
		
		// Verificamos que el codigo es KO
		assertEquals(salida.getStatus(), "KO");
	}
	
	@Test
	public void getPagosUsuarioAutorizProcedureOkTest() {
		Mockito.when(listaPagosHelperServiceImpl.getPagosUsuarioAutorizProcedure(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenCallRealMethod();
		
		Map<String, Object> datos = RellenarPagosUsuarioAutorizProcedure("OK");

		Mockito.when(jdbcTemplate.call(Mockito.any(), Mockito.any())).thenReturn(datos);
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		
		PagosUsuarioAutorizProcedureOut salida = listaPagosHelperServiceImpl.getPagosUsuarioAutorizProcedure("SGPdavidf787753", "", "");
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).getPagosUsuarioAutorizProcedure(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
		
		// Comprobamos los datos de salida
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getClaben());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getCodCuenta());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getCodExtracto());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getCodMedioPago());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getDescEstPago());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getDivisa());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getFecha());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getIdAuto());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getIdEstado());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getImporte());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getIndicadorUpload());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getIndImp());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getIndNota());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getN2897_nombenc());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getN2897_nombens1());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getN6564_nombenc());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getO2785_nombens1());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getPais());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getRefCliente());
		assertNotNull(salida.getDatosPagosAutorizar().get(0).getRftrans());
		assertNotNull(salida.getPagosLib().get(0));
		assertNotNull(salida.getPagosSinLib().get(0));
		
	}
	
	
	@Test
	public void getPagosUsuarioAutorizProcedureKoTest() {
		Mockito.when(listaPagosHelperServiceImpl.getPagosUsuarioAutorizProcedure(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenCallRealMethod();
		
		Map<String, Object> datos = RellenarPagosUsuarioAutorizProcedure("KO");

		Mockito.when(jdbcTemplate.call(Mockito.any(), Mockito.any())).thenReturn(datos);
		ReflectionTestUtils.setField(listaPagosHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		
		PagosUsuarioAutorizProcedureOut salida = listaPagosHelperServiceImpl.getPagosUsuarioAutorizProcedure("SGPdavidf787753", "", "");
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).getPagosUsuarioAutorizProcedure(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
		
		// Comprobamos los datos de salida
		assertEquals(salida.getDatosPagosAutorizar().size(), 0);
		assertEquals(salida.getPagosLib().size(), 0);
		assertEquals(salida.getPagosSinLib().size(), 0);
		
	}
	
	@Test
	public void rellenarDatosTest() {
		Mockito.when(listaPagosHelperServiceImpl.rellenarDatos(Mockito.any())).thenCallRealMethod();
		
		PagosUsuarioAutorizProcedureOut datosPagos = new PagosUsuarioAutorizProcedureOut();
		List<DatosPagoAutorizarProc> datosPagosAutorizar = new ArrayList<>();
		DatosPagoAutorizarProc datos = new DatosPagoAutorizarProc();
		
		datosPagosAutorizar.add(datos);
		datosPagos.setDatosPagosAutorizar(datosPagosAutorizar);
		
		ListaPagosAutorizarResponse salida = listaPagosHelperServiceImpl.rellenarDatos(datosPagos);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).rellenarDatos(Mockito.any());
		
		// Verificamos que tiene los campos
		assertEquals(salida.getListaDatosPagosAutorizar().get(0).getCodBeneficiario(), 0);
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getCodExtracto());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getCodMedioPago());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getCodPais());
		assertEquals(salida.getListaDatosPagosAutorizar().get(0).getCuentaOrdenante(), 0);
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getDescEstPago());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getDescNota());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getDivisa());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getFecha());
		assertEquals(salida.getListaDatosPagosAutorizar().get(0).getIdAutorizacion(), 0);
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getIdEstado());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getImporte());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getIndicadorUpload());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getIndImp());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getIndNota());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getNomBenef());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getRefCliente());
		assertNull(salida.getListaDatosPagosAutorizar().get(0).getRftrans());
	}
	
	@Test
	public void rellenarPagosCuentaTest() {
		Mockito.when(listaPagosHelperServiceImpl.rellenarPagosCuenta(Mockito.any())).thenCallRealMethod();
		
		PagosUsuarioAutorizProcedureOut datosPagos = new PagosUsuarioAutorizProcedureOut();
		List<DatosPagoAutorizarProc> datosPagosAutorizar = new ArrayList<>();
		DatosPagoAutorizarProc datos = new DatosPagoAutorizarProc();
		
		datosPagosAutorizar.add(datos);
		datosPagos.setDatosPagosAutorizar(datosPagosAutorizar);
		
		List<Integer> salida = listaPagosHelperServiceImpl.rellenarPagosCuenta(datosPagos);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).rellenarPagosCuenta(Mockito.any());
		
		// Verificamos que tiene los campos
		assertEquals(salida.get(0).intValue(), 0);
	}
	
	@Test
	public void rellenarListaNombresTest() {
		Mockito.when(listaPagosHelperServiceImpl.rellenarListaNombres(Mockito.any())).thenCallRealMethod();
		
		PagosUsuarioAutorizProcedureOut datosPagos = new PagosUsuarioAutorizProcedureOut();
		List<DatosPagoAutorizarProc> datosPagosAutorizar = new ArrayList<>();
		DatosPagoAutorizarProc datos = new DatosPagoAutorizarProc();
		
		datosPagosAutorizar.add(datos);
		datosPagos.setDatosPagosAutorizar(datosPagosAutorizar);
		
		List<ListaNombres> salida = listaPagosHelperServiceImpl.rellenarListaNombres(datosPagos);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).rellenarListaNombres(Mockito.any());
		
		// Verificamos que tiene los campos
		assertNull(salida.get(0).getCodMedioPago());
		assertNull(salida.get(0).getN2897_nombenc());
		assertNull(salida.get(0).getN2897_nombens1());
		assertNull(salida.get(0).getN6564_nombenc());
		assertNull(salida.get(0).getO2785_nombens1());
		
	}
	
	
	@Test
	public void tratarDatosTest() {
		Mockito.when(listaPagosHelperServiceImpl.tratarDatos(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		
		List<String> listaPagosFiltrados = new ArrayList<>();
		listaPagosFiltrados.add("SGP11111111");
		listaPagosFiltrados.add("SGP11111113");
		listaPagosFiltrados.add("SG411111114");
		listaPagosFiltrados.add("SGP11111115");
		listaPagosFiltrados.add("SGP11111116");
		listaPagosFiltrados.add("SGP11111117");
		listaPagosFiltrados.add("SGP11111118");
		listaPagosFiltrados.add("SGP11111119");
		
		ListaPagosAutorizarResponse response = new ListaPagosAutorizarResponse();
		List<DatosPagoAutorizar> listaPagos = RellenarDatosPagoAutorizar();
		response.setListaDatosPagosAutorizar(listaPagos);
		response.setStatus("OK");
		response.setMessage("Operación realizada correctamente.");
		response.setNumPagActual(1);
		response.setNumTotalPagos(3);
		
		List<Integer> listaPagosCuenta = new ArrayList<>();
		listaPagosCuenta.add(123);
		listaPagosCuenta.add(124);
		listaPagosCuenta.add(125);
		listaPagosCuenta.add(126);
		listaPagosCuenta.add(127);
		listaPagosCuenta.add(128);
		listaPagosCuenta.add(129);
		listaPagosCuenta.add(130);
		listaPagosCuenta.add(131);
		
		List<ListaNombres> nombres = rellenarNombres();
		
		String divisa = "EUR";
		
		List<String> pagosYaFirmados = new ArrayList<>();
		pagosYaFirmados.add("SGP11111113");
		
		ListaPagosAutorizarResponse salida = listaPagosHelperServiceImpl.tratarDatos(listaPagosFiltrados, response, listaPagosCuenta, nombres, pagosYaFirmados, divisa);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).tratarDatos(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString());
		
		// Verificamos los datos de salida
		assertNotNull(salida.getStatus());
		assertNotNull(salida.getMessage());
		assertNotNull(salida.getNumPagActual());
		assertNotNull(salida.getNumPagActual());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodBeneficiario());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodExtracto());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodMedioPago());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodPais());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCuentaOrdenante());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getDescEstPago());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getDescNota());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getDivisa());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getFecha());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIdAutorizacion());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIdEstado());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getImporte());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIndicadorUpload());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIndImp());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIndNota());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getNomBenef());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getRefCliente());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getRftrans());
	}
	
	@Test
	public void tratarDatosEmptyTest() {
		Mockito.when(listaPagosHelperServiceImpl.tratarDatos(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		
		List<String> listaPagosFiltrados = new ArrayList<>();
		ListaPagosAutorizarResponse response = new ListaPagosAutorizarResponse();		
		List<Integer> listaPagosCuenta = new ArrayList<>();
		List<ListaNombres> nombres = new ArrayList<>();
		
		String divisa = "";
		List<String> pagosYaFirmados = new ArrayList<>();
		
		ListaPagosAutorizarResponse salida = listaPagosHelperServiceImpl.tratarDatos(listaPagosFiltrados, response, listaPagosCuenta, nombres, pagosYaFirmados, divisa);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).tratarDatos(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString());
		
		divisa = "XXX";
		salida = listaPagosHelperServiceImpl.tratarDatos(listaPagosFiltrados, response, listaPagosCuenta, nombres, pagosYaFirmados, divisa);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(2)).tratarDatos(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString());
		
		// Verificamos los datos de salida
		assertEquals(salida.getStatus(), "KO");

	}
	
	
	@Test
	public void rellenarNotasTest() {
		Mockito.when(listaPagosHelperServiceImpl.rellenarNotas(Mockito.any())).thenCallRealMethod();
		
		ListaPagosAutorizarResponse param = new ListaPagosAutorizarResponse();
		List<DatosPagoAutorizar> listaDatosPagosAutorizar = new ArrayList<>();
		DatosPagoAutorizar datosPagoAutorizar = new DatosPagoAutorizar();
		datosPagoAutorizar.setIndNota("N");
		listaDatosPagosAutorizar.add(datosPagoAutorizar);
		DatosPagoAutorizar datosPagoAutorizarDos = new DatosPagoAutorizar();
		datosPagoAutorizarDos.setIndNota("S");
		listaDatosPagosAutorizar.add(datosPagoAutorizarDos);
		param.setListaDatosPagosAutorizar(listaDatosPagosAutorizar);
		param.setStatus("OK");
		param.setMessage("Operacion realizada correctamente.");
		param.setNumPagActual(1);
		param.setNumTotalPagos(2);
		ListaPagosAutorizarResponse salida = listaPagosHelperServiceImpl.rellenarNotas(param);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).rellenarNotas(Mockito.any());
		
		// Verficamos los datos de salida
		assertNotNull(salida.getListaDatosPagosAutorizar().size());
		assertNotNull(salida.getStatus());
		assertNotNull(salida.getMessage());
		assertNotNull(salida.getNumPagActual());
		assertNotNull(salida.getNumTotalPagos());
	}
	
	
	@Test
	public void datosPaginacionTest() {
		Mockito.when(listaPagosHelperServiceImpl.datosPaginacion(Mockito.any(), Mockito.any())).thenCallRealMethod();
		
		ListaPagosAutorizarResponse paramUno = new ListaPagosAutorizarResponse();
		paramUno.setListaDatosPagosAutorizar(RellenarDatosPagoAutorizar());
		paramUno.setStatus("OK");
		paramUno.setMessage("Operación realizada correctamente.");
		
		ListaPagosAutorizarRequest paramDos = new ListaPagosAutorizarRequest();
		paramDos.setNumPorPagina(12);
		paramDos.setNumPagina(1);
		
		ListaPagosAutorizarResponse salida = listaPagosHelperServiceImpl.datosPaginacion(paramUno, paramDos);
		
		// Verificamos que se ha llamado al metodo
		verify(listaPagosHelperServiceImpl, times(1)).datosPaginacion(Mockito.any(), Mockito.any());
		
		// Verificamos los datos de salida
		assertNotNull(salida.getStatus());
		assertNotNull(salida.getMessage());
		assertNotNull(salida.getNumPagActual());
		assertNotNull(salida.getNumPagActual());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodBeneficiario());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodExtracto());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodMedioPago());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCodPais());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getCuentaOrdenante());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getDescEstPago());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getDescNota());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getDivisa());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getFecha());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIdAutorizacion());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIdEstado());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getImporte());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIndicadorUpload());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIndImp());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getIndNota());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getNomBenef());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getRefCliente());
		assertNotNull(salida.getListaDatosPagosAutorizar().get(0).getRftrans());
	}
	
	@Test
	public void equalsAndHashCodeTest() {
		DatosPagoAutorizar datosPagoAutorizar = new DatosPagoAutorizar();
		datosPagoAutorizar.setRftrans("ref1234");
		boolean esIgual = datosPagoAutorizar.equals("");
		assertEquals(esIgual, false);
		
		esIgual = datosPagoAutorizar.equals(null);
		
		esIgual = datosPagoAutorizar.equals(datosPagoAutorizar);
		assertEquals(esIgual, true);
		
		int code = datosPagoAutorizar.hashCode();
		assertNotNull(code);
		
		
	}
	
	private Map<String, Object> RellenarPagosUsuarioAutorizProcedure(String test) {
		Map<String, Object> datos = new HashMap<>();
		List<Object> result = new ArrayList<>();
		Map<String, Object> objetos = new HashMap<>();
		objetos.put("N6563_RFTRANS", "SGP11111111");
		objetos.put("N6563_ESTPAGO", "Ingresado");
		objetos.put("N6563_CANTPAGL", "10");
		objetos.put("N6563_CODMONSWI", "EUR");
		objetos.put("N6563_FEC_VAL", "2018-11-27");
		objetos.put("N6563_CLIREFER", "CLIREF0004545");
		objetos.put("N6563_CDMEDPAG", "TR");
		objetos.put("N6563_CLABEN", 158);
		objetos.put("N2897_NOMBENS1", "nombens1");
		objetos.put("N2897_NOMBENC", "nombenc");
		objetos.put("O2785_NOMBENS1", "nombens1");
		objetos.put("N6564_NOMBENC", "nombenc");
		objetos.put("N6563_ACUENCOT", 123121);
		objetos.put("N6563_IDAUTH", 658);
		objetos.put("N6563_CODPAIS", "ES");
		objetos.put("N6563_INMODIFI", "S");
		objetos.put("INDNOTA_PAGO", "S");
		objetos.put("INDUPL_PAGO", "N");
		objetos.put("H1162_CODCTAEX", "458975");
		objetos.put("ESTADO_TRAD", "Ingresado");
		objetos.put("INDLIB", "N");
		result.add(objetos);
		
		Map<String, Object> objetos2 = new HashMap<>();
		objetos2.put("N6563_RFTRANS", "SGP11111111");
		objetos2.put("N6563_ESTPAGO", "Ingresado");
		objetos2.put("N6563_CANTPAGL", "10");
		objetos2.put("N6563_CODMONSWI", "EUR");
		Date fecha = new Date();
		objetos2.put("N6563_FEC_VAL", fecha);
		
		objetos2.put("N6563_CLIREFER", "CLIREF0004545");
		objetos2.put("N6563_CDMEDPAG", "TR");
		objetos2.put("N6563_CLABEN", 158);
		objetos2.put("N2897_NOMBENS1", "nombens1");
		objetos2.put("N2897_NOMBENC", "nombenc");
		objetos2.put("O2785_NOMBENS1", "nombens1");
		objetos2.put("N6564_NOMBENC", "nombenc");
		objetos2.put("N6563_ACUENCOT", 123121);
		objetos2.put("N6563_IDAUTH", 658);
		objetos2.put("N6563_CODPAIS", "ES");
		objetos2.put("N6563_INMODIFI", "S");
		objetos2.put("INDNOTA_PAGO", "S");
		objetos2.put("INDUPL_PAGO", "N");
		objetos2.put("H1162_CODCTAEX", "458975");
		objetos2.put("ESTADO_TRAD", "Ingresado");
		objetos2.put("INDLIB", "S");
		result.add(objetos2);
		
		if("OK".equals(test)) {			
			datos.put("result", result);
		}else {
			datos.put("fail", result);
		}
		
		return datos;
	}
	
	private List<DatosPagoAutorizar> RellenarDatosPagoAutorizar() {
		List<DatosPagoAutorizar> salida = new ArrayList<>();
		List<String> listRftrans = new ArrayList();
		listRftrans.add("SGP11111111");
		listRftrans.add("SGP11111112");
		listRftrans.add("SGP11111113");
		listRftrans.add("SGP11111114");
		listRftrans.add("SGP11111115");
		listRftrans.add("SGP11111116");
		listRftrans.add("SGP11111117");
		listRftrans.add("SGP11111118");
		listRftrans.add("SGP11111119");
		
		for (int i = 0; i < 9; i++) {
			DatosPagoAutorizar datos = new DatosPagoAutorizar();
			datos.setRftrans(listRftrans.get(i));
			if(i == 8) {
				datos.setCodMedioPago("MT");
				datos.setCodBeneficiario(0);
				datos.setDivisa("EUR");
			}else if(i == 7) {
				datos.setCodMedioPago("MT");
				datos.setCodBeneficiario(0);
				datos.setDivisa("EUR");
			}else if(i == 6) {
				datos.setCodMedioPago("AR");
				datos.setCodBeneficiario(0);
				datos.setDivisa("GBP");
			}else {
				datos.setCodMedioPago("AR");
				datos.setCodBeneficiario(1120);
				datos.setDivisa("EUR");
			}
			datos.setIndNota("S");
			datos.setIndImp("S");
			datos.setIdEstado("Ingresado");
			datos.setCodExtracto("78798");
			datos.setIdAutorizacion(5434);
			datos.setNomBenef("nombre");
			BigDecimal importe = new BigDecimal(133);
			datos.setImporte(importe);
			Date fecha = new Date();
			datos.setFecha(fecha);
			datos.setRefCliente("34553");
			datos.setIndicadorUpload("N");
			datos.setCodPais("ES");
			datos.setDescEstPago("Aceptado");
			datos.setCuentaOrdenante(4455);
			datos.setDescNota("Nota de ingreso");
			salida.add(datos);
		}
		
		return salida;
		

	}
	
	private List<ListaNombres> rellenarNombres(){
		List<ListaNombres> salida = new ArrayList<>();
		
		for (int i = 0; i < 9; i++) {			
			ListaNombres nombres = new ListaNombres();
			nombres.setN2897_nombenc("Test1");
			nombres.setN2897_nombens1("Test2");
			nombres.setN6564_nombenc("Test3");
			nombres.setN6564_nombenc("Test4");
			if(i == 7 || i == 0) {				
				nombres.setCodMedioPago("AR");
			}else {
				nombres.setCodMedioPago("MT");
			}
			salida.add(nombres);
		}
		
		return salida;
	}

}
