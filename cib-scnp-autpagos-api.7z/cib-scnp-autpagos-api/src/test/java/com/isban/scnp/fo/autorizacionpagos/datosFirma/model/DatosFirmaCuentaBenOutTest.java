package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;

import com.isban.scnp.fo.autorizacionpagos.Application;

@WithAnonymousUser
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DatosFirmaCuentaBenOutTest {
	
	@Test
	public void DatosFirmaCuentaBenOutModelTest() {
		DatosFirmaCuentaBenOut data = new DatosFirmaCuentaBenOut();
		data.setDigitosCuentaBen("");
		data.getDigitosCuentaBen();
		
		assertNotNull(data);
		
	}
}
