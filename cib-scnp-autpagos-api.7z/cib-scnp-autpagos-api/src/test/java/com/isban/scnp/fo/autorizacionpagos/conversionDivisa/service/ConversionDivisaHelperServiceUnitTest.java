package com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaIn;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequest;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaRequestData;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisa_E;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.Importe;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ListaImportes;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl.ConversionDivisaHelperServiceImpl;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ConversionDivisaHelperServiceUnitTest {
	
	@Mock
	ConversionDivisaHelperServiceImpl conversionDivisaHelperServiceImpl;
	
	@Test
	public void conversionDivisa_ARStoEUR_Test() {	
		
		Mockito.when(conversionDivisaHelperServiceImpl.conversionDivisa(Mockito.any())).thenCallRealMethod();
		ConversionDivisaRequest request = new ConversionDivisaRequest();
		request.setToken("TOKEN");
		ConversionDivisaRequestData requestData = new ConversionDivisaRequestData();
		ConversionDivisaIn conversionDivisa = new ConversionDivisaIn();
		ConversionDivisa_E entrada = new ConversionDivisa_E();
		entrada.setDivisaConsolidacion("EUR");
		ListaImportes listaImporte = new ListaImportes();
		Importe importe = new Importe();
		importe.setImporte(new ImporteType(new BigDecimal(300), "ARS"));
		listaImporte.addImporte(importe);
		conversionDivisa.setEntrada(entrada);
		requestData.setConversionDivisa(conversionDivisa);
		request.setRequestData(requestData);
		entrada.addListaImportes(listaImporte);

		RestTemplate restTemplatePost = new RestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		Mockito.when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(conversionDivisaHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess(
				"{\"methodResult\":{\"listaImportes\":[{\"importe\":{\"IMPORTE\":29.22,\"DIVISA\":\"EUR\"}}],\"listaDivisas\":[{\"divisa\":\"EUR\"},{\"divisa\":\"USD\"},{\"divisa\":\"GBP\"},{\"divisa\":\"ARS\"}],\"listaDivisasSinConversion\":[],\"tipoCambio\":\"USD=1,07659 31-12-2017; GBP=1,07659 31-12-2017; ARS=10,267 05-01-2015\"}}"
				, MediaType.APPLICATION_JSON));
		ConversionDivisaResponse salida = conversionDivisaHelperServiceImpl.conversionDivisa(request);
		mockServer.verify();
		
		assertEquals(salida.getMethodResult().getListaImportes().get(0).getIMPORTE().compareTo(new BigDecimal("29.22")), 0);
		assertTrue(salida.getMethodResult().getListaDivisas().get(3).getDivisa().equals("ARS"));
		assertTrue(salida.getMethodResult().getListaDivisasSinConversion().isEmpty());
		
	}
	
	
	@Test
	public void conversionDivisa_ARStoDEFAULT_Test() {	
		
		Mockito.when(conversionDivisaHelperServiceImpl.conversionDivisa(Mockito.any())).thenCallRealMethod();
		ConversionDivisaRequest request = new ConversionDivisaRequest();
		request.setToken("TOKEN");
		ConversionDivisaRequestData requestData = new ConversionDivisaRequestData();
		ConversionDivisaIn conversionDivisa = new ConversionDivisaIn();
		ConversionDivisa_E entrada = new ConversionDivisa_E();
		List<ListaImportes> listaImportes = new ArrayList<>();
		ListaImportes listaImporte = new ListaImportes();
		Importe importe = new Importe();
		importe.setImporte(new ImporteType(new BigDecimal(300), "ARS"));
		listaImporte.addImporte(importe);
		listaImportes.add(listaImporte);
		entrada.setListaGruposImportes(listaImportes);
		conversionDivisa.setEntrada(entrada);
		requestData.setConversionDivisa(conversionDivisa);
		request.setRequestData(requestData);
		
		RestTemplate restTemplatePost = new RestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		Mockito.when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(conversionDivisaHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess(
				"{\"methodResult\":{\"listaImportes\":[{\"importe\":{\"IMPORTE\":29.22,\"DIVISA\":\"EUR\"}}],\"listaDivisas\":[{\"divisa\":\"EUR\"},{\"divisa\":\"USD\"},{\"divisa\":\"GBP\"},{\"divisa\":\"ARS\"}],\"listaDivisasSinConversion\":[],\"tipoCambio\":\"USD=1,07659 31-12-2017; GBP=1,07659 31-12-2017; ARS=10,267 05-01-2015\"}}"
				, MediaType.APPLICATION_JSON));
		ConversionDivisaResponse salida = conversionDivisaHelperServiceImpl.conversionDivisa(request);
		mockServer.verify();
		
		assertEquals(salida.getMethodResult().getListaImportes().get(0).getIMPORTE().compareTo(new BigDecimal("29.22")), 0);
		assertTrue(salida.getMethodResult().getListaDivisas().get(3).getDivisa().equals("ARS"));
		assertTrue(salida.getMethodResult().getListaDivisasSinConversion().isEmpty());
		
	}
	
	@Test
	public void conversionDivisaEURtoARSsum_TEST() {
		Mockito.when(conversionDivisaHelperServiceImpl.conversionDivisa(Mockito.any())).thenCallRealMethod();
		ConversionDivisaRequest request = new ConversionDivisaRequest();
		request.setToken("TOKEN");
		ConversionDivisaRequestData requestData = new ConversionDivisaRequestData();
		ConversionDivisaIn conversionDivisa = new ConversionDivisaIn();
		ConversionDivisa_E entrada = new ConversionDivisa_E();
		entrada.setDivisaConsolidacion("ARS");
		List<ListaImportes> listaImportes = new ArrayList<>();
		ListaImportes listaImporte = new ListaImportes();
		Importe importe = new Importe();
		importe.setImporte(new ImporteType(new BigDecimal(300), "EUR"));
		listaImporte.addImporte(importe);
		listaImportes.add(listaImporte);
		Importe importe2 = new Importe();
		ImporteType importeType2 = new ImporteType();
		importeType2.setIMPORTE(new BigDecimal(300));
		importeType2.setDIVISA("EUR");
		importe2.setImporte(importeType2);
		listaImporte.addImporte(importe2);
		entrada.setListaGruposImportes(listaImportes);
		conversionDivisa.setEntrada(entrada);
		requestData.setConversionDivisa(conversionDivisa);
		request.setRequestData(requestData);
		
		RestTemplate restTemplatePost = new RestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		Mockito.when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(conversionDivisaHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess(
				"{\"methodResult\":{\"listaImportes\":[{\"importe\":{\"IMPORTE\":6160.2,\"DIVISA\":\"ARS\"}}],\"listaDivisas\":[{\"divisa\":\"EUR\"},{\"divisa\":\"USD\"},{\"divisa\":\"GBP\"},{\"divisa\":\"ARS\"}],\"listaDivisasSinConversion\":[],\"tipoCambio\":\"EUR=0,0974 01-01-0001; USD=0,10486 31-12-2017; GBP=0,10486 31-12-2017\"}}	"
				, MediaType.APPLICATION_JSON));
		ConversionDivisaResponse salida = conversionDivisaHelperServiceImpl.conversionDivisa(request);
		mockServer.verify();
		
		assertEquals(salida.getMethodResult().getListaImportes().get(0).getIMPORTE().compareTo(new BigDecimal("6160.2")), 0);
		assertTrue(salida.getMethodResult().getListaDivisas().get(3).getDivisa().equals("ARS"));
		assertTrue(salida.getMethodResult().getListaDivisasSinConversion().isEmpty());
	}

}
