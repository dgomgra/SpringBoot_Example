package com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaOut;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl.ConversionDivisaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ClaveValor;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ClaveValorMapper;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ConsultaPagosCreados_S;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosLotesWarehousing;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosPagoDeLoteW;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosPagoLoteW;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosPagoWarehousing;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.IdiomaUsuario;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaLotesWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaPagosWarehouseResponse;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.ListaWarehouseRequest;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl.ListaWarehouseHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl.ListaPagosHelperServiceImpl;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ListaWarehouseHelperServiceUnitTest {

	private static final String STR_N = "N";
	private static final String STR_S = "S";
	private static final String STR_RESULT = "result";
	
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private ListaWarehouseHelperServiceImpl listaWarehouseHelperServiceImpl;
	
	@Mock
	private RestTemplate restTemplatePost;

	@Test
	public void getListaPagosWarehouseImpTest_Ok()
	{
		String idUsuarioLogado = "USUARIO";
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);
		
		//Simulamos llamada al método 		
		//Llamada a obtenerIdiomaUsuario

		IdiomaUsuario idiomaUsuario = rellenarIdiomaUsuario ();		
		
		//Llamada a getPagosUsuarioAutorizProcedure
		List<ConsultaPagosCreados_S> listaPagosCreados = rellenarListaPagosCreados();
		
		//Llamada a obtenerUltimaNota
		List<String> listaNotas = rellenarListaNotas();
		
		//Llamada a prepararPagina
		List<DatosPagoWarehousing> listaSalida = rellenarListaPagosWarehouse();
		
		//respuestaCompleta
		ListaPagosWarehouseResponse respuestaCompleta = rellenarResponseCompleto();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl listaPagosHelperServiceImpl = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "listaPagosHelperService", listaPagosHelperServiceImpl);
		
		RestTemplate restTemplatePost = new RestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.POST)).andRespond(withSuccess("{\"methodResult\": [{\"cutOff\": {\"fechaCutOff\": \"2019-01-16T22:00:00.000Z\",\"fechaPaisOrigen\": \"2019-01-16T14:44:10.000Z\"}}]}", MediaType.APPLICATION_JSON));
		
		Mockito.when(listaPagosHelperServiceImpl.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerIdiomaUsuario(anyString())).thenReturn(idiomaUsuario);
		Mockito.when(listaWarehouseHelperServiceImpl.getPagosUsuarioAutorizProcedure(anyString(), any())).thenReturn(listaPagosCreados);
		Mockito.when(listaWarehouseHelperServiceImpl.calcularCutOff(any())).thenCallRealMethod();
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerUltimaNota(any())).thenReturn(listaNotas);
		Mockito.when(listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(any())).thenCallRealMethod();
		
		// 1) Prueba con una consulta OK
		ListaWarehouseRequest listaWarehouseRequest=new ListaWarehouseRequest();
		listaWarehouseRequest.setNumPagina(1);
		listaWarehouseRequest.setNumPorPagina(10);
		listaWarehouseRequest.setTokenBks("TOKEN");
		
		ListaPagosWarehouseResponse salidaOk = listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(listaWarehouseRequest);
		//VERIFICACIONES:
			// Verificamos que no retorne un valor nulo
			assertThat(salidaOk, notNullValue());
			
			// Verificamos el tipo de dato de la salida
			assertThat(salidaOk.getStatus(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getMessage(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing(), notNullValue());
			assertThat(salidaOk.getListaDatosPagosWarehousing(), org.hamcrest.Matchers.isA(List.class));
			assertThat(salidaOk.getPagina(), org.hamcrest.Matchers.isA(Integer.class));
			assertThat(salidaOk.getTotalPagos(), org.hamcrest.Matchers.isA(Integer.class));
			
			// Verificamos los tipos de dato de la listaDatosLote
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getRftrans(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getIndNota(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getUltimaNota(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getIndImp(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getIdEstado(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getCodExtracto(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getNomBenef(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getCodBeneficiario(), org.hamcrest.Matchers.isA(Integer.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getIdAutorizacion(), org.hamcrest.Matchers.isA(Integer.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getImporte(), org.hamcrest.Matchers.isA(BigDecimal.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getDivisa(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getFecha(), org.hamcrest.Matchers.isA(Date.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getRefCliente(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getIndicadorUpload(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getCodPais(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getCodMedioPago(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getDescEstPago(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getCuentaOrdenante(), org.hamcrest.Matchers.isA(Integer.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getAliasCuentaOrdenante(), org.hamcrest.Matchers.isA(String.class));
			assertThat(salidaOk.getListaDatosPagosWarehousing().get(0).getIndStopPayment(), org.hamcrest.Matchers.isA(String.class));
			
			// Verificamos que el codigo y el mensaje son correctos
			assertEquals(salidaOk.getStatus(), "OK");
			assertEquals(salidaOk.getMessage(), "OK");
			
		// 2) Prueba con una consulta de una pagina que no existe
		listaSalida.clear();
		ListaWarehouseRequest requestPaginaKO = new ListaWarehouseRequest();
		requestPaginaKO.setNumPagina(100);
		requestPaginaKO.setNumPorPagina(10);
		requestPaginaKO.setTokenBks("TOKEN");
		
		//Mockito.when(listaWarehouseHelperServiceImpl.calcularCutOff(any())).thenReturn(listaCutOffs);
		mockServer.reset();
		mockServer.expect(method(HttpMethod.POST)).andRespond(withSuccess("{\"methodResult\": [{\"cutOff\": {\"fechaCutOff\": \"2019-01-16T22:00:00.000Z\",\"fechaPaisOrigen\": \"2019-01-16T14:44:10.000Z\"}}]}", MediaType.APPLICATION_JSON));

		ListaPagosWarehouseResponse salidaKoPag = listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(requestPaginaKO);
		//VERIFICACIONES:
			// Verificamos que el codigo y el mensaje son correctos
				assertEquals(salidaKoPag.getStatus(), "KO");
				assertEquals(salidaKoPag.getMessage(),  "0053");

		// 3) Prueba con una consulta que no obtiene datos
		//respuestaCompleta.getListaDatosPagosWarehousing().clear();
		listaPagosCreados.clear();		
		ListaPagosWarehouseResponse salidaKoSinDatos = listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(listaWarehouseRequest);
		//VERIFICACIONES:
			// Verificamos que el codigo y el mensaje son correctos
			assertEquals(salidaKoSinDatos.getStatus(), "KO");
			assertEquals(salidaKoSinDatos.getMessage(),  "0000");
			
		// 5) Prueba con una consulta con respuesta vacia
		respuestaCompleta.setStatus(null);
		ListaPagosWarehouseResponse salidaVacia = listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(listaWarehouseRequest);
		//VERIFICACIONES:	
			// Verificamos que se ha llamado al metodo 4 veces
			assertNull(salidaVacia.getListaDatosPagosWarehousing());
			verify(listaWarehouseHelperServiceImpl, times(4)).getListaPagosWarehouseImp(any());
	}

	@Test
	public void getListaPagosWarehouseImpTest_SinFirma() {
		
		ListaWarehouseRequest request = new ListaWarehouseRequest();
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl listaPagosHelperServiceImpl = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "listaPagosHelperService", listaPagosHelperServiceImpl);
		
		String token = null;
		
		Mockito.when(listaPagosHelperServiceImpl.comprobarTokenSKeyUsu(anyString())).thenReturn(token);
		Mockito.when(listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(any())).thenCallRealMethod();
		
		ListaPagosWarehouseResponse salidaNull = listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(request);		
		assertEquals(salidaNull.getStatus(), "KO");
		assertEquals(salidaNull.getMessage(), "0023");
		
		token = "";		
		ListaPagosWarehouseResponse salidaVacio = listaWarehouseHelperServiceImpl.getListaPagosWarehouseImp(request);		
		assertEquals(salidaVacio.getStatus(), "KO");
		assertEquals(salidaVacio.getMessage(), "0023");
	}
	
	@Test
	public void getPagosUsuarioAutorizProcedureTest() {
		
		Mockito.when(jdbcTemplate.call(any(), any())).thenReturn(rellenarDatosProcedure());
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		Mockito.when(listaWarehouseHelperServiceImpl.getPagosUsuarioAutorizProcedure(anyString(), any())).thenCallRealMethod();
		
		List<ConsultaPagosCreados_S> salida = listaWarehouseHelperServiceImpl.getPagosUsuarioAutorizProcedure("USUARIO", new IdiomaUsuario());
		
		assertNotNull(salida);
		assertEquals(salida.size(), 1);
		assertThat(salida.get(0).getIdEstado(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getImporte(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salida.get(0).getDivisa(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getFecha(), org.hamcrest.Matchers.isA(Date.class));
		assertThat(salida.get(0).getRefCliente(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getRefSistema(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getCodMedioPago(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndImp(), org.hamcrest.Matchers.isA(String.class));		
		assertThat(salida.get(0).getIndNota(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndicadorUpload(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndStopPayment(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getAliasCuentaOrdenante(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getCodExtracto(), org.hamcrest.Matchers.isA(String.class));		
		assertThat(salida.get(0).getCodEnt(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getCodBeneficiario(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getIdAutorizacionBeneficiario(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getNomBenef(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getCuenta(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getPais(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getDescEstPago(), org.hamcrest.Matchers.isA(String.class));
		
		// Verificamos que se ha llamado al metodo
		verify(listaWarehouseHelperServiceImpl, times(1)).getPagosUsuarioAutorizProcedure(anyString(),any());		
	}
	
	@Test
	public void traducirMulidiTest()
	{
		Mockito.when(jdbcTemplate.query(anyString(),  any(Object[].class), any(ClaveValorMapper.class))).thenReturn(rellenarDatosMulidi());
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		Mockito.when(listaWarehouseHelperServiceImpl.traducirMulidi(anyString(),  any(ArrayList.class), anyString())).thenCallRealMethod();
		
		List<String> salidaOk = listaWarehouseHelperServiceImpl.traducirMulidi("TIPO_DATO", new ArrayList<String>(Arrays.asList("PE")), "USUARIO");
		
		assertEquals(salidaOk.size(), 1);
		assertThat(salidaOk, notNullValue());
		assertThat(salidaOk, org.hamcrest.Matchers.isA(List.class));		
	}
	
	private List<ClaveValor> rellenarDatosMulidi() {

		List<ClaveValor> salida = new ArrayList<>();		
		ClaveValor claveValor = new ClaveValor("PE", "Warehouse");
		salida.add(claveValor);
	
		return salida;
	}

	private ListaPagosWarehouseResponse rellenarResponseCompleto() {
		
		ListaPagosWarehouseResponse salida = new ListaPagosWarehouseResponse();
		
		salida.setStatus("OK");
		salida.setMessage("Operación realizada correctamente");
		salida.setTotalPagos(1);
		salida.setPagina(1);
		
		List<DatosPagoWarehousing> listaDatosPagosWarehousing = rellenarListaPagosWarehouse();
		salida.setListaDatosPagosWarehousing(listaDatosPagosWarehousing);

		return salida;
	}
	
	private List<String> rellenarListaNotas() {
		List<String> salida = new ArrayList<String> ();
		
		String notaPago = "Pago para James";
		salida.add(notaPago);
		
		return salida;
	}
	
	private List<ConsultaPagosCreados_S> rellenarListaPagosCreados() {
		
		List<ConsultaPagosCreados_S> salida = new ArrayList<ConsultaPagosCreados_S> ();
		ConsultaPagosCreados_S nuevoPago = new ConsultaPagosCreados_S();
		
		Date fechaInstruccion= new Date();
		fechaInstruccion.setTime(1549839600000L);		
		
		nuevoPago.setAliasCuentaOrdenante("Alias cuenta ES");
		nuevoPago.setCodBeneficiario(0);
		nuevoPago.setCodEnt(7);
		nuevoPago.setCodExtracto("ES999888777666555444");
		nuevoPago.setCodMedioPago("CB");
		nuevoPago.setCuenta(1259);		
		nuevoPago.setDescEstPago("Warehouse");		
		nuevoPago.setDivisa("EUR");		
		nuevoPago.setFecha(fechaInstruccion);		
		nuevoPago.setIdAutorizacionBeneficiario(0);
		nuevoPago.setIdEstado("PE");
		nuevoPago.setImporte(new BigDecimal("100.00"));
		nuevoPago.setIndicadorUpload(STR_N);
		nuevoPago.setIndImp(STR_N);
		nuevoPago.setIndNota(STR_N);
		nuevoPago.setIndStopPayment(STR_S);
		nuevoPago.setNomBenef("James Smith");
		nuevoPago.setPais("ES");
		nuevoPago.setRefCliente("PagoJames");
		nuevoPago.setRefSistema("SGP1901100000367");
		
		salida.add(nuevoPago);
		
		return salida;
	}
	
	private IdiomaUsuario rellenarIdiomaUsuario() {
		
		IdiomaUsuario salida = new IdiomaUsuario();
		salida.setIdioma(" es");
		salida.setPais("ES");
		
		return salida;
	}


	private List<DatosPagoWarehousing> rellenarListaPagosWarehouse() {
		
		List<DatosPagoWarehousing> salida = new ArrayList<DatosPagoWarehousing>();
		DatosPagoWarehousing nuevoPago = new DatosPagoWarehousing();
	
		Date fechaInstruccion= new Date();
		fechaInstruccion.setTime(1549839600000L);		
		
		nuevoPago.setCodBeneficiario(0);
		nuevoPago.setCodExtracto("ES999888777666555444");
		nuevoPago.setCodMedioPago("CB");
		nuevoPago.setCodPais("ES");
		nuevoPago.setCuentaOrdenante(1259);
		nuevoPago.setDescEstPago("Warehouse");
		nuevoPago.setDivisa("EUR");
		nuevoPago.setFecha(fechaInstruccion);
		nuevoPago.setIdEstado("PE");
		nuevoPago.setImporte(new BigDecimal(100.00));
		nuevoPago.setIndicadorUpload("S");
		nuevoPago.setIndImp("N");
		nuevoPago.setIndNota("N");
		nuevoPago.setIndStopPayment("S");
		nuevoPago.setNomBenef("James Smith");
		nuevoPago.setRefCliente("PagoJames");
		nuevoPago.setRftrans("SGP1901100000367");
		nuevoPago.setUltimaNota("");
		
		salida.add(nuevoPago);
		
		return salida;		
	}
	
	private Map<String, Object> rellenarSalidaPL()
	{
		Timestamp fechaInstruccion= new Timestamp(1549839600000L);
		
		Map<String, Object> salida = new HashMap<>();
		
		salida.put("N6563_RFTRANS", "SGP1901100000367");
		salida.put("N6563_CODMONSWI", "EUR");
		salida.put("N6563_CANTPAGL", 100.00);
		salida.put("N6563_FEC_VAL", fechaInstruccion);
		salida.put("N6563_CLIREFER", "James Smith");
		salida.put("N6563_CDMEDPAG", "CB");
		salida.put("N6563_ESTPAGO", "PE");
		salida.put("H1162_CODCTAEX", "ES999888777666555444");
		salida.put("H5204_ALITE15", "Alias cuenta ES");
		salida.put("H1162_CENTBSGP", 7);
		salida.put("N2897_NOMBENS1", "James Smith");
		salida.put("N2897_NOMBENC", "James Smith");
		salida.put("O2785_NOMBENS1", "James Smith");
		salida.put("N6564_NOMBENC", "James Smith");
		salida.put("N6563_CODPAIS", "ES");
		salida.put("N6563_CLABEN", 0);
		salida.put("N2897_IDAUTH", 0);
		salida.put("N6563_ACUENCOT", 1259);		
		salida.put("N6563_INMODIFI", STR_N);
		salida.put("INDUPL_PAGO", STR_S);
		salida.put("INDNOTA_PAGO", STR_N);
		salida.put("PERMISO_STP", STR_S);
		salida.put("ESTADO_TRAD", "Warehouse");
		
		
		return salida;
	}
	
	private Map<String, Object> rellenarSalidaPLLotes()
	{
		Timestamp fechaInstruccion= new Timestamp(1549839600000L);
		
		Map<String, Object> salida = new HashMap<>();
		
		salida.put("O2046_NULOTE", "L201908290915068");
		salida.put("O2046_ESTPAGO", "PE");
		salida.put("O2046_DESCRI50", "LoteL201908290915068");
		salida.put("O2046_CODPAIS", "ES");
		salida.put("O2046_CODMONSWI", "EUR");
		salida.put("O2046_IMPLOTE2", "100.0");
		salida.put("O2046_FECHALOT", fechaInstruccion);
		salida.put("O2046_TOTPAGOS", 1);
		salida.put("O2046_BATCH_B", STR_N);
		salida.put("O2046_IND_NOM", STR_S);
		salida.put("NUM_IMP_LOTE", 1);
		salida.put("NUM_UPL_LOTE", 1);
		salida.put("NUM_NOTA_LOTE", 1);
		salida.put("NUM_CBL_LOTE", 0);
		salida.put("NUM_ELI_LOTE", 1);
		salida.put("ESTADO_TRAD", "Warehouse");
		salida.put("O2046_TOTPAGOSACRE", 0);
		salida.put("O2046_LOTEIMPACRE", "0.00");
		salida.put("N6563_RFTRANS", "SGP1909180000070");
		salida.put("N6563_ESTPAGO", "PE");
		salida.put("N6563_CDMEDPAG", "CB");
		salida.put("H1162_CENTBSGP", 1);
		salida.put("N6563_ACUENCOT", 1);
		salida.put("N6563_CANTPAGL", "100.0");
		salida.put("N6563_CODMONSWI", "EUR");
		salida.put("PERMISO_STP", STR_S);
		salida.put("N6563_FEC_VAL", fechaInstruccion);
		
		return salida;
	}
	
	private Map<String, Object> rellenarDatosProcedure ()
	{
		Map<String, Object> salida = new HashMap<>();
		
		List<Map<String,Object>> listaPL = new ArrayList<>();
		listaPL.add(rellenarSalidaPL());
		
		salida.put(STR_RESULT, listaPL);		
		return salida;
	}
	
	private Map<String, Object> rellenarDatosLoteProcedure ()
	{
		Map<String, Object> salida = new HashMap<>();
		
		List<Map<String,Object>> listaPL = new ArrayList<>();
		listaPL.add(rellenarSalidaPLLotes());
		
		salida.put(STR_RESULT, listaPL);		
		return salida;
	}
	private ConversionDivisaResponse retornoDivisa() {
		ConversionDivisaResponse salida = new ConversionDivisaResponse();
		ConversionDivisaOut convDivisa = new ConversionDivisaOut();
		List<ImporteType> listaImportes = new ArrayList<>();
		ImporteType imp0 = new ImporteType(new BigDecimal(333.78), "EUR");
		listaImportes.add(imp0);
		convDivisa.setListaImportes(listaImportes);
		salida.setMethodResult(convDivisa);
		
		return salida;
	}
	
	@Test
	public void getListaLotesWarehouseImpTest_Ok()
	{
		String idUsuarioLogado = "USUARIO";
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);
		
		//Simulamos llamada al método 		
		//Llamada a obtenerIdiomaUsuario
		IdiomaUsuario idiomaUsuario = rellenarIdiomaUsuario ();		
		
		//Llamada a getPagosUsuarioAutorizProcedure
		List<ConsultaPagosCreados_S> listaPagosCreados =rellenarListaPagosCreados();
		
		List<DatosPagoLoteW> listaPagosLoteCreados = rellenarListaLotesPagosCreados();
		
		//List<CalcularCutOff_S> listaCutOffs = listaPagosCreados.isEmpty() ? new ArrayList<> (0) : obtenerCutOffs(tokenBks, listaPagosCreados);
		
		List<DatosLotesWarehousing> listaSalida = rellenarListaLotesWarehouse();
		
		//respuestaCompleta
		ListaLotesWarehouseResponse respuestaCompleta = rellenarResponseCompletoLotes();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl listaPagosHelperServiceImpl = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "listaPagosHelperService", listaPagosHelperServiceImpl);
		
		// Servicio externo (listawarehouse)
		ConversionDivisaHelperServiceImpl conversionDivisaHelperService = Mockito.mock(ConversionDivisaHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "conversionDivisaHelperService", conversionDivisaHelperService);
		
		RestTemplate restTemplatePost = new RestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.POST)).andRespond(withSuccess("{\"methodResult\": [{\"cutOff\": {\"fechaCutOff\": \"2019-01-16T22:00:00.000Z\",\"fechaPaisOrigen\": \"2019-01-16T14:44:10.000Z\"}}]}", MediaType.APPLICATION_JSON));

		Mockito.when(listaPagosHelperServiceImpl.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerIdiomaUsuario(anyString())).thenReturn(idiomaUsuario);
		//Mockito.when(listaWarehouseHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure(anyString(), any() , any())).thenReturn(listaPagosLoteCreados);
				
		Mockito.when(listaWarehouseHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure(anyString(), any() , any())).thenAnswer(new Answer<List<DatosPagoLoteW>>() {
			@Override
			public List<DatosPagoLoteW> answer(InvocationOnMock invocation) throws Throwable {
				
				List<DatosPagoLoteW> salida = new ArrayList<DatosPagoLoteW> (0);
				
				List<ConsultaPagosCreados_S> args = (List<ConsultaPagosCreados_S>) (invocation.getArguments()[2]);				
				
				salida= rellenarListaLotesPagosCreados();
				
				List<ConsultaPagosCreados_S> listaTemp = rellenarListaPagosCreados();
				args.add(listaTemp.get(0));
			
	            return salida;
			}
		});
		
		Mockito.when(listaWarehouseHelperServiceImpl.calcularCutOff(any())).thenCallRealMethod();
		Mockito.when(conversionDivisaHelperService.conversionDivisa(any())).thenReturn(retornoDivisa());
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerListaDivisas(anyString(), any())).thenCallRealMethod();				
		Mockito.when(listaWarehouseHelperServiceImpl.getListaLotesWarehouseImp(any(), anyBoolean())).thenCallRealMethod();
		
		
		// 1) Prueba con una consulta OK
		ListaLotesWarehouseRequest listaLotesWarehouseRequest=new ListaLotesWarehouseRequest();
		listaLotesWarehouseRequest.setNumPagina(1);
		listaLotesWarehouseRequest.setNumPorPagina(10);
		listaLotesWarehouseRequest.setMonedaConsolidacion("EUR");
		listaLotesWarehouseRequest.setTokenBks("TOKEN");
		
		ListaLotesWarehouseResponse salidaOk = listaWarehouseHelperServiceImpl.getListaLotesWarehouseImp(listaLotesWarehouseRequest, false);
		
		//VERIFICACIONES:
		// Verificamos que no retorne un valor nulo
		assertThat(salidaOk, notNullValue());
		
		// Verificamos el tipo de dato de la salida
		assertThat(salidaOk.getStatus(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getMessage(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing(), notNullValue());
		assertThat(salidaOk.getListaDatosLotesWarehousing(), org.hamcrest.Matchers.isA(List.class));
		assertThat(salidaOk.getPagina(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salidaOk.getTotalLotes(), org.hamcrest.Matchers.isA(Integer.class));
		
		// Verificamos los tipos de dato de la listaDatosLote
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIdLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getCodEstLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getNomLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getCodPais(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getImpLote(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getDivisaLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getFechaLote(), org.hamcrest.Matchers.isA(Date.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getTotalPagos(), org.hamcrest.Matchers.isA(Long.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndImportado(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndNotas(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndicadorUpload(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndSalario(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getDescEstLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndicadorCbs(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndBulk(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLotesWarehousing().get(0).getIndStopPayment(), org.hamcrest.Matchers.isA(String.class));		
		
		// Verificamos que el codigo y el mensaje son correctos
		assertEquals(salidaOk.getStatus(), "OK");
		assertEquals(salidaOk.getMessage(), "OK");
		
	// 2) Prueba con una consulta de una pagina que no existe
	listaSalida.clear();
	ListaLotesWarehouseRequest requestPaginaKO = new ListaLotesWarehouseRequest();
	requestPaginaKO.setNumPagina(100);
	requestPaginaKO.setNumPorPagina(10);
	requestPaginaKO.setMonedaConsolidacion("EUR");
	requestPaginaKO.setTokenBks("TOKEN");
	
	mockServer.reset();
	mockServer.expect(method(HttpMethod.POST)).andRespond(withSuccess("{\"methodResult\": [{\"cutOff\": {\"fechaCutOff\": \"2019-01-16T22:00:00.000Z\",\"fechaPaisOrigen\": \"2019-01-16T14:44:10.000Z\"}}]}", MediaType.APPLICATION_JSON));

	ListaLotesWarehouseResponse salidaKoPag = listaWarehouseHelperServiceImpl.getListaLotesWarehouseImp(requestPaginaKO, true);
	//VERIFICACIONES:
		// Verificamos que el codigo y el mensaje son correctos
			assertEquals(salidaKoPag.getStatus(), "KO");
			assertEquals(salidaKoPag.getMessage(),  "0053");


		verify(listaWarehouseHelperServiceImpl, times(2)).getListaLotesWarehouseImp(any(), anyBoolean());
	}

	private ListaLotesWarehouseResponse rellenarResponseCompletoLotes() {

		ListaLotesWarehouseResponse salida = new ListaLotesWarehouseResponse();
		
		salida.setStatus("OK");
		salida.setMessage("Operación realizada correctamente");
		salida.setTotalLotes(1);
		salida.setPagina(1);
		
		List<DatosLotesWarehousing> listaLotesPagosWarehousing = rellenarListaLotesWarehouse();
		salida.setListaDatosLotesWarehousing(listaLotesPagosWarehousing);
		
		List<String> listaDivisas = new ArrayList<>();
		listaDivisas.add("EUR");
		salida.setListaDivisas(listaDivisas);
		
		return salida;
	}

	private List<DatosLotesWarehousing> rellenarListaLotesWarehouse() {
		
		List<DatosLotesWarehousing> salida = new ArrayList<DatosLotesWarehousing>(0);
		Date fechaInstruccion= new Date();
		fechaInstruccion.setTime(1549839600000L);		
		
		DatosLotesWarehousing nuevoLote = new DatosLotesWarehousing();
		
		nuevoLote.setIdLote("L201908290915068");
		nuevoLote.setCodEstLote("PE");
		nuevoLote.setNomLote("LoteL201908290915068");
		nuevoLote.setCodPais("ES");
		nuevoLote.setImpLote(new BigDecimal("100.00"));
		nuevoLote.setDivisaLote("EUR");
		nuevoLote.setFechaLote(fechaInstruccion);
		nuevoLote.setTotalPagos(1);
		nuevoLote.setIndImportado(STR_S);
		nuevoLote.setIndNotas(STR_N);
		nuevoLote.setIndicadorUpload(STR_S);
		nuevoLote.setIndSalario(STR_S);
		nuevoLote.setDescEstLote("Warehouse");
		nuevoLote.setIndicadorCbs(STR_S);
		nuevoLote.setIndBulk(STR_N);
		nuevoLote.setIndStopPayment(STR_S);
		
		salida.add(nuevoLote);
		
		return salida;
	}

	private List<DatosPagoLoteW> rellenarListaLotesPagosCreados() {
		
		List<DatosPagoLoteW> salida = new ArrayList<DatosPagoLoteW>(0);
		
		Date fechaInstruccion= new Date();
		fechaInstruccion.setTime(1549839600000L);		
		
		DatosPagoLoteW nuevoPagoLote = new DatosPagoLoteW();
		
		nuevoPagoLote.setLote("L201908290915068");
		nuevoPagoLote.setIdEstado("PE");
		nuevoPagoLote.setNombreLote("LoteL201908290915068");
		nuevoPagoLote.setCodPais("ES");
		nuevoPagoLote.setMoneda("EUR");
		nuevoPagoLote.setMonto(new BigDecimal("100.00"));
		nuevoPagoLote.setFecha(fechaInstruccion);
		nuevoPagoLote.setTotalPagos(1);
		nuevoPagoLote.setIndBulk(STR_N);
		nuevoPagoLote.setIndSalarios(STR_N);
		nuevoPagoLote.setIndImp(STR_S);
		nuevoPagoLote.setIndUpl(STR_S);
		nuevoPagoLote.setIndNota(STR_N);
		nuevoPagoLote.setIndCbl(STR_S);
		nuevoPagoLote.setTamEliminables(0);
		nuevoPagoLote.setIndEli(STR_N);
		nuevoPagoLote.setEstado("Warehouse");
		nuevoPagoLote.setNumPagosAutRech(0);
		nuevoPagoLote.setMontoAcre(new BigDecimal("0.00"));
		nuevoPagoLote.setDivAcre("EUR");
		
		DatosPagoDeLoteW nuevoPago = new DatosPagoDeLoteW();
		nuevoPago.setIdPago("SGP1909180000070");
		nuevoPago.setEstPago("PE");
		nuevoPago.setMedPago("CB");
		nuevoPago.setCodEnt(1);
		nuevoPago.setCuenta(1);
		nuevoPago.setCodExtracto("ES11111");
		nuevoPago.setMontoPago(new BigDecimal(100.0));
		nuevoPago.setDivisa("EUR");
		nuevoPago.setFecValPago(fechaInstruccion);
		nuevoPago.setIndStopPayment(STR_S);
		
		nuevoPagoLote.setDatosPagoDeLote(nuevoPago);		
		
		salida.add(nuevoPagoLote);			
		
		return salida;
	}

	@Test
	public void getListaLotesWarehouseImpTest_NoData()
	{
		ListaLotesWarehouseRequest listaLotesWarehouseRequest=new ListaLotesWarehouseRequest();
		listaLotesWarehouseRequest.setNumPagina(1);
		listaLotesWarehouseRequest.setNumPorPagina(10);
		listaLotesWarehouseRequest.setMonedaConsolidacion("EUR");
		listaLotesWarehouseRequest.setTokenBks("TOKEN");
		
		String idUsuarioLogado = "USUARIO";
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);
		
		//Simulamos llamada al método 		
		//Llamada a obtenerIdiomaUsuario
		IdiomaUsuario idiomaUsuario = rellenarIdiomaUsuario ();		
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl listaPagosHelperServiceImpl = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "listaPagosHelperService", listaPagosHelperServiceImpl);
		
		Mockito.when(listaPagosHelperServiceImpl.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		Mockito.when(listaWarehouseHelperServiceImpl.obtenerIdiomaUsuario(anyString())).thenReturn(idiomaUsuario);
		Mockito.when(listaWarehouseHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure(anyString(), any() ,any())).thenAnswer(new Answer<List<DatosPagoLoteW>>() {
			@Override
			public List<DatosPagoLoteW> answer(InvocationOnMock invocation) throws Throwable {
				
				List<DatosPagoLoteW> salida = new ArrayList<DatosPagoLoteW> (0);
				
				List<ConsultaPagosCreados_S> args = (List<ConsultaPagosCreados_S>) (invocation.getArguments()[2]);	
				
				args=new ArrayList<ConsultaPagosCreados_S>(0);
	            return salida;
			}
		});
		Mockito.when(listaWarehouseHelperServiceImpl.getListaLotesWarehouseImp(any(), anyBoolean())).thenCallRealMethod();
		
		ListaLotesWarehouseResponse salidaKoSinDatos = listaWarehouseHelperServiceImpl.getListaLotesWarehouseImp(listaLotesWarehouseRequest, true);
		//VERIFICACIONES:
			// Verificamos que el codigo y el mensaje son correctos
			assertEquals(salidaKoSinDatos.getStatus(), "KO");
			assertEquals(salidaKoSinDatos.getMessage(),  "0000");
			
		verify(listaWarehouseHelperServiceImpl, times(1)).getListaLotesWarehouseImp(any(), anyBoolean());
	}
	
	@Test
	public void getLotesUsuarioAutorizProcedureTest() {
		
		Mockito.when(jdbcTemplate.call(any(), any())).thenReturn(rellenarDatosLoteProcedure());
		ReflectionTestUtils.setField(listaWarehouseHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		Mockito.when(listaWarehouseHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure(anyString(), any(), any())).thenCallRealMethod();
		
		List<ConsultaPagosCreados_S> listaDatosL = new ArrayList<ConsultaPagosCreados_S>(0);
		
		List<DatosPagoLoteW> salida = listaWarehouseHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure("USUARIO", new IdiomaUsuario(), listaDatosL);
		
		assertNotNull(salida);
		assertEquals(salida.size(), 1);
		assertThat(salida.get(0).getLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIdEstado(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getNombreLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getCodPais(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getMoneda(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getMonto(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salida.get(0).getFecha(), org.hamcrest.Matchers.isA(Date.class));
		assertThat(salida.get(0).getTotalPagos(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getIndBulk(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndSalarios(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndImp(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndUpl(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndNota(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getIndCbl(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getTamEliminables(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getIndEli(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getEstado(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getNumPagosAutRech(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getMontoAcre(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salida.get(0).getDivAcre(), org.hamcrest.Matchers.isA(String.class));
		
		assertThat(salida.get(0).getDatosPagoDeLote().getIdPago(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getEstPago(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getMedPago(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getCodEnt(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getCuenta(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getMontoPago(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getDivisa(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getIndStopPayment(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.get(0).getDatosPagoDeLote().getFecValPago(), org.hamcrest.Matchers.isA(Date.class));
		
		// Verificamos que se ha llamado al metodo
		verify(listaWarehouseHelperServiceImpl, times(1)).getPagosLotesUsuarioAutorizProcedure(anyString(), any(), any());		
	}
	
	@Test
	public void comparePagoTest()
	{
		Date d = new Date();
		Date dMayor = new Date(d.getTime()+1000);
		Date dMenor = new Date(d.getTime()-1000);
		
		DatosPagoWarehousing pago1 = new DatosPagoWarehousing();
		pago1.setRftrans("SGP2009150000126");
		pago1.setFecha(d);
		
		DatosPagoWarehousing pago2 = new DatosPagoWarehousing();		
		pago2.setRftrans("SGP2009150000126");
		pago2.setFecha(d);
		
		DatosPagoWarehousing pago3 = new DatosPagoWarehousing();		
		pago3.setRftrans("SGP2009150000127");
		pago3.setFecha(d);
		
		DatosPagoWarehousing pago4 = new DatosPagoWarehousing();		
		pago4.setRftrans("SGP2009150000128");
		pago4.setFecha(d);
		
		DatosPagoWarehousing pago5 = new DatosPagoWarehousing();		
		pago5.setRftrans("SGP2009150000129");
		pago5.setFecha(dMayor);		
		
		DatosPagoWarehousing pago6 = new DatosPagoWarehousing();		
		pago6.setRftrans("SGP2009150000130");
		pago6.setFecha(dMenor);
		
		int compararIgual = pago1.compareTo(pago2);
		boolean compararMenorNombre = pago1.compareTo(pago3)<0;
		boolean compararIgual3 = pago1.equals(pago1);
		boolean compararMenor4 = pago1.compareTo(pago4)<0;
		
		boolean compararMenor = pago1.compareTo(pago5)<0;
		boolean compararMayor = pago1.compareTo(pago6)>0;
		
		int hash = pago1.hashCode();
		
		assertEquals(compararIgual, 0);
		assertTrue(compararMenorNombre);
		assertTrue(compararIgual3);
		assertTrue(compararMenor4);
		assertTrue(compararMenor);
		assertTrue(compararMayor);	
		assertTrue(hash!=0);
	}
}
