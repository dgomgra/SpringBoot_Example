package com.isban.scnp.fo.autorizacionpagos.listaarchivos.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaOut;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl.ConversionDivisaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.GrupoPerfUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.impl.ListaArchivosPendientesServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl.ListaPagosHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
/*@SqlGroup({ 
	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:database/listaArchivosPendientes/ListaArchivosSeed.sql"),
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:database/listaArchivosPendientes/ListaArchivosPurgue.sql") 
	})*/
public class ListaArchivosPendientesHelperServiceUnitBBDDTest {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	ListaArchivosPendientesServiceImpl listaArchivosPendientesServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;

	/*@Before
	public void before() throws SQLException {
		 
		 //	Servidor H2 Interno Accesible
		 Server webServer = Server.createWebServer("-web", 
                 "-webAllowOthers", "-webPort", "8082");
		 webServer.start();
		 try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	*/
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaArchivosSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaArchivosPurge.sql"));
	}
	
	@Test
	public void obtIndARMultiPais_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtIndARMultiPais(anyInt())).thenCallRealMethod();
		String salida = listaArchivosPendientesServiceImpl.obtIndARMultiPais(7);
		assertEquals(salida, "N");
	}
	
	@Test
	public void obtIndARMultiPais_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtIndARMultiPais(anyInt())).thenCallRealMethod();
		String salida = listaArchivosPendientesServiceImpl.obtIndARMultiPais(1);
		assertEquals(salida, null);
	}
	
	@Test
	public void obtGrupoPerfUsuarioSQL_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtGrupoPerfUsuarioSQL(anyString())).thenCallRealMethod();
		GrupoPerfUsuarioOut salida = listaArchivosPendientesServiceImpl.obtGrupoPerfUsuarioSQL("SGPdanice727718");
		
		assertEquals(salida.getCodGrupoUsu(), 0);
		assertEquals(salida.getIDAuthUsu(), 77552);
	}
	
	@Test
	public void obtGrupoPerfUsuarioSQL_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtGrupoPerfUsuarioSQL(anyString())).thenCallRealMethod();
		GrupoPerfUsuarioOut salida = listaArchivosPendientesServiceImpl.obtGrupoPerfUsuarioSQL("SGPdanicenoexis");
		assertEquals(salida,null);
	}
	
	@Test 
	public void obtPaisesARPerfUsuarioSQL_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtPaisesARPerfUsuarioSQL(anyString(), anyInt())).thenCallRealMethod();
		List<String> salida = listaArchivosPendientesServiceImpl.obtPaisesARPerfUsuarioSQL("SGPdanice727718", 77552);
		assertThat(salida).contains("AR");
		assertThat(salida).contains("BR");
		assertThat(salida).contains("CL");
		assertThat(salida).contains("DE");
		assertThat(salida).contains("ES");
		assertThat(salida).contains("FR");
		assertThat(salida).contains("GB");
		assertThat(salida).contains("IT");
		assertThat(salida).contains("MX");
		assertThat(salida).contains("PE");
		assertThat(salida).contains("PL");
		assertThat(salida).contains("PT");
		assertThat(salida).contains("UY");		
	}
	
	@Test 
	public void obtPaisesARPerfUsuarioSQL_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtPaisesARPerfUsuarioSQL(anyString(), anyInt())).thenCallRealMethod();
		List<String> salida = listaArchivosPendientesServiceImpl.obtPaisesARPerfUsuarioSQL("SGPdanicenoexis", 0);
		assertThat(salida).isEmpty();
	}
	
	@Test
	public void obtPaisesARPerfGrupUsuarioSQL_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtPaisesARPerfGrupUsuarioSQL(anyInt(), anyInt())).thenCallRealMethod();
		List<String> salida = listaArchivosPendientesServiceImpl.obtPaisesARPerfGrupUsuarioSQL(1,70694);
		assertThat(salida).contains("ES");
		assertThat(salida).contains("DE");
		assertThat(salida).contains("CO");
		assertThat(salida).contains("CL");
		assertThat(salida).contains("BR");
		assertThat(salida).contains("AR");
	}
	
	@Test
	public void obtPaisesARPerfGrupUsuarioSQL_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtPaisesARPerfGrupUsuarioSQL(anyInt(), anyInt())).thenCallRealMethod();
		List<String> salida = listaArchivosPendientesServiceImpl.obtPaisesARPerfGrupUsuarioSQL(1,1);
		assertThat(salida).isEmpty();
	}
	
	
	@Test
	public void obtCodigoGrupoEmp_Usuario_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtCodigoGrupoEmp(anyString())).thenCallRealMethod();
		int salida = listaArchivosPendientesServiceImpl.obtCodigoGrupoEmp("SGPdanice727718");
		assertEquals(salida, 7);
	}
	
	@Test
	public void obtCodigoGrupoEmp_Usuario_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtCodigoGrupoEmp(anyString())).thenCallRealMethod();
		int salida = listaArchivosPendientesServiceImpl.obtCodigoGrupoEmp("SGPdanicenoexis");
		assertEquals(salida, 0);
	}
	
	
	@Test
	public void obtArchivosPendientes_OK_S_SinFiltro() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtArchivosPendientes(anyInt(), anyString(), Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> salida = listaArchivosPendientesServiceImpl.obtArchivosPendientes(7,"S", Arrays.asList());
		List<Integer> listaIdsArchivo = new ArrayList<>();
		for (int i=0;i<salida.size();i++) {
			listaIdsArchivo.add(salida.get(i).getIdArchivo());
		}
		assertThat(listaIdsArchivo).contains(2186);
		assertThat(listaIdsArchivo).contains(2187);
		assertThat(listaIdsArchivo).contains(2192);
		assertThat(listaIdsArchivo).contains(2185);
	}
	
	@Test
	public void obtArchivosPendientes_OK_N_Filtro() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtArchivosPendientes(anyInt(), anyString(), Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> salida = listaArchivosPendientesServiceImpl.obtArchivosPendientes(7,"N",Arrays.asList("AR","GB","ES"));
		List<Integer> listaIdsArchivo = new ArrayList<>();
		for (int i=0;i<salida.size();i++) {
			listaIdsArchivo.add(salida.get(i).getIdArchivo());
		}
		assertThat(listaIdsArchivo).contains(2186);
		assertThat(listaIdsArchivo).contains(2187);
		assertThat(listaIdsArchivo).contains(2192);
		assertThat(listaIdsArchivo).contains(2185);
	}
	
	@Test
	public void obtArchivosPendientes_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtArchivosPendientes(anyInt(), anyString(), Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> salida = listaArchivosPendientesServiceImpl.obtArchivosPendientes(1,"N", Arrays.asList(""));
		assertThat(salida).isEmpty();
	}

	@Test
	public void obtIdauthPerfGrupUsuSQL_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtIdauthPerfGrupUsuSQL(anyInt())).thenCallRealMethod();
		int salida = listaArchivosPendientesServiceImpl.obtIdauthPerfGrupUsuSQL(1);
		assertEquals(salida, 74352);
	}
	
	@Test
	public void obtIdauthPerfGrupUsuSQL_OK_NoExiste() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.obtIdauthPerfGrupUsuSQL(anyInt())).thenCallRealMethod();
		int salida = listaArchivosPendientesServiceImpl.obtIdauthPerfGrupUsuSQL(0);
		assertEquals(salida, 0);
	}

	@Test
	public void cambiarDivisaArchivoRA_OK() {
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(listaArchivosPendientesServiceImpl.cambiarDivisaArchivoRA(Mockito.any(),anyString(),anyString())).thenCallRealMethod();
		
		ConversionDivisaHelperServiceImpl conversionDivisaHelperServiceImpl = Mockito.mock(ConversionDivisaHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "conversionDivisaHelperService", conversionDivisaHelperServiceImpl);
		// Generamos salida de conversor de divisas
		
		ConversionDivisaResponse value = new ConversionDivisaResponse();
		ImporteType importe1 = new ImporteType(new BigDecimal("1"), "EUR");
		ImporteType importe2 = new ImporteType(new BigDecimal("1"), "EUR");
		ImporteType importe3 = new ImporteType(new BigDecimal("1"), "EUR");
		ImporteType importe4 = new ImporteType(new BigDecimal("1"), "EUR");
		
		value.setMethodResult(new ConversionDivisaOut());
		value.getMethodResult().setListaImportes(new ArrayList<>());
		value.getMethodResult().getListaImportes().add(importe1);
		value.getMethodResult().getListaImportes().add(importe2);
		value.getMethodResult().getListaImportes().add(importe3);
		value.getMethodResult().getListaImportes().add(importe4);
		
		when(conversionDivisaHelperServiceImpl.conversionDivisa(Mockito.any())).thenReturn(value);
		
		// Generamos entrada
		List<ArchivoAR> list = new ArrayList<>();
		ArchivoAR ar1 = new ArchivoAR();
		ArchivoAR ar2 = new ArchivoAR();
		ArchivoAR ar3 = new ArchivoAR();
		ArchivoAR ar4 = new ArchivoAR();
		ar1.setIdArchivo(2192);
		ar2.setIdArchivo(2187);
		ar3.setIdArchivo(2186);
		ar4.setIdArchivo(2185);
		list.add(ar1);
		list.add(ar2);
		list.add(ar3);
		list.add(ar4);
		
		List<String> salida = listaArchivosPendientesServiceImpl.cambiarDivisaArchivoRA(list, "EUR", "TOKEN");
		
		for (int i=0;i<salida.size();i++) {
			assertEquals(list.get(i).getDivisa(), "EUR");
			assertEquals(list.get(i).getImporte(), new BigDecimal(1));
		}
		assertEquals(salida.size(), 3);
	}
	
	@Test
	public void getListaArchivosPendientes_No_Firma(){
		when(listaArchivosPendientesServiceImpl.getListaArchivosPendientes(Mockito.any(), anyBoolean())).thenCallRealMethod();
		
		UserDetails userDetails = Mockito.mock(UserDetails.class);
		Authentication authentication =  Mockito.mock(Authentication.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);
		when(userDetails.getUsername()).thenReturn("USUARIO");
				
		ListaArchivosARRequest request = new ListaArchivosARRequest();
		request.setMonConsolidacion("EUR");
		request.setNumPagina(1);
		request.setNumPorPagina(10);
		request.setTokenBks("TOKEN");
		
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "listaPagosHelperService", pagosHelpserService);
		ReflectionTestUtils.setField(listaArchivosPendientesServiceImpl, "schemaproc", schemaproc);
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn("OTROUSUARIO");
		
		ListaArchivosPendientesResponse salida = listaArchivosPendientesServiceImpl.getListaArchivosPendientes(request, false);
		assertEquals(salida.getStatus(), "KO");
		assertEquals(salida.getListaArchivos(), null);
		assertEquals(salida.getListaDivisas(), null);
		assertEquals(salida.getNumFichTotales(), 0);
		assertEquals(salida.getNumPaginaActual(), 0);
		assertEquals(salida.getMessage(), "0023");
	}	
}

