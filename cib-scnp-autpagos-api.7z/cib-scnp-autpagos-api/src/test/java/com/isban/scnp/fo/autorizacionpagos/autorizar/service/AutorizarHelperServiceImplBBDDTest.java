package com.isban.scnp.fo.autorizacionpagos.autorizar.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.autorizar.service.impl.AutorizarHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenMapper;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenOut;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class AutorizarHelperServiceImplBBDDTest {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Mock
	private AutorizarHelperServiceImpl autorizarHelperServiceImpl;

	private NamedParameterJdbcTemplate namedJdbcTemplate;
	
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/AutorizarSeed.sql"));
		
		namedJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/AutorizarPurge.sql"));
	}
	
	@Test
	public void AutorizarObtenerNombresPagosTest() {
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", namedJdbcTemplate);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "schemaproc", schemaproc);
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenCallRealMethod();
		List<String> listaIds = new ArrayList<>();
		listaIds.add("SGP1812260001156");
		listaIds.add("SGP1812210005693");
		listaIds.add("SGP1812210005686");		
		List<String> salida = autorizarHelperServiceImpl.obtenerListaNombres("pagos", listaIds);
		assertTrue(salida.size() == 3);
	}
	@Test
	public void AutorizarObtenerNombresLotesTest() {
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", namedJdbcTemplate);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "schemaproc", schemaproc);
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenCallRealMethod();
		List<String> listaIds = new ArrayList<>();
		listaIds.add("L201901030981396");
		listaIds.add("L201812270981371");
		listaIds.add("L201812270969216");		
		List<String> salida = autorizarHelperServiceImpl.obtenerListaNombres("lotes", listaIds);
		assertTrue(salida.size() == 3);
	}
	
	@Test
	public void getDatosDigitosCuentaBenQueryTest() {
		Mockito.when(autorizarHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenCallRealMethod();
		
		NamedParameterJdbcTemplate jdbcMock = Mockito.mock(NamedParameterJdbcTemplate.class);
		
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcMock);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "schemaproc", schemaproc);
		
		List<DatosFirmaCuentaBenOut> salida = new ArrayList<>();
		
		Mockito.when(jdbcMock.query(Mockito.anyString(), Mockito.any(DatosFirmaCuentaBenMapper.class)))
		.thenReturn(salida);
		
		autorizarHelperServiceImpl.getDatosDigitosCuentaBenQuery("");

		
	}
		
}
