package com.isban.scnp.fo.autorizacionpagos.datosFirma.service;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaArchOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaLotesOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaRequest;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaResponse;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.impl.DatosFirmaHelperServiceImpl;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class DatosFirmaHelperServiceUnitTest {
	
	@Mock
	private DatosFirmaHelperServiceImpl datosFirmaHelperServiceImpl;
	
	@Test
	@Ignore
	public void getDatosFirmaTest() {
		
		// Retorno de getDatosFirmaLotes
		DatosFirmaLotesOut datosFirmaLo = new DatosFirmaLotesOut();
		datosFirmaLo.setImporte(new BigDecimal(100));
		datosFirmaLo.setNumPagos(1);
		
		// Retorno de getDatosFirmaArch
		DatosFirmaArchOut datosFirmaAr = new DatosFirmaArchOut();
		datosFirmaAr.setImporte(new BigDecimal(100));
		datosFirmaAr.setNumPagos(1);
		
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaPagos(Mockito.any())).thenReturn("100");
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaLotes(Mockito.any())).thenReturn(datosFirmaLo);
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaArch(Mockito.any())).thenReturn(datosFirmaAr);
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirma(Mockito.any())).thenCallRealMethod();
		
		AppContext appContext = Mockito.mock(AppContext.class);
		Mockito.when(appContext.getUserData()).thenReturn(new DatosUsuario("###", "##/##/##", " es", "ES","S"));
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "appContext", appContext);
		
		DatosFirmaRequest datosFirmaRequest = new DatosFirmaRequest();
		
		// Prueba con pagos
		List<String> listaIds = new ArrayList<>();
		listaIds.add("SGP1707260006979");
		datosFirmaRequest.setTipo("pagos");
		datosFirmaRequest.setListaIds(listaIds);
		
		DatosFirmaResponse salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
		AppContext appContext2 = Mockito.mock(AppContext.class);
		Mockito.when(appContext2.getUserData()).thenReturn(new DatosUsuario("###", "##/##/##", " es", "ES","N"));
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "appContext", appContext2);
		
		// Prueba con lotes
		datosFirmaRequest.setTipo("lotes");
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
		// Prueba con archivos
		datosFirmaRequest.setTipo("ar");
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
		// Verificamos que se ha llamado al metodo 3 veces
		verify(datosFirmaHelperServiceImpl, times(3)).getDatosFirma(Mockito.any());
	}
	
	@Test
	@Ignore
	public void getDatosFirmaImpTest() {
		
		// Retorno de getDatosFirmaLotes
		DatosFirmaLotesOut datosFirmaLo = new DatosFirmaLotesOut();
		datosFirmaLo.setImporte(new BigDecimal(1004545874486456.66));
		datosFirmaLo.setNumPagos(1);
		
		// Retorno de getDatosFirmaArch
		DatosFirmaArchOut datosFirmaAr = new DatosFirmaArchOut();
		datosFirmaAr.setImporte(new BigDecimal(1004545874486456.66));
		datosFirmaAr.setNumPagos(1);
		
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaPagos(Mockito.any())).thenReturn("100");
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaLotes(Mockito.any())).thenReturn(datosFirmaLo);
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaArch(Mockito.any())).thenReturn(datosFirmaAr);
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirma(Mockito.any())).thenCallRealMethod();
		
		AppContext appContext = Mockito.mock(AppContext.class);
		Mockito.when(appContext.getUserData()).thenReturn(new DatosUsuario("###", "##/##/##", " es", "ES","S"));
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "appContext", appContext);
		
		DatosFirmaRequest datosFirmaRequest = new DatosFirmaRequest();
		
		// Prueba con pagos
		List<String> listaIds = new ArrayList<>();
		listaIds.add("485");
		datosFirmaRequest.setTipo("pagos");
		datosFirmaRequest.setListaIds(listaIds);
		
		List<DatosFirmaCuentaBenOut> listaCuenta = new ArrayList<>();
		Mockito.when(datosFirmaHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenReturn(listaCuenta);
		
		DatosFirmaResponse salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
//		List<DatosFirmaCuentaBenOut> listaCuenta2 = null;
//		Mockito.when(datosFirmaHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenReturn(listaCuenta2);
		
		// Prueba con lotes
		datosFirmaRequest.setTipo("lotes");
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
//		List<DatosFirmaCuentaBenOut> listaCuenta4 = new ArrayList<>();
//		DatosFirmaCuentaBenOut firmaCuenta2 = new DatosFirmaCuentaBenOut();
//		firmaCuenta2.setDigitosCuentaBen(null);
//		listaCuenta4.add(firmaCuenta2);
//		Mockito.when(datosFirmaHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenReturn(listaCuenta4);
		
		// Prueba con archivos
		datosFirmaRequest.setTipo("ar");
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
		// Verificamos que se ha llamado al metodo 3 veces
		verify(datosFirmaHelperServiceImpl, times(3)).getDatosFirma(Mockito.any());
	}
	
	@Test
	public void getDatosFirmaImpTest2() {
		
		// Retorno de getDatosFirmaLotes
		DatosFirmaLotesOut datosFirmaLo = new DatosFirmaLotesOut();
		datosFirmaLo.setImporte(new BigDecimal(1004545874486456.66));
		datosFirmaLo.setNumPagos(1);
		
		// Retorno de getDatosFirmaArch
		DatosFirmaArchOut datosFirmaAr = new DatosFirmaArchOut();
		datosFirmaAr.setImporte(new BigDecimal(1004545874486456.66));
		datosFirmaAr.setNumPagos(1);
		
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaPagos(Mockito.any())).thenReturn("100");
//		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaLotes(Mockito.any())).thenReturn(datosFirmaLo);
//		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirmaArch(Mockito.any())).thenReturn(datosFirmaAr);
		Mockito.when(datosFirmaHelperServiceImpl.getDatosFirma(Mockito.any())).thenCallRealMethod();
		
		AppContext appContext = Mockito.mock(AppContext.class);
		Mockito.when(appContext.getUserData()).thenReturn(new DatosUsuario("###", "##/##/##", " es", "ES","S"));
		ReflectionTestUtils.setField(datosFirmaHelperServiceImpl, "appContext", appContext);
		
		DatosFirmaRequest datosFirmaRequest = new DatosFirmaRequest();
		
		// Prueba con pagos
		List<String> listaIds = new ArrayList<>();
		listaIds.add("485");
		datosFirmaRequest.setTipo("pagos");
		datosFirmaRequest.setListaIds(listaIds);
		
		String paisPago = "ES";
		Mockito.when(datosFirmaHelperServiceImpl.getPaisPago(Mockito.anyString())).thenReturn(paisPago);
		
		List<DatosFirmaCuentaBenOut> listaCuenta3 = new ArrayList<>();
		DatosFirmaCuentaBenOut firmaCuenta = new DatosFirmaCuentaBenOut();
		firmaCuenta.setDigitosCuentaBen("123456789");
		listaCuenta3.add(firmaCuenta);
		Mockito.when(datosFirmaHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenReturn(listaCuenta3);
			
		DatosFirmaResponse salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salida.getStatus(), notNullValue());
		assertThat(salida.getMessage(), notNullValue());
		assertThat(salida.getImporte(), notNullValue());
		assertThat(salida.getNumPagos(), notNullValue());
		
		// Prueba con una cuenta con 0
		listaCuenta3.clear();
		firmaCuenta.setDigitosCuentaBen("123450123");
		listaCuenta3.add(firmaCuenta);
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Prueba con un pais no permitido
		paisPago = "CL";
		Mockito.when(datosFirmaHelperServiceImpl.getPaisPago(Mockito.anyString())).thenReturn(paisPago);
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Prueba con la lista vacia
		listaCuenta3.clear();
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Prueba con la lista a null
		List<DatosFirmaCuentaBenOut> listaCuenta4 = null;
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		// Prueba con la lista con mas de un id
		listaIds.add("123");
		datosFirmaRequest.setListaIds(listaIds);
		salida = datosFirmaHelperServiceImpl.getDatosFirma(datosFirmaRequest);
		
		
	}

}
