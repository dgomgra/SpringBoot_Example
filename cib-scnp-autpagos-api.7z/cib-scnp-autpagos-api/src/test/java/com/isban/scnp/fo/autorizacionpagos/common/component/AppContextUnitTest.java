package com.isban.scnp.fo.autorizacionpagos.common.component;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.isban.scnp.fo.autorizacionpagos.common.model.AmountSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DateSerializer;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.common.service.impl.CommonHelperServiceImpl;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@RunWith(MockitoJUnitRunner.class)
public class AppContextUnitTest {

	@Mock
	AppContext appContext;
	
	private JsonGenerator jsonGenerator;
	
	@Test
	public void appContest_Test() {
		
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("###,###,###.##", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
		
		appContext.getUserData();
		appContext.getUserData();
		appContext.getUserData();
		appContext.getUserData();
		
		// Singleton que se ejecuta una el componente una unica vez, por lo que comprobamos que es así
		verify(commonHelpserServiceImpl, times(1)).obtenerDatosUsuario(anyString());
		verify(appContext, times(4)).getUserData();
	}
	
	@Test
	public void DateSerializerTest() throws IOException {
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("###,###,###.##", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
			
		Writer jsonWriter = new StringWriter();
	    jsonGenerator = new JsonFactory().createGenerator(jsonWriter);
	    SerializerProvider serializerProvider = new ObjectMapper().getSerializerProvider();
		jsonGenerator.flush();
		
		DateSerializer ds= new DateSerializer();
		ReflectionTestUtils.setField(ds, "appContext", appContext);
		ds.serialize(new Date(), jsonGenerator, serializerProvider);		
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);
		
		
	}
	
	@Test
	public void AmountSerializerTest() throws IOException {
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("###,###,###.##", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
			
		Writer jsonWriter = new StringWriter();
	    jsonGenerator = new JsonFactory().createGenerator(jsonWriter);
	    SerializerProvider serializerProvider = new ObjectMapper().getSerializerProvider();
		jsonGenerator.flush();
		
		AmountSerializer as= new AmountSerializer();
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("123456789.12"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);		
	}
	@Test
	public void AmountSerializerTest2() throws IOException {
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("###.###.###,##", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
			
		Writer jsonWriter = new StringWriter();
	    jsonGenerator = new JsonFactory().createGenerator(jsonWriter);
	    SerializerProvider serializerProvider = new ObjectMapper().getSerializerProvider();
		jsonGenerator.flush();
		
		AmountSerializer as= new AmountSerializer();
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("123456789.12"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);		
	}
	@Test
	public void AmountSerializerTest3() throws IOException {
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("#########,##", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
			
		Writer jsonWriter = new StringWriter();
	    jsonGenerator = new JsonFactory().createGenerator(jsonWriter);
	    SerializerProvider serializerProvider = new ObjectMapper().getSerializerProvider();
		jsonGenerator.flush();
		
		AmountSerializer as= new AmountSerializer();
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("123456789.12"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);		
	}
	
	@Test
	public void AmountSerializerTest4() throws IOException {
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("#########.##", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
			
		Writer jsonWriter = new StringWriter();
	    jsonGenerator = new JsonFactory().createGenerator(jsonWriter);
	    SerializerProvider serializerProvider = new ObjectMapper().getSerializerProvider();
		jsonGenerator.flush();
		
		AmountSerializer as= new AmountSerializer();
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("123456789.12"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);		
	}
	
	@Test
	public void AmountSerializerTestResto() throws IOException {
		CommonHelperServiceImpl commonHelpserServiceImpl = Mockito.mock(CommonHelperServiceImpl.class);
		when(commonHelpserServiceImpl.obtenerDatosUsuario(anyString())).thenReturn(new DatosUsuario("", "dd/MM/yyyy", " es", "ES","S"));
		ReflectionTestUtils.setField(appContext, "chs", commonHelpserServiceImpl);
		
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(appContext.getUserData()).thenCallRealMethod();
			
		Writer jsonWriter = new StringWriter();
	    jsonGenerator = new JsonFactory().createGenerator(jsonWriter);
	    SerializerProvider serializerProvider = new ObjectMapper().getSerializerProvider();
		jsonGenerator.flush();
		
		AmountSerializer as= new AmountSerializer();
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("123456789"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);
		
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("0"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);	

		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("-3.41"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);	
		
		ReflectionTestUtils.setField(as, "appContext", appContext);
		as.serialize(new BigDecimal("-1.4"), jsonGenerator, serializerProvider);
		
		jsonGenerator.flush();
		assertTrue(jsonWriter.toString().length()>0);	
		
	}	
	
}
