package com.isban.scnp.fo.autorizacionpagos.rehacer.web;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.rehacer.model.RehacerRequest;
import com.isban.scnp.fo.autorizacionpagos.rehacer.service.impl.RehacerServiceImpl;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class RehacerControllerUnitTest {
	
	@Autowired
    private WebApplicationContext webApplicationContext;
	
	@Autowired
	RehacerRestController rehacerRestController;
	
	private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	private String cadena = "";
   
	private MockMvc mockMvc;
	
	@Before
    public void setup() throws Exception{
    	leerFichero();
        this.mockMvc = webAppContextSetup(webApplicationContext).build();     
    }
	
	
	@Test
	public void rehacerTest () throws Exception {		
		RehacerServiceImpl rehacerHelperServiceiImpl = Mockito.mock(RehacerServiceImpl.class);
		ReflectionTestUtils.setField(rehacerRestController, "rehacerHelperService", rehacerHelperServiceiImpl);
		
		String uri = "/authorization/v1/rehacer";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		
		verify(rehacerHelperServiceiImpl, times(1)).rehacerImpl(Mockito.any());
	}
	
	@Test
	public void rehacerTestKO() throws Exception {		
		RehacerServiceImpl rehacerHelperServiceiImpl = Mockito.mock(RehacerServiceImpl.class);
		ReflectionTestUtils.setField(rehacerRestController, "rehacerHelperService", rehacerHelperServiceiImpl);
		//when(rehacerHelperServiceiImpl.rehacerImpl(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
		//when(rehacerHelperServiceiImpl.rehacerImpl(Mockito.any())).the
		doThrow(new NullPointerException("Error occurred")).when(rehacerHelperServiceiImpl).rehacerImpl(Mockito.any());
		
		String uri = "/authorization/v1/rehacer";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isInternalServerError())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		
		verify(rehacerHelperServiceiImpl, times(1)).rehacerImpl(Mockito.any());
	}
	
	@Test
	public void rehacerTest_KOCredencial() throws Exception {		
		RehacerServiceImpl rehacerHelperServiceiImpl = Mockito.mock(RehacerServiceImpl.class);
		ReflectionTestUtils.setField(rehacerRestController, "rehacerHelperService", rehacerHelperServiceiImpl);
		doThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset())
		).when(rehacerHelperServiceiImpl).rehacerImpl(Mockito.any());
		
		String uri = "/authorization/v1/rehacer";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isUnauthorized())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		
		verify(rehacerHelperServiceiImpl, times(1)).rehacerImpl(Mockito.any());
	}
	
	@Test
	public void rehacerTestKO_Otro() throws Exception {		
		RehacerServiceImpl rehacerHelperServiceiImpl = Mockito.mock(RehacerServiceImpl.class);
		ReflectionTestUtils.setField(rehacerRestController, "rehacerHelperService", rehacerHelperServiceiImpl);
		doThrow(
				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset())
		).when(rehacerHelperServiceiImpl).rehacerImpl(Mockito.any());
		
		String uri = "/authorization/v1/rehacer";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
	
		mockMvc.perform(post(uri)
				.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.content(jsonInString))
		.andExpect(status().isInternalServerError())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andDo(print());
		
		verify(rehacerHelperServiceiImpl, times(1)).rehacerImpl(Mockito.any());
	}
	
	
	
	
	
	
	private RehacerRequest rellenarEntrada(String tipo) {
		RehacerRequest salida = new RehacerRequest();

		if("ok".equals(tipo)) {    		
			String tipoEj = JsonPath.read(jsonFile, "$.ejecucionOK.tipo");
			String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
			List<String> ids = JsonPath.read(jsonFile, "$.ejecucionOK.listaIds");

			salida.setTipo(tipoEj);
			salida.setTokenBks(tokenBks);
			salida.setListaIds(ids);
		}else {
			
		}

		return salida;
	}

	
	private void leerFichero() {
		try {
			File file = new File("src/test/resources/json/RehacerControllerUnitTest.json");
			fe = new FileInputStream(file);
			isr = new InputStreamReader(fe);
			br = new BufferedReader(isr);

			while((cadena = br.readLine()) != null){
				System.out.println(cadena);
				jsonFile = jsonFile.concat(cadena);
			}

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
