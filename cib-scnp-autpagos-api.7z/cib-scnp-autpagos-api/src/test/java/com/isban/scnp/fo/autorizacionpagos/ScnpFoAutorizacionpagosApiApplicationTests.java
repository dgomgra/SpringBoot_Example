package com.isban.scnp.fo.autorizacionpagos;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class ScnpFoAutorizacionpagosApiApplicationTests {

	@Test
	public void contextLoads() {
		String s=new String("ResumenIntradia");
		assertNotNull(s);
	}

}
