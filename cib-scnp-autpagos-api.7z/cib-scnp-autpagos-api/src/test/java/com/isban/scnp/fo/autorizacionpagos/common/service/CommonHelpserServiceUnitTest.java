package com.isban.scnp.fo.autorizacionpagos.common.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuarioMapper;
import com.isban.scnp.fo.autorizacionpagos.common.service.impl.CommonHelperServiceImpl;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class CommonHelpserServiceUnitTest {

	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	CommonHelperServiceImpl commonHelperServiceImpl;
	
	@Test
	public void obtenerDatosUsuario_Test() {
		when(commonHelperServiceImpl.obtenerDatosUsuario(Mockito.anyString())).thenCallRealMethod();		
			
		
		DatosUsuario datosUsuario0 = new DatosUsuario("", "", "", "","");
		datosUsuario0.setFormatoCantidad("##");
		datosUsuario0.setFormatoFecha("##/##/#####");
		datosUsuario0.setIdioma(" es");
		datosUsuario0.setCodPais("ES");
		datosUsuario0.setTipoCripto("S");
		
		List<DatosUsuario> datosUsuario = new ArrayList<DatosUsuario>();
		datosUsuario.add(new DatosUsuario("##", "##/##/#####", " es", "ES","S"));
		
		Mockito.when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(DatosUsuarioMapper.class))).thenReturn(datosUsuario);
		ReflectionTestUtils.setField(commonHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		
		DatosUsuario salida = commonHelperServiceImpl.obtenerDatosUsuario("USUARIO");
	
		verify(commonHelperServiceImpl, times(1)).obtenerDatosUsuario(Mockito.anyString());

		assertEquals(salida.getFormatoCantidad(), "##");
		assertEquals(salida.getFormatoFecha(), "##/##/#####");	
		
		assertEquals(salida.getFormatoCantidad(), datosUsuario0.getFormatoCantidad());
		assertEquals(salida.getFormatoFecha(), datosUsuario0.getFormatoFecha());
		assertEquals(salida.getIdioma(), datosUsuario0.getIdioma());
		assertEquals(salida.getCodPais(), datosUsuario0.getCodPais());
		assertEquals(salida.getTipoCripto(), datosUsuario0.getTipoCripto());		
	}
	
}
