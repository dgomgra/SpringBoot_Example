package com.isban.scnp.fo.autorizacionpagos.listaLotes.service;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.comppagosrol.model.CompPagosRolUsuPendFirmaOut;
import com.isban.scnp.fo.autorizacionpagos.comppagosrol.service.CompPagosRolHelperService;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaOut;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl.ConversionDivisaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.model.DatosLotesWarehousing;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DatosLote;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DatosPagoLoteDivisa;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteOut;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.impl.ListaLotesHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.DatosPagoAutorizar;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class ListaLotesHelperServiceImplUnitTest {
	
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	ListaLotesHelperServiceImpl listaLotesHelperServiceImpl;
	
	@Test
	public void getListaLotesAutorizarByPageTest_Ok() {
		
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		
		// Salida de la llamada al procedimiento
		ListaLotesAutorizarResponse procedimientoOut = new ListaLotesAutorizarResponse();
		
		// Salida de la llamada a getListaLotesAutorizar
		ListaLotesAutorizarResponse respuestaCompleta = rellenarListaLotesAut();
		
		// Salida de la llamada a prepararPagina y obtenerDivisasConvertidas
		List<DatosLote> listaSalida = rellenarDatosLote();
		
		// Salida de la llamada a obtenerListaDivisas
		List <String> listaDivisas = new ArrayList<>();
		
		
		Mockito.when(listaLotesHelperServiceImpl.getListaLotesAutorizar(anyString(), anyString(), anyString(), any(), any())).thenReturn(respuestaCompleta);
		Mockito.when(listaLotesHelperServiceImpl.prepararPagina(anyInt(), anyInt(), any())).thenReturn(listaSalida);
		Mockito.when(listaLotesHelperServiceImpl.obtenerDivisasConvertidas(any(), anyString(), anyString())).thenReturn(listaSalida);
		Mockito.when(listaLotesHelperServiceImpl.obtenerListaDivisas(anyString(), any(), any(), any())).thenReturn(listaDivisas);
		Mockito.when(listaLotesHelperServiceImpl.getListaLotesAutorizarByPage(any(), anyBoolean())).thenCallRealMethod();
		
		// 1) Prueba con una consulta OK
		ListaLotesRequest listaLotesRequest = new ListaLotesRequest();
		listaLotesRequest.setNumPagina(1);
		listaLotesRequest.setNumPorPagina(10);
		listaLotesRequest.setMonedaConsolidacion("EUR");
		listaLotesRequest.setTokenBks("TOKEN");
		ListaLotesAutorizarResponse salidaOk = listaLotesHelperServiceImpl.getListaLotesAutorizarByPage(listaLotesRequest, false);
		
		// Verificamos que no retorne un valor nulo
		assertThat(salidaOk, notNullValue());
		
		// Verificamos el tipo de dato de la salida
		assertThat(salidaOk.getStatus(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getMessage(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getPagina(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salidaOk.getTotalLotes(), org.hamcrest.Matchers.isA(Integer.class));
		assertThat(salidaOk.getListaDatosLote(), notNullValue());
		assertThat(salidaOk.getListaDivisas(), notNullValue());
		
		// Verificamos los tipos de dato de la listaDatosLote
		assertThat(salidaOk.getListaDatosLote().get(0).getIdLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getCodEstLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getNomLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getCodPais(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getImpLote(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getDivisaLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getFechaLote(), org.hamcrest.Matchers.isA(Date.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getTotalPagos(), org.hamcrest.Matchers.isA(long.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getIndImportado(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getIndNotas(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getIndicadorUpload(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getIndSalario(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getDescEstLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getIndicadorCbs(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salidaOk.getListaDatosLote().get(0).getIndBulk(), org.hamcrest.Matchers.isA(String.class));
		
		
		// Verificamos que el codigo y el mensaje son correctos
		assertEquals(salidaOk.getStatus(), "OK");
		assertEquals(salidaOk.getMessage(), "OK");
		
		
		// 2) Prueba con una consulta de una pagina que no existe
		listaSalida.clear();
		ListaLotesAutorizarResponse salidaKoPag = listaLotesHelperServiceImpl.getListaLotesAutorizarByPage(listaLotesRequest, false);
		
		// Verificamos que el codigo y el mensaje son correctos
		assertEquals(salidaKoPag.getStatus(), "KO");
		assertEquals(salidaKoPag.getMessage(),  "0053");
		
		// 3) Prueba con una consulta con el indicador resumen a true
		ListaLotesAutorizarResponse salidaOkResumen = listaLotesHelperServiceImpl.getListaLotesAutorizarByPage(listaLotesRequest, true);
	
		// Verificamos que el codigo y el mensaje son correctos
		assertEquals(salidaOkResumen.getStatus(), "OK");
		assertEquals(salidaOkResumen.getMessage(),  "OK");
		
		// 4) Prueba con una consulta que no obtiene datos
		respuestaCompleta.getListaDatosLote().clear();
		ListaLotesAutorizarResponse salidaKoSinDatos = listaLotesHelperServiceImpl.getListaLotesAutorizarByPage(listaLotesRequest, false);
		
		// Verificamos que el codigo y el mensaje son correctos
		assertEquals(salidaKoSinDatos.getStatus(), "KO");
		assertEquals(salidaKoSinDatos.getMessage(),  "0000");
		
		// 5) Prueba con una consulta con respuesta vacia
		respuestaCompleta.setStatus(null);
		ListaLotesAutorizarResponse salidaVacia = listaLotesHelperServiceImpl.getListaLotesAutorizarByPage(listaLotesRequest, false);
		
		// Verificamos que se ha llamado al metodo 5 veces
		verify(listaLotesHelperServiceImpl, times(5)).getListaLotesAutorizarByPage(any(), anyBoolean());
	}
	
	@Test
	public void getPagosLotesUsuarioAutorizProcedureTest() {
		
		//Map<String, Object> datos = RellenarLotesUsuarioAutorizProcedure("OK");
		Map<String, Object> datos = new HashMap<>();

		Mockito.when(jdbcTemplate.call(any(), any())).thenReturn(datos);
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		Mockito.when(listaLotesHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure(anyString())).thenCallRealMethod();
		
		Map<String, Object> salida = listaLotesHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure("SGPdavidf787753");
		
		// Falta verificar los datos de salida del procedimiento
		
		// Verificamos que se ha llamado al metodo
		verify(listaLotesHelperServiceImpl, times(1)).getPagosLotesUsuarioAutorizProcedure(anyString());
		
	}
	
	@Test
	public void getDetalleLoteImpTest() {
		// Salida de la llamada a getDetalleLote
		DetalleLoteOut detalle = rellenarDetalleLote();
		
		// Interfaz listaPagosHelperService
		ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
		ListaPagosAutorizarResponse pagos = new ListaPagosAutorizarResponse();
		pagos.setListaDatosPagosAutorizar(RellenarDatosPagoAutorizar());
		
		Mockito.when(listaLotesHelperServiceImpl.getDetalleLote(anyString())).thenReturn(detalle);
		Mockito.when(listaPagosHelperService.getListaPagosAutorizarImp(any())).thenReturn(pagos);
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "listaPagosHelperService", listaPagosHelperService);
		Mockito.when(listaLotesHelperServiceImpl.getDetalleLoteImp(any())).thenCallRealMethod();
		
		DetalleLoteRequest detalleLoteRequest = new DetalleLoteRequest();
		detalleLoteRequest.setNumLote("L00000001");
		detalleLoteRequest.setTokenBks("TOKEN");
		DetalleLoteResponse salida = listaLotesHelperServiceImpl.getDetalleLoteImp(detalleLoteRequest);
		
		// Verificamos los tipos de datos de la salida
		assertThat(salida.getStatus(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getMessage(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getNumLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getEstadoLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getNombreLote(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getPais(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getDivisa(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getMonto(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salida.getNumPagos(), org.hamcrest.Matchers.isA(int.class));
		assertThat(salida.getFecha(), org.hamcrest.Matchers.isA(Date.class));
		assertThat(salida.getListaPagos().get(0).getDivisa(), org.hamcrest.Matchers.isA(String.class));
		assertThat(salida.getListaPagos().get(0).getImporte(), org.hamcrest.Matchers.isA(BigDecimal.class));
		assertThat(salida.getListaPagos().get(0).getNumPagos(), org.hamcrest.Matchers.isA(int.class));

		
		// Verificamos que se ha llamado al metodo
		verify(listaLotesHelperServiceImpl, times(1)).getDetalleLoteImp(any());
	}
	
	@Test
	public void getListaLotesAutorizarTest() {
		
		// Interfaz listaPagosHelperService
		ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
		
		// Salida de la llamada a getPagosLotesUsuarioAutorizProcedure
		Map<String, Object> datosLotes = rellenarListaPagosLotesUsuarioAutoriz("OK");
			
		Mockito.when(listaPagosHelperService.comprobarTokenSKeyUsu(anyString())).thenReturn("SGPdavidf787753");
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "listaPagosHelperService", listaPagosHelperService);
		Mockito.when(listaLotesHelperServiceImpl.getPagosLotesUsuarioAutorizProcedure(anyString())).thenReturn(datosLotes);
		Mockito.when(listaLotesHelperServiceImpl.getListaLotesAutorizar(anyString(), anyString(), anyString(), any(), any())).thenCallRealMethod();
		
		CompPagosRolHelperService compPagosRolHelperService = Mockito.mock(CompPagosRolHelperService.class);
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "compPagosRolHelperService", compPagosRolHelperService);
		List<CompPagosRolUsuPendFirmaOut> salidaRolUsuPendFirma = new ArrayList<>();
		CompPagosRolUsuPendFirmaOut out = new CompPagosRolUsuPendFirmaOut();
		out.setCodSentencia(1);
		out.setIdAutorizacion(1);
		out.setRftrans("SGPPAGO1");
		salidaRolUsuPendFirma.add(out);
		CompPagosRolUsuPendFirmaOut out2 = new CompPagosRolUsuPendFirmaOut();
		out2.setCodSentencia(1);
		out2.setIdAutorizacion(1);
		out2.setRftrans("SGPPAGO2");
		salidaRolUsuPendFirma.add(out2);
		when(compPagosRolHelperService.compPagosRolUsuPendFirma(any())).thenReturn(salidaRolUsuPendFirma);
		

		List<String> firmados = new ArrayList<>();
		firmados.add("SGPPAGO1");
		when(listaPagosHelperService.obtPagosFirmaOKUsuario(anyString(), any())).thenReturn(firmados);
		
		
		// Datos de entrada de la consulta
		Map<String, String> mapIdPago_IdLote = new HashMap<>();
		List<String> listaPagosObtenidos = new ArrayList<>();
		ListaLotesAutorizarResponse salida = listaLotesHelperServiceImpl.getListaLotesAutorizar("SGPdavidf787753", "EUR", "1234", mapIdPago_IdLote, listaPagosObtenidos);
		
		
		// Verificamos que se ha llamado al metodo
		verify(listaLotesHelperServiceImpl, times(1)).getListaLotesAutorizar(anyString(), anyString(), anyString(), any(), any());
	}
	
	
	private Map<String, Object> rellenarListaPagosLotesUsuarioAutoriz(String test) {
		Map<String, Object> datos = new HashMap<>();
		List<Object> result = new ArrayList<>();
		Map<String, Object> objetos = new HashMap<>();
		objetos.put("N6563_RFTRANS", "SGPPAGO1");
		objetos.put("O2046_NULOTE", "L000001");
		objetos.put("O2046_ESTPAGO", "LA");
		objetos.put("O2046_DESCRI50", "LOTE1");
		objetos.put("O2046_CODPAIS", "ES");
		objetos.put("O2046_CODMONSWI", "EUR");
		objetos.put("O2046_IMPLOTE2", "400");
		objetos.put("O2046_IND_NOM", "N");
		objetos.put("O2046_FECHALOT", new Date());
		objetos.put("O2046_TOTPAGOS", 1);
		objetos.put("O2046_BATCH_B", "N");
		objetos.put("INDLIB", "N");
		objetos.put("INDIMP_LOTE", "N");
		objetos.put("INDUPL_LOTE", "N");
		objetos.put("INDNOTA_LOTE", "N");
		objetos.put("INDCBS_LOTE", "N");
		objetos.put("ESTADO_TRAD", "INGRESADO");
		result.add(objetos);
		
		Map<String, Object> objetos2 = new HashMap<>();
		objetos2.put("N6563_RFTRANS", "SGPPAGO2");
		objetos2.put("O2046_NULOTE", "L000002");
		objetos2.put("O2046_ESTPAGO", "LA");
		objetos2.put("O2046_DESCRI50", "LOTE2");
		objetos2.put("O2046_CODPAIS", "ES");
		objetos2.put("O2046_CODMONSWI", "EUR");
		objetos2.put("O2046_IMPLOTE2", "400");
		objetos2.put("O2046_IND_NOM", "N");
		objetos2.put("O2046_FECHALOT", new Date());
		objetos2.put("O2046_TOTPAGOS", 1);
		objetos2.put("O2046_BATCH_B", "N");
		objetos2.put("INDLIB", "S");
		objetos2.put("INDIMP_LOTE", "N");
		objetos2.put("INDUPL_LOTE", "N");
		objetos2.put("INDNOTA_LOTE", "N");
		objetos2.put("INDCBS_LOTE", "N");
		objetos2.put("ESTADO_TRAD", "INGRESADO");
		result.add(objetos2);
		
		if("OK".equals(test)) {			
			datos.put("result", result);
		}else {
			datos.put("fail", result);
		}
		return datos;
	}

	@Test
	public void equalsAndHashCodeTest() {
		DatosLote datosLote = new DatosLote();
		datosLote.setIdLote("LOT1234");
		datosLote.setFechaLote(new Date());
		boolean esIgual = datosLote.equals("");
		assertEquals(esIgual, false);
		
		esIgual = datosLote.equals(null);
		
		esIgual = datosLote.equals(datosLote);
		assertEquals(esIgual, true);
		
		int code = datosLote.hashCode();
		assertNotNull(code);
		
		int comp = datosLote.compareTo(datosLote);
		assertNotNull(comp);
		
	}
	
	private ListaLotesAutorizarResponse rellenarListaLotesAut() {
		ListaLotesAutorizarResponse salida = new ListaLotesAutorizarResponse();
		
		salida.setStatus("OK");
		salida.setMessage("Operación realizada correctamente");
		salida.setTotalLotes(1);
		salida.setPagina(1);
		
		List<DatosLote> listaDatosLote = rellenarDatosLote();
		salida.setListaDatosLote(listaDatosLote);
		
		List<String> listaDivisas = new ArrayList<>();
		listaDivisas.add("EUR");
		salida.setListaDivisas(listaDivisas);
		
		return salida;

	}
	
	private List<DatosLote> rellenarDatosLote(){
		List<DatosLote> salida = new ArrayList<>();
		DatosLote datosLote = new DatosLote();
		datosLote.setIdLote("L201812260912277");
		datosLote.setCodEstLote("AL");
		datosLote.setNomLote("Lote_test");
		datosLote.setCodPais("ES");
		datosLote.setImpLote(new BigDecimal(100));
		datosLote.setDivisaLote("EUR");
		datosLote.setFechaLote(new Date());
		datosLote.setTotalPagos(1);
		datosLote.setIndImportado("N");
		datosLote.setIndNotas("N");
		datosLote.setIndicadorUpload("N");
		datosLote.setIndSalario("N");
		datosLote.setDescEstLote("Autorizado");
		datosLote.setIndicadorCbs("N");
		datosLote.setIndBulk("N");
		salida.add(datosLote);
		return salida;
	}
	
	private List<DatosPagoAutorizar> RellenarDatosPagoAutorizar() {
		List<DatosPagoAutorizar> salida = new ArrayList<>();
		List<String> listRftrans = new ArrayList();
		listRftrans.add("SGP11111111");
		listRftrans.add("SGP11111112");
		listRftrans.add("SGP11111113");
		listRftrans.add("SGP11111114");
		listRftrans.add("SGP11111115");
		listRftrans.add("SGP11111116");
		listRftrans.add("SGP11111117");
		listRftrans.add("SGP11111118");
		listRftrans.add("SGP11111119");
		
		for (int i = 0; i < 9; i++) {
			DatosPagoAutorizar datos = new DatosPagoAutorizar();
			datos.setRftrans(listRftrans.get(i));
			if(i == 8) {
				datos.setCodMedioPago("MT");
				datos.setCodBeneficiario(0);
				datos.setDivisa("EUR");
			}else if(i == 7) {
				datos.setCodMedioPago("MT");
				datos.setCodBeneficiario(0);
				datos.setDivisa("EUR");
			}else if(i == 6) {
				datos.setCodMedioPago("AR");
				datos.setCodBeneficiario(0);
				datos.setDivisa("GBP");
			}else {
				datos.setCodMedioPago("AR");
				datos.setCodBeneficiario(1120);
				datos.setDivisa("EUR");
			}
			datos.setIndNota("S");
			datos.setIndImp("S");
			datos.setIdEstado("Ingresado");
			datos.setCodExtracto("78798");
			datos.setIdAutorizacion(5434);
			datos.setNomBenef("nombre");
			BigDecimal importe = new BigDecimal(133);
			datos.setImporte(importe);
			Date fecha = new Date();
			datos.setFecha(fecha);
			datos.setRefCliente("34553");
			datos.setIndicadorUpload("N");
			datos.setCodPais("ES");
			datos.setDescEstPago("Aceptado");
			datos.setCuentaOrdenante(4455);
			datos.setDescNota("Nota de ingreso");
			salida.add(datos);
		}
		
		return salida;
	}
	
	private DetalleLoteOut rellenarDetalleLote() {
		DetalleLoteOut salida = new DetalleLoteOut();
		salida.setNumLote("Lot1234");
		salida.setEstadoLote("LA");
		salida.setNombreLote("Lote1234");
		salida.setPais("ES");
		salida.setDivisa("EUR");
		salida.setMonto(new BigDecimal(1500));
		salida.setNumPagos(3);
		salida.setFecha(new Date());
		
		return salida;
	}

	@Test
	public void obtenerListaDivisasTest() {
		List<DatosPagoLoteDivisa> salidaDivisasPagos = new ArrayList<>();
		
		DatosPagoLoteDivisa pagoLoteDivisa = new DatosPagoLoteDivisa();
		pagoLoteDivisa.setDivisaPago("ARS");
		pagoLoteDivisa.setIdLote("LOTE1");
		pagoLoteDivisa.setIdPago("RFTRANS1");
		salidaDivisasPagos.add(pagoLoteDivisa);
		
		when(listaLotesHelperServiceImpl.obtDivisasPagos(any())).thenReturn(salidaDivisasPagos);
		
		List<String> listaPagosObtenidos = Arrays.asList("RFTRANS1");
		Map<String, String> mapaPagoLote = new HashMap<String, String>();
		mapaPagoLote.put("RFTRANS1", "LOTE1");
		
		List<DatosLote> listaSalida = new ArrayList<>();
		DatosLote datosLote = new DatosLote();
		datosLote.setCodEstLote("LA");
		datosLote.setCodPais("ES");
		datosLote.setDescEstLote("DESCRIPCION");
		datosLote.setDivisaLote("ARS");
		datosLote.setFechaLote(new Date());
		datosLote.setIdLote("LOTE1");
		datosLote.setImpLote(new BigDecimal(10));
		datosLote.setIndBulk("N");
		datosLote.setIndicadorCbs("N");
		datosLote.setIndicadorUpload("N");
		datosLote.setIndImportado("N");
		datosLote.setIndNotas("N");
		datosLote.setIndSalario("N");
		datosLote.setNomLote("NOMBRELOTE1");
		datosLote.setTotalPagos(1);
		listaSalida.add(datosLote);
		
		when(listaLotesHelperServiceImpl.obtenerListaDivisas(anyString(), any(), any(), any())).thenCallRealMethod();
		List<String> salida = listaLotesHelperServiceImpl.obtenerListaDivisas("EUR", listaPagosObtenidos, mapaPagoLote, listaSalida);
		
		assertTrue(salida.size() > 0);
		assertTrue(salida.contains("EUR"));
		assertTrue(salida.contains("USD"));
		assertTrue(salida.contains("GBP"));
		assertTrue(salida.contains("ARS"));
	}
	
	@Test
	public void obtenerDivisasConvertidasTest()
	{
		// Servicio externo (listawarehouse)
		ConversionDivisaHelperServiceImpl conversionDivisaHelperService = Mockito.mock(ConversionDivisaHelperServiceImpl.class);
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "conversionDivisaHelperService", conversionDivisaHelperService);
		when(conversionDivisaHelperService.conversionDivisa(any())).thenReturn(retornoDivisa());
		when(listaLotesHelperServiceImpl.obtenerDivisasConvertidas(any(), anyString(), anyString())).thenCallRealMethod();
		
		List<DatosLote> listaLotes = new ArrayList<>();
		DatosLote lote1 = new DatosLote();
		lote1.setDivisaLote("USD");
		lote1.setImpLote(new BigDecimal(300));
		listaLotes.add(lote1);
		List<DatosLote> salida = listaLotesHelperServiceImpl.obtenerDivisasConvertidas(listaLotes, "EUR", "token123");
		assertTrue(salida.size() > 0);
		assertEquals(salida.get(0).getDivisaLote(), "EUR");
		
	}

	private ConversionDivisaResponse retornoDivisa() {
		ConversionDivisaResponse cdr = new ConversionDivisaResponse();
		ConversionDivisaOut convDivisa = new ConversionDivisaOut();
		List<ImporteType> listaImportes = new ArrayList<>();
		ImporteType imp0 = new ImporteType(new BigDecimal(333.78), "EUR");
		listaImportes.add(imp0);
		convDivisa.setListaImportes(listaImportes);
		cdr.setMethodResult(convDivisa);
		return cdr;
	}
	
	@Test
	public void prepararPaginaTest() {
		when(listaLotesHelperServiceImpl.prepararPagina(anyInt(), anyInt(), any())).thenCallRealMethod();
		List salida = listaLotesHelperServiceImpl.prepararPagina(1-1, 1, Arrays.asList("1", "2", "3"));
		assertTrue(salida.size() == 1);
		
		salida = listaLotesHelperServiceImpl.prepararPagina(2-1, 3, Arrays.asList("1", "2", "3", "4"));
		assertTrue(salida.size() == 1);
		
		salida = listaLotesHelperServiceImpl.prepararPagina(2-1, 5, Arrays.asList("1", "2", "3"));
		assertTrue(salida.size() == 0);
		
		verify(listaLotesHelperServiceImpl, times(3)).prepararPagina(anyInt(), anyInt(), any());
	}
	
	@Test
	public void compareLoteTest()
	{
		Date d = new Date();
		Date dMayor = new Date(d.getTime()+1000);
		Date dMenor = new Date(d.getTime()-1000);
		
		DatosLotesWarehousing lote1 = new DatosLotesWarehousing();
		lote1.setIdLote("L202009150928902");
		lote1.setFechaLote(d);
		
		DatosLotesWarehousing lote2 = new DatosLotesWarehousing();		
		lote2.setIdLote("L202009150928902");
		lote2.setFechaLote(d);
		
		DatosLotesWarehousing lote3 = new DatosLotesWarehousing();		
		lote3.setIdLote("L202009150928903");
		lote3.setFechaLote(d);
		
		DatosLotesWarehousing lote4 = new DatosLotesWarehousing();		
		lote4.setIdLote("L202009150928904");
		lote4.setFechaLote(d);
		
		DatosLotesWarehousing lote5 = new DatosLotesWarehousing();		
		lote5.setIdLote("L202009150928905");
		lote5.setFechaLote(dMayor);		
		
		DatosLotesWarehousing lote6 = new DatosLotesWarehousing();		
		lote6.setIdLote("L202009150928906");
		lote6.setFechaLote(dMenor);
		
		int compararIgual = lote1.compareTo(lote2);
		boolean compararMenorNombre = lote1.compareTo(lote3)<0;
		boolean compararIgual3 = lote1.equals(lote1);
		boolean compararMenor4 = lote1.compareTo(lote4)<0;
		
		boolean compararMenor = lote1.compareTo(lote5)<0;
		boolean compararMayor = lote1.compareTo(lote6)>0;
		
		int hash = lote1.hashCode();
		
		assertEquals(compararIgual, 0);
		assertTrue(compararMenorNombre);
		assertTrue(compararIgual3);
		assertTrue(compararMenor4);
		assertTrue(compararMenor);
		assertTrue(compararMayor);	
		assertTrue(hash!=0);
	}
}
