package com.isban.scnp.fo.autorizacionpagos.datosFirma.model;

import static org.junit.Assert.assertNotNull;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;

import com.isban.scnp.fo.autorizacionpagos.Application;

@WithAnonymousUser
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DatosFirmaCuentaBenMapperTest {
	
	@Test
	public void DatosFirmaCuentaBenMapperModelTest() throws SQLException {
		
		DatosFirmaCuentaBenMapper mapper = new DatosFirmaCuentaBenMapper();
		
		DatosFirmaCuentaBenOut  salida = new DatosFirmaCuentaBenOut();
		
		ResultSet rs = Mockito.mock(ResultSet.class);
		
		Mockito.when(rs.getString(Mockito.anyString())).thenReturn("");
		
		salida = mapper.mapRow(rs, 1);
		
		assertNotNull(salida);
		
	}

}
