package com.isban.scnp.fo.autorizacionpagos.listaLotes.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.ListaLotesRequest;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.ListaLotesHelperService;
import com.isban.scnp.fo.autorizacionpagos.listalotes.web.ListaLotesRestController;
import com.jayway.jsonpath.JsonPath;

@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaLotesRestControllerUnitTest {

	  @Autowired
	  private WebApplicationContext webApplicationContext;
	  
	  @Autowired
	  ListaLotesRestController listaLotesRestController;
	  
	    private MockMvc mockMvc;
	    
		private FileInputStream fe = null;
		private InputStreamReader isr = null;
		private BufferedReader br = null;
		private String jsonFile = "";
		private String cadena = "";
	    
	    
	    @Before
	    public void setup() throws Exception{
	    	leerFichero();
	        this.mockMvc = webAppContextSetup(webApplicationContext).build();     
	    }
	    
	    @Test
	    public void getListaLotesAutorizarByPageOkTest() throws Exception {
	        // Se rellenan los datos para ListaLotesAutorizarResponse
	    	ListaLotesAutorizarResponse respuesta = rellenarLotesAutorizar("OK");
	    	
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	        Mockito.when(listaLotesHelperService.getListaLotesAutorizarByPage(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
	        ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	    	
	    	ObjectMapper mapper = new ObjectMapper();
	    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	    	
	    	String uri = "/authorization/v1/listadoLotesAutorizar";
	    	
	    	mockMvc.perform(post(uri)
	    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.content(jsonInString))
	        .andExpect(status().isOk())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	        .andDo(print());
	    }
	    
	    @Test
	    public void getListaPagosAutorizarKoTest() throws Exception {
	    	
	        // Se rellenan los datos para ListaLotesAutorizarResponse
	    	ListaLotesAutorizarResponse respuesta = rellenarLotesAutorizar("KO");
	    
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	        Mockito.when(listaLotesHelperService.getListaLotesAutorizarByPage(Mockito.any(), Mockito.anyBoolean())).thenReturn(respuesta);
	        ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	    	
	    	ObjectMapper mapper = new ObjectMapper();
	    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	    	
	    	String uri = "/authorization/v1/listadoLotesAutorizar";
	    	
	    	mockMvc.perform(post(uri)
	    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.content(jsonInString))
	        .andExpect(status().isOk())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	        .andDo(print());

	    }
	    
	    @Test
	    public void getListaPagosAutorizarKo2Test() throws Exception {
	    
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	        Exception ex = new Exception();
	        Mockito.when(listaLotesHelperService.getListaLotesAutorizarByPage(Mockito.any(), Mockito.anyBoolean())).thenThrow(new NullPointerException("Error occurred"));
	        ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	    	
	    	ObjectMapper mapper = new ObjectMapper();
	    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
	    	
	    	String uri = "/authorization/v1/listadoLotesAutorizar";
	    	
	    	mockMvc.perform(post(uri)
	    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.content(jsonInString))
	        .andExpect(status().isInternalServerError())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	        .andDo(print());

	    }
	    
	    @Test
	   	public void listaPagosTest_KOCredencial() throws Exception {
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	   		
	   		ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	   		
	   		
	   		when(listaLotesHelperService.getListaLotesAutorizarByPage(Mockito.any(), Mockito.anyBoolean())).thenThrow(
	   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
	   		
	   		ObjectMapper mapper = new ObjectMapper();
	       	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	       	
	       	String uri = "/authorization/v1/listadoLotesAutorizar";
	       	
	       	mockMvc.perform(post(uri)
	       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.content(jsonInString))
	           .andExpect(status().isUnauthorized())
	           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	           .andDo(print());
	   		
	   	}
	   	
	   	@Test
	   	public void listaPagosTest_KOOtro() throws Exception {
	   		ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	   		ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	   		
	   		
	   		when(listaLotesHelperService.getListaLotesAutorizarByPage(Mockito.any(), Mockito.anyBoolean())).thenThrow(
	   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
	   		
	   		ObjectMapper mapper = new ObjectMapper();
	       	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
	       	
	       	String uri = "/authorization/v1/listadoLotesAutorizar";
	       	
	       	mockMvc.perform(post(uri)
	       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.content(jsonInString))
	           .andExpect(status().isInternalServerError())
	           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	           .andDo(print());
	   		
	   	}
	   	
	   	/*** ***/
	   	@Test
	    public void getDetalleLotesOkTest() throws Exception {
	        // Se rellenan los datos para DetalleLoteResponse
	   		DetalleLoteResponse respuesta = rellenarDetalleLotes("OK");
	    	
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	        Mockito.when(listaLotesHelperService.getDetalleLoteImp(Mockito.any())).thenReturn(respuesta);
	        ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	    	
	    	ObjectMapper mapper = new ObjectMapper();
	    	String jsonInString = mapper.writeValueAsString(rellenarEntradaDetalle("ok"));
	    	
	    	String uri = "/authorization/v1/detalleLote";
	    	
	    	mockMvc.perform(post(uri)
	    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.content(jsonInString))
	        .andExpect(status().isOk())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	        .andDo(print());
	    }
	    
	    @Test
	    public void getDetalleLotesKoTest() throws Exception {
	    	
	        // Se rellenan los datos para DetalleLoteResponse
	    	DetalleLoteResponse respuesta = rellenarDetalleLotes("KO");
	    
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	        Mockito.when(listaLotesHelperService.getDetalleLoteImp(Mockito.any())).thenReturn(respuesta);
	        ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	    	
	    	ObjectMapper mapper = new ObjectMapper();
	    	String jsonInString = mapper.writeValueAsString(rellenarEntradaDetalle("ok"));
	    	
	    	String uri = "/authorization/v1/detalleLote";
	    	
	    	mockMvc.perform(post(uri)
	    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.content(jsonInString))
	        .andExpect(status().isOk())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	        .andDo(print());

	    }
	    
	    @Test
	    public void getDetalleLotesKo2Test() throws Exception {
	    
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	        Mockito.when(listaLotesHelperService.getDetalleLoteImp(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
	        ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	    	
	    	ObjectMapper mapper = new ObjectMapper();
	    	String jsonInString = mapper.writeValueAsString(rellenarEntradaDetalle("ko"));
	    	
	    	String uri = "/authorization/v1/detalleLote";
	    	
	    	mockMvc.perform(post(uri)
	    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	    			.content(jsonInString))
	        .andExpect(status().isInternalServerError())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	        .andDo(print());

	    }
	    
	    @Test
	   	public void getDetalleLotes_KOCredencial() throws Exception {
	    	ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	   		
	   		ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	   		
	   		
	   		when(listaLotesHelperService.getDetalleLoteImp(Mockito.any())).thenThrow(
	   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
	   		
	   		ObjectMapper mapper = new ObjectMapper();
	       	String jsonInString = mapper.writeValueAsString(rellenarEntradaDetalle("ok"));
	       	
	       	String uri = "/authorization/v1/detalleLote";
	       	
	       	mockMvc.perform(post(uri)
	       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.content(jsonInString))
	           .andExpect(status().isUnauthorized())
	           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	           .andDo(print());
	   		
	   	}
	   	
	   	@Test
	   	public void getDetalleLotes_KOOtro() throws Exception {
	   		ListaLotesHelperService listaLotesHelperService = Mockito.mock(ListaLotesHelperService.class);
	   		ReflectionTestUtils.setField(listaLotesRestController, "listaLotesHelperService", listaLotesHelperService);
	   		
	   		
	   		when(listaLotesHelperService.getDetalleLoteImp(Mockito.any())).thenThrow(
	   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
	   		
	   		ObjectMapper mapper = new ObjectMapper();
	       	String jsonInString = mapper.writeValueAsString(rellenarEntradaDetalle("ok"));
	       	
	       	String uri = "/authorization/v1/detalleLote";
	       	
	       	mockMvc.perform(post(uri)
	       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
	       			.content(jsonInString))
	           .andExpect(status().isInternalServerError())
	           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	           .andDo(print());
	   		
	   	}
	    
	    private ListaLotesAutorizarResponse rellenarLotesAutorizar(String tipoPrueba) {
	    	ListaLotesAutorizarResponse salida = new ListaLotesAutorizarResponse();
	    	if("OK".equals(tipoPrueba)) {    		
	    		salida.setStatus("OK");
	    	}else {
	    		salida.setStatus("KO");
	    	}
	    	
	    	return salida;
	    }
	    
	    private DetalleLoteResponse rellenarDetalleLotes(String tipoPrueba) {
	    	DetalleLoteResponse salida = new DetalleLoteResponse();
	    	if("OK".equals(tipoPrueba)) {    		
	    		salida.setStatus("OK");
	    	}else {
	    		salida.setStatus("KO");
	    	}
	    	
	    	return salida;
	    }
	    
	    private ListaLotesRequest rellenarEntrada(String tipo) {
	    	ListaLotesRequest salida = new ListaLotesRequest();
	    	
	    	if("ok".equals(tipo)) {    		
	    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPorPagina");
	    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPagina");
	    		String monedaConsolidacion = JsonPath.read(jsonFile, "$.ejecucionOK.monedaConsolidacion");
	    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
	    		
	    		salida.setNumPorPagina(numPorPagina);
	    		salida.setNumPagina(numPagina);
	    		salida.setMonedaConsolidacion(monedaConsolidacion);
	    		salida.setTokenBks(tokenBks);
	    	}else {
	    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPorPagina");
	    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPagina");
	    		String monedaConsolidacion = JsonPath.read(jsonFile, "$.ejecucionKO.monedaConsolidacion");
	    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionKO.tokenBks");
	    		
	    		salida.setNumPorPagina(numPorPagina);
	    		salida.setNumPagina(numPagina);
	    		salida.setMonedaConsolidacion(monedaConsolidacion);
	    		salida.setTokenBks(tokenBks);
	    	}
	    	
	    	return salida;
	    }
	    
	    private DetalleLoteRequest rellenarEntradaDetalle(String tipo) {
	    	DetalleLoteRequest salida = new DetalleLoteRequest();
	    	
	    	if("ok".equals(tipo)) {    		
	    		String numLote = JsonPath.read(jsonFile, "$.ejecucionOKDetalle.numLote");
	    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOKDetalle.tokenBks");
	    		
	    		salida.setNumLote(numLote);
	    		salida.setTokenBks(tokenBks);
	    	}else {
	    		String numLote = JsonPath.read(jsonFile, "$.ejecucionKODetalle.numLote");
	    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionKODetalle.tokenBks");
	    		
	    		salida.setNumLote(numLote);
	    		salida.setTokenBks(tokenBks);
	    	}
	    	
	    	return salida;
	    }
	    
	    
	    private void leerFichero() {
	    	try {
	    		File file = new File("src/test/resources/json/ListaLotesControllerUnitTest.json");
				fe = new FileInputStream(file);
				isr = new InputStreamReader(fe);
				br = new BufferedReader(isr);
				
				while((cadena = br.readLine()) != null){
					System.out.println(cadena);
					jsonFile = jsonFile.concat(cadena);
				}
				
			} catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
	    }
	  
}
