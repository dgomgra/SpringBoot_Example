package com.isban.scnp.fo.autorizacionpagos.listaarchivos.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ArchivoPolitica;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service.impl.CompRolSecAutRemServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaOut;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ConversionDivisaResponse;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.model.ImporteType;
import com.isban.scnp.fo.autorizacionpagos.conversionDivisa.service.impl.ConversionDivisaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.DetPerfiladoUsuarioResponse;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaPermisosSubprodArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ListaServiciosAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.PermisosSubprodArbol;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.model.ServicioPaisAR;
import com.isban.scnp.fo.autorizacionpagos.detperfiladoUsu.service.impl.DetPerfiladoUsuarioHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl.ListaWarehouseHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.GrupoPerfUsuarioOut;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosARRequest;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ListaArchivosPendientesResponse;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.service.impl.ListaArchivosPendientesServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.impl.ListaPagosHelperServiceImpl;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ListaArchivosPendientesHelperServiceUnitTest {
	
	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private ListaArchivosPendientesServiceImpl listaArchivosPendientesServiceImpl;

	/**
	 * 	Test que comprueba que el usuario logado no tiene firma
	 * 
	 */
	@Test
	public void getListaArchivosPendientesAutorizarImpTest_SinFirma() {
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		Mockito.when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		
		// Servicio de pagos (donde está el metodo de comprobarTokenSKeyUsu)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);

		Mockito.when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(null); // El retorno de este metodo a null es que no tiene firma
		
		ListaArchivosARRequest requestMock = Mockito.mock(ListaArchivosARRequest.class);
		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(requestMock, false);
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());
		
		// Verificamos que el codigo es KO y el mensaje es el de que el usuario logado no tiene firma
		assertEquals(salida.getStatus(), "KO");
		assertEquals(salida.getMessage(), "0023");
	}
	

	@Test
	public void getListaArchivosPendientesAutorizarImpTest_OK() {
		
		String idUsuarioLogado = "SGP_USUARIOLOGADO";
		
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);
		
		// Servicio externo (comprolsecautrem)
		CompRolSecAutRemServiceImpl compRolSecAutRemHelperService = Mockito.mock(CompRolSecAutRemServiceImpl.class);
		ReflectionTestUtils.setField(mock, "compRolSecAutRemHelperService", compRolSecAutRemHelperService);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaWarehouseHelperService", listaWarehouseHelperService);
		
		// Servicio externo (detPerfiladoUsu)
		DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperService = Mockito.mock(DetPerfiladoUsuarioHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);
		
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);

		// Metodos usados
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		when(mock.obtCodigoGrupoEmp(idUsuarioLogado)).thenReturn(0);
		when(mock.obtIndARMultiPais(0)).thenReturn("S");
		when(mock.obtArchivosPendientes(0, "S", new ArrayList<String>())).thenReturn(new ArrayList<ArchivoAR>());
		when(compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(idUsuarioLogado, 0, new ArrayList<>())).thenReturn(new ArrayList<ArchivoPolitica>());
		
		when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(permisoAR());
		
		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(generarEntrada(), false);	
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());
		
		assertNotNull(salida);
		assertEquals(salida.getStatus(), "KO");
		assertTrue(salida.getListaArchivos().isEmpty());
		assertTrue(salida.getListaDivisas().contains("EUR"));
		assertTrue(salida.getListaDivisas().contains("GBP"));
		assertTrue(salida.getListaDivisas().contains("USD"));

	}
	
	@Test
	public void getListaArchivosPendientesAutorizarImpTest_OK_MultiPais_Usuario() {
		
		String idUsuarioLogado = "SGP_USUARIOLOGADO";
		
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);
		
		// Servicio externo (comprolsecautrem)
		CompRolSecAutRemServiceImpl compRolSecAutRemHelperService = Mockito.mock(CompRolSecAutRemServiceImpl.class);
		ReflectionTestUtils.setField(mock, "compRolSecAutRemHelperService", compRolSecAutRemHelperService);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaWarehouseHelperService", listaWarehouseHelperService);
		
		// Servicio externo (detPerfiladoUsu)
		DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperService = Mockito.mock(DetPerfiladoUsuarioHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);
		
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);

		// Metodos usados
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		when(mock.obtCodigoGrupoEmp(idUsuarioLogado)).thenReturn(0);
		when(mock.obtIndARMultiPais(0)).thenReturn("N");
		when(mock.obtArchivosPendientes(0, "N", new ArrayList<String>())).thenReturn(new ArrayList<ArchivoAR>());
		when(mock.obtGrupoPerfUsuarioSQL(idUsuarioLogado)).thenReturn(new  GrupoPerfUsuarioOut(0, 0));
		when(mock.obtPaisesARPerfUsuarioSQL(idUsuarioLogado, 0)).thenReturn(new ArrayList<String>());
		when(compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(idUsuarioLogado, 0, new ArrayList<>())).thenReturn(new ArrayList<ArchivoPolitica>());
		
		
		when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(permisoAR());
		
		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(generarEntrada(), false);	
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());
		
		assertNotNull(salida);
		assertEquals(salida.getStatus(), "KO");
		assertTrue(salida.getListaArchivos().isEmpty());
		assertTrue(salida.getListaDivisas().contains("EUR"));
		assertTrue(salida.getListaDivisas().contains("GBP"));
		assertTrue(salida.getListaDivisas().contains("USD"));
	}
	
	@Test
	public void getListaArchivosPendientesAutorizarImpTest_OK_MultiPais_Usuario_Resumen() {
		
		String idUsuarioLogado = "SGP_USUARIOLOGADO";
		
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);
		
		// Servicio externo (comprolsecautrem)
		CompRolSecAutRemServiceImpl compRolSecAutRemHelperService = Mockito.mock(CompRolSecAutRemServiceImpl.class);
		ReflectionTestUtils.setField(mock, "compRolSecAutRemHelperService", compRolSecAutRemHelperService);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaWarehouseHelperService", listaWarehouseHelperService);
		
		// Servicio externo (detPerfiladoUsu)
		DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperService = Mockito.mock(DetPerfiladoUsuarioHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);
		
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);
		
		// Metodos usados
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		when(mock.obtCodigoGrupoEmp(idUsuarioLogado)).thenReturn(0);
		when(mock.obtIndARMultiPais(0)).thenReturn("N");
		when(mock.obtArchivosPendientes(0, "N", new ArrayList<String>())).thenReturn(new ArrayList<ArchivoAR>());
		when(mock.obtGrupoPerfUsuarioSQL(idUsuarioLogado)).thenReturn(new  GrupoPerfUsuarioOut(0, 0));
		when(mock.obtPaisesARPerfUsuarioSQL(idUsuarioLogado, 0)).thenReturn(new ArrayList<String>());
		when(compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(idUsuarioLogado, 0, new ArrayList<>())).thenReturn(new ArrayList<ArchivoPolitica>());
		
		when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(permisoAR());
		
		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(generarEntrada(), true);	
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());
		
		assertNotNull(salida);
		assertEquals(salida.getStatus(), "OK");
	}
	
	
	@Test
	public void getListaArchivosPendientesAutorizarImpTest_OK_MultiPais_Grupo() {
		
		String idUsuarioLogado = "SGP_USUARIOLOGADO";
		
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);
		
		// Servicio externo (comprolsecautrem)
		CompRolSecAutRemServiceImpl compRolSecAutRemHelperService = Mockito.mock(CompRolSecAutRemServiceImpl.class);
		ReflectionTestUtils.setField(mock, "compRolSecAutRemHelperService", compRolSecAutRemHelperService);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaWarehouseHelperService", listaWarehouseHelperService);
		
		// Servicio externo (detPerfiladoUsu)
		DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperService = Mockito.mock(DetPerfiladoUsuarioHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);
		
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);

		// Metodos usados
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		when(mock.obtCodigoGrupoEmp(idUsuarioLogado)).thenReturn(0);
		when(mock.obtIndARMultiPais(0)).thenReturn("N");
		when(mock.obtArchivosPendientes(0, "N", new ArrayList<String>())).thenReturn(new ArrayList<ArchivoAR>());
		when(mock.obtGrupoPerfUsuarioSQL(idUsuarioLogado)).thenReturn(new  GrupoPerfUsuarioOut(1, 300));
		when(mock.obtPaisesARPerfGrupUsuarioSQL(1, 300)).thenReturn(new ArrayList<String>());
		when(compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(idUsuarioLogado, 0, new ArrayList<>())).thenReturn(new ArrayList<ArchivoPolitica>());
		
		when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(permisoAR());
		
		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(generarEntrada(), false);	
		
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());
		
		assertNotNull(salida);
		assertEquals(salida.getStatus(), "KO");
		assertTrue(salida.getListaArchivos().isEmpty());
		assertTrue(salida.getListaDivisas().contains("EUR"));
		assertTrue(salida.getListaDivisas().contains("GBP"));
		assertTrue(salida.getListaDivisas().contains("USD"));
	}
	
	@Test
	public void getListaArchivosPendientesAutorizarImpTest_OK_MultiPais_Grupo_Resumen() {
		
		String idUsuarioLogado = "SGP_USUARIOLOGADO";
		
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		
		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);
		
		// Servicio externo (comprolsecautrem)
		CompRolSecAutRemServiceImpl compRolSecAutRemHelperService = Mockito.mock(CompRolSecAutRemServiceImpl.class);
		ReflectionTestUtils.setField(mock, "compRolSecAutRemHelperService", compRolSecAutRemHelperService);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaWarehouseHelperService", listaWarehouseHelperService);
		
		// Servicio externo (detPerfiladoUsu)
		DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperService = Mockito.mock(DetPerfiladoUsuarioHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);
		
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);

		// Metodos usados
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		when(mock.obtCodigoGrupoEmp(idUsuarioLogado)).thenReturn(0);
		when(mock.obtIndARMultiPais(0)).thenReturn("N");
		when(mock.obtArchivosPendientes(0, "N", new ArrayList<String>())).thenReturn(new ArrayList<ArchivoAR>());
		when(mock.obtGrupoPerfUsuarioSQL(idUsuarioLogado)).thenReturn(new  GrupoPerfUsuarioOut(1, 300));
		when(mock.obtPaisesARPerfGrupUsuarioSQL(1, 300)).thenReturn(new ArrayList<String>());
		when(compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(idUsuarioLogado, 0, new ArrayList<>())).thenReturn(new ArrayList<ArchivoPolitica>());
		
		when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(permisoAR());

		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(generarEntrada(), true);	
		
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());
		
		assertNotNull(salida);
		assertEquals(salida.getStatus(), "OK");
	}
	
	
	@Test
	public void getListaArchivosPendienetsAutorizar_OK() {

		String idUsuarioLogado = "SGP_USUARIOLOGADO";

		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();

		// Servicio externo (listaPagos)
		ListaPagosHelperServiceImpl pagosHelpserService = Mockito.mock(ListaPagosHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaPagosHelperService", pagosHelpserService);

		// Servicio externo (comprolsecautrem)
		CompRolSecAutRemServiceImpl compRolSecAutRemHelperService = Mockito.mock(CompRolSecAutRemServiceImpl.class);
		ReflectionTestUtils.setField(mock, "compRolSecAutRemHelperService", compRolSecAutRemHelperService);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "listaWarehouseHelperService", listaWarehouseHelperService);
		
		// Servicio externo (listawarehouse)
		ConversionDivisaHelperServiceImpl conversionDivisaHelperService = Mockito.mock(ConversionDivisaHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "conversionDivisaHelperService", conversionDivisaHelperService);
		
		// Servicio externo (detPerfiladoUsu)
		DetPerfiladoUsuarioHelperServiceImpl detPerfiladoUsuarioHelperService = Mockito.mock(DetPerfiladoUsuarioHelperServiceImpl.class);
		ReflectionTestUtils.setField(mock, "detPerfiladoUsuarioHelperService", detPerfiladoUsuarioHelperService);

		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn(idUsuarioLogado);

		// Metodos usados
		when(pagosHelpserService.comprobarTokenSKeyUsu(anyString())).thenReturn(idUsuarioLogado);
		when(mock.obtCodigoGrupoEmp(idUsuarioLogado)).thenReturn(7);
		when(mock.obtIndARMultiPais(anyInt())).thenReturn("N");
		
		when(mock.obtArchivosPendientes(anyInt(), anyString(), any())).thenReturn(salidaAR());
		when(mock.obtGrupoPerfUsuarioSQL(idUsuarioLogado)).thenReturn(new  GrupoPerfUsuarioOut(0, 0));
		when(mock.obtPaisesARPerfUsuarioSQL(idUsuarioLogado, 0)).thenReturn(new ArrayList<String>());
		when(compRolSecAutRemHelperService.comprobarRolSecuenciaAutRA(anyString(), anyInt(), any())).thenReturn(salidaRetornoCompRol());
		when(conversionDivisaHelperService.conversionDivisa(any())).thenReturn(retornoDivisa());
		when(mock.cambiarDivisaArchivoRA(any(), anyString(), anyString())).thenAnswer(new Answer<List<String>>() {
			@Override
			public List<String> answer(InvocationOnMock invocation) throws Throwable {
				List<String> listaDivisas = new ArrayList<String>(0);
				List<ArchivoAR> args = (List<ArchivoAR>) (invocation.getArguments()[0]);
				for (int i=0;i<args.size();i++) {
					args.get(i).setFecha(new Date());
					args.get(i).setDivisa("EUR");
					args.get(i).setImporte(new BigDecimal(1));
					
					listaDivisas.add("EUR");
				}
	            return listaDivisas;
			}
		});
		
		when(detPerfiladoUsuarioHelperService.detPerfiladoUsuario(anyString())).thenReturn(permisoAR());
		
		when(listaWarehouseHelperService.traducirMulidi(anyString(), any(), anyString())).thenReturn(traducciones());
		ListaArchivosPendientesResponse salida = mock.getListaArchivosPendientes(generarEntrada(), false);	
		verify(mock, times(1)).getListaArchivosPendientes(any(), anyBoolean());

		assertNotNull(salida);
		assertEquals(salida.getStatus(), "OK");
		assertEquals(salida.getListaArchivos().size(), 4);
		assertTrue(salida.getListaDivisas().contains("EUR"));
		assertTrue(salida.getListaDivisas().contains("GBP"));
		assertTrue(salida.getListaDivisas().contains("USD"));
		assertEquals(salida.getListaArchivos().get(0).getDescripcionEstado(), "Listo para autorizar");
		assertEquals(salida.getListaArchivos().get(1).getDescripcionEstado(), "Listo para autorizar");
		assertEquals(salida.getListaArchivos().get(2).getDescripcionEstado(), "Listo para autorizar");
		assertEquals(salida.getListaArchivos().get(3).getDescripcionEstado(), "Listo para autorizar");

	}
	
	private DetPerfiladoUsuarioResponse permisoAR() {
		DetPerfiladoUsuarioResponse response = new DetPerfiladoUsuarioResponse();
		DetPerfiladoUsuarioOut methodResult = new DetPerfiladoUsuarioOut();
		
		List<ListaServiciosAR> listaServicios = new ArrayList<ListaServiciosAR>();
		ListaServiciosAR servicios = new ListaServiciosAR();
		ServicioPaisAR servicio = new ServicioPaisAR();
		servicio.setCodServicio("FI");
		servicio.setNecesCuenta("N");
		servicio.setNecesTip("N");
		List<ListaPermisosSubprodArbol> listaPermisosSinMetodos = new ArrayList<ListaPermisosSubprodArbol>();
		ListaPermisosSubprodArbol permisos = new ListaPermisosSubprodArbol();
		PermisosSubprodArbol permiso = new PermisosSubprodArbol();
		permiso.setCodPermiso("apr");
		permiso.setCodigoSubproducto(102);
		permisos.setPemisos(permiso);
		listaPermisosSinMetodos.add(permisos);
		servicio.setListaPermisosSinMetodos(listaPermisosSinMetodos);
		servicios.setServicio(servicio);
		listaServicios.add(servicios);
		methodResult.setListadoServicios(listaServicios);
		response.setMethodResult(methodResult);
		return response;
	}


	private ConversionDivisaResponse retornoDivisa() {
		ConversionDivisaOut convDivisa = new ConversionDivisaOut();
		List<ImporteType> listaImportes = new ArrayList<>();
		ImporteType imp0 = new ImporteType(new BigDecimal(333.78), "EUR");
		ImporteType imp1 = new ImporteType(new BigDecimal(211.05), "EUR");
		ImporteType imp2 = new ImporteType(new BigDecimal(300.35), "EUR");
		ImporteType imp3 = new ImporteType(new BigDecimal(60470.88), "EUR");
		listaImportes.add(imp0);
		listaImportes.add(imp1);
		listaImportes.add(imp2);
		listaImportes.add(imp3);
		convDivisa.setListaImportes(listaImportes);
		return null;
	}


	private List<String> traducciones() {
		List<String> traducciones = new ArrayList<>();
		traducciones.add("Listo para autorizar");
		traducciones.add("Listo para autorizar");
		traducciones.add("Listo para autorizar");
		traducciones.add("Listo para autorizar");
		return traducciones;
	}


	private List<ArchivoPolitica> salidaRetornoCompRol() {
		List<ArchivoPolitica> comprobarRolSecuencia = new ArrayList<>();
		
		ArchivoPolitica archivo0 = new ArchivoPolitica();
		archivo0.setIdArchivo(2185);
		archivo0.setCodSentencia(2);
		archivo0.setIdAutorizacion(70946);
		
		ArchivoPolitica archivo1 = new ArchivoPolitica();
		archivo1.setIdArchivo(2186);
		archivo1.setCodSentencia(1);
		archivo1.setIdAutorizacion(77549);
		
		ArchivoPolitica archivo2 = new ArchivoPolitica();
		archivo2.setIdArchivo(2187);
		archivo2.setCodSentencia(1);
		archivo2.setIdAutorizacion(77549);
		
		ArchivoPolitica archivo3 = new ArchivoPolitica();
		archivo3.setIdArchivo(2192);
		archivo3.setCodSentencia(2);
		archivo3.setIdAutorizacion(77714);
		
		comprobarRolSecuencia.add(archivo0);
		comprobarRolSecuencia.add(archivo1);
		comprobarRolSecuencia.add(archivo2);
		comprobarRolSecuencia.add(archivo3);
		
		return comprobarRolSecuencia;
	}


	private List<ArchivoAR> salidaAR() {
		List<ArchivoAR> salidaAR = new ArrayList<ArchivoAR>();
		ArchivoAR archivo0 = new ArchivoAR();;
		archivo0.setEstado("E0");
		archivo0.setIdArchivo(2186);
		archivo0.setFecha(new Date());
		archivo0.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000000");
		archivo0.setNumTransacciones(9);
		
		ArchivoAR archivo1 = new ArchivoAR();
		archivo1.setEstado("E0");
		archivo1.setIdArchivo(2187);
		archivo1.setFecha(new Date());
		archivo1.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000000");
		archivo1.setNumTransacciones(1);
		
		ArchivoAR archivo2 = new ArchivoAR();
		archivo2.setEstado("E0");
		archivo2.setIdArchivo(2185);
		archivo2.setFecha(new Date());
		archivo2.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181114.T0900.15000000");
		archivo2.setNumTransacciones(5);
		
		ArchivoAR archivo3 = new ArchivoAR();
		archivo3.setEstado("E0");
		archivo3.setIdArchivo(2192);
		archivo3.setFecha(new Date());
		archivo3.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000004");
		archivo3.setNumTransacciones(1);
		
		salidaAR.add(archivo1);
		salidaAR.add(archivo2);
		salidaAR.add(archivo3);
		
		return salidaAR;
		
	}


	@Test
	public void getListaArchivosPendientesAutorizarImpTest_OK_vacio() {
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
	}
	
	@Test(expected = Exception.class)
	public void getListaArchivosPendientesAutorizarImpTest_KO_real() {
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenCallRealMethod();
		mock.getListaArchivosPendientes(generarEntrada(), false);		
	}
	
	@Test(expected = Exception.class)
	public void getListaArchivosPendientesAutorizarImpTest_KO_throw() {
		ListaArchivosPendientesServiceImpl mock =  Mockito.mock(ListaArchivosPendientesServiceImpl.class);
		when(mock.getListaArchivosPendientes(any(), anyBoolean())).thenThrow(new NullPointerException("Error occurred"));
		mock.getListaArchivosPendientes(generarEntrada(), false);
	
	}
	
	
	private ListaArchivosARRequest generarEntrada() {
		ListaArchivosARRequest entrada= new ListaArchivosARRequest();
		entrada.setMonConsolidacion("EUR");
		entrada.setNumPagina(1);
		entrada.setNumPorPagina(5);
		entrada.setTokenBks("SGPTOKEN");
		return entrada;
	}
	
	@Test
	public void compararArchivosARTest_OK (){
		
		Date d = new Date();
		Date d2 = new Date (d.getTime()-1000);
		ArchivoAR archivo0 = new ArchivoAR();
		archivo0.setEstado("E0");
		archivo0.setIdArchivo(2186);
		archivo0.setFecha(d);
		archivo0.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000000");
		archivo0.setNumTransacciones(9);
		
		ArchivoAR archivo1 = new ArchivoAR();
		archivo1.setEstado("E0");
		archivo1.setIdArchivo(2187);
		archivo1.setFecha(d2);
		archivo1.setNombre("IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000000");
		archivo1.setNumTransacciones(1);
		
		boolean iguales = archivo0.compareTo(archivo0)==0;
		boolean iguales2 = archivo0.equals(archivo0);
				
		boolean distintos = archivo0.compareTo(archivo1)!=0;
		boolean distintos2 = !archivo0.equals(archivo1);
		boolean distintos3 = !archivo0.equals(null);
		boolean distintos4 = !archivo0.equals("");		
				
		int hash= archivo0.hashCode();
		
		assertTrue(iguales);
		assertTrue(iguales2);
		assertTrue(distintos);
		assertTrue(distintos2);
		assertTrue(distintos3);
		assertTrue(distintos4);
		assertTrue(hash!=0);
	}	
}
