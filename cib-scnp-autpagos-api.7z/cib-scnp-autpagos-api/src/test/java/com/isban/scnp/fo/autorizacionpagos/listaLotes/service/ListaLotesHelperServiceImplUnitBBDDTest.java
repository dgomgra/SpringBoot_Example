package com.isban.scnp.fo.autorizacionpagos.listaLotes.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DatosPagoLoteDivisa;
import com.isban.scnp.fo.autorizacionpagos.listalotes.model.DetalleLoteOut;
import com.isban.scnp.fo.autorizacionpagos.listalotes.service.impl.ListaLotesHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaLotesHelperServiceImplUnitBBDDTest {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Mock
	ListaLotesHelperServiceImpl listaLotesHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaLotesSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/ListaLotesPurge.sql"));
	}
	
	@Test
	public void obtDivisasPagosTest() {
		Mockito.when(listaLotesHelperServiceImpl.obtDivisasPagos(Mockito.any())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "schemaproc", schemaproc);
		
		List<String> listaPagos = new ArrayList<>();
		listaPagos.add("SGP1707260006979");
		listaPagos.add("SGP1707260006980");
		List<DatosPagoLoteDivisa> salidaOk= listaLotesHelperServiceImpl.obtDivisasPagos(listaPagos);
		
		assertNotNull(salidaOk.get(0).getDivisaPago());
		assertNotNull(salidaOk.get(0).getIdLote());
		assertNotNull(salidaOk.get(0).getIdPago());
		
		listaPagos.clear();
		listaPagos.add("");
		List<DatosPagoLoteDivisa> salidaNull = listaLotesHelperServiceImpl.obtDivisasPagos(listaPagos);
		
		assertEquals(salidaNull.size(), 0);
	}
	
	@Test
	public void getDetalleLoteTest() {
		Mockito.when(listaLotesHelperServiceImpl.getDetalleLote(Mockito.anyString())).thenCallRealMethod();
		
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(listaLotesHelperServiceImpl, "schemaproc", schemaproc);
		

		DetalleLoteOut salidaOk= listaLotesHelperServiceImpl.getDetalleLote("L201811190848366");
		
		assertNotNull(salidaOk.getNumLote());
		assertNotNull(salidaOk.getEstadoLote());
		assertNotNull(salidaOk.getNombreLote());
		assertNotNull(salidaOk.getPais());
		assertNotNull(salidaOk.getDivisa());
		assertNotNull(salidaOk.getMonto());
		assertNotNull(salidaOk.getNumPagos());
		assertNotNull(salidaOk.getFecha());
		
		DetalleLoteOut salidaNull = listaLotesHelperServiceImpl.getDetalleLote("");
		
		assertEquals(salidaNull.getNumLote(), null);
		assertEquals(salidaNull.getEstadoLote(), null);
		assertEquals(salidaNull.getNombreLote(), null);
		assertEquals(salidaNull.getPais(), null);
		assertEquals(salidaNull.getDivisa(), null);
		assertEquals(salidaNull.getMonto(), null);
		assertEquals(salidaNull.getNumPagos(), 0);
		assertEquals(salidaNull.getFecha(), null);
	}
}
