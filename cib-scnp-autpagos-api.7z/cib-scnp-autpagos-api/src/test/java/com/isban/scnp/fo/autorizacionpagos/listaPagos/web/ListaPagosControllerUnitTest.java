package com.isban.scnp.fo.autorizacionpagos.listaPagos.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.listapagos.model.ListaPagosAutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.listapagos.service.ListaPagosHelperService;
import com.isban.scnp.fo.autorizacionpagos.listapagos.web.ListaPagosRestController;
import com.jayway.jsonpath.JsonPath;


@WithAnonymousUser
@WebAppConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class ListaPagosControllerUnitTest {
	
    @Autowired
    private WebApplicationContext webApplicationContext;
    
    @Autowired
	private ListaPagosRestController listaPagosRestController;
    
    private MockMvc mockMvc;
    
	private FileInputStream fe = null;
	private InputStreamReader isr = null;
	private BufferedReader br = null;
	private String jsonFile = "";
	private String cadena = "";
    
    
    @Before
    public void setup() throws Exception{
    	leerFichero();
        this.mockMvc = webAppContextSetup(webApplicationContext).build();     
    }
    
    @Test
    public void getListaPagosAutorizarOkTest() throws Exception {
    	
        // Se rellenan los datos para ListaPagosAutorizarResponse
        ListaPagosAutorizarResponse respuesta = rellenarPagosAutorizar("OK");
    
        ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
        Mockito.when(listaPagosHelperService.getListaPagosAutorizarImp(Mockito.any())).thenReturn(respuesta);
        ReflectionTestUtils.setField(listaPagosRestController, "listaPagosHelperService", listaPagosHelperService);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/listadoPagosAutorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());

    }
    
    
    @Test
    public void getListaPagosAutorizarKoTest() throws Exception {
    	
        // Se rellenan los datos para ListaPagosAutorizarResponse
        ListaPagosAutorizarResponse respuesta = rellenarPagosAutorizar("KO");
    
        ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
        Mockito.when(listaPagosHelperService.getListaPagosAutorizarImp(Mockito.any())).thenReturn(respuesta);
        ReflectionTestUtils.setField(listaPagosRestController, "listaPagosHelperService", listaPagosHelperService);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
    	
    	String uri = "/authorization/v1/listadoPagosAutorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());

    }
    
    @Test
    public void getListaPagosAutorizarKo2Test() throws Exception {
    
        ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
        Exception ex = new Exception();
        Mockito.when(listaPagosHelperService.getListaPagosAutorizarImp(Mockito.any())).thenThrow(new NullPointerException("Error occurred"));
        ReflectionTestUtils.setField(listaPagosRestController, "listaPagosHelperService", listaPagosHelperService);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ko"));
    	
    	String uri = "/authorization/v1/listadoPagosAutorizar";
    	
    	mockMvc.perform(post(uri)
    			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
    			.content(jsonInString))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andDo(print());

    }
    
    @Test
   	public void listaPagosTest_KOCredencial() throws Exception {
    	ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
   		
   		ReflectionTestUtils.setField(listaPagosRestController, "listaPagosHelperService", listaPagosHelperService);
   		
   		
   		when(listaPagosHelperService.getListaPagosAutorizarImp(Mockito.any())).thenThrow(
   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"50201021\",\"faultstring\":\"Credencial inválida.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
   		
   		ObjectMapper mapper = new ObjectMapper();
       	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
       	
       	String uri = "/authorization/v1/listadoPagosAutorizar";
       	
       	mockMvc.perform(post(uri)
       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.content(jsonInString))
           .andExpect(status().isUnauthorized())
           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
           .andDo(print());
   		
   	}
   	
   	@Test
   	public void listaPagosTest_KOOtro() throws Exception {
   		ListaPagosHelperService listaPagosHelperService = Mockito.mock(ListaPagosHelperService.class);
   		ReflectionTestUtils.setField(listaPagosRestController, "listaPagosHelperService", listaPagosHelperService);
   		
   		
   		when(listaPagosHelperService.getListaPagosAutorizarImp(Mockito.any())).thenThrow(
   				new HttpServerErrorException(HttpStatus.OK, "", "{\"fault\":{\"faultcode\":\"888\",\"faultstring\":\"Error.\",\"detail\":null}}".getBytes(), Charset.defaultCharset()));
   		
   		ObjectMapper mapper = new ObjectMapper();
       	String jsonInString = mapper.writeValueAsString(rellenarEntrada("ok"));
       	
       	String uri = "/authorization/v1/listadoPagosAutorizar";
       	
       	mockMvc.perform(post(uri)
       			.accept(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
       			.content(jsonInString))
           .andExpect(status().isInternalServerError())
           .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
           .andDo(print());
   		
   	}
    
    private ListaPagosAutorizarResponse rellenarPagosAutorizar(String tipoPrueba) {
    	ListaPagosAutorizarResponse salida = new ListaPagosAutorizarResponse();
    	if("OK".equals(tipoPrueba)) {    		
    		salida.setStatus("OK");
    	}else {
    		salida.setStatus("KO");
    	}
    	
    	return salida;
    }
    
    private ListaPagosAutorizarRequest rellenarEntrada(String tipo) {
    	ListaPagosAutorizarRequest salida = new ListaPagosAutorizarRequest();
    	
    	if("ok".equals(tipo)) {    		
    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPorPagina");
    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionOK.numPagina");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionOK.tokenBks");
    		
    		salida.setNumPorPagina(numPorPagina);
    		salida.setNumPagina(numPagina);
    		salida.setTokenBks(tokenBks);
    	}else {
    		int numPorPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPorPagina");
    		int numPagina = JsonPath.read(jsonFile, "$.ejecucionKO.numPagina");
    		String tokenBks = JsonPath.read(jsonFile, "$.ejecucionKO.tokenBks");
    		
    		salida.setNumPorPagina(numPorPagina);
    		salida.setNumPagina(numPagina);
    		salida.setTokenBks(tokenBks);
    	}
    	
    	return salida;
    }
    
    private void leerFichero() {
    	try {
    		File file = new File("src/test/resources/json/ListaPagosControllerUnitTest.json");
			fe = new FileInputStream(file);
			isr = new InputStreamReader(fe);
			br = new BufferedReader(isr);
			
			while((cadena = br.readLine()) != null){
				System.out.println(cadena);
				jsonFile = jsonFile.concat(cadena);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
    }
    
}
