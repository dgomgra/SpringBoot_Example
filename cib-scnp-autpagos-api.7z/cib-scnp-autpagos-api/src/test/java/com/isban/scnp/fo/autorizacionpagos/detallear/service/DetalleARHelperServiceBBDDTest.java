package com.isban.scnp.fo.autorizacionpagos.detallear.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DatosArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.model.DetalleArchivo;
import com.isban.scnp.fo.autorizacionpagos.detallear.service.impl.DetalleARHelperServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class DetalleARHelperServiceBBDDTest {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	DetalleARHelperServiceImpl detalleARHelperServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		//Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/DetalleArchivoARSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/DetalleArchivoARPurge.sql"));
	}
	
	@Test
	public void obtDetalleArchivoTest_OKNota() {
		when(detalleARHelperServiceImpl.obtDetalleArchivo(Mockito.anyInt(), Mockito.anyString())).thenCallRealMethod();
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "schemaproc", schemaproc);
		DetalleArchivo salida = detalleARHelperServiceImpl.obtDetalleArchivo(2186, "SGPdanice727718");
		assertEquals(salida.getNombre(), "IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000000");
		assertEquals(salida.getMotivoRechazo(), "Motivo");
	}
	
	@Test
	public void obtDetalleArchivoTest_OK() {
		when(detalleARHelperServiceImpl.obtDetalleArchivo(Mockito.anyInt(), Mockito.anyString())).thenCallRealMethod();
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "schemaproc", schemaproc);
		DetalleArchivo salida = detalleARHelperServiceImpl.obtDetalleArchivo(2187, "SGPdanice727718");
		assertEquals(salida.getNombre(), "IPHSAN.TESTPORT.I.IDOC02.XXXX.D181122.T0900.15000000");
	}
	
	@Test
	public void obtDetalleArchivoTest_Vacio() {
		when(detalleARHelperServiceImpl.obtDetalleArchivo(Mockito.anyInt(), Mockito.anyString())).thenCallRealMethod();
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "schemaproc", schemaproc);
		DetalleArchivo salida = detalleARHelperServiceImpl.obtDetalleArchivo(1, "SGPdanice727718");
		assertEquals(salida, null);
	}
		
	@Test
	public void obtDatosArchivoTest_OK() {
		when(detalleARHelperServiceImpl.obtDatosArchivo(Mockito.anyInt())).thenCallRealMethod();
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "schemaproc", schemaproc);
		List<DatosArchivo> salida = detalleARHelperServiceImpl.obtDatosArchivo(2186);
		assertEquals(salida.size(), 3);
		assertTrue(salida.get(0).getNumTransac() == 2);
		assertTrue(salida.get(1).getNumTransac() == 4);
		assertTrue(salida.get(2).getNumTransac() == 3);
		
	}
	
	@Test
	public void obtDatosArchivoTest_Vacio() {
		when(detalleARHelperServiceImpl.obtDatosArchivo(Mockito.anyInt())).thenCallRealMethod();
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(detalleARHelperServiceImpl, "schemaproc", schemaproc);
		List<DatosArchivo> salida = detalleARHelperServiceImpl.obtDatosArchivo(1);
		assertTrue(salida.isEmpty());
	}
}
