package com.isban.scnp.fo.autorizacionpagos.autorizar.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarRequest;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.AutorizarResponse;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdLoteNombre;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdLoteNombreK;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdPagoNombre;
import com.isban.scnp.fo.autorizacionpagos.autorizar.model.IdPagoNombreK;
import com.isban.scnp.fo.autorizacionpagos.autorizar.service.impl.AutorizarHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.common.component.ApiRestTemplate;
import com.isban.scnp.fo.autorizacionpagos.common.component.AppContext;
import com.isban.scnp.fo.autorizacionpagos.common.model.DatosUsuario;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.model.DatosFirmaCuentaBenOut;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.DatosFirmaHelperService;
import com.isban.scnp.fo.autorizacionpagos.datosFirma.service.impl.DatosFirmaHelperServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaWarehouse.service.impl.ListaWarehouseHelperServiceImpl;
import com.santander.serenity.devstack.jwt.model.JwtDetails;
import com.santander.serenity.devstack.jwt.validation.JwtAuthenticationToken;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.Silent.class)
public class AutorizarHelperServiceImplUnitTest {

	@Mock
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Mock
	private AutorizarHelperServiceImpl autorizarHelperServiceImpl;

	@Mock
	private AsyncRestTemplate restTemplatePost;
	
	@Autowired
	DatosFirmaHelperService datosFirmaHelperService;

	@Test
	public void AutorizarTest_StopPago() {

		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);
		
		// getPaisPago
		DatosFirmaHelperService datosFirmaHelperService = Mockito.mock(DatosFirmaHelperService.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "datosFirmaHelperService", datosFirmaHelperService);
		when(datosFirmaHelperService.getPaisPago(Mockito.anyString())).thenReturn("ES");

		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(Arrays.asList(new IdPagoNombre("SGP1811120000005", "RefCliente")));

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(), Mockito.any(), Mockito.any(), ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);


		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaStopPago());

		assertEquals(salida.getStatus(), "OK");
		assertEquals(salida.getMessage(), "OK");
	}


	private AutorizarRequest generarEntradaStopPago() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"pagos\",\"accion\":\"stopPayment\",\"listaIds\":[\"SGP1811120000005\"],\"numeroPagos\":1,\"montoTotal\":\"100.0\",\"respuestaVasco\":\"28801998\",\"nota\":\"pruebas nota\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}

	@Test
	public void AutorizarTest_StopLote() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);

		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);

		List<IdLoteNombre> listaLotes = new ArrayList<>();
		listaLotes.add(new IdLoteNombre("L201811120848350", "NombreLote1"));
		listaLotes.add(new IdLoteNombre("L201811120848351", "NombreLote2"));
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(listaLotes);

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withServerError());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaStopLote());

		verify(autorizarHelperServiceImpl, times(1)).autorizarImpl(Mockito.any());

	}

	private AutorizarRequest generarEntradaStopLote() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"lotes\",\"accion\":\"stopPayment\",\"listaIds\":[\"L201811120848350\",\"L201811120848351\"],\"numeroPagos\":4,\"montoTotal\":\"400.0\",\"respuestaVasco\":\"28769341\",\"nota\":\"pruebas nota\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}


	@Test
	public void AutorizarTest_AutorizarPago() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);

		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		List<IdPagoNombreK> salidaPagos = new ArrayList<>();
		
		
		IdPagoNombre id1 = new IdPagoNombre();
		id1.setIdPago("SGP1811200000009" );
		id1.setRefCliente("RefCliente1");
		
		IdPagoNombre id2 = new IdPagoNombre();
		id2.setIdPago("SGP1811200000012" );
		id2.setRefCliente("RefCliente2");
		
		IdPagoNombreK idk1 = new IdPagoNombreK();
		idk1.setIdPagoNombre(id1);
		
		IdPagoNombreK idk2 = new IdPagoNombreK();
		idk2.setIdPagoNombre(id2);
		
		salidaPagos.add(idk1);
		salidaPagos.add(idk2);

		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(salidaPagos);

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaAutorizarPago());

		assertEquals(salida.getStatus(), "OK");
		assertEquals(salida.getMessage(), "OK");
	}

	private AutorizarRequest generarEntradaAutorizarPago() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"pagos\",\"accion\":\"autorizar\",\"listaIds\":[\"SGP1811200000009\",\"SGP1811200000012\"],\"numeroPagos\":2,\"montoTotal\":\"200.0\",\"respuestaVasco\":\"89925104\",\"nota\":\"pruebas autorización\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}



	@Test
	public void AutorizarTest_AutorizarLote() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);

		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);

		List<IdLoteNombreK> listaLotes = new ArrayList<>();
		
		IdLoteNombre lote1 = new IdLoteNombre();
		lote1.setIdLote("L201811200848370");
		lote1.setNomLote("NombreLote1");
		
		IdLoteNombre lote2 = new IdLoteNombre();
		lote2.setIdLote("L201811200848371");
		lote2.setNomLote("NombreLote2");
		
		IdLoteNombreK idlotek1 = new IdLoteNombreK();
		idlotek1.setIdLoteNombre(lote1);
		
		IdLoteNombreK idlotek2 = new IdLoteNombreK();
		idlotek2.setIdLoteNombre(lote2);
		
		listaLotes.add(idlotek1);
		listaLotes.add(idlotek2);
	
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(listaLotes);

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withServerError());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaAutorizarLote());

		verify(autorizarHelperServiceImpl, times(1)).autorizarImpl(Mockito.any());
	}

	private AutorizarRequest generarEntradaAutorizarLote() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"lotes\",\"accion\":\"autorizar\",\"listaIds\":[\"L201811200848370\",\"L201811200848371\"],\"numeroPagos\":4,\"montoTotal\":\"400.0\",\"respuestaVasco\":\"91596067\",\"nota\":\"pruebas nota\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}


	@Test
	public void AutorizarTest_RechazarPago() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);

		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(Arrays.asList(new IdPagoNombre("SGP1811200000015", "RefCliente1"),new IdPagoNombre("SGP1811200000023", "RefCliente2") ));

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaRechazarPago());

		assertEquals(salida.getStatus(), "OK");
		assertEquals(salida.getMessage(), "OK");
	}

	private AutorizarRequest generarEntradaRechazarPago() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"pagos\",\"accion\":\"rechazar\",\"listaIds\":[\"SGP1811200000015\",\"SGP1811200000023\"],\"numeroPagos\":2,\"montoTotal\":\"200.0\",\"respuestaVasco\":\"65430438\",\"nota\":\"pruebas autorización rechazo\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}


	@Test
	public void AutorizarTest_RechazarLote() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");
		
		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);

		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);

		List<IdLoteNombre> listaLotes = new ArrayList<>();
		listaLotes.add(new IdLoteNombre("L201811210848372", "NombreLote1"));
		listaLotes.add(new IdLoteNombre("L201811210848373", "NombreLote2"));
		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(listaLotes);

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withServerError());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaRechazarLote());

		verify(autorizarHelperServiceImpl, times(1)).autorizarImpl(Mockito.any());
	}

	private AutorizarRequest generarEntradaRechazarLote() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"lotes\",\"accion\":\"rechazar\",\"listaIds\":[\"L201811210848372\",\"L201811210848373\"],\"numeroPagos\":4,\"montoTotal\":\"400.0\",\"respuestaVasco\":\"27982531\",\"nota\":\"pruebas nota Autorización\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}
	

	@Test
	public void AutorizarTest_AutorizarAR() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());
		
		
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess());
		
		AutorizarRequest autorizarRequest = generarEntradaAutorizarRA();
		
		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(autorizarRequest);

		assertEquals(salida.getStatus(), "OK");
		assertEquals(salida.getMessage(), "OK");
	}

	private AutorizarRequest generarEntradaAutorizarRA() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"ar\",\"accion\":\"autorizar\",\"listaIds\":[3270, 2580],\"numeroPagos\":5,\"montoTotal\":\"47884.0\",\"respuestaVasco\":\"28769341\",\"nota\":\"pruebas nota\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}
	
	@Test
	public void AutorizarTest_RechazarAR() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "N");
		when(appContext.getUserData()).thenReturn(datosUsuario);
		
		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());
		
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withServerError());

		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(generarEntradaRechazarAR());

		verify(autorizarHelperServiceImpl, times(1)).autorizarImpl(Mockito.any());
	}

	private AutorizarRequest generarEntradaRechazarAR() {
		ObjectMapper objectMapper = new ObjectMapper();	
		String peticion = "{\"tipo\":\"ar\",\"accion\":\"rechazar\",\"listaIds\":[3271,3272],\"numeroPagos\":5,\"montoTotal\":\"47884.0\",\"respuestaVasco\":\"28769341\",\"nota\":\"pruebas nota\",\"tokenBks\":\"1234\"}";
		AutorizarRequest entrada = null;
		try {
			entrada = objectMapper.readValue(peticion, AutorizarRequest.class);
		} catch (IOException e) {
		}
		return entrada;
	}


	private List<String> traducciones() {
		List<String> traducciones = new ArrayList<>();
		traducciones.add("Traduccion");
		return traducciones;
	}
	
	@Test
	public void autorizarImplTest() {
		// ********* CONTROL DE SEGURIDAD MOCK DEL METODO QUE OBTIENE EL USUARIO LOGADO *********
		Authentication authentication =  Mockito.mock(JwtAuthenticationToken.class);
		SecurityContext securityContext =  Mockito.mock(SecurityContext.class);
		JwtDetails detalles = Mockito.mock(JwtDetails.class);
		SecurityContextHolder.setContext(securityContext);
		when(securityContext.getAuthentication()).thenReturn(authentication);
		when(authentication.getDetails()).thenReturn(detalles);
		when (detalles.getUid()).thenReturn("USUARIO");

		when(autorizarHelperServiceImpl.autorizarImpl(Mockito.any())).thenCallRealMethod();
		
		// getPaisPago
		DatosFirmaHelperService datosFirmaHelperService = Mockito.mock(DatosFirmaHelperService.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "datosFirmaHelperService", datosFirmaHelperService);
		when(datosFirmaHelperService.getPaisPago(Mockito.anyString())).thenReturn("ES");
		
		// Mock appContext.getUserData()
		AppContext appContext = Mockito.mock(AppContext.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "appContext", appContext);
		DatosUsuario datosUsuario = new DatosUsuario("", "", "", "", "S");
		when(appContext.getUserData()).thenReturn(datosUsuario);
		
		// getDatosDigitosCuentaBenQuery
		List<DatosFirmaCuentaBenOut> listaCuenta = new ArrayList<>();
		DatosFirmaCuentaBenOut datosFirmaCuentaBenOut = new DatosFirmaCuentaBenOut();
		datosFirmaCuentaBenOut.setDigitosCuentaBen("1234564687897456");
		listaCuenta.add(datosFirmaCuentaBenOut);
		when(autorizarHelperServiceImpl.getDatosDigitosCuentaBenQuery(Mockito.anyString())).thenReturn(listaCuenta);


		// Servicio externo (listawarehouse)
		ListaWarehouseHelperServiceImpl listaWarehouseHelperService = Mockito.mock(ListaWarehouseHelperServiceImpl.class);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "listaWarehouseHelperService", listaWarehouseHelperService);
		when(listaWarehouseHelperService.traducirMulidi(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(traducciones());

		// BD
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "jdbcTemplate", jdbcTemplate);
		List<IdPagoNombreK> salidaPagos = new ArrayList<>();
		
		
		IdPagoNombre id1 = new IdPagoNombre();
		id1.setIdPago("SGP1811200000009" );
		id1.setRefCliente("RefCliente1");
		
		IdPagoNombre id2 = new IdPagoNombre();
		id2.setIdPago("SGP1811200000012" );
		id2.setRefCliente("RefCliente2");
		
		IdPagoNombreK idk1 = new IdPagoNombreK();
		idk1.setIdPagoNombre(id1);
		
		IdPagoNombreK idk2 = new IdPagoNombreK();
		idk2.setIdPagoNombre(id2);
		
		salidaPagos.add(idk1);
		salidaPagos.add(idk2);

		when(autorizarHelperServiceImpl.obtenerListaNombres(Mockito.anyString(), Mockito.any())).thenReturn(salidaPagos);

		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		ListenableFuture<ResponseEntity<Object>> responseEntity = mock(ListenableFuture.class);
		Mockito.when(restTemplatePost.exchange(Mockito.any(),Mockito.any(),Mockito.any(),ArgumentMatchers.eq(Object.class))).thenReturn(responseEntity);

		restTemplatePost=new AsyncRestTemplate();
		ApiRestTemplate apiRestTemplate = Mockito.mock(ApiRestTemplate.class);
		when(apiRestTemplate.getAsyncRestTemplate()).thenReturn(restTemplatePost);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiRestTemplate);
		
		MockRestServiceServer mockServer = MockRestServiceServer.createServer(restTemplatePost);
		mockServer.expect(method(HttpMethod.GET)).andRespond(withSuccess());
		
		AutorizarRequest request = new AutorizarRequest();
		request.setTipo("pagos");
		request.setAccion("");
		request.setNumeroPagos(1);
		List<String> listaIds = new ArrayList<>();
		listaIds.add("1236564");
		request.setListaIds(listaIds);
		

		// test con lista cuentas
		AutorizarResponse salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		
		// test con lista cuentas
		listaCuenta.get(0).setDigitosCuentaBen(null);
		salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		
		// test con una cuenta con 0
		listaCuenta.clear();
		datosFirmaCuentaBenOut.setDigitosCuentaBen("1234564687890123");
		listaCuenta.add(datosFirmaCuentaBenOut);
		salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		
		// Prueba con un pais no permitido
		when(datosFirmaHelperService.getPaisPago(Mockito.anyString())).thenReturn("ES");
		salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		
		// test sin lista cuentas
		listaCuenta.clear();
		salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		
		// test lista cuentas null
		listaCuenta = null;
		salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		
		// test numero pagos > 2
		request.setNumeroPagos(3);
		salida = autorizarHelperServiceImpl.autorizarImpl(request);
		assertEquals(salida.getStatus(), "KO");
		

	}
	
	@Test
	public void verificarFirmaVascoBksTest() {
		
		Mockito.doCallRealMethod().when(autorizarHelperServiceImpl).verificarFirmaVascoBks(Mockito.anyString(), Mockito.anyInt(), Mockito.any(), Mockito.anyString());
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		
		// ApiRestTemplate
		ApiRestTemplate apiMock = Mockito.mock(ApiRestTemplate.class);
		RestTemplate rest = new RestTemplate();
		Mockito.when(apiMock.getRestTemplate()).thenReturn(rest);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiMock);

		MockRestServiceServer mockServer = MockRestServiceServer.createServer(rest);
		mockServer.expect(method(HttpMethod.POST)).andRespond(withSuccess());

		
		autorizarHelperServiceImpl.verificarFirmaVascoBks("", 1, new BigDecimal("10"), "");
	}
	
	@Test
	public void verificarFirmaVascoBksStrTest() {
		
		Mockito.doCallRealMethod().when(autorizarHelperServiceImpl).verificarFirmaVascoStrBks(Mockito.anyString(), Mockito.anyInt(), Mockito.any(), Mockito.anyString());
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "urlBks", "http://wwww.any.com");
		
		// ApiRestTemplate
		ApiRestTemplate apiMock = Mockito.mock(ApiRestTemplate.class);
		RestTemplate rest = new RestTemplate();
		Mockito.when(apiMock.getRestTemplate()).thenReturn(rest);
		ReflectionTestUtils.setField(autorizarHelperServiceImpl, "apiRestTemplate", apiMock);

		MockRestServiceServer mockServer = MockRestServiceServer.createServer(rest);
		mockServer.expect(method(HttpMethod.POST)).andRespond(withSuccess());

		
		autorizarHelperServiceImpl.verificarFirmaVascoStrBks("", 1, new BigDecimal("10"), "");
	}


}
