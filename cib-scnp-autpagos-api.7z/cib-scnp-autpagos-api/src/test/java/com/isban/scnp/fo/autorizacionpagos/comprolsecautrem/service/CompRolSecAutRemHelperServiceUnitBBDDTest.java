package com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.h2.tools.Server;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isban.scnp.fo.autorizacionpagos.Application;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ArchivoPolitica;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.IdArchivoGrupoEmp;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRol;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.model.ObtArchivoSentRolFirmado;
import com.isban.scnp.fo.autorizacionpagos.comprolsecautrem.service.impl.CompRolSecAutRemServiceImpl;
import com.isban.scnp.fo.autorizacionpagos.listaarchivos.model.ArchivoAR;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@ActiveProfiles("test")
public class CompRolSecAutRemHelperServiceUnitBBDDTest {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private CompRolSecAutRemServiceImpl compRolSecAutRemServiceImpl;
	
	@Value("${schema_proc}")
    protected String schemaproc;
	
	@Before
	public void beforeCheckDatabase() throws SQLException {
		//Server webServer = Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082");
		Server webServer = Server.createTcpServer(); webServer.start();
		
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/CompRolSecAutRemSeed.sql"));
	}
	
	@After
	public void afterDeletaData() throws SQLException {
		// Comprobamos que estamos en la base de datos de TEST
		assertThat(jdbcTemplate.getDataSource().getConnection().getMetaData().getDriverName()).contains("H2 JDBC Driver");
		ScriptUtils.executeSqlScript(jdbcTemplate.getDataSource().getConnection(), new ClassPathResource("database/CompRolSecAutRemPurge.sql"));
	}
	
	@Test
	public void comprobarRolSecuenciaAutRA_OK () {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.comprobarRolSecuenciaAutRA(Mockito.anyString(), Mockito.anyInt(), Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtRolUsuario(Mockito.anyString())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario(Mockito.anyString(),  Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtArchivosSentRol(Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtArchivosSentRolFirmado(Mockito.anyInt(), Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> entrada = new ArrayList<>();
		ArchivoAR archivo1 = new ArchivoAR();
		archivo1.setIdArchivo(2186);
		ArchivoAR archivo2 = new ArchivoAR();
		archivo2.setIdArchivo(2187);
		ArchivoAR archivo3 = new ArchivoAR();
		archivo3.setIdArchivo(2185);
		ArchivoAR archivo4 = new ArchivoAR();
		archivo4.setIdArchivo(2192);
		entrada.add(archivo1);
		entrada.add(archivo2);
		entrada.add(archivo3);
		entrada.add(archivo4);	
		List<ArchivoPolitica> salida = compRolSecAutRemServiceImpl.comprobarRolSecuenciaAutRA("SGPdanice727718", 7, entrada);
		assertEquals(salida.size(), 4);
		
	}
	
	@Test
	public void comprobarRolSecuenciaAutRA_OK2 () {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.comprobarRolSecuenciaAutRA(Mockito.anyString(), Mockito.anyInt(), Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtRolUsuario(Mockito.anyString())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario(Mockito.anyString(),  Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtArchivosSentRol(Mockito.any())).thenCallRealMethod();
		when(compRolSecAutRemServiceImpl.obtArchivosSentRolFirmado(Mockito.anyInt(), Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> entrada = new ArrayList<>();
		ArchivoAR archivo1 = new ArchivoAR();
		archivo1.setIdArchivo(2186);
		ArchivoAR archivo2 = new ArchivoAR();
		archivo2.setIdArchivo(2187);
		ArchivoAR archivo3 = new ArchivoAR();
		archivo3.setIdArchivo(2185);
		ArchivoAR archivo4 = new ArchivoAR();
		archivo4.setIdArchivo(2192);
		entrada.add(archivo1);
		entrada.add(archivo2);
		entrada.add(archivo3);
		entrada.add(archivo4);	
		List<ArchivoPolitica> salida = compRolSecAutRemServiceImpl.comprobarRolSecuenciaAutRA("SGPdanice748145", 7, entrada);
		assertEquals(salida.size(), 3);
	}
	
	
	@Test
	public void obtArchivosSentRolFirmadoTestOK_Vacio() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosSentRolFirmado(Mockito.anyInt(), Mockito.any())).thenCallRealMethod();
		List<ObtArchivoSentRolFirmado> salida = compRolSecAutRemServiceImpl.obtArchivosSentRolFirmado(2, Arrays.asList(2186, 2187, 2185, 2192));
		assertTrue(salida.isEmpty());
	}
	
	@Test
	public void obtArchivosSentRolFirmadoTestOK() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosSentRolFirmado(Mockito.anyInt(), Mockito.any())).thenCallRealMethod();
		List<ObtArchivoSentRolFirmado> salida = compRolSecAutRemServiceImpl.obtArchivosSentRolFirmado(1, Arrays.asList(2140));
		assertTrue(!salida.isEmpty());
	}
	
	@Test
	public void obtArchivosSentRolTest_OK() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosSentRol(Mockito.any())).thenCallRealMethod();
		List<ObtArchivoSentRol> salida = compRolSecAutRemServiceImpl.obtArchivosSentRol(Arrays.asList(2186, 2187, 2185, 2192));
		assertEquals(salida.size(), 5);
	}
	
	public void obtArchivosSentRolTest_Vacio() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosSentRol(Mockito.any())).thenCallRealMethod();
		List<ObtArchivoSentRol> salida = compRolSecAutRemServiceImpl.obtArchivosSentRol(Arrays.asList(2140));
		assertEquals(salida.size(), 0);
	}
	
	public void obtArchivosSentRolTest_EntradaVacia() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosSentRol(Mockito.any())).thenCallRealMethod();
		List<ObtArchivoSentRol> salida = compRolSecAutRemServiceImpl.obtArchivosSentRol(Arrays.asList());
		assertEquals(salida.size(), 0);
	}
	
	@Test
	public void obtRolUsuarioTest() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtRolUsuario(Mockito.anyString())).thenCallRealMethod();
		int salida = compRolSecAutRemServiceImpl.obtRolUsuario("SGPdanice727718");
		assertEquals(salida, 1);
	}
	
	@Test
	public void obtRolUsuarioTest_Vacio() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtRolUsuario(Mockito.anyString())).thenCallRealMethod();
		int salida = compRolSecAutRemServiceImpl.obtRolUsuario("IDNOEXISTENTE");
		assertEquals(salida, 0);
	}
	
	@Test
	public void obtGrupoEmpArchivosTest() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> entrada = new ArrayList<>();
		ArchivoAR archivo1 = new ArchivoAR();
		archivo1.setIdArchivo(2186);
		ArchivoAR archivo2 = new ArchivoAR();
		archivo2.setIdArchivo(2187);
		ArchivoAR archivo3 = new ArchivoAR();
		archivo3.setIdArchivo(2185);
		ArchivoAR archivo4 = new ArchivoAR();
		archivo4.setIdArchivo(2192);
		entrada.add(archivo1);
		entrada.add(archivo2);
		entrada.add(archivo3);
		entrada.add(archivo4);	
		List<IdArchivoGrupoEmp> salida = compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(entrada);
		assertEquals(salida.size(), 4);
	}
	
	@Test
	public void obtGrupoEmpArchivosTest_Vacio() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(Mockito.any())).thenCallRealMethod();
		List<ArchivoAR> entrada = new ArrayList<>();
		List<IdArchivoGrupoEmp> salida = compRolSecAutRemServiceImpl.obtGrupoEmpArchivos(entrada);
		assertEquals(salida.size(), 0);
		
	}
	
	@Test
	public void obtArchivosFirmaOKUsuarioTest() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario(Mockito.anyString(),  Mockito.any())).thenCallRealMethod();
		List<Integer> salida = compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario("SGPgabrie114752", Arrays.asList(2140));
		assertEquals(salida.size(), 1);
	}
	
	@Test
	public void obtArchivosFirmaOKUsuarioTest_Vacio() {
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "jdbcTemplate", jdbcTemplate);
		ReflectionTestUtils.setField(compRolSecAutRemServiceImpl, "schemaproc", schemaproc);
		when(compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario(Mockito.anyString(),  Mockito.any())).thenCallRealMethod();
		List<Integer> salida = compRolSecAutRemServiceImpl.obtArchivosFirmaOKUsuario("SGPgabrie114752", Arrays.asList(2186, 2187, 2185, 2192));
		assertEquals(salida.size(), 0);
	}
}
